package edu.thu.ext.json;

import edu.thu.cache.ICacheManagement;
import edu.thu.cache.ResourceCacheLoader;
import edu.thu.config.AppConfig;
import edu.thu.core.IResource;
import edu.thu.core.IResourceObjectParser;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.util.Coercions;
import edu.thu.lang.exceptions.StdException;
import edu.thu.lang.util.JsonUtils;
import edu.thu.service.util.ContextHelper;
import java.util.Map;

public class JsonResource
  implements IResourceObjectParser<Map<String, Object>>, ICacheManagement<String>
{
  ResourceCacheLoader<Map<String, Object>> loader = new ResourceCacheLoader("json.", this);
  static JsonResource _resource = new JsonResource();
  public static final String DEFAULT_GROUP = "default";
  
  public static JsonResource getInstance()
  {
    return _resource;
  }
  
  public void clearCache()
  {
    this.loader.clearCache();
  }
  
  String getResourcePath(String paramString)
  {
    paramString = paramString.replace('.', '/');
    return "/_config/data/" + paramString + ".json";
  }
  
  public boolean isUseMapping()
  {
    return Coercions.toBoolean(AppConfig.getVar("global.use_key_map"), true);
  }
  
  Map<String, Object> load(String paramString)
  {
    return (Map)this.loader.getObject(getResourcePath(paramString));
  }
  
  public Object getObject(String paramString1, String paramString2)
  {
    if ((paramString1 == null) || (paramString2 == null)) {
      return null;
    }
    Map localMap = load(paramString1);
    if (localMap != null)
    {
      Object localObject = localMap.get(paramString2);
      if (localObject != null) {
        return localObject;
      }
    }
    if (!"default".equals(paramString1))
    {
      localMap = load("default");
      if (localMap != null) {
        return localMap.get(paramString2);
      }
    }
    return null;
  }
  
  public String getString(String paramString1, String paramString2)
  {
    Object localObject = getObject(paramString1, paramString2);
    return localObject == null ? paramString2 : localObject.toString();
  }
  
  public String guessGroup(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    int i = paramString.lastIndexOf('/');
    if (i >= 0) {
      paramString = paramString.substring(i + 1);
    }
    i = paramString.lastIndexOf('\\');
    if (i >= 0) {
      paramString = paramString.substring(i + 1);
    }
    i = paramString.indexOf('.');
    if (i >= 0) {
      paramString = paramString.substring(0, i);
    }
    return paramString;
  }
  
  public String m(String paramString1, String paramString2)
  {
    if (!isUseMapping()) {
      return paramString2;
    }
    return getString(guessGroup(paramString1), paramString2);
  }
  
  public String m(String paramString)
  {
    return m("default", paramString);
  }
  
  public Map<String, Object> parseFromResource(IResource paramIResource, boolean paramBoolean)
  {
    if (!paramIResource.exists()) {
      return null;
    }
    String str = ContextHelper.loadText(paramIResource.getPath());
    Object localObject = JsonUtils.getInstance().deserialize(str);
    if (!(localObject instanceof Map)) {
      throw Exceptions.code("json.CAN_err_json_not_map_format").param(paramIResource.getPath()).param(str);
    }
    return (Map)localObject;
  }
  
  public void removeCacheItem(String paramString)
  {
    this.loader.removeCacheItem(getResourcePath(paramString));
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\json\JsonResource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */