package edu.thu.ext.hsql;

import edu.thu.db.BaseDataSource;
import edu.thu.db.SQL;
import edu.thu.db.SqlBuilder;
import edu.thu.db.core.IJdbcTemplate;
import java.io.File;

public class HsqlManager
  extends AbstractDbManager
{
  boolean E = false;
  
  public HsqlManager() {}
  
  public HsqlManager(String paramString)
  {
    super(paramString);
  }
  
  protected BaseDataSource createDataSource(File paramFile)
  {
    if (!paramFile.exists()) {
      return null;
    }
    String str = paramFile.getAbsolutePath();
    try
    {
      BaseDataSource localBaseDataSource1 = DbManagerHelper.createMdbDs(str, "", "");
      DbManagerHelper.checkConnection(localBaseDataSource1);
      return localBaseDataSource1;
    }
    catch (Exception localException)
    {
      BaseDataSource localBaseDataSource2 = DbManagerHelper.createHqlDs(str, "sa", "");
      DbManagerHelper.checkConnection(localBaseDataSource2);
      return localBaseDataSource2;
    }
  }
  
  public void close()
  {
    if (this.E) {
      return;
    }
    if (jdbc() == null) {
      return;
    }
    try
    {
      jdbc().executeUpdate(SQL.begin().sql("shutdown").end());
      this.E = true;
    }
    catch (Exception localException) {}
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\hsql\HsqlManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */