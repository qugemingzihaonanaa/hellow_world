package edu.thu.ext.hsql;

import java.io.File;
import javax.sql.DataSource;

public abstract interface IDbManager
{
  public abstract void init();
  
  public abstract void close();
  
  public abstract void remove();
  
  public abstract DataSource getDataSource();
  
  public abstract File getAttachmentDir();
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\hsql\IDbManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */