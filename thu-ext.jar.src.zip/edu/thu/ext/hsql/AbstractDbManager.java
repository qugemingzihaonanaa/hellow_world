package edu.thu.ext.hsql;

import edu.thu.db.BaseDataSource;
import edu.thu.db.core.IJdbcTemplate;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.io.util.IoUtils;
import edu.thu.orm.dao.DaoProvider;
import edu.thu.util.FileUtils;
import edu.thu.vfs.IFile;
import edu.thu.vfs.IFileFilter;
import edu.thu.vfs.spi.local.LocalFile;
import edu.thu.vfs.spi.local.LocalFileSystem;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import javax.sql.DataSource;

public abstract class AbstractDbManager
  implements IDbManager
{
  File A;
  BaseDataSource D;
  IJdbcTemplate C;
  String B = "store.db";
  
  public AbstractDbManager() {}
  
  public AbstractDbManager(String paramString)
  {
    setDir(new File(paramString));
  }
  
  public void setDir(File paramFile)
  {
    this.A = paramFile;
  }
  
  public File getAttachmentDir()
  {
    return new File(this.A, "attachment");
  }
  
  public DataSource getDataSource()
  {
    return this.D;
  }
  
  public void _zipTo(File paramFile)
  {
    LocalFileSystem.getInstance().zipToFile(this.A.getAbsolutePath(), paramFile.getAbsolutePath(), new IFileFilter()
    {
      public boolean accept(IFile paramAnonymousIFile)
      {
        return !paramAnonymousIFile.getName().equals(".svn");
      }
    });
  }
  
  public void clearDir()
  {
    LocalFileSystem.getInstance().removeSub(this.A.getAbsolutePath());
  }
  
  public void _unzipFrom(File paramFile)
  {
    if (!this.A.exists()) {
      this.A.mkdirs();
    }
    LocalFileSystem.getInstance().unzipToDir(new LocalFile(paramFile), new LocalFile(this.A));
  }
  
  public void _unzipToFile(ZipInputStream paramZipInputStream, ZipEntry paramZipEntry, String paramString)
  {
    Object localObject1 = null;
    try
    {
      String str = paramZipEntry.getName();
      if ((str.endsWith("/")) || (str.endsWith("\\"))) {
        return;
      }
      File localFile = new File(paramString + str);
      FileUtils.assureParentExists(localFile);
      localObject1 = new FileOutputStream(paramString + str);
      IoUtils.copy(paramZipInputStream, (OutputStream)localObject1);
      ((FileOutputStream)localObject1).flush();
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
    finally
    {
      IoUtils.safeClose((OutputStream)localObject1);
    }
    IoUtils.safeClose((OutputStream)localObject1);
  }
  
  public String getDbFileName()
  {
    return this.B;
  }
  
  public void setDbFileName(String paramString)
  {
    this.B = paramString;
  }
  
  public void init()
  {
    this.A.mkdirs();
    this.D = createDataSource(new File(this.A, getDbFileName()));
    this.C = (this.D == null ? null : DaoProvider.jdbc(this.D));
  }
  
  public IJdbcTemplate jdbc()
  {
    return this.C;
  }
  
  public abstract void close();
  
  public void removeDir()
  {
    FileUtils.remove(this.A);
  }
  
  public void closeAndRemove()
  {
    try
    {
      close();
    }
    catch (Exception localException) {}
    removeDir();
  }
  
  public void remove()
  {
    removeDir();
  }
  
  protected abstract BaseDataSource createDataSource(File paramFile);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\hsql\AbstractDbManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */