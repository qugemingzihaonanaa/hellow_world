package edu.thu.ext.hsql;

import edu.thu.db.BaseDataSource;
import edu.thu.global.exceptions.Exceptions;
import java.io.File;

public class AccessManager
  extends AbstractDbManager
{
  public BaseDataSource createDataSource(File paramFile)
  {
    try
    {
      Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw Exceptions.source(localClassNotFoundException);
    }
    BaseDataSource localBaseDataSource = new BaseDataSource();
    localBaseDataSource.setUrl("jdbc:odbc:driver={Microsoft Access Driver (*.mdb)};DBQ=" + paramFile.getAbsolutePath());
    localBaseDataSource.setUsername("");
    localBaseDataSource.setPassword("");
    return localBaseDataSource;
  }
  
  public void close() {}
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\hsql\AccessManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */