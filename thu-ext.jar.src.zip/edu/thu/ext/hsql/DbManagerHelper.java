package edu.thu.ext.hsql;

import edu.thu.db.BaseDataSource;
import edu.thu.global.exceptions.Exceptions;

public class DbManagerHelper
{
  /* Error */
  public static void checkConnection(javax.sql.DataSource paramDataSource)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: aload_0
    //   3: invokeinterface 16 1 0
    //   8: astore_1
    //   9: goto +27 -> 36
    //   12: astore_2
    //   13: aload_2
    //   14: invokestatic 22	edu/thu/global/exceptions/Exceptions:source	(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;
    //   17: athrow
    //   18: astore_3
    //   19: aload_1
    //   20: ifnull +14 -> 34
    //   23: aload_1
    //   24: invokeinterface 28 1 0
    //   29: goto +5 -> 34
    //   32: astore 4
    //   34: aload_3
    //   35: athrow
    //   36: aload_1
    //   37: ifnull +14 -> 51
    //   40: aload_1
    //   41: invokeinterface 28 1 0
    //   46: goto +5 -> 51
    //   49: astore 4
    //   51: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	52	0	paramDataSource	javax.sql.DataSource
    //   1	40	1	localConnection	java.sql.Connection
    //   12	2	2	localSQLException	java.sql.SQLException
    //   18	17	3	localObject	Object
    //   32	1	4	localException1	Exception
    //   49	1	4	localException2	Exception
    // Exception table:
    //   from	to	target	type
    //   2	9	12	java/sql/SQLException
    //   2	18	18	finally
    //   23	29	32	java/lang/Exception
    //   40	46	49	java/lang/Exception
  }
  
  public static BaseDataSource createHqlDs(String paramString1, String paramString2, String paramString3)
  {
    try
    {
      Class.forName("org.hsqldb.jdbcDriver");
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
    BaseDataSource localBaseDataSource = new BaseDataSource();
    localBaseDataSource.setUrl("jdbc:hsqldb:file:" + paramString1 + ";ifexists=true");
    localBaseDataSource.setUsername(paramString2);
    localBaseDataSource.setPassword(paramString3);
    return localBaseDataSource;
  }
  
  public static BaseDataSource createMdbDs(String paramString1, String paramString2, String paramString3)
  {
    return createMdbDs(paramString1, paramString2, paramString3, "edu.thu.ext.hsql.WrapJdbcOdbcDriver");
  }
  
  public static BaseDataSource createMdbDs(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    if (paramString4 == null) {
      paramString4 = "sun.jdbc.odbc.JdbcOdbcDriver";
    }
    try
    {
      Class.forName(paramString4);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      throw Exceptions.source(localClassNotFoundException);
    }
    BaseDataSource localBaseDataSource = new BaseDataSource();
    localBaseDataSource.setUrl("jdbc:odbc:driver={Microsoft Access Driver (*.mdb)};DBQ=" + paramString1);
    localBaseDataSource.setUsername(paramString2);
    localBaseDataSource.setPassword(paramString3);
    return localBaseDataSource;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\hsql\DbManagerHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */