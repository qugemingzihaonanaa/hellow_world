package edu.thu.ext.freemarker;

import edu.thu.lang.util.ITplReference;
import edu.thu.lang.util.TplC;
import edu.thu.service.IServiceContext;
import java.util.HashMap;
import java.util.Map;

public class TplWrapper
{
  ITplReference B;
  IServiceContext C;
  TplC D;
  Map A;
  
  public TplWrapper(ITplReference paramITplReference, Map paramMap, IServiceContext paramIServiceContext)
  {
    this.B = paramITplReference;
    this.C = paramIServiceContext;
    this.A = paramMap;
    this.D = TplC.newWebTplC();
  }
  
  public String generate()
  {
    if (this.B == null) {
      return "";
    }
    return TplC.getTplOut(this.B, this.A, this.C);
  }
  
  public String generate(String paramString)
  {
    if (this.B == null) {
      return "";
    }
    if (this.A == null) {
      this.A = new HashMap(1);
    }
    this.A.put("name", paramString);
    return TplC.getTplOut(this.B, this.A, this.C);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\freemarker\TplWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */