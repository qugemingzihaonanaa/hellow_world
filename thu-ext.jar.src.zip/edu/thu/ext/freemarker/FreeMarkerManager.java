package edu.thu.ext.freemarker;

import edu.thu.config.AppConfig;
import edu.thu.core.AppEnv;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.web.WebContext;
import freemarker.cache.TemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;
import java.io.File;
import java.io.PrintStream;
import java.io.Reader;
import java.io.StringReader;
import java.io.Writer;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class FreeMarkerManager
{
  static Log D = LogFactory.getLog(FreeMarkerManager.class);
  Configuration C;
  File E;
  TemplateLoader A;
  boolean B;
  
  public static FreeMarkerManager newInstance(File paramFile)
  {
    FreeMarkerManager localFreeMarkerManager = new FreeMarkerManager();
    localFreeMarkerManager.setRootPath(paramFile);
    localFreeMarkerManager.afterPropertiesSet();
    return localFreeMarkerManager;
  }
  
  public static FreeMarkerManager newInstance()
  {
    return newInstance(new File(AppConfig.getRootPath()));
  }
  
  public void setRootPath(File paramFile)
  {
    this.E = paramFile;
  }
  
  public void setUseCache(boolean paramBoolean)
  {
    this.B = paramBoolean;
  }
  
  public void setTemplateLoader(TemplateLoader paramTemplateLoader)
  {
    this.A = paramTemplateLoader;
  }
  
  public void setConfiguration(Configuration paramConfiguration)
  {
    if (this.C != null) {
      throw Exceptions.code("freemarker.err_reset_configuration");
    }
    if (paramConfiguration == null) {
      throw Exceptions.code("freemarker.err_set_null_configuration");
    }
    this.C = paramConfiguration;
  }
  
  /* Error */
  public void generateToFile(String paramString, Map paramMap, File paramFile)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 4
    //   3: aload_3
    //   4: invokestatic 85	edu/thu/util/FileUtils:getWriter	(Ljava/io/File;)Ljava/io/Writer;
    //   7: astore 4
    //   9: aload_0
    //   10: aload_1
    //   11: aload_2
    //   12: aload 4
    //   14: invokevirtual 91	edu/thu/ext/freemarker/FreeMarkerManager:generate	(Ljava/lang/String;Ljava/util/Map;Ljava/io/Writer;)V
    //   17: aload 4
    //   19: invokevirtual 95	java/io/Writer:flush	()V
    //   22: goto +21 -> 43
    //   25: astore 5
    //   27: aload 5
    //   29: invokestatic 100	edu/thu/global/exceptions/Exceptions:source	(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;
    //   32: athrow
    //   33: astore 6
    //   35: aload 4
    //   37: invokestatic 104	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/Writer;)V
    //   40: aload 6
    //   42: athrow
    //   43: aload 4
    //   45: invokestatic 104	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/Writer;)V
    //   48: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	49	0	this	FreeMarkerManager
    //   0	49	1	paramString	String
    //   0	49	2	paramMap	Map
    //   0	49	3	paramFile	File
    //   1	43	4	localWriter	Writer
    //   25	3	5	localException	Exception
    //   33	8	6	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   3	22	25	java/lang/Exception
    //   3	33	33	finally
  }
  
  public void generate(String paramString, Map paramMap, Writer paramWriter)
  {
    try
    {
      if (!this.B) {
        this.C.clearTemplateCache();
      }
      Template localTemplate = this.C.getTemplate(paramString);
      long l1 = AppEnv.currentTimeMillis();
      localTemplate.process(paramMap, paramWriter);
      long l2 = AppEnv.currentTimeMillis();
      System.out.println("process_time:" + (l2 - l1) + "ms");
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public Template compile(String paramString)
  {
    try
    {
      return new Template("/temp.ftl", new StringReader(paramString), this.C);
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public void generate(Reader paramReader, Map paramMap, Writer paramWriter)
  {
    try
    {
      new Template("/temp.ftl", paramReader, this.C).process(paramMap, paramWriter);
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  Map A(HttpServletRequest paramHttpServletRequest)
  {
    Enumeration localEnumeration = paramHttpServletRequest.getAttributeNames();
    HashMap localHashMap = new HashMap();
    while (localEnumeration.hasMoreElements())
    {
      Object localObject = localEnumeration.nextElement();
      localHashMap.put(localObject, paramHttpServletRequest.getAttribute((String)localObject));
    }
    localHashMap.put("contextPath", paramHttpServletRequest.getContextPath());
    localHashMap.put("request", paramHttpServletRequest);
    return localHashMap;
  }
  
  @PostConstruct
  public void afterPropertiesSet()
  {
    if (this.C == null)
    {
      this.C = new Configuration();
      this.C.setLocalizedLookup(false);
    }
    if (this.A != null) {
      this.C.setTemplateLoader(this.A);
    } else if (this.E != null) {
      try
      {
        this.C.setDirectoryForTemplateLoading(this.E);
      }
      catch (Exception localException)
      {
        throw Exceptions.source(localException);
      }
    } else {
      throw Exceptions.code("freemarker.err_no_template_loader");
    }
  }
  
  public void render(String paramString, Map paramMap, WebContext paramWebContext)
  {
    Object localObject = A(paramWebContext.getServletRequest());
    if (localObject == null) {
      localObject = new HashMap();
    }
    if (paramMap != null) {
      ((Map)localObject).putAll(paramMap);
    }
    ((Map)localObject).put("thisObj", paramWebContext.getThisObj());
    ((Map)localObject).put("$out", paramWebContext.getOut());
    ((Map)localObject).put("$context", paramWebContext);
    generate(paramString, (Map)localObject, paramWebContext.getOut());
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\freemarker\FreeMarkerManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */