package edu.thu.ext.freemarker;

import freemarker.cache.TemplateLoader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import javax.servlet.ServletContext;

public class ServletContextTemplateLoader
  implements TemplateLoader
{
  ServletContext context;
  
  public ServletContextTemplateLoader(ServletContext paramServletContext)
  {
    this.context = paramServletContext;
  }
  
  public void closeTemplateSource(Object paramObject)
    throws IOException
  {}
  
  public Object findTemplateSource(String paramString)
    throws IOException
  {
    return paramString;
  }
  
  public long getLastModified(Object paramObject)
  {
    try
    {
      URL localURL = this.context.getResource((String)paramObject);
      if (localURL == null) {
        return 0L;
      }
      if (localURL.getProtocol().equals("file")) {
        return new File(localURL.getFile()).lastModified();
      }
      return 0L;
    }
    catch (Exception localException) {}
    return 0L;
  }
  
  public Reader getReader(Object paramObject, String paramString)
    throws IOException
  {
    if (paramString == null) {
      paramString = System.getProperty("file.encoding");
    }
    return new InputStreamReader(this.context.getResourceAsStream((String)paramObject), paramString);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\freemarker\ServletContextTemplateLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */