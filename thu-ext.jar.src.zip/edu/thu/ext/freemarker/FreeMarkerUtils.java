package edu.thu.ext.freemarker;

import edu.thu.global.exceptions.Exceptions;
import freemarker.ext.beans.BeansWrapper;
import freemarker.template.TemplateException;
import freemarker.template.TemplateHashModel;

public class FreeMarkerUtils
{
  public static TemplateHashModel getStaticModel(String paramString)
  {
    BeansWrapper localBeansWrapper = BeansWrapper.getDefaultInstance();
    TemplateHashModel localTemplateHashModel = localBeansWrapper.getStaticModels();
    try
    {
      return (TemplateHashModel)localTemplateHashModel.get(paramString);
    }
    catch (TemplateException localTemplateException)
    {
      throw Exceptions.source(localTemplateException);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\freemarker\FreeMarkerUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */