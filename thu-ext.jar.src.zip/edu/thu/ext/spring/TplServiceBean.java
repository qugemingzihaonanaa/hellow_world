package edu.thu.ext.spring;

import edu.thu.config.AppConfig;
import edu.thu.java.util.Coercions;
import edu.thu.lang.util.ITplReference;
import edu.thu.lang.util.TplC;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceCall;
import edu.thu.service.IServiceContext;
import edu.thu.service.SystemServiceContext;
import java.util.Map;

public class TplServiceBean
  implements IServiceCall
{
  private static final long serialVersionUID = 5052622678541470873L;
  String namespace;
  String tagName;
  String libPath;
  ITplReference tpl;
  
  public String getLibPath()
  {
    return this.libPath;
  }
  
  public void setLibPath(String paramString)
  {
    this.libPath = paramString;
  }
  
  public String getNamespace()
  {
    return this.namespace;
  }
  
  public void setNamespace(String paramString)
  {
    this.namespace = paramString;
  }
  
  public String getTagName()
  {
    return this.tagName;
  }
  
  public void setTagName(String paramString)
  {
    this.tagName = paramString;
  }
  
  boolean isUseCache()
  {
    return Coercions.toBoolean(AppConfig.getVar("web.tpl.use_cache"), false);
  }
  
  public Object invoke(Map<String, Object> paramMap, IServiceContext paramIServiceContext)
  {
    ITplReference localITplReference = this.tpl;
    if ((localITplReference == null) || (!isUseCache()))
    {
      TreeNode localTreeNode1 = TreeNode.make("c:div");
      TreeNode localTreeNode2 = TreeNode.make("c:lib");
      localTreeNode2.setAttribute("namespace", this.namespace);
      localTreeNode2.setAttribute("src", this.libPath);
      localTreeNode1.appendChild(localTreeNode2);
      TreeNode localTreeNode3 = TreeNode.make(this.namespace + ":" + this.tagName);
      localTreeNode1.appendChild(localTreeNode3);
      TplC localTplC = new TplC();
      localITplReference = localTplC.compileBody(localTreeNode1, null, SystemServiceContext.getInstance());
    }
    this.tpl = localITplReference;
    return TplC.runTpl(localITplReference, paramMap, paramIServiceContext);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\spring\TplServiceBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */