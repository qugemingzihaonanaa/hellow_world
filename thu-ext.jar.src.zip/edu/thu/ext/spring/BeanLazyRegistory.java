package edu.thu.ext.spring;

import edu.thu.lang.reflect.BeanInstance;
import edu.thu.service.BeanLoader;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class BeanLazyRegistory
{
  Map<String, String> A;
  
  public void setItems(Map<String, String> paramMap)
  {
    this.A = paramMap;
  }
  
  public void init()
  {
    if (this.A == null) {
      return;
    }
    BeanLazyInitializer localBeanLazyInitializer = (BeanLazyInitializer)BeanLoader.getBean(BeanLazyInitializer.class);
    Iterator localIterator = this.A.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      String str1 = (String)localEntry.getKey();
      final String str2 = (String)localEntry.getValue();
      final Object localObject = BeanLoader.getBean(str1);
      localBeanLazyInitializer.add(new Runnable()
      {
        public void run()
        {
          BeanInstance localBeanInstance = new BeanInstance(localObject);
          localBeanInstance.invokeExactMethod(str2, new Object[0]);
        }
      });
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\spring\BeanLazyRegistory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */