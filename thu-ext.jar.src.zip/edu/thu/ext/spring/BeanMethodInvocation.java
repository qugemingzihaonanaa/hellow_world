package edu.thu.ext.spring;

import edu.thu.lang.reflect.BeanInstance;

public class BeanMethodInvocation
  implements Runnable
{
  Object A;
  String B;
  
  public void setBean(Object paramObject)
  {
    this.A = paramObject;
  }
  
  public void setMethod(String paramString)
  {
    this.B = paramString;
  }
  
  public void run()
  {
    BeanInstance localBeanInstance = new BeanInstance(this.A);
    localBeanInstance.invokeExactMethod(this.B, new Object[0]);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\spring\BeanMethodInvocation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */