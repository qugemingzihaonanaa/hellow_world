package edu.thu.ext.spring;

import edu.thu.core.IResource;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.aop.IBeanProxy;
import edu.thu.java.aop.IDynamicBean;
import edu.thu.lang.exceptions.StdException;
import edu.thu.lang.util.TplC;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceCall;
import edu.thu.service.SystemServiceContext;
import edu.thu.service.bean.interfaces.IFactoryBean;
import edu.thu.service.util.ContextHelper;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class TplFactoryBean
  implements IFactoryBean<Object>
{
  boolean singleton = true;
  Class<?> objectType = Object.class;
  Map<String, Object> properties;
  String src;
  IServiceCall builder;
  Object object;
  
  public void setSrc(String paramString)
  {
    this.src = paramString;
  }
  
  public void setProperties(Map<String, Object> paramMap)
  {
    this.properties = paramMap;
  }
  
  public void setSingleton(boolean paramBoolean)
  {
    this.singleton = paramBoolean;
  }
  
  public void setObjectType(Class<?> paramClass)
  {
    this.objectType = paramClass;
  }
  
  public Class<?> getObjectType()
  {
    return this.objectType;
  }
  
  public boolean isSingleton()
  {
    return this.singleton;
  }
  
  public Object getObject()
    throws Exception
  {
    if ((this.object != null) && (!this.singleton)) {
      return this.object;
    }
    this.object = buildObject();
    return this.object;
  }
  
  Object buildObject()
  {
    HashMap localHashMap = new HashMap();
    Object localObject = this.builder.invoke(localHashMap, SystemServiceContext.getInstance());
    if (!(localObject instanceof IBeanProxy)) {
      throw Exceptions.code("bean.CAN_err_not_bean_proxy").param(localObject).param(this.src);
    }
    if (this.properties != null)
    {
      IDynamicBean localIDynamicBean = ((IBeanProxy)localObject).getDynamicBean();
      Iterator localIterator = this.properties.keySet().iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        localIDynamicBean.setProperty(str, this.properties.get(str));
      }
    }
    return localObject;
  }
  
  public void refresh()
  {
    try
    {
      Object localObject = null;
      IResource localIResource = ContextHelper.getCustomizableResource(this.src);
      if (!localIResource.exists())
      {
        localObject = ContextHelper.loadCustomizableCpObject(this.src);
      }
      else
      {
        TreeNode localTreeNode = ContextHelper.loadXml(localIResource.getPath());
        localObject = new TplC().compileBody(localTreeNode, null, SystemServiceContext.getInstance());
      }
      if (localObject == null) {
        throw Exceptions.code("bean.CAN_err_tpl_bean_null_src").param(this.src);
      }
      this.builder = TplC.toServiceCall(localObject);
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public void afterPropertiesSet()
  {
    refresh();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\spring\TplFactoryBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */