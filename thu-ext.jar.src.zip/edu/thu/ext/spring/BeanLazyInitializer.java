package edu.thu.ext.spring;

import edu.thu.service.util.TaskList;

public class BeanLazyInitializer
  extends TaskList
{}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\spring\BeanLazyInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */