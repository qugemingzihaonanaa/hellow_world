package edu.thu.ext.hibernate;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.util.ITypeConverter;
import edu.thu.orm.OrmEntity;
import edu.thu.orm.dao.IOrmTemplate;
import java.io.Serializable;

public class EntityTypeConverter
  implements ITypeConverter
{
  IOrmTemplate ormTemplate;
  
  public void setOrmTemplate(IOrmTemplate paramIOrmTemplate)
  {
    this.ormTemplate = paramIOrmTemplate;
  }
  
  public boolean canHandle(String paramString, Class paramClass)
  {
    return OrmEntity.class.isAssignableFrom(paramClass);
  }
  
  public Object convert(String paramString, Class paramClass, Object paramObject)
  {
    if (paramObject == null) {
      return null;
    }
    if ((paramObject instanceof String))
    {
      String str = (String)paramObject;
      if (str.length() <= 0) {
        return null;
      }
    }
    if (!(paramObject instanceof Serializable)) {
      throw Exceptions.code("ds.err_not_entity_id").param(paramObject);
    }
    return this.ormTemplate.load(paramClass.getName(), (Serializable)paramObject);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\hibernate\EntityTypeConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */