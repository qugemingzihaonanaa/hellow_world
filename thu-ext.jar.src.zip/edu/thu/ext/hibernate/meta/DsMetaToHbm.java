package edu.thu.ext.hibernate.meta;

import edu.thu.model.stg.ds.spi.DsConstants;
import edu.thu.util.FileUtils;
import edu.thu.xml.dom4j.Dom4jUtils;
import java.io.File;
import java.util.List;
import org.dom4j.Element;

public class DsMetaToHbm
  implements DsConstants
{
  public Element transform(Element paramElement)
  {
    Element localElement1 = Dom4jUtils.createElement("class");
    String str1 = paramElement.elementText("entityName");
    String str2 = paramElement.elementText("entityClass");
    localElement1.addAttribute("name", str2 != null ? str2 : str1);
    Element localElement2 = paramElement.element("provider");
    if (localElement2 == null) {
      return null;
    }
    String str3 = localElement2.elementText("table");
    if (str3 == null) {
      return null;
    }
    localElement1.addAttribute("table", str3);
    String str4 = paramElement.elementText("pkField");
    if (str4 == null) {
      return null;
    }
    Element localElement3 = localElement1.addElement("id");
    List localList = paramElement.element("fields").elements();
    int j = localList.size();
    for (int i = 0; i < j; i++)
    {
      Element localElement4 = (Element)localList.get(i);
      String str5 = localElement4.attributeValue("name");
      String str6 = localElement4.attributeValue("baseName");
      if (str6 == null) {
        str6 = str5;
      }
      String str7 = localElement4.elementText("storeType");
      if (str7 == null) {
        str7 = localElement4.elementText("type");
      }
      String str8 = localElement4.elementText("storeSize");
      if (str8 == null) {
        str8 = localElement4.elementText("size");
      }
      Element localElement5;
      if (str5.equals(str4)) {
        localElement5 = localElement3;
      } else {
        localElement5 = localElement1.addElement("property");
      }
      localElement5.addAttribute("name", str5);
      localElement5.addAttribute("column", str6);
      localElement5.addAttribute("type", str7);
      if ("string".equals(str7)) {
        localElement5.addAttribute("length", str8);
      }
    }
    return localElement1;
  }
  
  public void transform(File paramFile1, File paramFile2)
  {
    Element localElement1 = Dom4jUtils.load(paramFile1);
    Element localElement2 = transform(localElement1);
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<?xml version='1.0' encoding='gb2312'?>\r\n").append("<!DOCTYPE hibernate-mapping PUBLIC '-//Hibernate/Hibernate Mapping DTD 3.0//EN' 'http://hibernate.sourceforge.net/hibernate-mapping-3.0.dtd' >\r\n").append(Dom4jUtils.getPrettyXml(localElement2));
    FileUtils.save(paramFile2, localStringBuffer.toString());
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\hibernate\meta\DsMetaToHbm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */