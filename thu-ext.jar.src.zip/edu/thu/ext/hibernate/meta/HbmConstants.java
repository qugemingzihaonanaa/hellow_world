package edu.thu.ext.hibernate.meta;

public abstract interface HbmConstants
{
  public static final String HIBERNATE_MAPPING_NAME = "hibernate-mapping";
  public static final String PACKAGE_NAME = "package";
  public static final String META_NAME = "meta";
  public static final String ATTRIBUTE_NAME = "attribute";
  public static final String CLASS_NAME = "class";
  public static final String PROPERTY_NAME = "property";
  public static final String ENTITY_NAME_NAME = "entity-name";
  public static final String NAME_NAME = "name";
  public static final String ID_NAME = "id";
  public static final String COLUMN_NAME = "column";
  public static final String TABLE_NAME = "table";
  public static final String MANY_TO_ONE_NAME = "many-to-one";
  public static final String ONE_TO_ONE_NAME = "one-to-one";
  public static final String ONE_TO_MANY_NAME = "one-to-many";
  public static final String MANY_TO_MANY_NAME = "many-to-many";
  public static final String TYPE_NAME = "type";
  public static final String LENGTH_NAME = "length";
  public static final String COMPOSITE_ID_NAME = "composite-id";
  public static final String NOT_NULL_NAME = "not-null";
  public static final String FORMULA_NAME = "formula";
  public static final String PRECISION_NAME = "precision";
  public static final String SCALE_NAME = "scale";
  public static final String UNIQUE_NAME = "unique";
  public static final String UPDATE_NAME = "update";
  public static final String INSERT_NAME = "insert";
  public static final String CASCADE_NAME = "cascade";
  public static final String ANY_NAME = "any";
  public static final String COMPONENT_NAME = "component";
  public static final String DYNAMIC_COMPONENT_NAME = "dynamic-component";
  public static final String GENERATOR_NAME = "generator";
  public static final String TYPE_INTEGER = "integer";
  public static final String TYPE_DOUBLE = "double";
  public static final String TYPE_LONG = "long";
  public static final String TYPE_STRING = "string";
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\hibernate\meta\HbmConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */