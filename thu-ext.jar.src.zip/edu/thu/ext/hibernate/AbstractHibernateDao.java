package edu.thu.ext.hibernate;

import edu.thu.orm.dao.AbstractOrmDao;

public abstract class AbstractHibernateDao
  extends AbstractOrmDao
{
  public void afterPropertiesSet() {}
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\hibernate\AbstractHibernateDao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */