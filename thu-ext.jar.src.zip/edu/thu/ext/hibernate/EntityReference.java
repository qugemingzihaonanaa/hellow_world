package edu.thu.ext.hibernate;

import edu.thu.global.Debug;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.IReference;
import edu.thu.service.EntityManager;
import edu.thu.service.IEntityManager;
import java.io.Serializable;

public class EntityReference
  implements Serializable, IReference
{
  private static final long serialVersionUID = -7520720399327314420L;
  Object id;
  String entityName;
  
  public EntityReference(String paramString, Object paramObject)
  {
    Debug.check(paramString);
    Debug.check(paramObject);
    this.entityName = paramString;
    this.id = paramObject;
  }
  
  public Object getValue()
  {
    return EntityManager.getInstance().get(this.entityName, this.id);
  }
  
  public void setValue(Object paramObject)
  {
    throw Exceptions.notAllowed();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\hibernate\EntityReference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */