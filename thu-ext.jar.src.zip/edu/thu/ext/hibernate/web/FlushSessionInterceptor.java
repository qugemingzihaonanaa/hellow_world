package edu.thu.ext.hibernate.web;

import edu.thu.lang.aop.MethodInterceptorBase;
import edu.thu.orm.dao.IOrmTemplate;
import org.aopalliance.intercept.MethodInvocation;

public class FlushSessionInterceptor
  extends MethodInterceptorBase
{
  IOrmTemplate ormTemplate;
  
  public void setOrmTemplate(IOrmTemplate paramIOrmTemplate)
  {
    this.ormTemplate = paramIOrmTemplate;
  }
  
  public Object invoke(MethodInvocation paramMethodInvocation)
    throws Throwable
  {
    Object localObject = paramMethodInvocation.proceed();
    this.ormTemplate.flushSession();
    return localObject;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\hibernate\web\FlushSessionInterceptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */