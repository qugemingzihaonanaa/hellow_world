package edu.thu.ext.hibernate;

import edu.thu.global.exceptions.Exceptions;
import edu.thu.io.util.IoUtils;
import edu.thu.model.stg.IBinaryStreamMoniker;
import edu.thu.text.TextCoder;
import edu.thu.util.UrlUtils;
import edu.thu.vfs.FileSystem;
import edu.thu.vfs.IFile;
import edu.thu.vfs.spi.local.LocalFile;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FileItem
  implements Serializable
{
  private static final long serialVersionUID = -1913184939441645569L;
  String A;
  String G;
  String D = TextCoder.getDefaultCharacterEncoding();
  IBinaryStreamMoniker C;
  boolean E;
  String B;
  String F;
  
  public FileItem(String paramString, IBinaryStreamMoniker paramIBinaryStreamMoniker)
  {
    setFileId(paramString);
    this.G = this.A;
    this.C = paramIBinaryStreamMoniker;
  }
  
  public FileItem(String paramString1, String paramString2, IBinaryStreamMoniker paramIBinaryStreamMoniker)
  {
    setFileId(paramString1);
    this.G = paramString2;
    this.C = paramIBinaryStreamMoniker;
  }
  
  public String getCacheKey()
  {
    return this.F;
  }
  
  public void setCacheKey(String paramString)
  {
    this.F = paramString;
  }
  
  public String getUpdaterId()
  {
    return this.B;
  }
  
  public void setUpdaterId(String paramString)
  {
    this.B = paramString;
  }
  
  public boolean isEncoded()
  {
    return this.E;
  }
  
  public void setEncoded(boolean paramBoolean)
  {
    this.E = paramBoolean;
  }
  
  public FileItem copy()
  {
    FileItem localFileItem = new FileItem(this.A, this.G, this.C);
    localFileItem.D = this.D;
    localFileItem.E = this.E;
    return localFileItem;
  }
  
  public boolean exists()
  {
    if ((this.C instanceof IFile)) {
      return ((IFile)this.C).exists();
    }
    return true;
  }
  
  public IFile getFile()
  {
    if ((this.C instanceof IFile)) {
      return (IFile)this.C;
    }
    return null;
  }
  
  public String getEncoding()
  {
    return this.D;
  }
  
  public void setEncoding(String paramString)
  {
    this.D = paramString;
  }
  
  public InputStream getInputStream()
  {
    if (this.C == null) {
      return null;
    }
    return this.C.getInputStream();
  }
  
  public byte[] loadBytes()
  {
    InputStream localInputStream = getInputStream();
    if (localInputStream == null) {
      return null;
    }
    try
    {
      byte[] arrayOfByte = IoUtils.toByteArray(localInputStream);
      return arrayOfByte;
    }
    finally
    {
      IoUtils.safeClose(localInputStream);
    }
  }
  
  public void saveToFile(File paramFile)
  {
    saveTo(new LocalFile(paramFile));
  }
  
  public void saveToDir(File paramFile)
  {
    saveToFile(new File(paramFile, this.A));
  }
  
  public void copyFromFile(File paramFile)
  {
    if (this.C == null) {
      return;
    }
    IFile localIFile = (IFile)this.C;
    new LocalFile(paramFile).copyTo(localIFile);
  }
  
  /* Error */
  public void saveTo(IFile paramIFile)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 44	edu/thu/ext/hibernate/FileItem:C	Ledu/thu/model/stg/IBinaryStreamMoniker;
    //   4: ifnonnull +11 -> 15
    //   7: aload_1
    //   8: invokeinterface 132 1 0
    //   13: pop
    //   14: return
    //   15: aload_1
    //   16: invokeinterface 135 1 0
    //   21: astore_2
    //   22: aload_2
    //   23: ifnull +10 -> 33
    //   26: aload_2
    //   27: invokeinterface 138 1 0
    //   32: pop
    //   33: aload_1
    //   34: invokeinterface 141 1 0
    //   39: checkcast 145	edu/thu/vfs/FileSystem
    //   42: astore_3
    //   43: aload_0
    //   44: aload_1
    //   45: invokevirtual 147	edu/thu/ext/hibernate/FileItem:A	(Ledu/thu/vfs/IFile;)V
    //   48: aload_3
    //   49: aload_1
    //   50: invokevirtual 150	edu/thu/vfs/FileSystem:fireBeforeFileChange	(Ledu/thu/vfs/IFile;)V
    //   53: aload_1
    //   54: instanceof 107
    //   57: ifeq +22 -> 79
    //   60: aload_0
    //   61: getfield 44	edu/thu/ext/hibernate/FileItem:C	Ledu/thu/model/stg/IBinaryStreamMoniker;
    //   64: aload_1
    //   65: checkcast 107	edu/thu/vfs/spi/local/LocalFile
    //   68: invokevirtual 153	edu/thu/vfs/spi/local/LocalFile:getLocalFile	()Ljava/io/File;
    //   71: invokeinterface 157 2 0
    //   76: goto +70 -> 146
    //   79: aconst_null
    //   80: astore 4
    //   82: aload_1
    //   83: invokeinterface 159 1 0
    //   88: pop
    //   89: aconst_null
    //   90: astore 5
    //   92: aload_0
    //   93: getfield 44	edu/thu/ext/hibernate/FileItem:C	Ledu/thu/model/stg/IBinaryStreamMoniker;
    //   96: invokeinterface 82 1 0
    //   101: astore 4
    //   103: aload_1
    //   104: invokeinterface 162 1 0
    //   109: astore 5
    //   111: aload 4
    //   113: aload 5
    //   115: invokestatic 166	edu/thu/io/util/IoUtils:copy	(Ljava/io/InputStream;Ljava/io/OutputStream;)V
    //   118: goto +18 -> 136
    //   121: astore 6
    //   123: aload 4
    //   125: invokestatic 95	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/InputStream;)V
    //   128: aload 5
    //   130: invokestatic 169	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/OutputStream;)V
    //   133: aload 6
    //   135: athrow
    //   136: aload 4
    //   138: invokestatic 95	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/InputStream;)V
    //   141: aload 5
    //   143: invokestatic 169	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/OutputStream;)V
    //   146: aload_3
    //   147: aload_1
    //   148: invokevirtual 172	edu/thu/vfs/FileSystem:fireAfterFileChange	(Ledu/thu/vfs/IFile;)V
    //   151: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	152	0	this	FileItem
    //   0	152	1	paramIFile	IFile
    //   21	6	2	localIFile	IFile
    //   42	105	3	localFileSystem	FileSystem
    //   80	57	4	localInputStream	InputStream
    //   90	52	5	localOutputStream	OutputStream
    //   121	13	6	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   92	121	121	finally
  }
  
  public void download(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
  {
    paramHttpServletResponse.resetBuffer();
    paramHttpServletResponse.setContentType("bin");
    if (this.C == null) {
      return;
    }
    Object localObject1 = null;
    InputStream localInputStream = null;
    try
    {
      localInputStream = this.C.getInputStream();
      if (localInputStream == null) {
        return;
      }
      localObject1 = paramHttpServletResponse.getOutputStream();
      IoUtils.copy(localInputStream, (OutputStream)localObject1);
      ((OutputStream)localObject1).flush();
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
    finally
    {
      IoUtils.safeClose(localInputStream);
      IoUtils.safeClose((OutputStream)localObject1);
    }
    IoUtils.safeClose(localInputStream);
    IoUtils.safeClose((OutputStream)localObject1);
  }
  
  public String getFileId()
  {
    return this.A;
  }
  
  public String getFileName()
  {
    return this.G;
  }
  
  public String getFileExt()
  {
    if (this.G == null) {
      return "";
    }
    int i = this.G.lastIndexOf('.');
    if (i < 0) {
      return "";
    }
    return this.G.substring(i + 1);
  }
  
  public long getLastModified()
  {
    if (!(getMoniker() instanceof IFile)) {
      return 0L;
    }
    return ((IFile)getMoniker()).lastModified();
  }
  
  public void setFileId(String paramString)
  {
    if ((paramString != null) && (paramString.length() > 0)) {
      paramString = UrlUtils.getFullName(paramString.replace('\\', '/'));
    }
    this.A = paramString;
  }
  
  public IBinaryStreamMoniker getMoniker()
  {
    return this.C;
  }
  
  public long getContentLength()
  {
    if (this.C == null) {
      return 0L;
    }
    return this.C.getContentLength();
  }
  
  public String getFileSizeString()
  {
    long l = getContentLength();
    if (l == 0L) {
      return "0K";
    }
    if (l < 1024L) {
      return l + "B";
    }
    return l / 1024L + "K";
  }
  
  public void setMoniker(IBinaryStreamMoniker paramIBinaryStreamMoniker)
  {
    this.C = paramIBinaryStreamMoniker;
  }
  
  public OutputStream getOutputStream()
  {
    IFile localIFile = (IFile)getMoniker();
    return localIFile.getOutputStream();
  }
  
  void A(IFile paramIFile) {}
  
  public void saveFrom(InputStream paramInputStream)
  {
    IFile localIFile = getFile();
    A(localIFile);
    FileSystem localFileSystem = (FileSystem)localIFile.getFileSystem();
    localFileSystem.saveData(localIFile, paramInputStream);
  }
  
  public List<IFile> getHistoryList()
  {
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\hibernate\FileItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */