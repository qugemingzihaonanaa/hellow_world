package edu.thu.ext.hibernate;

import edu.thu.app.sys.entity.EntityFieldList;
import edu.thu.app.sys.entity.EntityPk;
import edu.thu.lang.IGetter;
import edu.thu.model.entity.Tags;
import edu.thu.model.stg.ds.DataSourceMeta;
import java.io.Serializable;
import java.util.Map;

public abstract class AbstractEntity
  implements Serializable, IGetter
{
  public static final String PREFIX_EXT_FIELDS = "ext_";
  
  public static Object _toObject(int paramInt)
  {
    if (paramInt == 0) {
      return null;
    }
    return new Integer(paramInt);
  }
  
  public AbstractEntity cloneInstance()
  {
    return null;
  }
  
  public void setEntityMissing(boolean paramBoolean) {}
  
  public Map<String, Object> makeDynamics()
  {
    return null;
  }
  
  public void distBeforeProcess() {}
  
  public void entityBeforeSave() {}
  
  public void entityBeforeUpdate() {}
  
  public EntityPk getEntityPk()
  {
    return null;
  }
  
  public String getEntityName_()
  {
    return null;
  }
  
  public boolean isEntityEncoded()
  {
    return false;
  }
  
  public String getIdAsString()
  {
    return null;
  }
  
  public DataSourceMeta getDsMeta_()
  {
    return null;
  }
  
  public String getStoreEntityName_()
  {
    return null;
  }
  
  public String getEntityEncodeKey()
  {
    return null;
  }
  
  public EntityFieldList getExtFields()
  {
    return null;
  }
  
  public Tags getTagsObj()
  {
    return null;
  }
  
  public static Object _toObject(Object paramObject)
  {
    return paramObject;
  }
  
  public Object get(Object paramObject)
  {
    return null;
  }
  
  public Object toDbType()
  {
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\hibernate\AbstractEntity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */