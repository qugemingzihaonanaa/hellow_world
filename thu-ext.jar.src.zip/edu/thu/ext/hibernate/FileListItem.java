package edu.thu.ext.hibernate;

import edu.thu.model.stg.IBinaryStreamMoniker;
import edu.thu.util.UrlUtils;
import java.util.ArrayList;
import java.util.List;

public class FileListItem
{
  List A;
  List C;
  String B;
  
  public FileListItem() {}
  
  public FileListItem(List paramList1, List paramList2)
  {
    this.A = paramList1;
    this.C = paramList2;
  }
  
  public String getUpdaterId()
  {
    return this.B;
  }
  
  public void setUpdaterId(String paramString)
  {
    this.B = paramString;
  }
  
  public boolean isEmpty()
  {
    return (this.A == null) || (this.A.isEmpty());
  }
  
  public List getDataList()
  {
    return this.C;
  }
  
  public void setDataList(List paramList)
  {
    this.C = paramList;
  }
  
  public List getFileNames()
  {
    return this.A;
  }
  
  public FileListItem copy()
  {
    FileListItem localFileListItem = new FileListItem();
    localFileListItem.A = (this.A == null ? null : new ArrayList(this.A));
    localFileListItem.C = (this.C == null ? null : new ArrayList(this.C));
    return localFileListItem;
  }
  
  public void setFileNames(List paramList)
  {
    this.A = paramList;
  }
  
  public void addMoniker(IBinaryStreamMoniker paramIBinaryStreamMoniker)
  {
    if (this.A == null) {
      this.A = new ArrayList();
    }
    if (this.C == null) {
      this.C = new ArrayList();
    }
    String str = A(paramIBinaryStreamMoniker);
    this.A.add(str);
    this.C.add(paramIBinaryStreamMoniker);
  }
  
  public void addFileItem(FileItem paramFileItem)
  {
    if (this.A == null) {
      this.A = new ArrayList();
    }
    if (this.C == null) {
      this.C = new ArrayList();
    }
    this.A.add(paramFileItem.getFileName());
    this.C.add(paramFileItem.getMoniker());
  }
  
  String A(IBinaryStreamMoniker paramIBinaryStreamMoniker)
  {
    return UrlUtils.getFullName(paramIBinaryStreamMoniker.getReferenceName().replace('\\', '/'));
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\hibernate\FileListItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */