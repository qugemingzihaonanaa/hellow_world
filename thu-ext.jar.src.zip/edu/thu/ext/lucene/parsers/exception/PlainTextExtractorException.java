package edu.thu.ext.lucene.parsers.exception;

import edu.thu.lang.exceptions.StdException;

public class PlainTextExtractorException
  extends StdException
{
  public PlainTextExtractorException(Throwable paramThrowable)
  {
    super("extractor.err_fail", paramThrowable);
  }
  
  public PlainTextExtractorException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\exception\PlainTextExtractorException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */