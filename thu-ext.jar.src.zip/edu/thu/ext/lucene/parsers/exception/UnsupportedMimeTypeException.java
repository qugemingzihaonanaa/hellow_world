package edu.thu.ext.lucene.parsers.exception;

public class UnsupportedMimeTypeException
  extends Exception
{
  public UnsupportedMimeTypeException() {}
  
  public UnsupportedMimeTypeException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\exception\UnsupportedMimeTypeException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */