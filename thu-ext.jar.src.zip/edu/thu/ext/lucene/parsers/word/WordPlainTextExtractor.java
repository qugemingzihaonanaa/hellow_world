package edu.thu.ext.lucene.parsers.word;

import edu.thu.ext.lucene.parsers.IPlainTextExtractor;
import edu.thu.ext.lucene.parsers.exception.PlainTextExtractorException;
import java.io.InputStream;
import java.io.Writer;
import org.textmining.extraction.TextExtractor;
import org.textmining.extraction.word.WordTextExtractorFactory;

public class WordPlainTextExtractor
  implements IPlainTextExtractor
{
  public void extract(InputStream paramInputStream, Writer paramWriter, String paramString)
    throws PlainTextExtractorException
  {
    try
    {
      TextExtractor localTextExtractor = new WordTextExtractorFactory().textExtractor(paramInputStream);
      String str = localTextExtractor.getText();
      paramWriter.write(str);
    }
    catch (Exception localException)
    {
      throw new PlainTextExtractorException(localException);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\word\WordPlainTextExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */