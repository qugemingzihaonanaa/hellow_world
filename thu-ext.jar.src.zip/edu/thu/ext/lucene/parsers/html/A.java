package edu.thu.ext.lucene.parsers.html;

import edu.thu.ext.lucene.search.SearchConstants;
import java.io.CharArrayWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.Writer;
import java.util.HashMap;

class A
  extends HTMLParser
{
  public A(Reader paramReader, Writer paramWriter, boolean paramBoolean, InputStream paramInputStream)
  {
    super(paramReader, paramWriter, paramBoolean, paramInputStream);
  }
  
  protected void addText(String paramString)
    throws IOException
  {
    if ((!this.inStyle) && (!this.inScript)) {
      if (this.lookingForEncoding) {
        this.resultedChars.write(paramString);
      } else {
        this.output.write(paramString);
      }
    }
  }
  
  protected void addSpace()
    throws IOException
  {
    if ((!this.inStyle) && (!this.inScript))
    {
      String str = this.afterTag ? SearchConstants.EOL : " ";
      if (this.lookingForEncoding) {
        this.resultedChars.write(str);
      } else {
        this.output.write(str);
      }
    }
  }
  
  protected void processTag(String paramString, HashMap paramHashMap, boolean paramBoolean)
    throws IOException
  {
    checkoutAttribute(paramHashMap, "title");
    if (paramString.equalsIgnoreCase("<script"))
    {
      this.inScript = true;
    }
    else if (paramString.equalsIgnoreCase("</script"))
    {
      this.inScript = false;
    }
    else if (paramString.equalsIgnoreCase("<img"))
    {
      checkoutAttribute(paramHashMap, "alt");
    }
    else if (paramString.equalsIgnoreCase("<meta"))
    {
      checkoutNameContentPair(paramHashMap, "keywords");
      checkoutNameContentPair(paramHashMap, "description");
      checkoutNameContentPair(paramHashMap, "copyright");
      checkoutNameContentPair(paramHashMap, "publisher");
      checkoutNameContentPair(paramHashMap, "author");
      if (this.lookingForEncoding) {
        checkoutEncodingChange(paramHashMap);
      }
    }
    else if (((paramString.equalsIgnoreCase("</head")) || (paramString.equalsIgnoreCase("<body"))) && (!this.headFinished))
    {
      this.lookingForEncoding = false;
      this.headFinished = true;
      if ((this.initialStream instanceof D))
      {
        D localD = (D)this.initialStream;
        localD.B();
        this.output.write(this.resultedChars.toCharArray());
        this.resultedChars = null;
      }
    }
  }
  
  protected void considerText(String paramString)
    throws IOException
  {
    addText(paramString);
  }
  
  protected void considerSpace()
    throws IOException
  {
    addSpace();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\html\A.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */