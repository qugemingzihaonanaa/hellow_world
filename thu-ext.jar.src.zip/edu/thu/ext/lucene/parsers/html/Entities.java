package edu.thu.ext.lucene.parsers.html;

import java.util.Hashtable;

public class Entities
{
  static final Hashtable B = new Hashtable(300);
  static final String[] A = new String['Ā'];
  
  static
  {
    A("&nbsp", 160);
    A("&iexcl", 161);
    A("&cent", 162);
    A("&pound", 163);
    A("&curren", 164);
    A("&yen", 165);
    A("&brvbar", 166);
    A("&sect", 167);
    A("&uml", 168);
    A("&copy", 169);
    A("&ordf", 170);
    A("&laquo", 171);
    A("&not", 172);
    A("&shy", 173);
    A("&reg", 174);
    A("&macr", 175);
    A("&deg", 176);
    A("&plusmn", 177);
    A("&sup2", 178);
    A("&sup3", 179);
    A("&acute", 180);
    A("&micro", 181);
    A("&para", 182);
    A("&middot", 183);
    A("&cedil", 184);
    A("&sup1", 185);
    A("&ordm", 186);
    A("&raquo", 187);
    A("&frac14", 188);
    A("&frac12", 189);
    A("&frac34", 190);
    A("&iquest", 191);
    A("&Agrave", 192);
    A("&Aacute", 193);
    A("&Acirc", 194);
    A("&Atilde", 195);
    A("&Auml", 196);
    A("&Aring", 197);
    A("&AElig", 198);
    A("&Ccedil", 199);
    A("&Egrave", 200);
    A("&Eacute", 201);
    A("&Ecirc", 202);
    A("&Euml", 203);
    A("&Igrave", 204);
    A("&Iacute", 205);
    A("&Icirc", 206);
    A("&Iuml", 207);
    A("&ETH", 208);
    A("&Ntilde", 209);
    A("&Ograve", 210);
    A("&Oacute", 211);
    A("&Ocirc", 212);
    A("&Otilde", 213);
    A("&Ouml", 214);
    A("&times", 215);
    A("&Oslash", 216);
    A("&Ugrave", 217);
    A("&Uacute", 218);
    A("&Ucirc", 219);
    A("&Uuml", 220);
    A("&Yacute", 221);
    A("&THORN", 222);
    A("&szlig", 223);
    A("&agrave", 224);
    A("&aacute", 225);
    A("&acirc", 226);
    A("&atilde", 227);
    A("&auml", 228);
    A("&aring", 229);
    A("&aelig", 230);
    A("&ccedil", 231);
    A("&egrave", 232);
    A("&eacute", 233);
    A("&ecirc", 234);
    A("&euml", 235);
    A("&igrave", 236);
    A("&iacute", 237);
    A("&icirc", 238);
    A("&iuml", 239);
    A("&eth", 240);
    A("&ntilde", 241);
    A("&ograve", 242);
    A("&oacute", 243);
    A("&ocirc", 244);
    A("&otilde", 245);
    A("&ouml", 246);
    A("&divide", 247);
    A("&oslash", 248);
    A("&ugrave", 249);
    A("&uacute", 250);
    A("&ucirc", 251);
    A("&uuml", 252);
    A("&yacute", 253);
    A("&thorn", 254);
    A("&yuml", 255);
    A("&fnof", 402);
    A("&Alpha", 913);
    A("&Beta", 914);
    A("&Gamma", 915);
    A("&Delta", 916);
    A("&Epsilon", 917);
    A("&Zeta", 918);
    A("&Eta", 919);
    A("&Theta", 920);
    A("&Iota", 921);
    A("&Kappa", 922);
    A("&Lambda", 923);
    A("&Mu", 924);
    A("&Nu", 925);
    A("&Xi", 926);
    A("&Omicron", 927);
    A("&Pi", 928);
    A("&Rho", 929);
    A("&Sigma", 931);
    A("&Tau", 932);
    A("&Upsilon", 933);
    A("&Phi", 934);
    A("&Chi", 935);
    A("&Psi", 936);
    A("&Omega", 937);
    A("&alpha", 945);
    A("&beta", 946);
    A("&gamma", 947);
    A("&delta", 948);
    A("&epsilon", 949);
    A("&zeta", 950);
    A("&eta", 951);
    A("&theta", 952);
    A("&iota", 953);
    A("&kappa", 954);
    A("&lambda", 955);
    A("&mu", 956);
    A("&nu", 957);
    A("&xi", 958);
    A("&omicron", 959);
    A("&pi", 960);
    A("&rho", 961);
    A("&sigmaf", 962);
    A("&sigma", 963);
    A("&tau", 964);
    A("&upsilon", 965);
    A("&phi", 966);
    A("&chi", 967);
    A("&psi", 968);
    A("&omega", 969);
    A("&thetasym", 977);
    A("&upsih", 978);
    A("&piv", 982);
    A("&bull", 8226);
    A("&hellip", 8230);
    A("&prime", 8242);
    A("&Prime", 8243);
    A("&oline", 8254);
    A("&frasl", 8260);
    A("&weierp", 8472);
    A("&image", 8465);
    A("&real", 8476);
    A("&trade", 8482);
    A("&alefsym", 8501);
    A("&larr", 8592);
    A("&uarr", 8593);
    A("&rarr", 8594);
    A("&darr", 8595);
    A("&harr", 8596);
    A("&crarr", 8629);
    A("&lArr", 8656);
    A("&uArr", 8657);
    A("&rArr", 8658);
    A("&dArr", 8659);
    A("&hArr", 8660);
    A("&forall", 8704);
    A("&part", 8706);
    A("&exist", 8707);
    A("&empty", 8709);
    A("&nabla", 8711);
    A("&isin", 8712);
    A("&notin", 8713);
    A("&ni", 8715);
    A("&prod", 8719);
    A("&sum", 8721);
    A("&minus", 8722);
    A("&lowast", 8727);
    A("&radic", 8730);
    A("&prop", 8733);
    A("&infin", 8734);
    A("&ang", 8736);
    A("&and", 8743);
    A("&or", 8744);
    A("&cap", 8745);
    A("&cup", 8746);
    A("&int", 8747);
    A("&there4", 8756);
    A("&sim", 8764);
    A("&cong", 8773);
    A("&asymp", 8776);
    A("&ne", 8800);
    A("&equiv", 8801);
    A("&le", 8804);
    A("&ge", 8805);
    A("&sub", 8834);
    A("&sup", 8835);
    A("&nsub", 8836);
    A("&sube", 8838);
    A("&supe", 8839);
    A("&oplus", 8853);
    A("&otimes", 8855);
    A("&perp", 8869);
    A("&sdot", 8901);
    A("&lceil", 8968);
    A("&rceil", 8969);
    A("&lfloor", 8970);
    A("&rfloor", 8971);
    A("&lang", 9001);
    A("&rang", 9002);
    A("&loz", 9674);
    A("&spades", 9824);
    A("&clubs", 9827);
    A("&hearts", 9829);
    A("&diams", 9830);
    A("&quot", 34);
    A("&amp", 38);
    A("&lt", 60);
    A("&gt", 62);
    A("&OElig", 338);
    A("&oelig", 339);
    A("&Scaron", 352);
    A("&scaron", 353);
    A("&Yuml", 376);
    A("&circ", 710);
    A("&tilde", 732);
    A("&ensp", 8194);
    A("&emsp", 8195);
    A("&thinsp", 8201);
    A("&zwnj", 8204);
    A("&zwj", 8205);
    A("&lrm", 8206);
    A("&rlm", 8207);
    A("&ndash", 8211);
    A("&mdash", 8212);
    A("&lsquo", 8216);
    A("&rsquo", 8217);
    A("&sbquo", 8218);
    A("&ldquo", 8220);
    A("&rdquo", 8221);
    A("&bdquo", 8222);
    A("&dagger", 8224);
    A("&Dagger", 8225);
    A("&permil", 8240);
    A("&lsaquo", 8249);
    A("&rsaquo", 8250);
    A("&euro", 8364);
  }
  
  static final String A(String paramString)
  {
    if (paramString.charAt(paramString.length() - 1) == ';') {
      paramString = paramString.substring(0, paramString.length() - 1);
    }
    if (paramString.charAt(1) == '#')
    {
      int i = 2;
      int j = 10;
      if ((paramString.charAt(2) == 'X') || (paramString.charAt(2) == 'x'))
      {
        i++;
        j = 16;
      }
      Character localCharacter = new Character((char)Integer.parseInt(paramString.substring(i), j));
      return localCharacter.toString();
    }
    String str = (String)B.get(paramString);
    if (str != null) {
      return str;
    }
    return "";
  }
  
  public static final String encode(String paramString)
  {
    int i = paramString.length();
    StringBuffer localStringBuffer = new StringBuffer(i * 2);
    for (int j = 0; j < i; j++)
    {
      char c1 = paramString.charAt(j);
      char c2 = c1;
      if ((c2 < 'Ā') && (A[c2] != null))
      {
        localStringBuffer.append(A[c2]);
        localStringBuffer.append(';');
      }
      else if (c2 < '')
      {
        localStringBuffer.append(c1);
      }
      else
      {
        localStringBuffer.append("&#");
        localStringBuffer.append(c1);
        localStringBuffer.append(';');
      }
    }
    return localStringBuffer.toString();
  }
  
  static final void A(String paramString, int paramInt)
  {
    B.put(paramString, new Character((char)paramInt).toString());
    if (paramInt < 256) {
      A[paramInt] = paramString;
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\html\Entities.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */