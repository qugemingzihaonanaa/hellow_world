package edu.thu.ext.lucene.parsers.html;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class RefsParser
  extends HTMLParser
{
  protected List refList = new ArrayList();
  
  public RefsParser(Reader paramReader)
  {
    super(paramReader, null, false, null);
  }
  
  protected void addText(String paramString)
    throws IOException
  {}
  
  protected void addSpace()
    throws IOException
  {}
  
  protected void considerText(String paramString)
    throws IOException
  {
    this.refList.add(paramString);
  }
  
  protected void considerSpace()
    throws IOException
  {}
  
  protected void processTag(String paramString, HashMap paramHashMap, boolean paramBoolean)
    throws IOException
  {
    checkoutAttribute(paramHashMap, "src");
    checkoutAttribute(paramHashMap, "href");
    checkoutAttribute(paramHashMap, "background");
  }
  
  public List getExtractedRefs()
  {
    return this.refList;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\html\RefsParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */