package edu.thu.ext.lucene.parsers.html;

import edu.thu.ext.lucene.parsers.IPlainTextExtractor;
import edu.thu.ext.lucene.parsers.exception.PlainTextExtractorException;
import edu.thu.ext.lucene.search.SearchConstants;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.Writer;
import java.util.List;
import java.util.StringTokenizer;
import javax.swing.text.ChangedCharSetException;

public class HTMLPlainTextExtractor
  implements IPlainTextExtractor
{
  public void extract(InputStream paramInputStream, Writer paramWriter, String paramString)
    throws PlainTextExtractorException
  {
    A localA = null;
    Object localObject = null;
    try
    {
      if (paramString == null)
      {
        D localD = new D(paramInputStream);
        localObject = new InputStreamReader(localD, SearchConstants.DEFAULT_ENCODING);
        localA = new A((Reader)localObject, paramWriter, true, localD);
        try
        {
          localA.L();
        }
        catch (ChangedCharSetException localChangedCharSetException)
        {
          String str1 = localChangedCharSetException.getCharSetSpec();
          String str2 = localChangedCharSetException.keyEqualsCharSet() ? str1 : A(str1);
          localObject = new BufferedReader(new InputStreamReader(new B(localD), str2));
          localA = new A((Reader)localObject, paramWriter, false, null);
          localA.L();
        }
      }
      else
      {
        localObject = new BufferedReader(new InputStreamReader(paramInputStream, paramString));
        localA = new A((Reader)localObject, paramWriter, false, null);
        localA.L();
      }
    }
    catch (Exception localException)
    {
      throw new PlainTextExtractorException(localException);
    }
  }
  
  private String A(String paramString)
  {
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString, " \t;=");
    int i = localStringTokenizer.countTokens();
    String[] arrayOfString = new String[i];
    for (int j = 0; j < i; j++) {
      arrayOfString[j] = localStringTokenizer.nextToken();
    }
    String str;
    if ((i >= 3) && ("charset".equalsIgnoreCase(arrayOfString[1]))) {
      str = arrayOfString[2];
    } else {
      str = SearchConstants.DEFAULT_ENCODING;
    }
    return str;
  }
  
  public List extractInlineResources(InputStream paramInputStream, String paramString)
    throws PlainTextExtractorException
  {
    try
    {
      InputStreamReader localInputStreamReader = new InputStreamReader(paramInputStream, paramString);
      C localC = new C(localInputStreamReader);
      localC.L();
      return localC.P();
    }
    catch (IOException localIOException)
    {
      throw new PlainTextExtractorException(localIOException);
    }
    catch (ParseException localParseException)
    {
      throw new PlainTextExtractorException(localParseException);
    }
  }
  
  public List extractAllRefs(InputStream paramInputStream, String paramString)
    throws PlainTextExtractorException
  {
    try
    {
      InputStreamReader localInputStreamReader = new InputStreamReader(paramInputStream, paramString);
      RefsParser localRefsParser = new RefsParser(localInputStreamReader);
      localRefsParser.L();
      return localRefsParser.getExtractedRefs();
    }
    catch (IOException localIOException)
    {
      throw new PlainTextExtractorException(localIOException);
    }
    catch (ParseException localParseException)
    {
      throw new PlainTextExtractorException(localParseException);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\html\HTMLPlainTextExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */