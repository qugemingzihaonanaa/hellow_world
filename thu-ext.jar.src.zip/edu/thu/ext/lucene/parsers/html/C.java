package edu.thu.ext.lucene.parsers.html;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

class C
  extends HTMLParser
{
  protected List e = new ArrayList();
  
  public C(Reader paramReader)
  {
    super(paramReader, null, false, null);
  }
  
  protected void addText(String paramString)
    throws IOException
  {}
  
  protected void addSpace()
    throws IOException
  {}
  
  protected void considerText(String paramString)
    throws IOException
  {
    this.e.add(paramString);
  }
  
  protected void considerSpace()
    throws IOException
  {}
  
  protected void processTag(String paramString, HashMap paramHashMap, boolean paramBoolean)
    throws IOException
  {
    if (paramString.equalsIgnoreCase("<img"))
    {
      checkoutAttribute(paramHashMap, "src");
    }
    else if (paramString.equalsIgnoreCase("<link"))
    {
      checkoutAttribute(paramHashMap, "src");
      checkoutAttribute(paramHashMap, "href");
    }
    checkoutAttribute(paramHashMap, "background");
  }
  
  public List P()
  {
    return this.e;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\html\C.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */