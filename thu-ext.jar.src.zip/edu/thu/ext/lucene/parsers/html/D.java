package edu.thu.ext.lucene.parsers.html;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

class D
  extends InputStream
{
  private InputStream C;
  private ByteArrayOutputStream A;
  private boolean B;
  
  private D() {}
  
  D(InputStream paramInputStream)
  {
    this.C = paramInputStream;
    this.A = new ByteArrayOutputStream();
    this.B = true;
  }
  
  public int available()
    throws IOException
  {
    return this.C.available();
  }
  
  public void close()
    throws IOException
  {}
  
  public synchronized void reset()
    throws IOException
  {
    this.C.reset();
  }
  
  public boolean markSupported()
  {
    return this.C.markSupported();
  }
  
  public synchronized void mark(int paramInt)
  {
    this.C.mark(paramInt);
  }
  
  public long skip(long paramLong)
    throws IOException
  {
    return this.C.skip(paramLong);
  }
  
  public int read(byte[] paramArrayOfByte)
    throws IOException
  {
    return super.read(paramArrayOfByte);
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    return super.read(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  public int read()
    throws IOException
  {
    int i = this.C.read();
    if (this.B) {
      this.A.write(i);
    }
    return i;
  }
  
  public InputStream A()
  {
    return this.C;
  }
  
  public byte[] C()
  {
    return this.A == null ? null : this.A.toByteArray();
  }
  
  public void B()
  {
    this.B = false;
    this.A = null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\html\D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */