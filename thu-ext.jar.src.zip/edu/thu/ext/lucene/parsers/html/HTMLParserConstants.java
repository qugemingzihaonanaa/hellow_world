package edu.thu.ext.lucene.parsers.html;

public abstract interface HTMLParserConstants
{
  public static final int EOF = 0;
  public static final int ScriptStart = 1;
  public static final int TagName = 2;
  public static final int DeclName = 3;
  public static final int Comment1 = 4;
  public static final int Comment2 = 5;
  public static final int Word = 6;
  public static final int LET = 7;
  public static final int NUM = 8;
  public static final int Entity = 9;
  public static final int Space = 10;
  public static final int SP = 11;
  public static final int Punct = 12;
  public static final int ScriptText = 13;
  public static final int ScriptEnd = 14;
  public static final int ArgName = 15;
  public static final int ArgEquals = 16;
  public static final int TagEnd = 17;
  public static final int ArgValue = 18;
  public static final int ArgQuote1 = 19;
  public static final int ArgQuote2 = 20;
  public static final int Quote1Text = 22;
  public static final int CloseQuote1 = 23;
  public static final int Quote2Text = 24;
  public static final int CloseQuote2 = 25;
  public static final int CommentText1 = 26;
  public static final int CommentEnd1 = 27;
  public static final int CommentText2 = 28;
  public static final int CommentEnd2 = 29;
  public static final int DEFAULT = 0;
  public static final int WithinScript = 1;
  public static final int WithinTag = 2;
  public static final int AfterEquals = 3;
  public static final int WithinQuote1 = 4;
  public static final int WithinQuote2 = 5;
  public static final int WithinComment1 = 6;
  public static final int WithinComment2 = 7;
  public static final String[] tokenImage = { "<EOF>", "\"<script\"", "<TagName>", "<DeclName>", "\"<!--\"", "\"<!\"", "<Word>", "<LET>", "<NUM>", "<Entity>", "<Space>", "<SP>", "<Punct>", "<ScriptText>", "<ScriptEnd>", "<ArgName>", "\"=\"", "<TagEnd>", "<ArgValue>", "\"\\'\"", "\"\\\"\"", "<token of kind 21>", "<Quote1Text>", "<CloseQuote1>", "<Quote2Text>", "<CloseQuote2>", "<CommentText1>", "\"-->\"", "<CommentText2>", "\">\"" };
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\html\HTMLParserConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */