package edu.thu.ext.lucene.parsers.html;

import java.io.CharArrayWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.Writer;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Set;
import java.util.Vector;
import javax.swing.text.ChangedCharSetException;

public class HTMLParser
  implements HTMLParserConstants
{
  protected Writer output;
  protected InputStream initialStream;
  protected boolean lookingForEncoding;
  protected CharArrayWriter resultedChars;
  protected boolean headFinished;
  protected int length = 0;
  protected boolean inTitle = false;
  protected boolean inMetaTag = false;
  protected boolean inStyle = false;
  protected boolean inScript = false;
  protected boolean afterTag = false;
  public HTMLParserTokenManager token_source;
  SimpleCharStream Y;
  public Token token;
  public Token jj_nt;
  private int _;
  private Token W;
  private Token Q;
  private int V;
  public boolean lookingAhead = false;
  private boolean U;
  private int Z;
  private final int[] S = new int[14];
  private static int[] P;
  private final _A[] d = new _A[2];
  private boolean a = false;
  private int b = 0;
  private final _B N = new _B(null);
  private Vector T = new Vector();
  private int[] X;
  private int O = -1;
  private int[] c = new int[100];
  private int R;
  
  static {}
  
  public HTMLParser(Reader paramReader, Writer paramWriter, boolean paramBoolean, InputStream paramInputStream)
  {
    this(paramReader);
    this.output = paramWriter;
    this.lookingForEncoding = paramBoolean;
    this.headFinished = false;
    this.initialStream = paramInputStream;
    this.resultedChars = new CharArrayWriter();
  }
  
  protected void addText(String paramString)
    throws IOException
  {}
  
  protected void addSpace()
    throws IOException
  {}
  
  protected void processTag(String paramString, HashMap paramHashMap, boolean paramBoolean)
    throws IOException
  {}
  
  protected void checkoutAttribute(HashMap paramHashMap, String paramString)
    throws IOException
  {
    String str = (String)paramHashMap.get(paramString);
    if (notEmpty(str))
    {
      considerText(str);
      considerSpace();
    }
  }
  
  protected void checkoutNameContentPair(HashMap paramHashMap, String paramString)
    throws IOException
  {
    String str1 = (String)paramHashMap.get("name");
    if ((notEmpty(str1)) && (str1.equalsIgnoreCase(paramString)))
    {
      String str2 = (String)paramHashMap.get("content");
      if (notEmpty(str2))
      {
        considerText(str2);
        considerSpace();
      }
    }
  }
  
  protected void checkoutEncodingChange(HashMap paramHashMap)
    throws ChangedCharSetException
  {
    String str1 = (String)paramHashMap.get("http-equiv");
    if ((notEmpty(str1)) && (str1.equalsIgnoreCase("Content-Type")))
    {
      String str2 = (String)paramHashMap.get("content");
      if (notEmpty(str2)) {
        throw new ChangedCharSetException(str2, false);
      }
    }
  }
  
  protected boolean notEmpty(String paramString)
  {
    return (paramString != null) && (!paramString.trim().equals(""));
  }
  
  protected void considerText(String paramString)
    throws IOException
  {}
  
  protected void considerSpace()
    throws IOException
  {}
  
  void L()
    throws IOException, ParseException
  {
    HTMLDocument();
    if (this.lookingForEncoding) {
      this.output.write(this.resultedChars.toCharArray());
    }
  }
  
  public final void HTMLDocument()
    throws ParseException, IOException
  {
    for (;;)
    {
      switch (this._ == -1 ? J() : this._)
      {
      case 1: 
      case 2: 
      case 3: 
      case 4: 
      case 5: 
      case 6: 
      case 9: 
      case 10: 
      case 12: 
        break;
      case 7: 
      case 8: 
      case 11: 
      default: 
        this.S[0] = this.Z;
        break;
      }
      Token localToken;
      switch (this._ == -1 ? J() : this._)
      {
      case 2: 
        Tag();
        this.afterTag = true;
        break;
      case 3: 
        localToken = Decl();
        this.afterTag = true;
        break;
      case 4: 
      case 5: 
        CommentTag();
        this.afterTag = true;
        break;
      case 1: 
        ScriptTag();
        this.afterTag = true;
        break;
      case 6: 
        localToken = F(6);
        addText(localToken.image);
        this.afterTag = false;
        break;
      case 9: 
        localToken = F(9);
        addText(Entities.A(localToken.image));
        this.afterTag = false;
        break;
      case 12: 
        localToken = F(12);
        addText(localToken.image);
        this.afterTag = false;
        break;
      case 10: 
        F(10);
        addSpace();
        this.afterTag = false;
      }
    }
    this.S[1] = this.Z;
    F(-1);
    throw new ParseException();
    F(0);
  }
  
  public final void Tag()
    throws ParseException, IOException
  {
    Token localToken1 = F(2);
    String str1 = localToken1.image.toLowerCase();
    if (Tags.WS_ELEMS.contains(str1)) {
      addSpace();
    }
    this.inTitle = str1.equalsIgnoreCase("<title");
    this.inMetaTag = str1.equalsIgnoreCase("<META");
    this.inStyle = str1.equalsIgnoreCase("<STYLE");
    HashMap localHashMap = new HashMap();
    for (;;)
    {
      switch (this._ == -1 ? J() : this._)
      {
      case 15: 
        break;
      default: 
        this.S[2] = this.Z;
        break;
      }
      localToken1 = F(15);
      switch (this._ == -1 ? J() : this._)
      {
      case 16: 
        F(16);
        switch (this._ == -1 ? J() : this._)
        {
        case 18: 
        case 19: 
        case 20: 
          Token localToken2 = ArgValue();
          String str2 = localToken1.image.toLowerCase();
          String str3 = localToken2 == null ? "" : localToken2.image;
          localHashMap.put(str2, str3);
          break;
        default: 
          this.S[3] = this.Z;
        }
        break;
      default: 
        this.S[4] = this.Z;
      }
    }
    F(17);
    boolean bool = str1.charAt(1) == '/';
    processTag(str1, localHashMap, bool);
  }
  
  public final Token ArgValue()
    throws ParseException
  {
    Token localToken = null;
    switch (this._ == -1 ? J() : this._)
    {
    case 18: 
      localToken = F(18);
      return localToken;
    }
    this.S[5] = this.Z;
    if (E(2))
    {
      F(19);
      F(23);
      return localToken;
    }
    switch (this._ == -1 ? J() : this._)
    {
    case 19: 
      F(19);
      localToken = F(22);
      F(23);
      return localToken;
    }
    this.S[6] = this.Z;
    if (C(2))
    {
      F(20);
      F(25);
      return localToken;
    }
    switch (this._ == -1 ? J() : this._)
    {
    case 20: 
      F(20);
      localToken = F(24);
      F(25);
      return localToken;
    }
    this.S[7] = this.Z;
    F(-1);
    throw new ParseException();
  }
  
  public final Token Decl()
    throws ParseException
  {
    Token localToken = F(3);
    for (;;)
    {
      switch (this._ == -1 ? J() : this._)
      {
      case 15: 
      case 16: 
      case 18: 
      case 19: 
      case 20: 
        break;
      case 17: 
      default: 
        this.S[8] = this.Z;
        break;
      }
      switch (this._ == -1 ? J() : this._)
      {
      case 15: 
        F(15);
        break;
      case 18: 
      case 19: 
      case 20: 
        ArgValue();
        break;
      case 16: 
        F(16);
      }
    }
    this.S[9] = this.Z;
    F(-1);
    throw new ParseException();
    F(17);
    return localToken;
  }
  
  public final void CommentTag()
    throws ParseException
  {
    switch (this._ == -1 ? J() : this._)
    {
    case 4: 
      F(4);
      for (;;)
      {
        switch (this._ == -1 ? J() : this._)
        {
        case 26: 
          break;
        default: 
          this.S[10] = this.Z;
          break;
        }
        F(26);
      }
      F(27);
      break;
    case 5: 
      F(5);
      for (;;)
      {
        switch (this._ == -1 ? J() : this._)
        {
        case 28: 
          break;
        default: 
          this.S[11] = this.Z;
          break;
        }
        F(28);
      }
      F(29);
      break;
    default: 
      this.S[12] = this.Z;
      F(-1);
      throw new ParseException();
    }
  }
  
  public final void ScriptTag()
    throws ParseException
  {
    F(1);
    for (;;)
    {
      switch (this._ == -1 ? J() : this._)
      {
      case 13: 
        break;
      default: 
        this.S[13] = this.Z;
        break;
      }
      F(13);
    }
    F(14);
  }
  
  private final boolean E(int paramInt)
  {
    this.V = paramInt;
    this.Q = (this.W = this.token);
    try
    {
      boolean bool = !K();
      return bool;
    }
    catch (_B local_B)
    {
      return true;
    }
    finally
    {
      N(0, paramInt);
    }
  }
  
  private final boolean C(int paramInt)
  {
    this.V = paramInt;
    this.Q = (this.W = this.token);
    try
    {
      boolean bool = !M();
      return bool;
    }
    catch (_B local_B)
    {
      return true;
    }
    finally
    {
      N(1, paramInt);
    }
  }
  
  private final boolean M()
  {
    if (D(20)) {
      return true;
    }
    return D(25);
  }
  
  private final boolean K()
  {
    if (D(19)) {
      return true;
    }
    return D(23);
  }
  
  private static void O()
  {
    P = new int[] { 5758, 5758, 32768, 1835008, 65536, 262144, 524288, 1048576, 1933312, 1933312, 67108864, 268435456, 48, 8192 };
  }
  
  public HTMLParser(InputStream paramInputStream)
  {
    this.Y = new SimpleCharStream(paramInputStream, 1, 1);
    this.token_source = new HTMLParserTokenManager(this.Y);
    this.token = new Token();
    this._ = -1;
    this.Z = 0;
    for (int i = 0; i < 14; i++) {
      this.S[i] = -1;
    }
    for (i = 0; i < this.d.length; i++) {
      this.d[i] = new _A();
    }
  }
  
  public void ReInit(InputStream paramInputStream)
  {
    this.Y.ReInit(paramInputStream, 1, 1);
    this.token_source.ReInit(this.Y);
    this.token = new Token();
    this._ = -1;
    this.Z = 0;
    for (int i = 0; i < 14; i++) {
      this.S[i] = -1;
    }
    for (i = 0; i < this.d.length; i++) {
      this.d[i] = new _A();
    }
  }
  
  public HTMLParser(Reader paramReader)
  {
    this.Y = new SimpleCharStream(paramReader, 1, 1);
    this.token_source = new HTMLParserTokenManager(this.Y);
    this.token = new Token();
    this._ = -1;
    this.Z = 0;
    for (int i = 0; i < 14; i++) {
      this.S[i] = -1;
    }
    for (i = 0; i < this.d.length; i++) {
      this.d[i] = new _A();
    }
  }
  
  public void ReInit(Reader paramReader)
  {
    this.Y.ReInit(paramReader, 1, 1);
    this.token_source.ReInit(this.Y);
    this.token = new Token();
    this._ = -1;
    this.Z = 0;
    for (int i = 0; i < 14; i++) {
      this.S[i] = -1;
    }
    for (i = 0; i < this.d.length; i++) {
      this.d[i] = new _A();
    }
  }
  
  public HTMLParser(HTMLParserTokenManager paramHTMLParserTokenManager)
  {
    this.token_source = paramHTMLParserTokenManager;
    this.token = new Token();
    this._ = -1;
    this.Z = 0;
    for (int i = 0; i < 14; i++) {
      this.S[i] = -1;
    }
    for (i = 0; i < this.d.length; i++) {
      this.d[i] = new _A();
    }
  }
  
  public void ReInit(HTMLParserTokenManager paramHTMLParserTokenManager)
  {
    this.token_source = paramHTMLParserTokenManager;
    this.token = new Token();
    this._ = -1;
    this.Z = 0;
    for (int i = 0; i < 14; i++) {
      this.S[i] = -1;
    }
    for (i = 0; i < this.d.length; i++) {
      this.d[i] = new _A();
    }
  }
  
  private final Token F(int paramInt)
    throws ParseException
  {
    Token localToken;
    if ((localToken = this.token).next != null) {
      this.token = this.token.next;
    } else {
      this.token = (this.token.next = this.token_source.getNextToken());
    }
    this._ = -1;
    if (this.token.kind == paramInt)
    {
      this.Z += 1;
      if (++this.b > 100)
      {
        this.b = 0;
        for (int i = 0; i < this.d.length; i++) {
          for (_A local_A = this.d[i]; local_A != null; local_A = local_A.B) {
            if (local_A.D < this.Z) {
              local_A.C = null;
            }
          }
        }
      }
      return this.token;
    }
    this.token = localToken;
    this.O = paramInt;
    throw generateParseException();
  }
  
  private final boolean D(int paramInt)
  {
    if (this.W == this.Q)
    {
      this.V -= 1;
      if (this.W.next == null) {
        this.Q = (this.W = this.W.next = this.token_source.getNextToken());
      } else {
        this.Q = (this.W = this.W.next);
      }
    }
    else
    {
      this.W = this.W.next;
    }
    if (this.a)
    {
      int i = 0;
      for (Token localToken = this.token; (localToken != null) && (localToken != this.W); localToken = localToken.next) {
        i++;
      }
      if (localToken != null) {
        M(paramInt, i);
      }
    }
    if (this.W.kind != paramInt) {
      return true;
    }
    if ((this.V == 0) && (this.W == this.Q)) {
      throw this.N;
    }
    return false;
  }
  
  public final Token getNextToken()
  {
    if (this.token.next != null) {
      this.token = this.token.next;
    } else {
      this.token = (this.token.next = this.token_source.getNextToken());
    }
    this._ = -1;
    this.Z += 1;
    return this.token;
  }
  
  public final Token getToken(int paramInt)
  {
    Token localToken = this.lookingAhead ? this.W : this.token;
    for (int i = 0; i < paramInt; i++) {
      if (localToken.next != null) {
        localToken = localToken.next;
      } else {
        localToken = localToken.next = this.token_source.getNextToken();
      }
    }
    return localToken;
  }
  
  private final int J()
  {
    if ((this.jj_nt = this.token.next) == null) {
      return this._ = (this.token.next = this.token_source.getNextToken()).kind;
    }
    return this._ = this.jj_nt.kind;
  }
  
  private void M(int paramInt1, int paramInt2)
  {
    if (paramInt2 >= 100) {
      return;
    }
    if (paramInt2 == this.R + 1)
    {
      this.c[(this.R++)] = paramInt1;
    }
    else if (this.R != 0)
    {
      this.X = new int[this.R];
      for (int i = 0; i < this.R; i++) {
        this.X[i] = this.c[i];
      }
      i = 0;
      Enumeration localEnumeration = this.T.elements();
      while (localEnumeration.hasMoreElements())
      {
        int[] arrayOfInt = (int[])localEnumeration.nextElement();
        if (arrayOfInt.length == this.X.length)
        {
          i = 1;
          for (int j = 0; j < this.X.length; j++) {
            if (arrayOfInt[j] != this.X[j])
            {
              i = 0;
              break;
            }
          }
          if (i != 0) {
            break;
          }
        }
      }
      if (i == 0) {
        this.T.addElement(this.X);
      }
      if (paramInt2 != 0) {
        this.c[((this.R = paramInt2) - 1)] = paramInt1;
      }
    }
  }
  
  public ParseException generateParseException()
  {
    this.T.removeAllElements();
    boolean[] arrayOfBoolean = new boolean[30];
    for (int i = 0; i < 30; i++) {
      arrayOfBoolean[i] = false;
    }
    if (this.O >= 0)
    {
      arrayOfBoolean[this.O] = true;
      this.O = -1;
    }
    for (i = 0; i < 14; i++) {
      if (this.S[i] == this.Z) {
        for (j = 0; j < 32; j++) {
          if ((P[i] & 1 << j) != 0) {
            arrayOfBoolean[j] = true;
          }
        }
      }
    }
    for (i = 0; i < 30; i++) {
      if (arrayOfBoolean[i] != 0)
      {
        this.X = new int[1];
        this.X[0] = i;
        this.T.addElement(this.X);
      }
    }
    this.R = 0;
    N();
    M(0, 0);
    int[][] arrayOfInt = new int[this.T.size()][];
    for (int j = 0; j < this.T.size(); j++) {
      arrayOfInt[j] = ((int[])this.T.elementAt(j));
    }
    return new ParseException(this.token, arrayOfInt, tokenImage);
  }
  
  public final void enable_tracing() {}
  
  public final void disable_tracing() {}
  
  private final void N()
  {
    this.a = true;
    for (int i = 0; i < 2; i++)
    {
      _A local_A = this.d[i];
      do
      {
        if (local_A.D > this.Z)
        {
          this.V = local_A.A;
          this.Q = (this.W = local_A.C);
          switch (i)
          {
          case 0: 
            K();
            break;
          case 1: 
            M();
          }
        }
        local_A = local_A.B;
      } while (local_A != null);
    }
    this.a = false;
  }
  
  private final void N(int paramInt1, int paramInt2)
  {
    for (_A local_A = this.d[paramInt1]; local_A.D > this.Z; local_A = local_A.B) {
      if (local_A.B == null)
      {
        local_A = local_A.B = new _A();
        break;
      }
    }
    local_A.D = (this.Z + paramInt2 - this.V);
    local_A.C = this.token;
    local_A.A = paramInt2;
  }
  
  static final class _A
  {
    int D;
    Token C;
    int A;
    _A B;
  }
  
  private static final class _B
    extends Error
  {}
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\html\HTMLParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */