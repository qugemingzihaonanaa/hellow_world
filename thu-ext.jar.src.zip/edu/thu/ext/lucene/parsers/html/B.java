package edu.thu.ext.lucene.parsers.html;

import java.io.IOException;
import java.io.InputStream;

class B
  extends InputStream
{
  private InputStream C;
  private byte[] B;
  private int A;
  
  private B() {}
  
  B(D paramD)
  {
    this.C = paramD.A();
    this.B = paramD.C();
    this.A = 0;
  }
  
  public int available()
    throws IOException
  {
    return this.B.length - this.A + this.C.available();
  }
  
  public void close()
    throws IOException
  {
    this.B = new byte[0];
    this.A = 0;
    this.C.close();
  }
  
  public synchronized void reset()
    throws IOException
  {
    this.A = 0;
    this.C.reset();
  }
  
  public boolean markSupported()
  {
    return false;
  }
  
  public synchronized void mark(int paramInt) {}
  
  public long skip(long paramLong)
    throws IOException
  {
    int i = this.B.length - this.A;
    long l1;
    long l2;
    if (paramLong <= i)
    {
      this.A = ((int)(this.A + paramLong));
      l1 = 0L;
      l2 = paramLong;
    }
    else
    {
      this.A = this.B.length;
      l1 = this.C.skip(paramLong - i);
      l2 = i;
    }
    return l2 + l1;
  }
  
  public int read(byte[] paramArrayOfByte)
    throws IOException
  {
    return super.read(paramArrayOfByte);
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    return super.read(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  public int read()
    throws IOException
  {
    if (this.A < this.B.length) {
      return this.B[(this.A++)];
    }
    return this.C.read();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\html\B.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */