package edu.thu.ext.lucene.parsers.rtf;

public class Token
{
  public int kind;
  public int beginLine;
  public int beginColumn;
  public int endLine;
  public int endColumn;
  public String image;
  public Token next;
  public Token specialToken;
  
  public String toString()
  {
    return this.image;
  }
  
  public static final Token newToken(int paramInt)
  {
    return new Token();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\rtf\Token.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */