package edu.thu.ext.lucene.parsers.rtf;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class SimpleCharStream
{
  public static final boolean staticFlag = false;
  int C;
  int B;
  int A;
  public int bufpos = -1;
  protected int[] bufline;
  protected int[] bufcolumn;
  protected int column = 0;
  protected int line = 1;
  protected boolean prevCharIsCR = false;
  protected boolean prevCharIsLF = false;
  protected Reader inputStream;
  protected char[] buffer;
  protected int maxNextCharInd = 0;
  protected int inBuf = 0;
  
  protected void ExpandBuff(boolean paramBoolean)
  {
    char[] arrayOfChar = new char[this.C + 2048];
    int[] arrayOfInt1 = new int[this.C + 2048];
    int[] arrayOfInt2 = new int[this.C + 2048];
    try
    {
      if (paramBoolean)
      {
        System.arraycopy(this.buffer, this.A, arrayOfChar, 0, this.C - this.A);
        System.arraycopy(this.buffer, 0, arrayOfChar, this.C - this.A, this.bufpos);
        this.buffer = arrayOfChar;
        System.arraycopy(this.bufline, this.A, arrayOfInt1, 0, this.C - this.A);
        System.arraycopy(this.bufline, 0, arrayOfInt1, this.C - this.A, this.bufpos);
        this.bufline = arrayOfInt1;
        System.arraycopy(this.bufcolumn, this.A, arrayOfInt2, 0, this.C - this.A);
        System.arraycopy(this.bufcolumn, 0, arrayOfInt2, this.C - this.A, this.bufpos);
        this.bufcolumn = arrayOfInt2;
        this.maxNextCharInd = (this.bufpos += this.C - this.A);
      }
      else
      {
        System.arraycopy(this.buffer, this.A, arrayOfChar, 0, this.C - this.A);
        this.buffer = arrayOfChar;
        System.arraycopy(this.bufline, this.A, arrayOfInt1, 0, this.C - this.A);
        this.bufline = arrayOfInt1;
        System.arraycopy(this.bufcolumn, this.A, arrayOfInt2, 0, this.C - this.A);
        this.bufcolumn = arrayOfInt2;
        this.maxNextCharInd = (this.bufpos -= this.A);
      }
    }
    catch (Throwable localThrowable)
    {
      throw new Error(localThrowable.getMessage());
    }
    this.C += 2048;
    this.B = this.C;
    this.A = 0;
  }
  
  protected void FillBuff()
    throws IOException
  {
    if (this.maxNextCharInd == this.B) {
      if (this.B == this.C)
      {
        if (this.A > 2048)
        {
          this.bufpos = (this.maxNextCharInd = 0);
          this.B = this.A;
        }
        else if (this.A < 0)
        {
          this.bufpos = (this.maxNextCharInd = 0);
        }
        else
        {
          ExpandBuff(false);
        }
      }
      else if (this.B > this.A) {
        this.B = this.C;
      } else if (this.A - this.B < 2048) {
        ExpandBuff(true);
      } else {
        this.B = this.A;
      }
    }
    try
    {
      int i;
      if ((i = this.inputStream.read(this.buffer, this.maxNextCharInd, this.B - this.maxNextCharInd)) == -1)
      {
        this.inputStream.close();
        throw new IOException();
      }
      this.maxNextCharInd += i;
      return;
    }
    catch (IOException localIOException)
    {
      this.bufpos -= 1;
      backup(0);
      if (this.A == -1) {
        this.A = this.bufpos;
      }
      throw localIOException;
    }
  }
  
  public char BeginToken()
    throws IOException
  {
    this.A = -1;
    char c = readChar();
    this.A = this.bufpos;
    return c;
  }
  
  protected void UpdateLineColumn(char paramChar)
  {
    this.column += 1;
    if (this.prevCharIsLF)
    {
      this.prevCharIsLF = false;
      this.line += (this.column = 1);
    }
    else if (this.prevCharIsCR)
    {
      this.prevCharIsCR = false;
      if (paramChar == '\n') {
        this.prevCharIsLF = true;
      } else {
        this.line += (this.column = 1);
      }
    }
    switch (paramChar)
    {
    case '\r': 
      this.prevCharIsCR = true;
      break;
    case '\n': 
      this.prevCharIsLF = true;
      break;
    case '\t': 
      this.column -= 1;
      this.column += 8 - (this.column & 0x7);
      break;
    }
    this.bufline[this.bufpos] = this.line;
    this.bufcolumn[this.bufpos] = this.column;
  }
  
  public char readChar()
    throws IOException
  {
    if (this.inBuf > 0)
    {
      this.inBuf -= 1;
      if (++this.bufpos == this.C) {
        this.bufpos = 0;
      }
      return this.buffer[this.bufpos];
    }
    if (++this.bufpos >= this.maxNextCharInd) {
      FillBuff();
    }
    char c = this.buffer[this.bufpos];
    UpdateLineColumn(c);
    return c;
  }
  
  public int getColumn()
  {
    return this.bufcolumn[this.bufpos];
  }
  
  public int getLine()
  {
    return this.bufline[this.bufpos];
  }
  
  public int getEndColumn()
  {
    return this.bufcolumn[this.bufpos];
  }
  
  public int getEndLine()
  {
    return this.bufline[this.bufpos];
  }
  
  public int getBeginColumn()
  {
    return this.bufcolumn[this.A];
  }
  
  public int getBeginLine()
  {
    return this.bufline[this.A];
  }
  
  public void backup(int paramInt)
  {
    this.inBuf += paramInt;
    if (this.bufpos -= paramInt < 0) {
      this.bufpos += this.C;
    }
  }
  
  public SimpleCharStream(Reader paramReader, int paramInt1, int paramInt2, int paramInt3)
  {
    this.inputStream = paramReader;
    this.line = paramInt1;
    this.column = (paramInt2 - 1);
    this.B = (this.C = paramInt3);
    this.buffer = new char[paramInt3];
    this.bufline = new int[paramInt3];
    this.bufcolumn = new int[paramInt3];
  }
  
  public SimpleCharStream(Reader paramReader, int paramInt1, int paramInt2)
  {
    this(paramReader, paramInt1, paramInt2, 4096);
  }
  
  public SimpleCharStream(Reader paramReader)
  {
    this(paramReader, 1, 1, 4096);
  }
  
  public void ReInit(Reader paramReader, int paramInt1, int paramInt2, int paramInt3)
  {
    this.inputStream = paramReader;
    this.line = paramInt1;
    this.column = (paramInt2 - 1);
    if ((this.buffer == null) || (paramInt3 != this.buffer.length))
    {
      this.B = (this.C = paramInt3);
      this.buffer = new char[paramInt3];
      this.bufline = new int[paramInt3];
      this.bufcolumn = new int[paramInt3];
    }
    this.prevCharIsLF = (this.prevCharIsCR = 0);
    this.A = (this.inBuf = this.maxNextCharInd = 0);
    this.bufpos = -1;
  }
  
  public void ReInit(Reader paramReader, int paramInt1, int paramInt2)
  {
    ReInit(paramReader, paramInt1, paramInt2, 4096);
  }
  
  public void ReInit(Reader paramReader)
  {
    ReInit(paramReader, 1, 1, 4096);
  }
  
  public SimpleCharStream(InputStream paramInputStream, int paramInt1, int paramInt2, int paramInt3)
  {
    this(new InputStreamReader(paramInputStream), paramInt1, paramInt2, 4096);
  }
  
  public SimpleCharStream(InputStream paramInputStream, int paramInt1, int paramInt2)
  {
    this(paramInputStream, paramInt1, paramInt2, 4096);
  }
  
  public SimpleCharStream(InputStream paramInputStream)
  {
    this(paramInputStream, 1, 1, 4096);
  }
  
  public void ReInit(InputStream paramInputStream, int paramInt1, int paramInt2, int paramInt3)
  {
    ReInit(new InputStreamReader(paramInputStream), paramInt1, paramInt2, 4096);
  }
  
  public void ReInit(InputStream paramInputStream)
  {
    ReInit(paramInputStream, 1, 1, 4096);
  }
  
  public void ReInit(InputStream paramInputStream, int paramInt1, int paramInt2)
  {
    ReInit(paramInputStream, paramInt1, paramInt2, 4096);
  }
  
  public String GetImage()
  {
    if (this.bufpos >= this.A) {
      return new String(this.buffer, this.A, this.bufpos - this.A + 1);
    }
    return new String(this.buffer, this.A, this.C - this.A) + new String(this.buffer, 0, this.bufpos + 1);
  }
  
  public char[] GetSuffix(int paramInt)
  {
    char[] arrayOfChar = new char[paramInt];
    if (this.bufpos + 1 >= paramInt)
    {
      System.arraycopy(this.buffer, this.bufpos - paramInt + 1, arrayOfChar, 0, paramInt);
    }
    else
    {
      System.arraycopy(this.buffer, this.C - (paramInt - this.bufpos - 1), arrayOfChar, 0, paramInt - this.bufpos - 1);
      System.arraycopy(this.buffer, 0, arrayOfChar, paramInt - this.bufpos - 1, this.bufpos + 1);
    }
    return arrayOfChar;
  }
  
  public void Done()
  {
    this.buffer = null;
    this.bufline = null;
    this.bufcolumn = null;
  }
  
  public void adjustBeginLineColumn(int paramInt1, int paramInt2)
  {
    int i = this.A;
    int j;
    if (this.bufpos >= this.A) {
      j = this.bufpos - this.A + this.inBuf + 1;
    } else {
      j = this.C - this.A + this.bufpos + 1 + this.inBuf;
    }
    int k = 0;
    int m = 0;
    int n = 0;
    int i1 = 0;
    int i2 = 0;
    while ((k < j) && (this.bufline[(m = i % this.C)] == this.bufline[(n = ++i % this.C)]))
    {
      this.bufline[m] = paramInt1;
      i1 = i2 + this.bufcolumn[n] - this.bufcolumn[m];
      this.bufcolumn[m] = (paramInt2 + i2);
      i2 = i1;
      k++;
    }
    if (k < j)
    {
      this.bufline[m] = (paramInt1++);
      this.bufcolumn[m] = (paramInt2 + i2);
      while (k++ < j) {
        if (this.bufline[(m = i % this.C)] != this.bufline[(++i % this.C)]) {
          this.bufline[m] = (paramInt1++);
        } else {
          this.bufline[m] = paramInt1;
        }
      }
    }
    this.line = this.bufline[m];
    this.column = this.bufcolumn[m];
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\rtf\SimpleCharStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */