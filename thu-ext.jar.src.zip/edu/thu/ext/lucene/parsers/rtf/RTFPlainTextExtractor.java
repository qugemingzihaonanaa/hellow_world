package edu.thu.ext.lucene.parsers.rtf;

import edu.thu.ext.lucene.parsers.IPlainTextExtractor;
import edu.thu.ext.lucene.parsers.exception.PlainTextExtractorException;
import edu.thu.ext.lucene.search.SearchConstants;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.List;

public class RTFPlainTextExtractor
  implements IPlainTextExtractor, RTFParserDelegate
{
  private StringWriter æ = null;
  private boolean è;
  private int ç;
  private int é;
  
  public void extract(InputStream paramInputStream, Writer paramWriter, String paramString)
    throws PlainTextExtractorException
  {
    this.é = 0;
    this.è = false;
    this.æ = new StringWriter();
    RTFParser localRTFParser = new RTFParser(paramInputStream);
    localRTFParser.setNewLine(SearchConstants.EOL);
    localRTFParser.setDelegate(this);
    try
    {
      localRTFParser.parse();
      paramWriter.write(this.æ.toString());
    }
    catch (Exception localException)
    {
      throw new PlainTextExtractorException(localException);
    }
  }
  
  public String getPlainText(String paramString)
  {
    this.é = 0;
    this.è = false;
    this.æ = new StringWriter();
    RTFParser localRTFParser = new RTFParser(new StringReader(paramString));
    localRTFParser.setNewLine(SearchConstants.EOL);
    localRTFParser.setDelegate(this);
    try
    {
      localRTFParser.parse();
      return this.æ.toString();
    }
    catch (Exception localException)
    {
      throw new PlainTextExtractorException(localException);
    }
  }
  
  private void A(String paramString, int paramInt)
  {
    if ((paramInt == 0) && (!this.è) && (this.æ != null)) {
      this.æ.write(paramString);
    }
  }
  
  public void text(String paramString1, String paramString2, int paramInt)
  {
    A(paramString1, paramInt);
  }
  
  public void controlSymbol(String paramString, int paramInt)
  {
    if ((paramString.equals("\\*")) && (!this.è))
    {
      this.è = true;
      this.ç = this.é;
    }
  }
  
  public void controlWord(String paramString, int paramInt1, int paramInt2)
  {
    if (paramString.equals("\\cell"))
    {
      A(" ", paramInt2);
    }
    else if (paramString.equals("\\row"))
    {
      A(SearchConstants.EOL, paramInt2);
    }
    else if (((paramString.equals("\\object")) || (paramString.equals("\\pict"))) && (!this.è))
    {
      this.è = true;
      this.ç = this.é;
    }
  }
  
  public void openGroup(int paramInt)
  {
    this.é += 1;
  }
  
  public void closeGroup(int paramInt)
  {
    this.é -= 1;
    if ((this.è) && (this.é < this.ç)) {
      this.è = false;
    }
  }
  
  public void styleList(List paramList) {}
  
  public void startDocument() {}
  
  public void endDocument() {}
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\rtf\RTFPlainTextExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */