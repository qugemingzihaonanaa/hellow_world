package edu.thu.ext.lucene.parsers.rtf;

import java.util.List;

public abstract interface RTFParserDelegate
{
  public static final String VERSION = "$Id: RTFParserDelegate.java,v 1.1 2005/03/26 14:26:06 agrebnev Exp $";
  public static final int IN_DOCUMENT = 0;
  public static final int IN_FONTTBL = 1;
  public static final int IN_FILETBL = 2;
  public static final int IN_COLORTBL = 3;
  public static final int IN_STYLESHEET = 4;
  public static final int IN_LISTTABLE = 5;
  public static final int IN_STYLE = 6;
  public static final int IN_REVTBL = 7;
  public static final int IN_INFO = 8;
  public static final int IN_PNTEXT = 9;
  public static final String NO_STYLE = new String();
  
  public abstract void text(String paramString1, String paramString2, int paramInt);
  
  public abstract void controlSymbol(String paramString, int paramInt);
  
  public abstract void controlWord(String paramString, int paramInt1, int paramInt2);
  
  public abstract void openGroup(int paramInt);
  
  public abstract void closeGroup(int paramInt);
  
  public abstract void styleList(List paramList);
  
  public abstract void startDocument();
  
  public abstract void endDocument();
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\rtf\RTFParserDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */