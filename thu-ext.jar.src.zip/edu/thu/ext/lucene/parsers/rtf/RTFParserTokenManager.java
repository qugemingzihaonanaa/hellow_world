package edu.thu.ext.lucene.parsers.rtf;

import java.io.IOException;
import java.io.PrintStream;

public class RTFParserTokenManager
  implements RTFParserConstants
{
  public PrintStream debugStream = System.out;
  static final long[] Å = { -2L, -1L, -1L, -1L };
  static final long[] Ä = { 0, 0, -1L, -1L };
  static final int[] Â = new int[0];
  public static final String[] jjstrLiteralImages = { 0, 0, 0, 0, 0, 0, 0, 0, "\\~", "\\-", "\\_", "\\\n", "\\\r", "\\*", "\\|", "\\:", "\\{", "\\}", "\\\\" };
  public static final String[] lexStateNames = { "CONTROL", "HEX", "DEFAULT" };
  public static final int[] jjnewLexState = { -1, 0, 1, -1, -1, -1, 2, 2, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 2, 2, 2, 2, 2, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 2 };
  static final long[] z = { -127926335L, 360447L };
  static final long[] Á = { 125829176L, 524288L };
  static final long[] £ = { 6L };
  protected SimpleCharStream input_stream;
  private final int[] ª = new int[3];
  private final int[] y = new int[6];
  StringBuffer º;
  int ¢;
  int µ;
  protected char curChar;
  int Æ = 2;
  int ¥ = 2;
  int À;
  int x;
  int ¤;
  int Ã;
  
  public void setDebugStream(PrintStream paramPrintStream)
  {
    this.debugStream = paramPrintStream;
  }
  
  private final int A(int paramInt, long paramLong)
  {
    switch (paramInt)
    {
    case 0: 
      if ((paramLong & 0x7FF06) != 0L) {
        return 1;
      }
      return -1;
    }
    return -1;
  }
  
  private final int B(int paramInt, long paramLong)
  {
    return B(A(paramInt, paramLong), paramInt + 1);
  }
  
  private final int D(int paramInt1, int paramInt2)
  {
    this.Ã = paramInt2;
    this.¤ = paramInt1;
    return paramInt1 + 1;
  }
  
  private final int A(int paramInt1, int paramInt2, int paramInt3)
  {
    this.Ã = paramInt2;
    this.¤ = paramInt1;
    try
    {
      this.curChar = this.input_stream.readChar();
    }
    catch (IOException localIOException)
    {
      return paramInt1 + 1;
    }
    return B(paramInt3, paramInt1 + 1);
  }
  
  private final int C()
  {
    switch (this.curChar)
    {
    case '\\': 
      this.Ã = 1;
      return B(524036L);
    case '{': 
      return D(0, 6);
    case '}': 
      return D(0, 7);
    }
    return B(0, 0);
  }
  
  private final int B(long paramLong)
  {
    try
    {
      this.curChar = this.input_stream.readChar();
    }
    catch (IOException localIOException)
    {
      A(0, paramLong);
      return 1;
    }
    switch (this.curChar)
    {
    case '\n': 
      if ((paramLong & 0x800) != 0L) {
        return D(1, 11);
      }
      break;
    case '\r': 
      if ((paramLong & 0x1000) != 0L) {
        return D(1, 12);
      }
      break;
    case '\'': 
      if ((paramLong & 0x4) != 0L) {
        return D(1, 2);
      }
      break;
    case '*': 
      if ((paramLong & 0x2000) != 0L) {
        return D(1, 13);
      }
      break;
    case '-': 
      if ((paramLong & 0x200) != 0L) {
        return D(1, 9);
      }
      break;
    case ':': 
      if ((paramLong & 0x8000) != 0L) {
        return D(1, 15);
      }
      break;
    case '\\': 
      if ((paramLong & 0x40000) != 0L) {
        return D(1, 18);
      }
      break;
    case '_': 
      if ((paramLong & 0x400) != 0L) {
        return D(1, 10);
      }
      break;
    case '{': 
      if ((paramLong & 0x10000) != 0L) {
        return D(1, 16);
      }
      break;
    case '|': 
      if ((paramLong & 0x4000) != 0L) {
        return D(1, 14);
      }
      break;
    case '}': 
      if ((paramLong & 0x20000) != 0L) {
        return D(1, 17);
      }
      break;
    case '~': 
      if ((paramLong & 0x100) != 0L) {
        return D(1, 8);
      }
      break;
    }
    return B(0, paramLong);
  }
  
  private final void A(int paramInt)
  {
    if (this.ª[paramInt] != this.x)
    {
      this.y[(this.À++)] = paramInt;
      this.ª[paramInt] = this.x;
    }
  }
  
  private final void G(int paramInt1, int paramInt2)
  {
    do
    {
      this.y[(this.À++)] = Â[paramInt1];
    } while (paramInt1++ != paramInt2);
  }
  
  private final void C(int paramInt1, int paramInt2)
  {
    A(paramInt1);
    A(paramInt2);
  }
  
  private final void F(int paramInt1, int paramInt2)
  {
    do
    {
      A(Â[paramInt1]);
    } while (paramInt1++ != paramInt2);
  }
  
  private final void B(int paramInt)
  {
    A(Â[paramInt]);
    A(Â[(paramInt + 1)]);
  }
  
  private final int B(int paramInt1, int paramInt2)
  {
    int i = 0;
    this.À = 3;
    int j = 1;
    this.y[0] = paramInt1;
    int k = Integer.MAX_VALUE;
    for (;;)
    {
      if (++this.x == Integer.MAX_VALUE) {
        B();
      }
      long l1;
      if (this.curChar < '@')
      {
        l1 = 1L << this.curChar;
        do
        {
          switch (this.y[(--j)])
          {
          case 0: 
          case 2: 
            if ((0xFFFFFFFFFFFFD9FF & l1) != 0L)
            {
              if (k > 20) {
                k = 20;
              }
              A(2);
            }
            break;
          case 1: 
            if (((0xFC00FFFEFFFFD9FF & l1) != 0L) && (k > 19)) {
              k = 19;
            }
            break;
          }
        } while (j != i);
      }
      else if (this.curChar < '')
      {
        l1 = 1L << (this.curChar & 0x3F);
        do
        {
          switch (this.y[(--j)])
          {
          case 0: 
            if ((0xD7FFFFFFEFFFFFFF & l1) != 0L)
            {
              if (k > 20) {
                k = 20;
              }
              A(2);
            }
            else if (this.curChar == '\\')
            {
              this.y[(this.À++)] = 1;
            }
            break;
          case 1: 
            if (((0xD0000001E8000001 & l1) != 0L) && (k > 19)) {
              k = 19;
            }
            break;
          case 2: 
            if ((0xD7FFFFFFEFFFFFFF & l1) != 0L)
            {
              if (k > 20) {
                k = 20;
              }
              A(2);
            }
            break;
          }
        } while (j != i);
      }
      else
      {
        int m = this.curChar >> '\b';
        int n = m >> 6;
        long l2 = 1L << (m & 0x3F);
        int i1 = (this.curChar & 0xFF) >> '\006';
        long l3 = 1L << (this.curChar & 0x3F);
        do
        {
          switch (this.y[(--j)])
          {
          case 0: 
          case 2: 
            if (A(m, n, i1, l2, l3))
            {
              if (k > 20) {
                k = 20;
              }
              A(2);
            }
            break;
          case 1: 
            if ((A(m, n, i1, l2, l3)) && (k > 19)) {
              k = 19;
            }
            break;
          }
        } while (j != i);
      }
      if (k != Integer.MAX_VALUE)
      {
        this.Ã = k;
        this.¤ = paramInt2;
        k = Integer.MAX_VALUE;
      }
      paramInt2++;
      if ((j = this.À) == (i = 3 - (this.À = i))) {
        return paramInt2;
      }
      try
      {
        this.curChar = this.input_stream.readChar();
      }
      catch (IOException localIOException) {}
    }
    return paramInt2;
  }
  
  private final int C(int paramInt, long paramLong)
  {
    return -1;
  }
  
  private final int D(int paramInt, long paramLong)
  {
    return E(C(paramInt, paramLong), paramInt + 1);
  }
  
  private final int B(int paramInt1, int paramInt2, int paramInt3)
  {
    this.Ã = paramInt2;
    this.¤ = paramInt1;
    try
    {
      this.curChar = this.input_stream.readChar();
    }
    catch (IOException localIOException)
    {
      return paramInt1 + 1;
    }
    return E(paramInt3, paramInt1 + 1);
  }
  
  private final int A()
  {
    switch (this.curChar)
    {
    case '\\': 
      this.Ã = 1;
      return A(4L);
    case '{': 
      return D(0, 6);
    case '}': 
      return D(0, 7);
    }
    return E(0, 0);
  }
  
  private final int A(long paramLong)
  {
    try
    {
      this.curChar = this.input_stream.readChar();
    }
    catch (IOException localIOException)
    {
      C(0, paramLong);
      return 1;
    }
    switch (this.curChar)
    {
    case '\'': 
      if ((paramLong & 0x4) != 0L) {
        return D(1, 2);
      }
      break;
    }
    return D(0, paramLong);
  }
  
  private final int E(int paramInt1, int paramInt2)
  {
    int i = 0;
    this.À = 2;
    int j = 1;
    this.y[0] = paramInt1;
    int k = Integer.MAX_VALUE;
    for (;;)
    {
      if (++this.x == Integer.MAX_VALUE) {
        B();
      }
      long l1;
      if (this.curChar < '@')
      {
        l1 = 1L << this.curChar;
        do
        {
          switch (this.y[(--j)])
          {
          case 0: 
            if ((0x3FF000000000000 & l1) != 0L) {
              this.y[(this.À++)] = 1;
            }
            break;
          case 1: 
            if (((0x3FF000000000000 & l1) != 0L) && (k > 22)) {
              k = 22;
            }
            break;
          }
        } while (j != i);
      }
      else if (this.curChar < '')
      {
        l1 = 1L << (this.curChar & 0x3F);
        do
        {
          switch (this.y[(--j)])
          {
          case 0: 
            if ((0x7E0000007E & l1) != 0L) {
              this.y[(this.À++)] = 1;
            }
            break;
          case 1: 
            if (((0x7E0000007E & l1) != 0L) && (k > 22)) {
              k = 22;
            }
            break;
          }
        } while (j != i);
      }
      else
      {
        int m = this.curChar >> '\b';
        int n = m >> 6;
        long l2 = 1L << (m & 0x3F);
        int i1 = (this.curChar & 0xFF) >> '\006';
        long l3 = 1L << (this.curChar & 0x3F);
        do
        {
          this.y[(--j)];
        } while (j != i);
      }
      if (k != Integer.MAX_VALUE)
      {
        this.Ã = k;
        this.¤ = paramInt2;
        k = Integer.MAX_VALUE;
      }
      paramInt2++;
      if ((j = this.À) == (i = 2 - (this.À = i))) {
        return paramInt2;
      }
      try
      {
        this.curChar = this.input_stream.readChar();
      }
      catch (IOException localIOException) {}
    }
    return paramInt2;
  }
  
  private final int A(int paramInt, long paramLong1, long paramLong2)
  {
    switch (paramInt)
    {
    case 0: 
      if ((paramLong1 & 0x800B8000000) != 0L) {
        return 0;
      }
      if (((paramLong1 & 0xFFFFF7FF40000000) != 0L) || ((paramLong2 & 0x7FFF) != 0L))
      {
        this.Ã = 80;
        return 0;
      }
      return -1;
    case 1: 
      if ((paramLong1 & 0x650000000) != 0L) {
        return 0;
      }
      if (((paramLong1 & 0xFFFFFFF980000000) != 0L) || ((paramLong2 & 0x7FFF) != 0L))
      {
        if (this.¤ != 1)
        {
          this.Ã = 80;
          this.¤ = 1;
        }
        return 0;
      }
      return -1;
    case 2: 
      if ((paramLong1 & 0xB001C00000000) != 0L) {
        return 0;
      }
      if ((paramLong2 & 1L) != 0L)
      {
        if (this.¤ < 1)
        {
          this.Ã = 80;
          this.¤ = 1;
        }
        return -1;
      }
      if (((paramLong1 & 0xFFF4FFE180000000) != 0L) || ((paramLong2 & 0x7FFE) != 0L))
      {
        this.Ã = 80;
        this.¤ = 2;
        return 0;
      }
      return -1;
    case 3: 
      if ((paramLong1 & 0x1401E000000000) != 0L) {
        return 0;
      }
      if ((paramLong2 & 0x3808) != 0L)
      {
        if (this.¤ < 2)
        {
          this.Ã = 80;
          this.¤ = 2;
        }
        return -1;
      }
      if ((paramLong2 & 1L) != 0L)
      {
        if (this.¤ < 1)
        {
          this.Ã = 80;
          this.¤ = 1;
        }
        return -1;
      }
      if (((paramLong1 & 0xFFE0FE0180000000) != 0L) || ((paramLong2 & 0x47F6) != 0L))
      {
        if (this.¤ != 3)
        {
          this.Ã = 80;
          this.¤ = 3;
        }
        return 0;
      }
      return -1;
    case 4: 
      if ((paramLong1 & 0x100000000) != 0L) {
        return 0;
      }
      if ((paramLong2 & 0x3808) != 0L)
      {
        if (this.¤ < 2)
        {
          this.Ã = 80;
          this.¤ = 2;
        }
        return -1;
      }
      if ((paramLong2 & 0x4) != 0L)
      {
        if (this.¤ < 3)
        {
          this.Ã = 80;
          this.¤ = 3;
        }
        return -1;
      }
      if ((paramLong2 & 1L) != 0L)
      {
        if (this.¤ < 1)
        {
          this.Ã = 80;
          this.¤ = 1;
        }
        return -1;
      }
      if (((paramLong1 & 0xFFE0FE4080000000) != 0L) || ((paramLong2 & 0x47F2) != 0L))
      {
        this.Ã = 80;
        this.¤ = 4;
        return 0;
      }
      return -1;
    case 5: 
      if ((paramLong1 & 0xE60060000000000) != 0L) {
        return 0;
      }
      if ((paramLong2 & 0x3808) != 0L)
      {
        if (this.¤ < 2)
        {
          this.Ã = 80;
          this.¤ = 2;
        }
        return -1;
      }
      if ((paramLong2 & 0x4) != 0L)
      {
        if (this.¤ < 3)
        {
          this.Ã = 80;
          this.¤ = 3;
        }
        return -1;
      }
      if ((paramLong2 & 0x702) != 0L)
      {
        if (this.¤ < 4)
        {
          this.Ã = 80;
          this.¤ = 4;
        }
        return -1;
      }
      if ((paramLong2 & 1L) != 0L)
      {
        if (this.¤ < 1)
        {
          this.Ã = 80;
          this.¤ = 1;
        }
        return -1;
      }
      if (((paramLong1 & 0xF180F84080000000) != 0L) || ((paramLong2 & 0x40F0) != 0L))
      {
        this.Ã = 80;
        this.¤ = 5;
        return 0;
      }
      return -1;
    case 6: 
      if ((paramLong1 & 0x3180084000000000) != 0L) {
        return 0;
      }
      if ((paramLong2 & 0x3808) != 0L)
      {
        if (this.¤ < 2)
        {
          this.Ã = 80;
          this.¤ = 2;
        }
        return -1;
      }
      if ((paramLong2 & 0x4) != 0L)
      {
        if (this.¤ < 3)
        {
          this.Ã = 80;
          this.¤ = 3;
        }
        return -1;
      }
      if ((paramLong2 & 0x702) != 0L)
      {
        if (this.¤ < 4)
        {
          this.Ã = 80;
          this.¤ = 4;
        }
        return -1;
      }
      if ((paramLong2 & 1L) != 0L)
      {
        if (this.¤ < 1)
        {
          this.Ã = 80;
          this.¤ = 1;
        }
        return -1;
      }
      if (((paramLong1 & 0xC000F00080000000) != 0L) || ((paramLong2 & 0x40F0) != 0L))
      {
        this.Ã = 80;
        this.¤ = 6;
        return 0;
      }
      return -1;
    case 7: 
      if ((paramLong1 & 0x300080000000) != 0L) {
        return 0;
      }
      if ((paramLong2 & 0x3808) != 0L)
      {
        if (this.¤ < 2)
        {
          this.Ã = 80;
          this.¤ = 2;
        }
        return -1;
      }
      if ((paramLong2 & 0x4) != 0L)
      {
        if (this.¤ < 3)
        {
          this.Ã = 80;
          this.¤ = 3;
        }
        return -1;
      }
      if ((paramLong2 & 0x702) != 0L)
      {
        if (this.¤ < 4)
        {
          this.Ã = 80;
          this.¤ = 4;
        }
        return -1;
      }
      if ((paramLong2 & 1L) != 0L)
      {
        if (this.¤ < 1)
        {
          this.Ã = 80;
          this.¤ = 1;
        }
        return -1;
      }
      if (((paramLong1 & 0xC000C00000000000) != 0L) || ((paramLong2 & 0x40F0) != 0L))
      {
        if (this.¤ != 7)
        {
          this.Ã = 80;
          this.¤ = 7;
        }
        return 0;
      }
      return -1;
    case 8: 
      if (((paramLong1 & 0x800000000000) != 0L) || ((paramLong2 & 0x4010) != 0L))
      {
        this.Ã = 80;
        this.¤ = 8;
        return 0;
      }
      if ((paramLong1 & 0xC000400000000000) != 0L) {
        return 0;
      }
      if ((paramLong2 & 0xE0) != 0L)
      {
        if (this.¤ < 7)
        {
          this.Ã = 80;
          this.¤ = 7;
        }
        return -1;
      }
      if ((paramLong2 & 0x1800) != 0L)
      {
        if (this.¤ < 2)
        {
          this.Ã = 80;
          this.¤ = 2;
        }
        return -1;
      }
      if ((paramLong2 & 0x702) != 0L)
      {
        if (this.¤ < 4)
        {
          this.Ã = 80;
          this.¤ = 4;
        }
        return -1;
      }
      if ((paramLong2 & 1L) != 0L)
      {
        if (this.¤ < 1)
        {
          this.Ã = 80;
          this.¤ = 1;
        }
        return -1;
      }
      return -1;
    case 9: 
      if ((paramLong1 & 0x800000000000) != 0L) {
        return 0;
      }
      if ((paramLong2 & 0x4010) != 0L)
      {
        if (this.¤ != 9)
        {
          this.Ã = 80;
          this.¤ = 9;
        }
        return 0;
      }
      if ((paramLong2 & 0xE0) != 0L)
      {
        if (this.¤ < 7)
        {
          this.Ã = 80;
          this.¤ = 7;
        }
        return -1;
      }
      if ((paramLong2 & 0x702) != 0L)
      {
        if (this.¤ < 4)
        {
          this.Ã = 80;
          this.¤ = 4;
        }
        return -1;
      }
      return -1;
    case 10: 
      if ((paramLong2 & 0xE0) != 0L)
      {
        if (this.¤ < 7)
        {
          this.Ã = 80;
          this.¤ = 7;
        }
        return -1;
      }
      if ((paramLong2 & 0x300) != 0L)
      {
        if (this.¤ < 4)
        {
          this.Ã = 80;
          this.¤ = 4;
        }
        return -1;
      }
      if ((paramLong2 & 0x4010) != 0L)
      {
        this.Ã = 80;
        this.¤ = 10;
        return 0;
      }
      return -1;
    case 11: 
      if ((paramLong2 & 0x60) != 0L)
      {
        if (this.¤ < 7)
        {
          this.Ã = 80;
          this.¤ = 7;
        }
        return -1;
      }
      if ((paramLong2 & 0x4010) != 0L)
      {
        this.Ã = 80;
        this.¤ = 11;
        return 0;
      }
      return -1;
    case 12: 
      if ((paramLong2 & 0x40) != 0L)
      {
        if (this.¤ < 7)
        {
          this.Ã = 80;
          this.¤ = 7;
        }
        return -1;
      }
      if ((paramLong2 & 0x4010) != 0L)
      {
        this.Ã = 80;
        this.¤ = 12;
        return 0;
      }
      return -1;
    case 13: 
      if ((paramLong2 & 0x10) != 0L) {
        return 0;
      }
      if ((paramLong2 & 0x4000) != 0L)
      {
        this.Ã = 80;
        this.¤ = 13;
        return 0;
      }
      return -1;
    }
    return -1;
  }
  
  private final int B(int paramInt, long paramLong1, long paramLong2)
  {
    return A(A(paramInt, paramLong1, paramLong2), paramInt + 1);
  }
  
  private final int C(int paramInt1, int paramInt2, int paramInt3)
  {
    this.Ã = paramInt2;
    this.¤ = paramInt1;
    try
    {
      this.curChar = this.input_stream.readChar();
    }
    catch (IOException localIOException)
    {
      return paramInt1 + 1;
    }
    return A(paramInt3, paramInt1 + 1);
  }
  
  private final int D()
  {
    switch (this.curChar)
    {
    case '\t': 
      return D(0, 26);
    case '\n': 
      return D(0, 24);
    case '\r': 
      return D(0, 25);
    case ' ': 
      return D(0, 23);
    case '\\': 
      this.Ã = 1;
      return E(4L, 0L);
    case 'a': 
      return E(412316860416L, 0L);
    case 'b': 
      return E(144115188075855872L, 0L);
    case 'c': 
      return E(17593259786240L, 15L);
    case 'd': 
      return E(549755813888L, 0L);
    case 'e': 
      return E(135107988821114880L, 0L);
    case 'f': 
      this.Ã = 29;
      return E(8798240505856L, 0L);
    case 'i': 
      return E(1099511627776L, 0L);
    case 'l': 
      return E(6057411867557494784L, 0L);
    case 'm': 
      return E(34359738368L, 0L);
    case 'p': 
      return E(2291412297056256L, 0L);
    case 'r': 
      return E(-6341066007594926080L, 0L);
    case 's': 
      return E(140737488355328L, 16384L);
    case 't': 
      return E(281474976710656L, 16368L);
    case 'u': 
      this.Ã = 27;
      return E(268435456L, 0L);
    case 'z': 
      return E(1688849860263936L, 0L);
    case '{': 
      return D(0, 6);
    case '}': 
      return D(0, 7);
    }
    return A(1, 0);
  }
  
  private final int E(long paramLong1, long paramLong2)
  {
    try
    {
      this.curChar = this.input_stream.readChar();
    }
    catch (IOException localIOException)
    {
      A(0, paramLong1, paramLong2);
      return 1;
    }
    switch (this.curChar)
    {
    case '\'': 
      if ((paramLong1 & 0x4) != 0L) {
        return D(1, 2);
      }
      break;
    case 'a': 
      return F(paramLong1, 2533309150134272L, paramLong2, 0L);
    case 'c': 
      if ((paramLong1 & 0x10000000) != 0L) {
        return C(1, 28, 0);
      }
      if ((paramLong1 & 0x200000000) != 0L)
      {
        this.Ã = 33;
        this.¤ = 1;
      }
      return F(paramLong1, 19327352832L, paramLong2, 0L);
    case 'd': 
      return F(paramLong1, -4611686018427387904L, paramLong2, 240L);
    case 'e': 
      return F(paramLong1, 2748779069440L, paramLong2, 16384L);
    case 'i': 
      return F(paramLong1, 4573968371548160L, paramLong2, 0L);
    case 'l': 
      return F(paramLong1, 4294967296L, paramLong2, 15L);
    case 'm': 
      return F(paramLong1, 45035996273704960L, paramLong2, 0L);
    case 'n': 
      return F(paramLong1, 90113086794498048L, paramLong2, 0L);
    case 'o': 
      return F(paramLong1, 26388279066624L, paramLong2, 0L);
    case 'q': 
      return F(paramLong1, 864691128455135232L, paramLong2, 0L);
    case 'r': 
      return F(paramLong1, 0L, paramLong2, 16128L);
    case 's': 
      if ((paramLong1 & 0x40000000) != 0L) {
        return C(1, 30, 0);
      }
      break;
    case 't': 
      return F(paramLong1, 3458905320028372992L, paramLong2, 0L);
    case 'u': 
      return F(paramLong1, 144115188075855872L, paramLong2, 0L);
    case 'w': 
      return F(paramLong1, 1688849860263936L, paramLong2, 0L);
    }
    return B(0, paramLong1, paramLong2);
  }
  
  private final int F(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    if ((paramLong2 &= paramLong1 | paramLong4 &= paramLong3) == 0L) {
      return B(0, paramLong1, paramLong3);
    }
    try
    {
      this.curChar = this.input_stream.readChar();
    }
    catch (IOException localIOException)
    {
      A(1, paramLong2, paramLong4);
      return 2;
    }
    switch (this.curChar)
    {
    case 'F': 
      return H(paramLong2, 0L, paramLong4, 1L);
    case 'N': 
      return H(paramLong2, 0L, paramLong4, 4L);
    case 'a': 
      if ((paramLong2 & 0x400000000) != 0L) {
        return C(2, 34, 0);
      }
      return H(paramLong2, 4294967296L, paramLong4, 0L);
    case 'b': 
      if ((paramLong2 & 0x1000000000000) != 0L) {
        return C(2, 48, 0);
      }
      return H(paramLong2, -4611686018427387904L, paramLong4, 0L);
    case 'c': 
      if ((paramLong2 & 0x800000000) != 0L) {
        return C(2, 35, 0);
      }
      return H(paramLong2, 0L, paramLong4, 16384L);
    case 'd': 
      return H(paramLong2, 27021597764222976L, paramLong4, 0L);
    case 'f': 
      if ((paramLong2 & 0x1000000000) != 0L) {
        return C(2, 36, 0);
      }
      return H(paramLong2, 1649267441664L, paramLong4, 2034L);
    case 'h': 
      return H(paramLong2, 2147483648L, paramLong4, 0L);
    case 'j': 
      if ((paramLong2 & 0x2000000000000) != 0L) {
        return C(2, 49, 0);
      }
      break;
    case 'l': 
      return H(paramLong2, 2449975789475594240L, paramLong4, 0L);
    case 'n': 
      return H(paramLong2, 5638295627235328L, paramLong4, 0L);
    case 'r': 
      if ((paramLong2 & 0x8000000000000) != 0L) {
        return C(2, 51, 0);
      }
      return H(paramLong2, 1152921504606846976L, paramLong4, 0L);
    case 's': 
      return H(paramLong2, 108192356490018816L, paramLong4, 0L);
    case 't': 
      return H(paramLong2, 4398046511104L, paramLong4, 0L);
    case 'u': 
      return H(paramLong2, 864691128455135232L, paramLong4, 0L);
    case 'v': 
      return H(paramLong2, 2199023255552L, paramLong4, 0L);
    case 'w': 
      return H(paramLong2, 0L, paramLong4, 14344L);
    case 'y': 
      return H(paramLong2, 140737488355328L, paramLong4, 0L);
    }
    return B(1, paramLong2, paramLong4);
  }
  
  private final int H(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    if ((paramLong2 &= paramLong1 | paramLong4 &= paramLong3) == 0L) {
      return B(1, paramLong1, paramLong3);
    }
    try
    {
      this.curChar = this.input_stream.readChar();
    }
    catch (IOException localIOException)
    {
      A(2, paramLong2, paramLong4);
      return 3;
    }
    switch (this.curChar)
    {
    case 'W': 
      return A(paramLong2, 0L, paramLong4, 14344L);
    case 'a': 
      return A(paramLong2, 27021599911706624L, paramLong4, 0L);
    case 'e': 
      if ((paramLong2 & 0x10000000000000) != 0L) {
        return C(3, 52, 0);
      }
      return A(paramLong2, 39582418599936L, paramLong4, 0L);
    case 'f': 
      if ((paramLong2 & 0x8000000000) != 0L) {
        return C(3, 39, 0);
      }
      break;
    case 'i': 
      if ((paramLong2 & 0x2000000000) != 0L)
      {
        this.Ã = 37;
        this.¤ = 3;
      }
      return A(paramLong2, 279172874240L, paramLong4, 1L);
    case 'j': 
      if ((paramLong2 & 0x4000000000000) != 0L) {
        return C(3, 50, 0);
      }
      break;
    case 'l': 
      return A(paramLong2, -4467430092863176704L, paramLong4, 0L);
    case 'm': 
      return A(paramLong2, 3458764513820540928L, paramLong4, 0L);
    case 'o': 
      if ((paramLong2 & 0x10000000000) != 0L) {
        return C(3, 40, 0);
      }
      return A(paramLong2, 864708720641179648L, paramLong4, 4L);
    case 'p': 
      return A(paramLong2, 108086391056891904L, paramLong4, 0L);
    case 'r': 
      return A(paramLong2, 0L, paramLong4, 240L);
    case 't': 
      return A(paramLong2, 81363860455424L, paramLong4, 18178L);
    }
    return B(2, paramLong2, paramLong4);
  }
  
  private final int A(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    if ((paramLong2 &= paramLong1 | paramLong4 &= paramLong3) == 0L) {
      return B(2, paramLong1, paramLong3);
    }
    try
    {
      this.curChar = this.input_stream.readChar();
    }
    catch (IOException localIOException)
    {
      A(3, paramLong2, paramLong4);
      return 4;
    }
    switch (this.curChar)
    {
    case 'W': 
      return D(paramLong2, 0L, paramLong4, 4L);
    case 'a': 
      return D(paramLong2, 3566850904877432832L, paramLong4, 0L);
    case 'b': 
      return D(paramLong2, 2199023255552L, paramLong4, 0L);
    case 'c': 
      return D(paramLong2, 35459249995776L, paramLong4, 0L);
    case 'e': 
      return D(paramLong2, 144255925564211200L, paramLong4, 0L);
    case 'i': 
      return D(paramLong2, 0L, paramLong4, 14344L);
    case 'm': 
      return D(paramLong2, 0L, paramLong4, 240L);
    case 'n': 
      if ((paramLong2 & 0x100000000) != 0L) {
        return C(4, 32, 0);
      }
      break;
    case 'q': 
      return D(paramLong2, -4611686018427387904L, paramLong4, 0L);
    case 'r': 
      return D(paramLong2, 17594333528064L, paramLong4, 0L);
    case 's': 
      return D(paramLong2, 27021597764222976L, paramLong4, 18178L);
    case 't': 
      return D(paramLong2, 864770293292335104L, paramLong4, 1L);
    case 'x': 
      return D(paramLong2, 4398046511104L, paramLong4, 0L);
    }
    return B(3, paramLong2, paramLong4);
  }
  
  private final int D(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    if ((paramLong2 &= paramLong1 | paramLong4 &= paramLong3) == 0L) {
      return B(3, paramLong1, paramLong3);
    }
    try
    {
      this.curChar = this.input_stream.readChar();
    }
    catch (IOException localIOException)
    {
      A(4, paramLong2, paramLong4);
      return 5;
    }
    switch (this.curChar)
    {
    case 'T': 
      return E(paramLong2, 0L, paramLong4, 1L);
    case 'W': 
      return E(paramLong2, 0L, paramLong4, 1794L);
    case 'a': 
      return E(paramLong2, 70368744177664L, paramLong4, 0L);
    case 'b': 
      return E(paramLong2, 8796093022208L, paramLong4, 0L);
    case 'c': 
      return E(paramLong2, 108086391056891904L, paramLong4, 0L);
    case 'd': 
      return E(paramLong2, 0L, paramLong4, 14344L);
    case 'e': 
      if ((paramLong2 & 0x400000000000000) != 0L) {
        return C(5, 58, 0);
      }
      if ((paramLong2 & 0x800000000000000) != 0L) {
        return C(5, 59, 0);
      }
      break;
    case 'h': 
      if ((paramLong2 & 0x20000000000000) != 0L) {
        return C(5, 53, 0);
      }
      if ((paramLong2 & 0x40000000000000) != 0L) {
        return C(5, 54, 0);
      }
      break;
    case 'l': 
      if ((paramLong2 & 0x20000000000) != 0L) {
        return C(5, 41, 0);
      }
      return E(paramLong2, 35184372088832L, paramLong4, 0L);
    case 'p': 
      return E(paramLong2, 274877906944L, paramLong4, 16384L);
    case 'r': 
      return E(paramLong2, 3458764513820540928L, paramLong4, 4L);
    case 's': 
      return E(paramLong2, 140739635838976L, paramLong4, 0L);
    case 't': 
      if ((paramLong2 & 0x40000000000) != 0L) {
        return C(5, 42, 0);
      }
      if ((paramLong2 & 0x200000000000000) != 0L) {
        return C(5, 57, 0);
      }
      return E(paramLong2, 17592186044416L, paramLong4, 240L);
    case 'u': 
      return E(paramLong2, -4611686018427387904L, paramLong4, 0L);
    }
    return B(4, paramLong2, paramLong4);
  }
  
  private final int E(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    if ((paramLong2 &= paramLong1 | paramLong4 &= paramLong3) == 0L) {
      return B(4, paramLong1, paramLong3);
    }
    try
    {
      this.curChar = this.input_stream.readChar();
    }
    catch (IOException localIOException)
    {
      A(5, paramLong2, paramLong4);
      return 6;
    }
    switch (this.curChar)
    {
    case 'a': 
      return G(paramLong2, 0L, paramLong4, 4L);
    case 'b': 
      return G(paramLong2, 87960930222080L, paramLong4, 0L);
    case 'e': 
      if ((paramLong2 & 0x80000000000000) != 0L) {
        return C(6, 55, 0);
      }
      if ((paramLong2 & 0x100000000000000) != 0L) {
        return C(6, 56, 0);
      }
      return G(paramLong2, 2147483648L, paramLong4, 16385L);
    case 'g': 
      if ((paramLong2 & 0x4000000000) != 0L) {
        return C(6, 38, 0);
      }
      break;
    case 'h': 
      return G(paramLong2, 140737488355328L, paramLong4, 0L);
    case 'i': 
      return G(paramLong2, 0L, paramLong4, 1794L);
    case 'k': 
      if ((paramLong2 & 0x1000000000000000) != 0L) {
        return C(6, 60, 0);
      }
      if ((paramLong2 & 0x2000000000000000) != 0L) {
        return C(6, 61, 0);
      }
      break;
    case 'l': 
      if ((paramLong2 & 0x80000000000) != 0L) {
        return C(6, 43, 0);
      }
      break;
    case 'o': 
      return G(paramLong2, -4611686018427387904L, paramLong4, 0L);
    case 't': 
      return G(paramLong2, 0L, paramLong4, 14344L);
    case 'v': 
      return G(paramLong2, 35184372088832L, paramLong4, 0L);
    case 'x': 
      return G(paramLong2, 0L, paramLong4, 240L);
    }
    return B(5, paramLong2, paramLong4);
  }
  
  private final int G(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    if ((paramLong2 &= paramLong1 | paramLong4 &= paramLong3) == 0L) {
      return B(5, paramLong1, paramLong3);
    }
    try
    {
      this.curChar = this.input_stream.readChar();
    }
    catch (IOException localIOException)
    {
      A(6, paramLong2, paramLong4);
      return 7;
    }
    switch (this.curChar)
    {
    case 'c': 
      return I(paramLong2, 0L, paramLong4, 16384L);
    case 'd': 
      return I(paramLong2, 0L, paramLong4, 1794L);
    case 'e': 
      return I(paramLong2, 140737488355328L, paramLong4, 0L);
    case 'h': 
      if ((paramLong4 & 0x8) != 0L) {
        return D(7, 67);
      }
      if ((paramLong4 & 0x2000) != 0L)
      {
        this.Ã = 77;
        this.¤ = 7;
      }
      return I(paramLong2, 0L, paramLong4, 6144L);
    case 'l': 
      if ((paramLong2 & 0x100000000000) != 0L) {
        return C(7, 44, 0);
      }
      if ((paramLong2 & 0x200000000000) != 0L) {
        return C(7, 45, 0);
      }
      return I(paramLong2, 70368744177664L, paramLong4, 0L);
    case 'p': 
      if ((paramLong4 & 0x4) != 0L) {
        return D(7, 66);
      }
      break;
    case 't': 
      if ((paramLong2 & 0x80000000) != 0L) {
        return C(7, 31, 0);
      }
      return I(paramLong2, -4611686018427387904L, paramLong4, 240L);
    case 'x': 
      return I(paramLong2, 0L, paramLong4, 1L);
    }
    return B(6, paramLong2, paramLong4);
  }
  
  private final int I(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    if ((paramLong2 &= paramLong1 | paramLong4 &= paramLong3) == 0L) {
      return B(6, paramLong1, paramLong3);
    }
    try
    {
      this.curChar = this.input_stream.readChar();
    }
    catch (IOException localIOException)
    {
      A(7, paramLong2, paramLong4);
      return 8;
    }
    switch (this.curChar)
    {
    case 'A': 
      if ((paramLong4 & 0x800) != 0L) {
        return D(8, 75);
      }
      break;
    case 'B': 
      if ((paramLong4 & 0x1000) != 0L) {
        return D(8, 76);
      }
      return B(paramLong2, 0L, paramLong4, 16L);
    case 'L': 
      return B(paramLong2, 0L, paramLong4, 32L);
    case 'R': 
      return B(paramLong2, 0L, paramLong4, 64L);
    case 'T': 
      return B(paramLong2, 0L, paramLong4, 128L);
    case 'e': 
      if ((paramLong2 & 0x400000000000) != 0L) {
        return C(8, 46, 0);
      }
      if ((paramLong2 & 0x4000000000000000) != 0L) {
        return C(8, 62, 0);
      }
      if ((paramLong2 & 0x8000000000000000) != 0L) {
        return C(8, 63, 0);
      }
      return B(paramLong2, 140737488355328L, paramLong4, 0L);
    case 'i': 
      return B(paramLong2, 0L, paramLong4, 16384L);
    case 't': 
      if ((paramLong4 & 1L) != 0L) {
        return D(8, 64);
      }
      return B(paramLong2, 0L, paramLong4, 1794L);
    }
    return B(7, paramLong2, paramLong4);
  }
  
  private final int B(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    if ((paramLong2 &= paramLong1 | paramLong4 &= paramLong3) == 0L) {
      return B(7, paramLong1, paramLong3);
    }
    try
    {
      this.curChar = this.input_stream.readChar();
    }
    catch (IOException localIOException)
    {
      A(8, paramLong2, paramLong4);
      return 9;
    }
    switch (this.curChar)
    {
    case 'e': 
      return C(paramLong2, 0L, paramLong4, 32L);
    case 'f': 
      return C(paramLong2, 0L, paramLong4, 16384L);
    case 'h': 
      if ((paramLong4 & 0x2) != 0L) {
        return D(9, 65);
      }
      if ((paramLong4 & 0x400) != 0L)
      {
        this.Ã = 74;
        this.¤ = 9;
      }
      return C(paramLong2, 0L, paramLong4, 768L);
    case 'i': 
      return C(paramLong2, 0L, paramLong4, 64L);
    case 'o': 
      return C(paramLong2, 0L, paramLong4, 144L);
    case 't': 
      if ((paramLong2 & 0x800000000000) != 0L) {
        return C(9, 47, 0);
      }
      break;
    }
    return B(8, paramLong2, paramLong4);
  }
  
  private final int C(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    if ((paramLong2 &= paramLong1 | paramLong4 &= paramLong3) == 0L) {
      return B(8, paramLong1, paramLong3);
    }
    try
    {
      this.curChar = this.input_stream.readChar();
    }
    catch (IOException localIOException)
    {
      A(9, 0L, paramLong4);
      return 10;
    }
    switch (this.curChar)
    {
    case 'A': 
      if ((paramLong4 & 0x100) != 0L) {
        return D(10, 72);
      }
      break;
    case 'B': 
      if ((paramLong4 & 0x200) != 0L) {
        return D(10, 73);
      }
      break;
    case 'f': 
      return A(paramLong4, 32L);
    case 'g': 
      return A(paramLong4, 64L);
    case 'p': 
      if ((paramLong4 & 0x80) != 0L) {
        return D(10, 71);
      }
      break;
    case 't': 
      return A(paramLong4, 16L);
    case 'y': 
      return A(paramLong4, 16384L);
    }
    return B(9, 0L, paramLong4);
  }
  
  private final int A(long paramLong1, long paramLong2)
  {
    if ((paramLong2 &= paramLong1) == 0L) {
      return B(9, 0L, paramLong1);
    }
    try
    {
      this.curChar = this.input_stream.readChar();
    }
    catch (IOException localIOException)
    {
      A(10, 0L, paramLong2);
      return 11;
    }
    switch (this.curChar)
    {
    case 'g': 
      return B(paramLong2, 16384L);
    case 'h': 
      return B(paramLong2, 64L);
    case 't': 
      if ((paramLong2 & 0x20) != 0L) {
        return D(11, 69);
      }
      return B(paramLong2, 16L);
    }
    return B(10, 0L, paramLong2);
  }
  
  private final int B(long paramLong1, long paramLong2)
  {
    if ((paramLong2 &= paramLong1) == 0L) {
      return B(10, 0L, paramLong1);
    }
    try
    {
      this.curChar = this.input_stream.readChar();
    }
    catch (IOException localIOException)
    {
      A(11, 0L, paramLong2);
      return 12;
    }
    switch (this.curChar)
    {
    case 'e': 
      return C(paramLong2, 16384L);
    case 'o': 
      return C(paramLong2, 16L);
    case 't': 
      if ((paramLong2 & 0x40) != 0L) {
        return D(12, 70);
      }
      break;
    }
    return B(11, 0L, paramLong2);
  }
  
  private final int C(long paramLong1, long paramLong2)
  {
    if ((paramLong2 &= paramLong1) == 0L) {
      return B(11, 0L, paramLong1);
    }
    try
    {
      this.curChar = this.input_stream.readChar();
    }
    catch (IOException localIOException)
    {
      A(12, 0L, paramLong2);
      return 13;
    }
    switch (this.curChar)
    {
    case 'm': 
      if ((paramLong2 & 0x10) != 0L) {
        return C(13, 68, 0);
      }
      break;
    case 'n': 
      return D(paramLong2, 16384L);
    }
    return B(12, 0L, paramLong2);
  }
  
  private final int D(long paramLong1, long paramLong2)
  {
    if ((paramLong2 &= paramLong1) == 0L) {
      return B(12, 0L, paramLong1);
    }
    try
    {
      this.curChar = this.input_stream.readChar();
    }
    catch (IOException localIOException)
    {
      A(13, 0L, paramLong2);
      return 14;
    }
    switch (this.curChar)
    {
    case 'N': 
      if ((paramLong2 & 0x4000) != 0L) {
        return C(14, 78, 0);
      }
      break;
    }
    return B(13, 0L, paramLong2);
  }
  
  private final int A(int paramInt1, int paramInt2)
  {
    int i = 0;
    this.À = 3;
    int j = 1;
    this.y[0] = paramInt1;
    int k = Integer.MAX_VALUE;
    for (;;)
    {
      if (++this.x == Integer.MAX_VALUE) {
        B();
      }
      long l1;
      if (this.curChar < '@')
      {
        l1 = 1L << this.curChar;
        do
        {
          switch (this.y[(--j)])
          {
          case 1: 
            if ((0x3FF000000000000 & l1) != 0L)
            {
              if (k > 82) {
                k = 82;
              }
              A(2);
            }
            else if (this.curChar == '-')
            {
              A(2);
            }
            break;
          case 2: 
            if ((0x3FF000000000000 & l1) != 0L)
            {
              k = 82;
              A(2);
            }
            break;
          }
        } while (j != i);
      }
      else if (this.curChar < '')
      {
        l1 = 1L << (this.curChar & 0x3F);
        do
        {
          switch (this.y[(--j)])
          {
          case 0: 
          case 1: 
            if ((0x7FFFFFE00084004 & l1) != 0L)
            {
              k = 80;
              A(0);
            }
            break;
          }
        } while (j != i);
      }
      else
      {
        int m = this.curChar >> '\b';
        int n = m >> 6;
        long l2 = 1L << (m & 0x3F);
        int i1 = (this.curChar & 0xFF) >> '\006';
        long l3 = 1L << (this.curChar & 0x3F);
        do
        {
          this.y[(--j)];
        } while (j != i);
      }
      if (k != Integer.MAX_VALUE)
      {
        this.Ã = k;
        this.¤ = paramInt2;
        k = Integer.MAX_VALUE;
      }
      paramInt2++;
      if ((j = this.À) == (i = 3 - (this.À = i))) {
        return paramInt2;
      }
      try
      {
        this.curChar = this.input_stream.readChar();
      }
      catch (IOException localIOException) {}
    }
    return paramInt2;
  }
  
  private static final boolean A(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2)
  {
    switch (paramInt1)
    {
    case 0: 
      return (Ä[paramInt3] & paramLong2) != 0L;
    }
    return (Å[paramInt2] & paramLong1) != 0L;
  }
  
  public RTFParserTokenManager(SimpleCharStream paramSimpleCharStream)
  {
    this.input_stream = paramSimpleCharStream;
  }
  
  public RTFParserTokenManager(SimpleCharStream paramSimpleCharStream, int paramInt)
  {
    this(paramSimpleCharStream);
    SwitchTo(paramInt);
  }
  
  public void ReInit(SimpleCharStream paramSimpleCharStream)
  {
    this.¤ = (this.À = 0);
    this.Æ = this.¥;
    this.input_stream = paramSimpleCharStream;
    B();
  }
  
  private final void B()
  {
    this.x = -2147483647;
    int i = 3;
    while (i-- > 0) {
      this.ª[i] = Integer.MIN_VALUE;
    }
  }
  
  public void ReInit(SimpleCharStream paramSimpleCharStream, int paramInt)
  {
    ReInit(paramSimpleCharStream);
    SwitchTo(paramInt);
  }
  
  public void SwitchTo(int paramInt)
  {
    if ((paramInt >= 3) || (paramInt < 0)) {
      throw new TokenMgrError("Error: Ignoring invalid lexical state : " + paramInt + ". State unchanged.", 2);
    }
    this.Æ = paramInt;
  }
  
  protected Token jjFillToken()
  {
    Token localToken = Token.newToken(this.Ã);
    localToken.kind = this.Ã;
    String str = jjstrLiteralImages[this.Ã];
    localToken.image = (str == null ? this.input_stream.GetImage() : str);
    localToken.beginLine = this.input_stream.getBeginLine();
    localToken.beginColumn = this.input_stream.getBeginColumn();
    localToken.endLine = this.input_stream.getEndLine();
    localToken.endColumn = this.input_stream.getEndColumn();
    return localToken;
  }
  
  public Token getNextToken()
  {
    Object localObject = null;
    int i = 0;
    Token localToken;
    try
    {
      this.curChar = this.input_stream.BeginToken();
    }
    catch (IOException localIOException1)
    {
      this.Ã = 0;
      localToken = jjFillToken();
      return localToken;
    }
    this.º = null;
    this.¢ = 0;
    for (;;)
    {
      switch (this.Æ)
      {
      case 0: 
        this.Ã = Integer.MAX_VALUE;
        this.¤ = 0;
        i = D();
        if ((this.¤ == 0) && (this.Ã > 83)) {
          this.Ã = 83;
        }
        break;
      case 1: 
        this.Ã = Integer.MAX_VALUE;
        this.¤ = 0;
        i = A();
        break;
      case 2: 
        try
        {
          this.input_stream.backup(0);
          do
          {
            this.curChar = this.input_stream.BeginToken();
            if (this.curChar > '\r') {
              break;
            }
          } while ((0x2600 & 1L << this.curChar) != 0L);
        }
        catch (IOException localIOException2) {}
        break;
        this.Ã = Integer.MAX_VALUE;
        this.¤ = 0;
        i = C();
      default: 
        if (this.Ã != Integer.MAX_VALUE)
        {
          if (this.¤ + 1 < i) {
            this.input_stream.backup(i - this.¤ - 1);
          }
          if ((z[(this.Ã >> 6)] & 1L << (this.Ã & 0x3F)) != 0L)
          {
            localToken = jjFillToken();
            A(localToken);
            if (jjnewLexState[this.Ã] != -1) {
              this.Æ = jjnewLexState[this.Ã];
            }
            return localToken;
          }
          if ((Á[(this.Ã >> 6)] & 1L << (this.Ã & 0x3F)) != 0L)
          {
            if (jjnewLexState[this.Ã] == -1) {
              break;
            }
            this.Æ = jjnewLexState[this.Ã];
            break;
          }
          this.¢ += this.¤ + 1;
          if (jjnewLexState[this.Ã] != -1) {
            this.Æ = jjnewLexState[this.Ã];
          }
          i = 0;
          this.Ã = Integer.MAX_VALUE;
          try
          {
            this.curChar = this.input_stream.readChar();
          }
          catch (IOException localIOException3) {}
        }
        break;
      }
    }
    int j = this.input_stream.getEndLine();
    int k = this.input_stream.getEndColumn();
    String str = null;
    boolean bool = false;
    try
    {
      this.input_stream.readChar();
      this.input_stream.backup(1);
    }
    catch (IOException localIOException4)
    {
      bool = true;
      str = i <= 1 ? "" : this.input_stream.GetImage();
      if ((this.curChar == '\n') || (this.curChar == '\r'))
      {
        j++;
        k = 0;
      }
      else
      {
        k++;
      }
    }
    if (!bool)
    {
      this.input_stream.backup(1);
      str = i <= 1 ? "" : this.input_stream.GetImage();
    }
    throw new TokenMgrError(bool, this.Æ, j, k, str, this.curChar, 0);
  }
  
  void A(Token paramToken)
  {
    switch (this.Ã)
    {
    case 8: 
      if (this.º == null) {
        this.º = new StringBuffer(jjstrLiteralImages[8]);
      } else {
        this.º.append(jjstrLiteralImages[8]);
      }
      paramToken.image = " ";
      break;
    case 9: 
      if (this.º == null) {
        this.º = new StringBuffer(jjstrLiteralImages[9]);
      } else {
        this.º.append(jjstrLiteralImages[9]);
      }
      paramToken.image = "­";
      break;
    case 10: 
      if (this.º == null) {
        this.º = new StringBuffer(jjstrLiteralImages[10]);
      } else {
        this.º.append(jjstrLiteralImages[10]);
      }
      paramToken.image = "‑";
      break;
    case 16: 
      if (this.º == null) {
        this.º = new StringBuffer(jjstrLiteralImages[16]);
      } else {
        this.º.append(jjstrLiteralImages[16]);
      }
      paramToken.image = "{";
      break;
    case 17: 
      if (this.º == null) {
        this.º = new StringBuffer(jjstrLiteralImages[17]);
      } else {
        this.º.append(jjstrLiteralImages[17]);
      }
      paramToken.image = "}";
      break;
    case 18: 
      if (this.º == null) {
        this.º = new StringBuffer(jjstrLiteralImages[18]);
      } else {
        this.º.append(jjstrLiteralImages[18]);
      }
      paramToken.image = "\\";
      break;
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\rtf\RTFParserTokenManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */