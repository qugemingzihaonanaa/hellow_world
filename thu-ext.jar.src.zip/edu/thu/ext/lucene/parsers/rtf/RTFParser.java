package edu.thu.ext.lucene.parsers.rtf;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Stack;
import java.util.Vector;

public class RTFParser
  implements RTFParserDelegate, RTFParserConstants
{
  private static final String[] Ô = new String['ÿ'];
  private static final int[] Ü;
  private static final String[] Þ;
  private static final Integer Ò;
  private Integer Ð = Ò;
  private final Stack Õ = new Stack();
  private static final String Ñ = "Cp1252";
  private String á = "Cp1252";
  private int Ì = 0;
  private final Map ß = new HashMap();
  private String Ï = "Cp1252";
  private final Stack Ù = new Stack();
  private int â = 0;
  private final Map ä = new HashMap();
  private final Stack É = new Stack();
  private String ã = NO_STYLE;
  private int Ç = 0;
  private int Ø = 0;
  private String Ê;
  private RTFParserDelegate å = this;
  public RTFParserTokenManager token_source;
  SimpleCharStream Û;
  public Token token;
  public Token jj_nt;
  private int à;
  private int Ý;
  private final int[] Ó = new int[21];
  private static int[] Î;
  private static int[] Í;
  private static int[] Ë;
  private Vector Ö = new Vector();
  private int[] Ú;
  private int È = -1;
  
  static
  {
    Ô[0] = "Cp1252";
    Ô[1] = "Cp1252";
    Ô[2] = "Cp1252";
    Ô[3] = null;
    Ô[77] = "MacRoman";
    Ô[''] = "MS932";
    Ô[''] = "MS949";
    Ô[''] = "Johab";
    Ô[''] = "MS936";
    Ô[''] = "MS950";
    Ô['¡'] = "Cp1253";
    Ô['¢'] = "Cp1254";
    Ô['£'] = "Cp1258";
    Ô['±'] = "Cp1255";
    Ô['²'] = "Cp1256";
    Ô['³'] = "Cp1256";
    Ô['´'] = "Cp1256";
    Ô['µ'] = "Cp1255";
    Ô['º'] = "Cp1257";
    Ô['Ì'] = "Cp866";
    Ô['Þ'] = "MS874";
    Ô['î'] = "Cp1250";
    Ô['þ'] = "Cp437";
    Ü = new int[] { 437, 819, 850, 852, 860, 862, 863, 864, 865, 866, 874, 932, 936, 949, 950, 1250, 1251, 1252, 1253, 1254, 1255, 1256, 1257, 1258, 1361 };
    Þ = new String[] { "Cp437", "Cp819", "Cp850", "Cp852", "Cp860", "Cp862", "Cp863", "Cp864", "Cp865", "Cp866", "MS874", "MS932", "MS936", "MS949", "MS950", "Cp1250", "Cp1251", "Cp1252", "Cp1253", "Cp1254", "Cp1255", "Cp1256", "Cp1257", "Cp1258", "Johab" };
    Ò = new Integer(1);
    G();
    L();
    F();
  }
  
  private static final String C(int paramInt)
  {
    int i = Arrays.binarySearch(Ü, paramInt);
    return i < 0 ? null : Þ[i];
  }
  
  public static void main(String[] paramArrayOfString)
    throws ParseException
  {
    RTFParser localRTFParser = createParser(new InputStreamReader(System.in));
    localRTFParser.parse();
  }
  
  public void reinitialize(Reader paramReader)
  {
    ReInit(paramReader);
  }
  
  public static RTFParser createParser(Reader paramReader)
  {
    return new RTFParser(paramReader);
  }
  
  public void parse()
    throws ParseException
  {
    try
    {
      document();
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      throw new ParseException("Could not decode bytes in encoding: " + localUnsupportedEncodingException.getMessage());
    }
  }
  
  public void setDelegate(RTFParserDelegate paramRTFParserDelegate)
  {
    this.å = paramRTFParserDelegate;
  }
  
  public String getNewLine()
  {
    return this.Ê;
  }
  
  public void setNewLine(String paramString)
  {
    this.Ê = paramString;
  }
  
  public int getFontForEncoding(String paramString)
  {
    Iterator localIterator = this.ß.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      if (localEntry.getValue().equals(paramString)) {
        return ((Integer)localEntry.getKey()).intValue();
      }
    }
    return -1;
  }
  
  public void text(String paramString1, String paramString2, int paramInt)
  {
    System.out.println(paramString1);
  }
  
  public void controlSymbol(String paramString, int paramInt) {}
  
  public void controlWord(String paramString, int paramInt1, int paramInt2) {}
  
  public void openGroup(int paramInt) {}
  
  public void closeGroup(int paramInt) {}
  
  public void styleList(List paramList) {}
  
  public void startDocument() {}
  
  public void endDocument() {}
  
  private void B(String paramString)
  {
    if (paramString == null) {
      throw new IllegalArgumentException("current encoding cannot be null");
    }
    this.Ï = paramString;
  }
  
  private String J()
  {
    if (this.Ç == 0) {
      return this.Ï;
    }
    return this.á;
  }
  
  private String I()
  {
    return this.ã;
  }
  
  private void C(String paramString)
  {
    this.ã = paramString;
  }
  
  private Integer K()
  {
    return this.Ð;
  }
  
  private void A(Integer paramInteger)
  {
    this.Ð = paramInteger;
  }
  
  private void D(String paramString)
  {
    if (paramString == null) {
      throw new IllegalArgumentException("document encoding cannot be null");
    }
    this.á = paramString;
  }
  
  private byte[] E(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    byte[] arrayOfByte = new byte[arrayOfChar.length];
    for (int i = 0; i < arrayOfChar.length; i++) {
      arrayOfByte[i] = ((byte)arrayOfChar[i]);
    }
    return arrayOfByte;
  }
  
  public final void text()
    throws ParseException, UnsupportedEncodingException
  {
    StringBuffer localStringBuffer1 = new StringBuffer();
    StringBuffer localStringBuffer2 = new StringBuffer();
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    for (;;)
    {
      byte[] arrayOfByte;
      switch (this.à == -1 ? H() : this.à)
      {
      case 8: 
      case 9: 
      case 10: 
      case 11: 
      case 12: 
      case 16: 
      case 17: 
      case 18: 
      case 27: 
      case 48: 
      case 49: 
      case 50: 
      case 51: 
      case 52: 
      case 53: 
      case 54: 
      case 55: 
      case 56: 
      case 57: 
      case 58: 
      case 59: 
      case 60: 
      case 61: 
      case 62: 
      case 63: 
        switch (this.à == -1 ? H() : this.à)
        {
        case 27: 
          u(localStringBuffer2);
          arrayOfByte = E();
          if (arrayOfByte != null) {
            localStringBuffer2.append(new String(arrayOfByte, J()));
          }
          break;
        case 16: 
        case 17: 
        case 18: 
          escaped(localStringBuffer2);
          break;
        case 11: 
        case 12: 
        case 48: 
        case 49: 
        case 50: 
        case 51: 
        case 52: 
        case 53: 
        case 54: 
        case 55: 
        case 56: 
        case 57: 
        case 58: 
        case 59: 
        case 60: 
        case 61: 
        case 62: 
        case 63: 
          special_character(localStringBuffer2);
          break;
        case 8: 
        case 9: 
        case 10: 
          textual_control_symbol(localStringBuffer2);
          break;
        case 13: 
        case 14: 
        case 15: 
        case 19: 
        case 20: 
        case 21: 
        case 22: 
        case 23: 
        case 24: 
        case 25: 
        case 26: 
        case 28: 
        case 29: 
        case 30: 
        case 31: 
        case 32: 
        case 33: 
        case 34: 
        case 35: 
        case 36: 
        case 37: 
        case 38: 
        case 39: 
        case 40: 
        case 41: 
        case 42: 
        case 43: 
        case 44: 
        case 45: 
        case 46: 
        case 47: 
        default: 
          this.Ó[0] = this.Ý;
          D(-1);
          throw new ParseException();
        }
        if (localByteArrayOutputStream.size() > 0)
        {
          localStringBuffer1.append(localByteArrayOutputStream.toString(J()));
          localByteArrayOutputStream.reset();
        }
        localStringBuffer1.append(localStringBuffer2.toString());
        localStringBuffer2.setLength(0);
        break;
      case 22: 
        int i = hex();
        localByteArrayOutputStream.write(i);
        break;
      case 20: 
        arrayOfByte = raw_text();
        localByteArrayOutputStream.write(arrayOfByte, 0, arrayOfByte.length);
        break;
      case 13: 
      case 14: 
      case 15: 
      case 19: 
      case 21: 
      case 23: 
      case 24: 
      case 25: 
      case 26: 
      case 28: 
      case 29: 
      case 30: 
      case 31: 
      case 32: 
      case 33: 
      case 34: 
      case 35: 
      case 36: 
      case 37: 
      case 38: 
      case 39: 
      case 40: 
      case 41: 
      case 42: 
      case 43: 
      case 44: 
      case 45: 
      case 46: 
      case 47: 
      default: 
        this.Ó[1] = this.Ý;
        D(-1);
        throw new ParseException();
      }
      switch (this.à == -1 ? H() : this.à)
      {
      }
    }
    this.Ó[2] = this.Ý;
    if (localByteArrayOutputStream.size() > 0)
    {
      localStringBuffer1.append(localByteArrayOutputStream.toString(J()));
      localByteArrayOutputStream.reset();
    }
    if (this.Ç == 4) {
      this.ä.put(new Integer(this.â), localStringBuffer1.toString());
    }
    this.å.text(localStringBuffer1.toString(), I(), this.Ç);
  }
  
  public final byte[] raw_text()
    throws ParseException, UnsupportedEncodingException
  {
    Token localToken = D(20);
    return E(localToken.image);
  }
  
  public final void escaped(StringBuffer paramStringBuffer)
    throws ParseException
  {
    Token localToken;
    switch (this.à == -1 ? H() : this.à)
    {
    case 18: 
      localToken = D(18);
      break;
    case 16: 
      localToken = D(16);
      break;
    case 17: 
      localToken = D(17);
      break;
    default: 
      this.Ó[3] = this.Ý;
      D(-1);
      throw new ParseException();
    }
    paramStringBuffer.append(localToken.image.charAt(0));
  }
  
  public final void textual_control_symbol(StringBuffer paramStringBuffer)
    throws ParseException
  {
    Token localToken;
    switch (this.à == -1 ? H() : this.à)
    {
    case 8: 
      localToken = D(8);
      break;
    case 9: 
      localToken = D(9);
      break;
    case 10: 
      localToken = D(10);
      break;
    default: 
      this.Ó[4] = this.Ý;
      D(-1);
      throw new ParseException();
    }
    paramStringBuffer.append(localToken.image);
  }
  
  public final byte hex()
    throws ParseException
  {
    Token localToken = D(22);
    byte b = (byte)Integer.parseInt(localToken.image.substring(2), 16);
    return b;
  }
  
  public final void special_character(StringBuffer paramStringBuffer)
    throws ParseException
  {
    switch (this.à == -1 ? H() : this.à)
    {
    case 52: 
      D(52);
      paramStringBuffer.append('\r');
      break;
    case 48: 
      D(48);
      paramStringBuffer.append('\t');
      break;
    case 53: 
      D(53);
      paramStringBuffer.append('—');
      break;
    case 54: 
      D(54);
      paramStringBuffer.append('–');
      break;
    case 55: 
      D(55);
      paramStringBuffer.append(' ');
      break;
    case 56: 
      D(56);
      paramStringBuffer.append(' ');
      break;
    case 57: 
      D(57);
      paramStringBuffer.append('•');
      break;
    case 58: 
      D(58);
      paramStringBuffer.append('‘');
      break;
    case 59: 
      D(59);
      paramStringBuffer.append('’');
      break;
    case 62: 
      D(62);
      paramStringBuffer.append('“');
      break;
    case 63: 
      D(63);
      paramStringBuffer.append('”');
      break;
    case 60: 
      D(60);
      paramStringBuffer.append('‎');
      break;
    case 61: 
      D(61);
      paramStringBuffer.append('‏');
      break;
    case 49: 
      D(49);
      paramStringBuffer.append('‍');
      break;
    case 50: 
      D(50);
      paramStringBuffer.append('‌');
      break;
    case 11: 
    case 12: 
    case 51: 
      switch (this.à == -1 ? H() : this.à)
      {
      case 51: 
        D(51);
        break;
      case 11: 
        D(11);
        break;
      case 12: 
        D(12);
        break;
      default: 
        this.Ó[5] = this.Ý;
        D(-1);
        throw new ParseException();
      }
      paramStringBuffer.append(getNewLine());
      break;
    default: 
      this.Ó[6] = this.Ý;
      D(-1);
      throw new ParseException();
    }
  }
  
  public final void lbrace()
    throws ParseException
  {
    D(6);
    this.Ù.push(J());
    this.Õ.push(K());
    this.É.push(I());
    this.å.openGroup(++this.Ø);
  }
  
  public final void rbrace()
    throws ParseException
  {
    D(7);
    A((Integer)this.Õ.pop());
    B((String)this.Ù.pop());
    C((String)this.É.pop());
    this.å.closeGroup(this.Ø);
    if (1 == --this.Ø)
    {
      if (this.Ç == 4) {
        this.å.styleList(new ArrayList(this.ä.values()));
      }
      this.Ç = 0;
    }
  }
  
  public final void table_declaration()
    throws ParseException
  {
    switch (this.à == -1 ? H() : this.à)
    {
    case 40: 
      D(40);
      this.Ç = 8;
      break;
    case 43: 
      D(43);
      this.Ç = 1;
      break;
    case 44: 
      D(44);
      this.Ç = 3;
      break;
    case 47: 
      D(47);
      this.Ç = 4;
      break;
    case 46: 
      D(46);
      this.Ç = 5;
      break;
    case 41: 
      D(41);
      this.Ç = 7;
      break;
    case 42: 
      D(42);
      switch (this.à == -1 ? H() : this.à)
      {
      case 82: 
        D(82);
        break;
      default: 
        this.Ó[7] = this.Ý;
      }
      this.Ç = 9;
      break;
    case 45: 
      D(45);
      switch (this.à == -1 ? H() : this.à)
      {
      case 82: 
        D(82);
        break;
      default: 
        this.Ó[8] = this.Ý;
      }
      this.Ç = 9;
      break;
    default: 
      this.Ó[9] = this.Ý;
      D(-1);
      throw new ParseException();
    }
  }
  
  public final void control_symbol()
    throws ParseException
  {
    Token localToken = null;
    switch (this.à == -1 ? H() : this.à)
    {
    case 19: 
      localToken = D(19);
      break;
    case 13: 
      localToken = D(13);
      break;
    case 14: 
      localToken = D(14);
      break;
    case 15: 
      localToken = D(15);
      break;
    case 16: 
    case 17: 
    case 18: 
    default: 
      this.Ó[10] = this.Ý;
      D(-1);
      throw new ParseException();
    }
    this.å.controlSymbol(localToken.image, this.Ç);
  }
  
  public final Token mixed_case_control_word()
    throws ParseException
  {
    Token localToken = null;
    switch (this.à == -1 ? H() : this.à)
    {
    case 64: 
      localToken = D(64);
      break;
    case 65: 
      localToken = D(65);
      break;
    case 66: 
      localToken = D(66);
      break;
    case 67: 
      localToken = D(67);
      break;
    case 68: 
      localToken = D(68);
      break;
    case 69: 
      localToken = D(69);
      break;
    case 70: 
      localToken = D(70);
      break;
    case 71: 
      localToken = D(71);
      break;
    case 72: 
      localToken = D(72);
      break;
    case 73: 
      localToken = D(73);
      break;
    case 74: 
      localToken = D(74);
      break;
    case 75: 
      localToken = D(75);
      break;
    case 76: 
      localToken = D(76);
      break;
    case 77: 
      localToken = D(77);
      break;
    case 78: 
      localToken = D(78);
      break;
    default: 
      this.Ó[11] = this.Ý;
      D(-1);
      throw new ParseException();
    }
    return localToken;
  }
  
  public final void control_word()
    throws ParseException
  {
    Token localToken1 = null;
    Token localToken2 = null;
    switch (this.à == -1 ? H() : this.à)
    {
    case 80: 
      localToken1 = D(80);
      break;
    case 64: 
    case 65: 
    case 66: 
    case 67: 
    case 68: 
    case 69: 
    case 70: 
    case 71: 
    case 72: 
    case 73: 
    case 74: 
    case 75: 
    case 76: 
    case 77: 
    case 78: 
      localToken1 = mixed_case_control_word();
      break;
    case 79: 
    default: 
      this.Ó[12] = this.Ý;
      D(-1);
      throw new ParseException();
    }
    switch (this.à == -1 ? H() : this.à)
    {
    case 82: 
      localToken2 = D(82);
      break;
    default: 
      this.Ó[13] = this.Ý;
    }
    int i = localToken2 == null ? 0 : Integer.parseInt(localToken2.image);
    this.å.controlWord(localToken1.image, i, this.Ç);
  }
  
  public final void u(StringBuffer paramStringBuffer)
    throws ParseException
  {
    D(27);
    Token localToken = D(82);
    int i = Integer.parseInt(localToken.image);
    if (i < 0) {
      i += 65536;
    }
    paramStringBuffer.append((char)i);
  }
  
  byte[] E()
    throws ParseException, UnsupportedEncodingException
  {
    byte[] arrayOfByte1 = null;
    for (int i = K().intValue(); i != 0; i--)
    {
      Token localToken = getNextToken();
      switch (localToken.kind)
      {
      case 22: 
        break;
      case 20: 
        if (localToken.image.length() > i)
        {
          byte[] arrayOfByte2 = E(localToken.image);
          arrayOfByte1 = new byte[arrayOfByte2.length - i];
          System.arraycopy(arrayOfByte2, i, arrayOfByte1, 0, arrayOfByte1.length);
          return arrayOfByte1;
        }
        break;
      case 21: 
      default: 
        throw new IllegalStateException("unexpected token while skipping");
      }
    }
    return arrayOfByte1;
  }
  
  public final void uc()
    throws ParseException
  {
    Token localToken1 = null;
    Token localToken2 = null;
    localToken1 = D(28);
    localToken2 = D(82);
    int i = localToken2 == null ? 0 : Integer.parseInt(localToken2.image);
    A(new Integer(i));
  }
  
  public final void fcharset()
    throws ParseException
  {
    Token localToken1 = null;
    Token localToken2 = null;
    localToken1 = D(31);
    localToken2 = D(82);
    int i = localToken2 == null ? 0 : Integer.parseInt(localToken2.image);
    if (1 == this.Ç) {
      this.ß.put(new Integer(this.Ì), this.á);
    }
  }
  
  public final void deff()
    throws ParseException
  {
    Token localToken = null;
    D(39);
    localToken = D(82);
  }
  
  public final void f()
    throws ParseException
  {
    Token localToken = null;
    D(29);
    localToken = D(82);
    int i = localToken == null ? 0 : Integer.parseInt(localToken.image);
    if (1 == this.Ç)
    {
      this.Ì = i;
    }
    else if (this.Ç == 0)
    {
      String str = (String)this.ß.get(new Integer(i));
      B(str == null ? "Cp1252" : str);
    }
  }
  
  public final void cs()
    throws ParseException
  {
    Token localToken = null;
    D(30);
    localToken = D(82);
    int i = localToken == null ? 0 : Integer.parseInt(localToken.image);
    if (4 == this.Ç) {
      this.â = i;
    } else if (this.Ç == 0) {
      C((String)this.ä.get(new Integer(i)));
    }
  }
  
  public final void plain()
    throws ParseException
  {
    D(32);
    C(NO_STYLE);
  }
  
  public final void document_charset()
    throws ParseException
  {
    switch (this.à == -1 ? H() : this.à)
    {
    case 33: 
      D(33);
      D(C(437));
      break;
    case 34: 
      D(34);
      D(C(850));
      break;
    case 35: 
      D(35);
      D("MacRoman");
      break;
    case 37: 
      D(37);
      D(C(1252));
      break;
    case 36: 
    default: 
      this.Ó[14] = this.Ý;
      D(-1);
      throw new ParseException();
    }
  }
  
  public final void ansicpg()
    throws ParseException
  {
    Token localToken = null;
    D(38);
    localToken = D(82);
    int i = localToken == null ? 0 : Integer.parseInt(localToken.image);
    D(C(i));
    B(C(i));
  }
  
  public final void group()
    throws ParseException, UnsupportedEncodingException
  {
    lbrace();
    for (;;)
    {
      switch (this.à == -1 ? H() : this.à)
      {
      case 40: 
      case 41: 
      case 42: 
      case 43: 
      case 44: 
      case 45: 
      case 46: 
      case 47: 
        table_declaration();
        break;
      case 28: 
        uc();
        break;
      case 29: 
        f();
        break;
      case 31: 
        fcharset();
        break;
      case 30: 
        cs();
        break;
      case 32: 
        plain();
        break;
      case 64: 
      case 65: 
      case 66: 
      case 67: 
      case 68: 
      case 69: 
      case 70: 
      case 71: 
      case 72: 
      case 73: 
      case 74: 
      case 75: 
      case 76: 
      case 77: 
      case 78: 
      case 80: 
        control_word();
        break;
      case 13: 
      case 14: 
      case 15: 
      case 19: 
        control_symbol();
        break;
      case 6: 
        group();
        break;
      case 8: 
      case 9: 
      case 10: 
      case 11: 
      case 12: 
      case 16: 
      case 17: 
      case 18: 
      case 20: 
      case 22: 
      case 27: 
      case 48: 
      case 49: 
      case 50: 
      case 51: 
      case 52: 
      case 53: 
      case 54: 
      case 55: 
      case 56: 
      case 57: 
      case 58: 
      case 59: 
      case 60: 
      case 61: 
      case 62: 
      case 63: 
        text();
        break;
      case 7: 
      case 21: 
      case 23: 
      case 24: 
      case 25: 
      case 26: 
      case 33: 
      case 34: 
      case 35: 
      case 36: 
      case 37: 
      case 38: 
      case 39: 
      case 79: 
      default: 
        this.Ó[15] = this.Ý;
        D(-1);
        throw new ParseException();
      }
      switch (this.à == -1 ? H() : this.à)
      {
      }
    }
    this.Ó[16] = this.Ý;
    rbrace();
  }
  
  public final void document()
    throws ParseException, UnsupportedEncodingException
  {
    this.å.startDocument();
    lbrace();
    D(36);
    D(82);
    document_charset();
    for (;;)
    {
      switch (this.à == -1 ? H() : this.à)
      {
      case 28: 
      case 38: 
      case 39: 
        break;
      default: 
        this.Ó[17] = this.Ý;
        break;
      }
      switch (this.à == -1 ? H() : this.à)
      {
      case 28: 
        uc();
        break;
      case 38: 
        ansicpg();
        break;
      case 39: 
        deff();
      }
    }
    this.Ó[18] = this.Ý;
    D(-1);
    throw new ParseException();
    for (;;)
    {
      switch (this.à == -1 ? H() : this.à)
      {
      case 28: 
        uc();
        break;
      case 29: 
        f();
        break;
      case 30: 
        cs();
        break;
      case 32: 
        plain();
        break;
      case 64: 
      case 65: 
      case 66: 
      case 67: 
      case 68: 
      case 69: 
      case 70: 
      case 71: 
      case 72: 
      case 73: 
      case 74: 
      case 75: 
      case 76: 
      case 77: 
      case 78: 
      case 80: 
        control_word();
        break;
      case 13: 
      case 14: 
      case 15: 
      case 19: 
        control_symbol();
        break;
      case 6: 
        group();
        break;
      case 8: 
      case 9: 
      case 10: 
      case 11: 
      case 12: 
      case 16: 
      case 17: 
      case 18: 
      case 20: 
      case 22: 
      case 27: 
      case 48: 
      case 49: 
      case 50: 
      case 51: 
      case 52: 
      case 53: 
      case 54: 
      case 55: 
      case 56: 
      case 57: 
      case 58: 
      case 59: 
      case 60: 
      case 61: 
      case 62: 
      case 63: 
        text();
        break;
      case 7: 
      case 21: 
      case 23: 
      case 24: 
      case 25: 
      case 26: 
      case 31: 
      case 33: 
      case 34: 
      case 35: 
      case 36: 
      case 37: 
      case 38: 
      case 39: 
      case 40: 
      case 41: 
      case 42: 
      case 43: 
      case 44: 
      case 45: 
      case 46: 
      case 47: 
      case 79: 
      default: 
        this.Ó[19] = this.Ý;
        D(-1);
        throw new ParseException();
      }
      switch (this.à == -1 ? H() : this.à)
      {
      }
    }
    this.Ó[20] = this.Ý;
    rbrace();
    this.å.endDocument();
  }
  
  private static void G()
  {
    Î = new int[] { 134684416, 139927296, 139927296, 458752, 1792, 6144, 6144, 0, 0, 0, 581632, 0, 0, 0, 0, -127926464, -127926464, 268435456, 268435456, 2019557184, 2019557184 };
  }
  
  private static void L()
  {
    Í = new int[] { -65536, -65536, -65536, 0, 0, 524288, -65536, 0, 0, 65280, 0, 0, 0, 0, 46, 65281, 65281, 192, 192, -65535, -65535 };
  }
  
  private static void F()
  {
    Ë = new int[] { 0, 0, 0, 0, 0, 0, 0, 262144, 262144, 0, 0, 32767, 98303, 262144, 0, 98303, 98303, 0, 0, 98303, 98303 };
  }
  
  public RTFParser(InputStream paramInputStream)
  {
    this.Û = new SimpleCharStream(paramInputStream, 1, 1);
    this.token_source = new RTFParserTokenManager(this.Û);
    this.token = new Token();
    this.à = -1;
    this.Ý = 0;
    for (int i = 0; i < 21; i++) {
      this.Ó[i] = -1;
    }
  }
  
  public void ReInit(InputStream paramInputStream)
  {
    this.Û.ReInit(paramInputStream, 1, 1);
    this.token_source.ReInit(this.Û);
    this.token = new Token();
    this.à = -1;
    this.Ý = 0;
    for (int i = 0; i < 21; i++) {
      this.Ó[i] = -1;
    }
  }
  
  public RTFParser(Reader paramReader)
  {
    this.Û = new SimpleCharStream(paramReader, 1, 1);
    this.token_source = new RTFParserTokenManager(this.Û);
    this.token = new Token();
    this.à = -1;
    this.Ý = 0;
    for (int i = 0; i < 21; i++) {
      this.Ó[i] = -1;
    }
  }
  
  public void ReInit(Reader paramReader)
  {
    this.Û.ReInit(paramReader, 1, 1);
    this.token_source.ReInit(this.Û);
    this.token = new Token();
    this.à = -1;
    this.Ý = 0;
    for (int i = 0; i < 21; i++) {
      this.Ó[i] = -1;
    }
  }
  
  public RTFParser(RTFParserTokenManager paramRTFParserTokenManager)
  {
    this.token_source = paramRTFParserTokenManager;
    this.token = new Token();
    this.à = -1;
    this.Ý = 0;
    for (int i = 0; i < 21; i++) {
      this.Ó[i] = -1;
    }
  }
  
  public void ReInit(RTFParserTokenManager paramRTFParserTokenManager)
  {
    this.token_source = paramRTFParserTokenManager;
    this.token = new Token();
    this.à = -1;
    this.Ý = 0;
    for (int i = 0; i < 21; i++) {
      this.Ó[i] = -1;
    }
  }
  
  private final Token D(int paramInt)
    throws ParseException
  {
    Token localToken;
    if ((localToken = this.token).next != null) {
      this.token = this.token.next;
    } else {
      this.token = (this.token.next = this.token_source.getNextToken());
    }
    this.à = -1;
    if (this.token.kind == paramInt)
    {
      this.Ý += 1;
      return this.token;
    }
    this.token = localToken;
    this.È = paramInt;
    throw generateParseException();
  }
  
  public final Token getNextToken()
  {
    if (this.token.next != null) {
      this.token = this.token.next;
    } else {
      this.token = (this.token.next = this.token_source.getNextToken());
    }
    this.à = -1;
    this.Ý += 1;
    return this.token;
  }
  
  public final Token getToken(int paramInt)
  {
    Token localToken = this.token;
    for (int i = 0; i < paramInt; i++) {
      if (localToken.next != null) {
        localToken = localToken.next;
      } else {
        localToken = localToken.next = this.token_source.getNextToken();
      }
    }
    return localToken;
  }
  
  private final int H()
  {
    if ((this.jj_nt = this.token.next) == null) {
      return this.à = (this.token.next = this.token_source.getNextToken()).kind;
    }
    return this.à = this.jj_nt.kind;
  }
  
  public ParseException generateParseException()
  {
    this.Ö.removeAllElements();
    boolean[] arrayOfBoolean = new boolean[84];
    for (int i = 0; i < 84; i++) {
      arrayOfBoolean[i] = false;
    }
    if (this.È >= 0)
    {
      arrayOfBoolean[this.È] = true;
      this.È = -1;
    }
    for (i = 0; i < 21; i++) {
      if (this.Ó[i] == this.Ý) {
        for (j = 0; j < 32; j++)
        {
          if ((Î[i] & 1 << j) != 0) {
            arrayOfBoolean[j] = true;
          }
          if ((Í[i] & 1 << j) != 0) {
            arrayOfBoolean[(32 + j)] = true;
          }
          if ((Ë[i] & 1 << j) != 0) {
            arrayOfBoolean[(64 + j)] = true;
          }
        }
      }
    }
    for (i = 0; i < 84; i++) {
      if (arrayOfBoolean[i] != 0)
      {
        this.Ú = new int[1];
        this.Ú[0] = i;
        this.Ö.addElement(this.Ú);
      }
    }
    int[][] arrayOfInt = new int[this.Ö.size()][];
    for (int j = 0; j < this.Ö.size(); j++) {
      arrayOfInt[j] = ((int[])this.Ö.elementAt(j));
    }
    return new ParseException(this.token, arrayOfInt, tokenImage);
  }
  
  public final void enable_tracing() {}
  
  public final void disable_tracing() {}
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\rtf\RTFParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */