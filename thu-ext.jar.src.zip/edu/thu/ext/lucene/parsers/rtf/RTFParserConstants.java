package edu.thu.ext.lucene.parsers.rtf;

public abstract interface RTFParserConstants
{
  public static final int EOF = 0;
  public static final int BACKSLASH = 1;
  public static final int HEX_ESCAPE = 2;
  public static final int LBRACE = 6;
  public static final int RBRACE = 7;
  public static final int NON_BREAKING_SPACE = 8;
  public static final int OPTIONAL_HYPHEN = 9;
  public static final int NON_BREAKING_HYPHEN = 10;
  public static final int ESCAPED_NEWLINE = 11;
  public static final int ESCAPED_CARRIAGE_RETURN = 12;
  public static final int IGNORABLE_DESTINATION = 13;
  public static final int FORMULA_CHARACTER = 14;
  public static final int INDEX_SUBENTRY = 15;
  public static final int ESCAPED_LBRACE = 16;
  public static final int ESCAPED_RBRACE = 17;
  public static final int ESCAPED_BACKSLASH = 18;
  public static final int CONTROL_SYM = 19;
  public static final int TEXT = 20;
  public static final int HEX_DIGIT = 21;
  public static final int HEX_CHAR = 22;
  public static final int U = 27;
  public static final int UC = 28;
  public static final int F = 29;
  public static final int CS = 30;
  public static final int FCHARSET = 31;
  public static final int PLAIN = 32;
  public static final int PC = 33;
  public static final int PCA = 34;
  public static final int MAC = 35;
  public static final int RTF = 36;
  public static final int ANSI = 37;
  public static final int ANSICPG = 38;
  public static final int DEFF = 39;
  public static final int INFO = 40;
  public static final int REVTBL = 41;
  public static final int PNTEXT = 42;
  public static final int FONTTBL = 43;
  public static final int COLORTBL = 44;
  public static final int PNSECLVL = 45;
  public static final int LISTTABLE = 46;
  public static final int STYLESHEET = 47;
  public static final int TAB = 48;
  public static final int ZWJ = 49;
  public static final int ZWNJ = 50;
  public static final int PAR = 51;
  public static final int LINE = 52;
  public static final int EMDASH = 53;
  public static final int ENDASH = 54;
  public static final int EMSPACE = 55;
  public static final int ENSPACE = 56;
  public static final int BULLET = 57;
  public static final int LQUOTE = 58;
  public static final int RQUOTE = 59;
  public static final int LTRMARK = 60;
  public static final int RTLMARK = 61;
  public static final int LDBLQUOTE = 62;
  public static final int RDBLQUOTE = 63;
  public static final int CLFITTEXT = 64;
  public static final int CLFTSWIDTH = 65;
  public static final int CLNOWRAP = 66;
  public static final int CLWWIDTH = 67;
  public static final int TDFRMTXTBOTTOM = 68;
  public static final int TDFRMTXTLEFT = 69;
  public static final int TDFRMTXTRIGHT = 70;
  public static final int TDFRMTXTTOP = 71;
  public static final int TRFTSWIDTHA = 72;
  public static final int TRFTSWIDTHB = 73;
  public static final int TRFTSWIDTH = 74;
  public static final int TRWWIDTHA = 75;
  public static final int TRWWIDTHB = 76;
  public static final int TRWWIDTH = 77;
  public static final int SECTSPECIFYGENN = 78;
  public static final int LC_LETTER = 79;
  public static final int CONTROL_WORD = 80;
  public static final int DIGIT = 81;
  public static final int CW_VAL = 82;
  public static final int CONTROL = 0;
  public static final int HEX = 1;
  public static final int DEFAULT = 2;
  public static final String[] tokenImage = { "<EOF>", "\"\\\\\"", "\"\\\\\\'\"", "\"\\n\"", "\"\\r\"", "\"\\t\"", "\"{\"", "\"}\"", "\"\\\\~\"", "\"\\\\-\"", "\"\\\\_\"", "\"\\\\\\n\"", "\"\\\\\\r\"", "\"\\\\*\"", "\"\\\\|\"", "\"\\\\:\"", "\"\\\\{\"", "\"\\\\}\"", "\"\\\\\\\\\"", "<CONTROL_SYM>", "<TEXT>", "<HEX_DIGIT>", "<HEX_CHAR>", "\" \"", "\"\\n\"", "\"\\r\"", "\"\\t\"", "\"u\"", "\"uc\"", "\"f\"", "\"cs\"", "\"fcharset\"", "\"plain\"", "\"pc\"", "\"pca\"", "\"mac\"", "\"rtf\"", "\"ansi\"", "\"ansicpg\"", "\"deff\"", "\"info\"", "\"revtbl\"", "\"pntext\"", "\"fonttbl\"", "\"colortbl\"", "\"pnseclvl\"", "\"listtable\"", "\"stylesheet\"", "\"tab\"", "\"zwj\"", "\"zwnj\"", "\"par\"", "\"line\"", "\"emdash\"", "\"endash\"", "\"emspace\"", "\"enspace\"", "\"bullet\"", "\"lquote\"", "\"rquote\"", "\"ltrmark\"", "\"rtlmark\"", "\"ldblquote\"", "\"rdblquote\"", "\"clFitText\"", "\"clftsWidth\"", "\"clNoWrap\"", "\"clwWidth\"", "\"tdfrmtxtBottom\"", "\"tdfrmtxtLeft\"", "\"tdfrmtxtRight\"", "\"tdfrmtxtTop\"", "\"trftsWidthA\"", "\"trftsWidthB\"", "\"trftsWidth\"", "\"trwWidthA\"", "\"trwWidthB\"", "\"trwWidth\"", "\"sectspecifygenN\"", "<LC_LETTER>", "<CONTROL_WORD>", "<DIGIT>", "<CW_VAL>", "<token of kind 83>" };
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\rtf\RTFParserConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */