package edu.thu.ext.lucene.parsers.excel;

import edu.thu.ext.lucene.parsers.IPlainTextExtractor;
import edu.thu.ext.lucene.parsers.exception.PlainTextExtractorException;
import edu.thu.ext.lucene.search.SearchConstants;
import java.io.IOException;
import java.io.InputStream;
import java.io.Writer;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

public class ExcelPlainTextExtractor
  implements IPlainTextExtractor
{
  public void extract(InputStream paramInputStream, Writer paramWriter, String paramString)
    throws PlainTextExtractorException
  {
    try
    {
      POIFSFileSystem localPOIFSFileSystem = new POIFSFileSystem(paramInputStream);
      HSSFWorkbook localHSSFWorkbook = new HSSFWorkbook(localPOIFSFileSystem);
      int i = localHSSFWorkbook.getNumberOfSheets();
      for (int j = 0; j < i; j++)
      {
        String str1 = localHSSFWorkbook.getSheetName(j);
        if (str1 != null)
        {
          paramWriter.write(str1);
          paramWriter.write(SearchConstants.EOL);
        }
        HSSFSheet localHSSFSheet = localHSSFWorkbook.getSheetAt(j);
        if (localHSSFSheet != null)
        {
          int k = localHSSFSheet.getFirstRowNum();
          int m = localHSSFSheet.getLastRowNum();
          for (int n = k; n <= m; n++)
          {
            HSSFRow localHSSFRow = localHSSFSheet.getRow(n);
            if (localHSSFRow != null)
            {
              short s1 = localHSSFRow.getFirstCellNum();
              short s2 = localHSSFRow.getLastCellNum();
              int i1 = 0;
              for (short s3 = s1; s3 <= s2; s3 = (short)(s3 + 1))
              {
                HSSFCell localHSSFCell = localHSSFRow.getCell(s3);
                if (localHSSFCell != null)
                {
                  int i2 = localHSSFCell.getCellType();
                  String str2 = null;
                  switch (i2)
                  {
                  case 0: 
                    str2 = localHSSFCell.getNumericCellValue();
                    break;
                  case 1: 
                    str2 = localHSSFCell.getStringCellValue();
                    break;
                  case 2: 
                    str2 = localHSSFCell.getNumericCellValue();
                    break;
                  case 3: 
                    str2 = "";
                    break;
                  case 4: 
                    str2 = localHSSFCell.getBooleanCellValue() ? "true" : "false";
                    break;
                  case 5: 
                    str2 = "";
                    break;
                  default: 
                    str2 = "";
                  }
                  if (i1 != 0) {
                    paramWriter.write(32);
                  } else {
                    i1 = 1;
                  }
                  paramWriter.write(str2);
                }
              }
              paramWriter.write(SearchConstants.EOL);
            }
          }
        }
      }
    }
    catch (IOException localIOException)
    {
      throw new PlainTextExtractorException(localIOException);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\excel\ExcelPlainTextExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */