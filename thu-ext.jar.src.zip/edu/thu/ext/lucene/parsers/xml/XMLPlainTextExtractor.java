package edu.thu.ext.lucene.parsers.xml;

import edu.thu.ext.lucene.parsers.IPlainTextExtractor;
import edu.thu.ext.lucene.parsers.exception.PlainTextExtractorException;
import java.io.InputStream;
import java.io.Writer;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

public class XMLPlainTextExtractor
  implements IPlainTextExtractor
{
  public void extract(InputStream paramInputStream, Writer paramWriter, String paramString)
    throws PlainTextExtractorException
  {
    try
    {
      SAXParserFactory localSAXParserFactory = SAXParserFactory.newInstance();
      SAXParser localSAXParser = localSAXParserFactory.newSAXParser();
      localSAXParser.parse(paramInputStream, new A(paramWriter));
    }
    catch (Exception localException)
    {
      throw new PlainTextExtractorException(localException);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\xml\XMLPlainTextExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */