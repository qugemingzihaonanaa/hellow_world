package edu.thu.ext.lucene.parsers.ppt;

import edu.thu.ext.lucene.parsers.IPlainTextExtractor;
import edu.thu.ext.lucene.parsers.exception.PlainTextExtractorException;
import edu.thu.ext.lucene.search.SearchConstants;
import java.io.IOException;
import java.io.InputStream;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;
import org.apache.poi.poifs.filesystem.DocumentInputStream;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.util.LittleEndian;

public class PowerPointPlainTextExtractor
  implements IPlainTextExtractor
{
  private static final int n = 8;
  private static final int r = -476987297;
  private static final int K = -1;
  private static final int c = -1;
  private static final int Q = 3;
  private static final int R = 4;
  private static final int W = 5;
  private static final int B = 6;
  private static final int q = 7;
  private static final int G = 8;
  private static final int H = 9;
  private static final int o = 10;
  private static final int O = 11;
  private static final int h = 12;
  private static final int C = 13;
  private static final int e = 14;
  private static final int T = 15;
  private static final int I = 16;
  private static final int m = 17;
  private static final int M = 40;
  private static final int u = 0;
  private static final int S = 1;
  private static final int a = 2;
  private static final int V = 3;
  private static final int L = 4;
  private static final int E = 5;
  private static final int t = 6;
  private static final int X = 7;
  private static final int f = 1000;
  private static final int D = 1006;
  private static final int s = 1008;
  private static final int p = 1011;
  private static final int i = 1016;
  private static final int Y = 1036;
  private static final int N = 4000;
  private static final int j = 4008;
  private static final int J = 4026;
  private static final int l = 4057;
  private static final int d = 4080;
  private Writer g = null;
  private static Map Z = new HashMap();
  private int b;
  private int A;
  private long[] P;
  private boolean _;
  private boolean k;
  
  static
  {
    Z.put(new _B(15, 4057), new _A(16, 0));
    Z.put(new _B(15, 4080), new _A(17, 0));
    Z.put(new _B(17, 1011), new _A(-1, 4));
    Z.put(new _B(17, 4008), new _A(-1, 5));
    Z.put(new _B(17, 4000), new _A(-1, 6));
    Z.put(new _B(17, -1), new _A(-1, 7));
    Z.put(new _B(40, 4057), new _A(16, 0));
    Z.put(new _B(3, 4057), new _A(16, 0));
    Z.put(new _B(3, 4026), new _A(-1, 0));
    Z.put(new _B(3, 1036), new _A(4, 0));
    Z.put(new _B(4, 61442), new _A(5, 0));
    Z.put(new _B(5, 61443), new _A(6, 0));
    Z.put(new _B(6, 61443), new _A(6, 0));
    Z.put(new _B(6, 61444), new _A(7, 0));
    Z.put(new _B(7, 61453), new _A(8, 0));
    Z.put(new _B(8, 4000), new _A(-1, 0));
    Z.put(new _B(8, 4008), new _A(-1, 1));
    Z.put(new _B(9, 4026), new _A(-1, 0));
    Z.put(new _B(9, 1036), new _A(10, 0));
    Z.put(new _B(10, 61442), new _A(11, 0));
    Z.put(new _B(11, 61443), new _A(12, 0));
    Z.put(new _B(12, 61443), new _A(12, 0));
    Z.put(new _B(12, 61444), new _A(13, 0));
    Z.put(new _B(13, 61453), new _A(14, 0));
    Z.put(new _B(14, 4000), new _A(-1, 0));
    Z.put(new _B(14, 4008), new _A(-1, 1));
    Z.put(new _B(16, 4026), new _A(-1, 3));
  }
  
  public void extract(InputStream paramInputStream, Writer paramWriter, String paramString)
    throws PlainTextExtractorException
  {
    this.g = paramWriter;
    try
    {
      POIFSFileSystem localPOIFSFileSystem = new POIFSFileSystem(paramInputStream);
      DocumentInputStream localDocumentInputStream1 = localPOIFSFileSystem.createDocumentInputStream("Current User");
      byte[] arrayOfByte1 = new byte[localDocumentInputStream1.available()];
      localDocumentInputStream1.read(arrayOfByte1);
      localDocumentInputStream1.close();
      int i1 = LittleEndian.getInt(arrayOfByte1, 12);
      if (i1 != -476987297) {
        throw new PlainTextExtractorException("That's not a supported PowerPoint Document");
      }
      int i2 = (int)LittleEndian.getUInt(arrayOfByte1, 16);
      DocumentInputStream localDocumentInputStream2 = localPOIFSFileSystem.createDocumentInputStream("PowerPoint Document");
      byte[] arrayOfByte2 = new byte[localDocumentInputStream2.available()];
      localDocumentInputStream2.read(arrayOfByte2);
      localDocumentInputStream2.close();
      this.P = A(arrayOfByte2, i2);
      int i3 = (int)LittleEndian.getUInt(arrayOfByte2, i2 + 8 + 16);
      if (this.P[i3] != -1L)
      {
        int i4 = (int)this.P[i3];
        int i5 = (int)LittleEndian.getUInt(arrayOfByte2, i4 + 4);
        int i6 = LittleEndian.getUShort(arrayOfByte2, i4 + 2);
        if (i6 != 1000) {
          throw new PlainTextExtractorException("PPT parser: Document container expected");
        }
        this._ = false;
        this.k = true;
        A(arrayOfByte2, i4 + 8, i5, 15);
      }
    }
    catch (IOException localIOException)
    {
      throw new PlainTextExtractorException(localIOException);
    }
  }
  
  private long[] A(byte[] paramArrayOfByte, int paramInt)
  {
    int i1 = (int)LittleEndian.getUInt(paramArrayOfByte, paramInt + 8 + 20);
    long[] arrayOfLong = new long[i1 + 1];
    for (int i2 = 0; i2 <= i1; i2++) {
      arrayOfLong[i2] = -1L;
    }
    do
    {
      i2 = (int)LittleEndian.getUInt(paramArrayOfByte, paramInt + 8 + 12);
      A(arrayOfLong, paramArrayOfByte, i2);
      paramInt = (int)LittleEndian.getUInt(paramArrayOfByte, paramInt + 8 + 8);
    } while (paramInt != 0);
    return arrayOfLong;
  }
  
  private void A(long[] paramArrayOfLong, byte[] paramArrayOfByte, int paramInt)
  {
    long l1 = LittleEndian.getUInt(paramArrayOfByte, paramInt + 4);
    int i1 = 0;
    while (i1 < l1)
    {
      long l2 = LittleEndian.getUInt(paramArrayOfByte, paramInt + 8 + i1);
      i1 += 4;
      int i2 = (int)(l2 >> 20);
      int i3 = (int)(l2 & 0xFFFFF);
      for (int i4 = 0; (i4 < i2) && (i1 < l1); i4++)
      {
        if (paramArrayOfLong[(i3 + i4)] == -1L) {
          paramArrayOfLong[(i3 + i4)] = LittleEndian.getUInt(paramArrayOfByte, paramInt + 8 + i1);
        }
        i1 += 4;
      }
    }
  }
  
  private void A(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3)
    throws IOException
  {
    if (((paramInt3 == 4) || (paramInt3 == 10)) && (this._)) {
      return;
    }
    long l1;
    for (int i1 = 0; i1 < paramInt2; i1 = (int)(i1 + (l1 + 8L)))
    {
      int i2 = LittleEndian.getUShort(paramArrayOfByte, paramInt1 + i1);
      int i3 = LittleEndian.getUShort(paramArrayOfByte, paramInt1 + i1 + 2);
      l1 = LittleEndian.getUInt(paramArrayOfByte, paramInt1 + i1 + 4);
      local_B = new _B(paramInt3, i3);
      local_A = (_A)Z.get(local_B);
      if (local_A != null)
      {
        int i4 = (i2 & 0xF) == 15 ? 1 : 0;
        if (i4 != 0)
        {
          if ((local_A.B == 17) && (i2 == 31))
          {
            boolean bool = this._;
            this._ = true;
            A(paramArrayOfByte, paramInt1 + i1 + 8, (int)l1, local_A.B);
            this._ = bool;
          }
          else
          {
            A(paramArrayOfByte, paramInt1 + i1 + 8, (int)l1, local_A.B);
          }
        }
        else {
          A(local_A.A, paramArrayOfByte, paramInt1 + i1 + 8, l1);
        }
      }
    }
    _B local_B = new _B(paramInt3, -1);
    _A local_A = (_A)Z.get(local_B);
    if (local_A != null) {
      A(local_A.A, paramArrayOfByte, 0, 0L);
    }
  }
  
  private void A(int paramInt1, byte[] paramArrayOfByte, int paramInt2, long paramLong)
    throws IOException
  {
    switch (paramInt1)
    {
    case 1: 
      C(paramArrayOfByte, paramInt2, (int)paramLong);
      break;
    case 0: 
      B(paramArrayOfByte, paramInt2, (int)paramLong);
      break;
    case 2: 
      F(paramArrayOfByte, paramInt2, (int)paramLong);
      break;
    case 3: 
      G(paramArrayOfByte, paramInt2, (int)paramLong);
      break;
    case 4: 
      A(paramArrayOfByte, paramInt2, (int)paramLong);
      break;
    case 5: 
      H(paramArrayOfByte, paramInt2, (int)paramLong);
      break;
    case 6: 
      E(paramArrayOfByte, paramInt2, (int)paramLong);
      break;
    case 7: 
      D(paramArrayOfByte, paramInt2, (int)paramLong);
      break;
    }
  }
  
  private void D(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    if (!this.k) {
      A(paramArrayOfByte);
    }
    this.k = true;
  }
  
  private void H(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    C(paramArrayOfByte, paramInt1, paramInt2);
    if (this.A > 0) {
      this.A -= 1;
    }
  }
  
  private void E(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    B(paramArrayOfByte, paramInt1, paramInt2);
    if (this.A > 0) {
      this.A -= 1;
    }
  }
  
  private void A(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    if (!this.k) {
      A(paramArrayOfByte);
    } else {
      this.k = false;
    }
    this.b = ((int)LittleEndian.getUInt(paramArrayOfByte, paramInt1));
    this.A = ((int)LittleEndian.getUInt(paramArrayOfByte, paramInt1 + 8));
  }
  
  private void A(byte[] paramArrayOfByte)
    throws IOException
  {
    int i1 = (int)this.P[this.b];
    int i2 = LittleEndian.getUShort(paramArrayOfByte, i1 + 2);
    int i3 = (int)LittleEndian.getUInt(paramArrayOfByte, i1 + 4);
    switch (i2)
    {
    case 1006: 
      A(paramArrayOfByte, i1 + 8, i3, 3);
      break;
    case 1008: 
      A(paramArrayOfByte, i1 + 8, i3, 9);
      break;
    case 1016: 
      A(paramArrayOfByte, i1 + 8, i3, 40);
      break;
    }
  }
  
  private void G(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    this.g.write(new String(paramArrayOfByte, paramInt1, paramInt2, "UTF-16LE"));
    this.g.write(SearchConstants.EOL);
  }
  
  private void C(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    this.g.write(new String(paramArrayOfByte, paramInt1, paramInt2));
    this.g.write(SearchConstants.EOL);
  }
  
  private void B(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    this.g.write(new String(paramArrayOfByte, paramInt1, paramInt2, "UTF-16LE"));
    this.g.write(SearchConstants.EOL);
  }
  
  private void F(byte[] paramArrayOfByte, int paramInt1, int paramInt2) {}
  
  private static class _B
  {
    public int B;
    public int A;
    
    _B(int paramInt1, int paramInt2)
    {
      this.B = paramInt1;
      this.A = paramInt2;
    }
    
    public boolean equals(Object paramObject)
    {
      _B local_B = (_B)paramObject;
      return (local_B.B == this.B) && (local_B.A == this.A);
    }
    
    public int hashCode()
    {
      int i = this.B;
      i = 29 * i + this.A;
      return i;
    }
  }
  
  private static class _A
  {
    public int B;
    public int A;
    
    _A(int paramInt1, int paramInt2)
    {
      this.B = paramInt1;
      this.A = paramInt2;
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\ppt\PowerPointPlainTextExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */