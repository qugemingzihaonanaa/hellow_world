package edu.thu.ext.lucene.parsers;

import edu.thu.ext.lucene.parsers.exception.PlainTextExtractorException;
import java.io.InputStream;
import java.io.Writer;

public abstract interface IPlainTextExtractor
{
  public abstract void extract(InputStream paramInputStream, Writer paramWriter, String paramString)
    throws PlainTextExtractorException;
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\IPlainTextExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */