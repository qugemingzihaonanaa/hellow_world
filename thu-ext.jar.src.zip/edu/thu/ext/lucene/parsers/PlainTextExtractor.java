package edu.thu.ext.lucene.parsers;

import edu.thu.ext.lucene.parsers.exception.PlainTextExtractorException;
import edu.thu.ext.lucene.parsers.exception.UnsupportedMimeTypeException;
import edu.thu.ext.lucene.search.SearchConstants;
import edu.thu.global.Debug;
import edu.thu.java.util.ClassUtils;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.Hashtable;
import java.util.Map;

public class PlainTextExtractor
  implements SearchConstants
{
  static PlainTextExtractor A = new PlainTextExtractor();
  Map<String, Class<?>> B = new Hashtable();
  
  static
  {
    A.registerExtractor("xls", "edu.thu.ext.lucene.parsers.excel.ExcelPlainTextExtractor");
    A.registerExtractor("htm", "edu.thu.ext.lucene.parsers.html.HTMLPlainTextExtractor");
    A.registerExtractor("html", "edu.thu.ext.lucene.parsers.html.HTMLPlainTextExtractor");
    A.registerExtractor("pdf", "edu.thu.ext.lucene.parsers.pdf.PDFPlainTextExtractor");
    A.registerExtractor("ppt", "edu.thu.ext.lucene.parsers.ppt.PowerPointPlainTextExtractor");
    A.registerExtractor("rtf", "edu.thu.ext.lucene.parsers.rtf.RTFPlainTextExtractor");
    A.registerExtractor("txt", "edu.thu.ext.lucene.parsers.txt.TXTPlainTextExtractor");
    A.registerExtractor("doc", "edu.thu.ext.lucene.parsers.word.WordPlainTextExtractor");
    A.registerExtractor("xml", "edu.thu.ext.lucene.parsers.xml.XMLPlainTextExtractor");
  }
  
  public static PlainTextExtractor getInstance()
  {
    return A;
  }
  
  public boolean supportDocType(String paramString)
  {
    return this.B.containsKey(paramString);
  }
  
  public boolean registerExtractor(String paramString1, String paramString2)
  {
    try
    {
      IPlainTextExtractor localIPlainTextExtractor = (IPlainTextExtractor)ClassUtils.stringToObject(paramString2);
      this.B.put(paramString1, localIPlainTextExtractor.getClass());
      return true;
    }
    catch (Throwable localThrowable)
    {
      Debug.trace("lucene.CAN_err_load_extractor::" + paramString2);
    }
    return false;
  }
  
  IPlainTextExtractor A(String paramString)
  {
    Class localClass = (Class)this.B.get(paramString);
    if (localClass == null) {
      return null;
    }
    return (IPlainTextExtractor)ClassUtils.classToObject(localClass);
  }
  
  public void extract(InputStream paramInputStream, String paramString1, Writer paramWriter, String paramString2)
    throws UnsupportedMimeTypeException, PlainTextExtractorException
  {
    IPlainTextExtractor localIPlainTextExtractor = A(paramString1);
    if (localIPlainTextExtractor != null) {
      localIPlainTextExtractor.extract(paramInputStream, paramWriter, paramString2);
    }
  }
  
  public String extract(InputStream paramInputStream, String paramString1, String paramString2)
    throws UnsupportedMimeTypeException, PlainTextExtractorException
  {
    StringWriter localStringWriter = new StringWriter();
    extract(paramInputStream, paramString1, localStringWriter, paramString2);
    return localStringWriter.toString();
  }
  
  public void extract(InputStream paramInputStream, String paramString, Writer paramWriter)
    throws UnsupportedMimeTypeException, PlainTextExtractorException
  {
    extract(paramInputStream, paramString, paramWriter, null);
  }
  
  public String extract(InputStream paramInputStream, String paramString)
    throws UnsupportedMimeTypeException, PlainTextExtractorException
  {
    return extract(paramInputStream, paramString, null);
  }
  
  public void extract(String paramString1, String paramString2, Writer paramWriter, String paramString3)
    throws UnsupportedMimeTypeException, PlainTextExtractorException
  {
    try
    {
      extract(stringToInputStream(paramString1, paramString3), paramString2, paramWriter, paramString3);
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      throw new PlainTextExtractorException(localUnsupportedEncodingException);
    }
  }
  
  public String extract(String paramString1, String paramString2, String paramString3)
    throws UnsupportedMimeTypeException, PlainTextExtractorException
  {
    try
    {
      return extract(stringToInputStream(paramString1, paramString3), paramString2, paramString3);
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      throw new PlainTextExtractorException(localUnsupportedEncodingException);
    }
  }
  
  public void extract(String paramString1, String paramString2, Writer paramWriter)
    throws UnsupportedMimeTypeException, PlainTextExtractorException
  {
    extract(paramString1, paramString2, paramWriter, null);
  }
  
  public String extract(String paramString1, String paramString2)
    throws UnsupportedMimeTypeException, PlainTextExtractorException
  {
    return extract(paramString1, paramString2, null);
  }
  
  protected InputStream stringToInputStream(String paramString1, String paramString2)
    throws UnsupportedEncodingException
  {
    if ((paramString2 == null) || (paramString2.trim().length() == 0)) {
      paramString2 = SearchConstants.DEFAULT_ENCODING;
    }
    return new ByteArrayInputStream(paramString1.getBytes(paramString2));
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\PlainTextExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */