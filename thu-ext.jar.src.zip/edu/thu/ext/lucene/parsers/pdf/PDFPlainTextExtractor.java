package edu.thu.ext.lucene.parsers.pdf;

import edu.thu.ext.lucene.parsers.IPlainTextExtractor;

public class PDFPlainTextExtractor
  implements IPlainTextExtractor
{
  /* Error */
  public void extract(java.io.InputStream paramInputStream, java.io.Writer paramWriter, String paramString)
    throws edu.thu.ext.lucene.parsers.exception.PlainTextExtractorException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 4
    //   3: new 21	org/apache/pdfbox/text/PDFTextStripper
    //   6: dup
    //   7: invokespecial 23	org/apache/pdfbox/text/PDFTextStripper:<init>	()V
    //   10: astore 5
    //   12: aload_1
    //   13: invokestatic 24	org/apache/pdfbox/pdmodel/PDDocument:load	(Ljava/io/InputStream;)Lorg/apache/pdfbox/pdmodel/PDDocument;
    //   16: astore 4
    //   18: aload 4
    //   20: invokevirtual 30	org/apache/pdfbox/pdmodel/PDDocument:isEncrypted	()Z
    //   23: pop
    //   24: aload 5
    //   26: aload 4
    //   28: aload_2
    //   29: invokevirtual 34	org/apache/pdfbox/text/PDFTextStripper:writeText	(Lorg/apache/pdfbox/pdmodel/PDDocument;Ljava/io/Writer;)V
    //   32: aload 4
    //   34: invokevirtual 38	org/apache/pdfbox/pdmodel/PDDocument:close	()V
    //   37: goto +25 -> 62
    //   40: astore 5
    //   42: new 19	edu/thu/ext/lucene/parsers/exception/PlainTextExtractorException
    //   45: dup
    //   46: aload 5
    //   48: invokespecial 41	edu/thu/ext/lucene/parsers/exception/PlainTextExtractorException:<init>	(Ljava/lang/Throwable;)V
    //   51: athrow
    //   52: astore 6
    //   54: aload 4
    //   56: invokestatic 44	edu/thu/service/util/CloseUtils:safeClose	(Ljava/lang/Object;)V
    //   59: aload 6
    //   61: athrow
    //   62: aload 4
    //   64: invokestatic 44	edu/thu/service/util/CloseUtils:safeClose	(Ljava/lang/Object;)V
    //   67: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	68	0	this	PDFPlainTextExtractor
    //   0	68	1	paramInputStream	java.io.InputStream
    //   0	68	2	paramWriter	java.io.Writer
    //   0	68	3	paramString	String
    //   1	62	4	localPDDocument	org.apache.pdfbox.pdmodel.PDDocument
    //   10	15	5	localPDFTextStripper	org.apache.pdfbox.text.PDFTextStripper
    //   40	7	5	localThrowable	Throwable
    //   52	8	6	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   3	37	40	java/lang/Throwable
    //   3	52	52	finally
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\pdf\PDFPlainTextExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */