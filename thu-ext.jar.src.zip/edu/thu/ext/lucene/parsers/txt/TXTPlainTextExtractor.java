package edu.thu.ext.lucene.parsers.txt;

import edu.thu.ext.lucene.parsers.IPlainTextExtractor;
import edu.thu.ext.lucene.parsers.exception.PlainTextExtractorException;
import edu.thu.ext.lucene.search.SearchConstants;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.Writer;

public class TXTPlainTextExtractor
  implements IPlainTextExtractor
{
  private static final int w = 4096;
  private char[] v = new char['က'];
  
  public void extract(InputStream paramInputStream, Writer paramWriter, String paramString)
    throws PlainTextExtractorException
  {
    try
    {
      if ((paramString == null) || (paramString.trim().length() == 0)) {
        paramString = SearchConstants.DEFAULT_ENCODING;
      }
      BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(paramInputStream, paramString));
      for (;;)
      {
        int i = localBufferedReader.read(this.v);
        if (i <= 0) {
          break;
        }
        paramWriter.write(this.v, 0, i);
      }
    }
    catch (IOException localIOException)
    {
      throw new PlainTextExtractorException(localIOException);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\parsers\txt\TXTPlainTextExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */