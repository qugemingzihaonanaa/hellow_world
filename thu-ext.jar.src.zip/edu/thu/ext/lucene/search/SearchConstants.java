package edu.thu.ext.lucene.search;

public abstract interface SearchConstants
{
  public static final String LOCALE_EN = "en";
  public static final String LOCALE_RU = "ru";
  public static final String LOCALE_ES = "es";
  public static final String LOCALE_DE = "de";
  public static final String LOCALE_PT = "pt";
  public static final String LOCALE_DA = "da";
  public static final String LOCALE_FI = "fa";
  public static final String LOCALE_FR = "fr";
  public static final String LOCALE_IT = "it";
  public static final String LOCALE_NO = "no";
  public static final String LOCALE_SV = "sv";
  public static final String LOCALE_NL = "nl";
  public static final String MIME_MS_WORD = "application/msword";
  public static final String MIME_MS_EXCEL = "application/vnd.ms-excel";
  public static final String MIME_MS_PPT = "application/vnd.ms-powerpoint";
  public static final String MIME_PDF = "application/pdf";
  public static final String MIME_RTF = "application/rtf";
  public static final String MIME_HTML = "text/html";
  public static final String MIME_XHTML = "application/xhtml+xml";
  public static final String MIME_XML = "text/xml";
  public static final String MIME_TXT = "text/plain";
  public static final String EXT_DOC = "doc";
  public static final String EXT_XLS = "xls";
  public static final String EXT_RTF = "rtf";
  public static final String EXT_PDF = "pdf";
  public static final String EXT_TXT = "txt";
  public static final String EXT_XML = "xml";
  public static final String EXT_PPT = "ppt";
  public static final String EXT_HTML = "html";
  public static final String EXT_HTM = "htm";
  public static final String DEFAULT_ENCODING = System.getProperty("file.encoding");
  public static final String EOL = System.getProperty("line.separator", "\n");
  public static final int MAX_SUMMARY_LEN = 500;
  public static final int RESULT_FRAGMENT_SIZE = 60;
  public static final int RESULT_FRAGMENT_NUMBER = 3;
  public static final String RESULT_FRAGMENT_DELIMITER = "...";
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\lucene\search\SearchConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */