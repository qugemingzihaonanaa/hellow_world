package edu.thu.ext.excel.poi;

import edu.thu.ext.excel.model.Workbook;
import java.io.File;

public class PoiModelParser
{
  public Workbook parseVirtualFile(String paramString)
  {
    return null;
  }
  
  public Workbook parseFile(File paramFile)
  {
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\poi\PoiModelParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */