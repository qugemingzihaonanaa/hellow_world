package edu.thu.ext.excel.tpl;

import edu.thu.ext.excel.WxReportRenderer;
import edu.thu.ext.excel.model.ExcelModelParser;
import edu.thu.ext.excel.model.Workbook;
import edu.thu.ext.excel.poi.PoiModelParser;
import edu.thu.lang.util.ITplReference;
import edu.thu.lang.util.TplC;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceContext;
import edu.thu.service.SystemServiceContext;
import edu.thu.xml.dom.DomToTree;
import java.io.File;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class ExcelTplParser
{
  TplC A = TplC.newWebTplC();
  
  public ExcelTplParser()
  {
    this.A.loadLib("xls_cp", "/_tpl/xls_cp.lib.xml");
  }
  
  public Workbook parseWkFromVirtualFile(String paramString)
  {
    if (paramString.toLowerCase().endsWith(".xls")) {
      return new PoiModelParser().parseVirtualFile(paramString);
    }
    return new ExcelModelParser().parseVirtualFile(paramString);
  }
  
  public Workbook parseWkFromStream(InputStream paramInputStream, String paramString)
  {
    return new ExcelModelParser().parseWorkbook(paramInputStream);
  }
  
  Workbook A(File paramFile)
  {
    if (paramFile.getName().toLowerCase().endsWith(".xls")) {
      return new PoiModelParser().parseFile(paramFile);
    }
    return new ExcelModelParser().parseFile(paramFile);
  }
  
  public Object compileTag(String paramString)
  {
    TreeNode localTreeNode = TreeNode.make(paramString);
    return this.A.compileNode(localTreeNode, SystemServiceContext.getInstance());
  }
  
  public String toTpl(Workbook paramWorkbook, Map<String, Object> paramMap)
  {
    WxReportRenderer localWxReportRenderer = new WxReportRenderer(paramWorkbook.getWxReportConfig());
    HashMap localHashMap = new HashMap();
    if (paramMap != null) {
      localHashMap.putAll(paramMap);
    }
    localHashMap.put("workbook", paramWorkbook);
    localHashMap.put("wxReportRenderer", localWxReportRenderer);
    TreeNode localTreeNode1 = TreeNode.make("xls_cp:WorkbookToTpl");
    TreeNode localTreeNode2 = TreeNode.make("c:div");
    localTreeNode2.appendChild(localTreeNode1);
    IServiceContext localIServiceContext = SystemServiceContext.getInstance();
    ITplReference localITplReference = this.A.compileBody(localTreeNode2, paramMap, localIServiceContext);
    return TplC.getTplOut(localITplReference, localHashMap, localIServiceContext);
  }
  
  public String toTpl(Workbook paramWorkbook)
  {
    return toTpl(paramWorkbook, null);
  }
  
  public String parseVirtualFile(String paramString)
  {
    return toTpl(parseWkFromVirtualFile(paramString));
  }
  
  public String parseFile(File paramFile)
  {
    return toTpl(A(paramFile));
  }
  
  public Object parseFileToTpl(File paramFile)
  {
    String str = parseFile(paramFile);
    TreeNode localTreeNode = DomToTree.getInstance().transform(str);
    return this.A.compileNode(localTreeNode, SystemServiceContext.getInstance());
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\tpl\ExcelTplParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */