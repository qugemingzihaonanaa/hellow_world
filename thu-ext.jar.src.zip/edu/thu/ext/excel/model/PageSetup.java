package edu.thu.ext.excel.model;

import edu.thu.xml.XmlUtils;
import java.io.Serializable;

public class PageSetup
  implements Serializable
{
  private static final long serialVersionUID = -5291838691767356940L;
  String A;
  Boolean K;
  Boolean J;
  Integer H;
  Double G;
  String L;
  Double B;
  String E;
  Double D;
  Double I;
  Double C;
  Double F;
  
  public boolean isHorPage()
  {
    return "Landscape".equals(this.A);
  }
  
  public void setHorPage(boolean paramBoolean)
  {
    this.A = (paramBoolean ? "Landscape" : null);
  }
  
  public String getOrientation()
  {
    return this.A;
  }
  
  public void setOrientation(String paramString)
  {
    this.A = paramString;
  }
  
  public boolean isHasLayout()
  {
    return (this.K != null) || (this.J != null) || (this.A != null);
  }
  
  public boolean isHasPageMargins()
  {
    return (this.D != null) || (this.I != null) || (this.C != null) || (this.F != null);
  }
  
  public boolean isHasHeader()
  {
    return (this.G != null) || (this.L != null);
  }
  
  public boolean isHasFooter()
  {
    return (this.B != null) || (this.E != null);
  }
  
  public Integer getStartPageNumber()
  {
    return this.H;
  }
  
  public void setStartPageNumber(Integer paramInteger)
  {
    this.H = paramInteger;
  }
  
  public Boolean getCenterHorizontal()
  {
    return this.K;
  }
  
  public void setCenterHorizontal(Boolean paramBoolean)
  {
    this.K = paramBoolean;
  }
  
  public Boolean getCenterVertical()
  {
    return this.J;
  }
  
  public void setCenterVertical(Boolean paramBoolean)
  {
    this.J = paramBoolean;
  }
  
  public Double getHeaderMargin()
  {
    return this.G;
  }
  
  public void setHeaderMargin(Double paramDouble)
  {
    this.G = paramDouble;
  }
  
  public String getHeaderData()
  {
    return this.L;
  }
  
  public void setHeaderData(String paramString)
  {
    this.L = paramString;
  }
  
  public Double getFooterMargin()
  {
    return this.B;
  }
  
  public void setFooterMargin(Double paramDouble)
  {
    this.B = paramDouble;
  }
  
  public String getFooterData()
  {
    return this.E;
  }
  
  public void setFooterData(String paramString)
  {
    this.E = paramString;
  }
  
  public Double getPageMarginsBottom()
  {
    return this.D;
  }
  
  public void setPageMarginsBottom(Double paramDouble)
  {
    this.D = paramDouble;
  }
  
  public Double getPageMarginsLeft()
  {
    return this.I;
  }
  
  public void setPageMarginsLeft(Double paramDouble)
  {
    this.I = paramDouble;
  }
  
  public Double getPageMarginsRight()
  {
    return this.C;
  }
  
  public void setPageMarginsRight(Double paramDouble)
  {
    this.C = paramDouble;
  }
  
  public Double getPageMarginsTop()
  {
    return this.F;
  }
  
  public void setPageMarginsTop(Double paramDouble)
  {
    this.F = paramDouble;
  }
  
  void A(StringBuilder paramStringBuilder, String paramString, Object paramObject)
  {
    if (paramObject != null) {
      paramStringBuilder.append(" ").append(paramString).append("=\"").append(paramObject).append("\"");
    }
  }
  
  String A(Boolean paramBoolean)
  {
    if (paramBoolean == null) {
      return null;
    }
    return paramBoolean.booleanValue() ? "1" : "0";
  }
  
  public String toXls()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("<PageSetup>");
    if (isHasLayout())
    {
      localStringBuilder.append("<Layout ");
      A(localStringBuilder, "x:Orientation", this.A);
      A(localStringBuilder, "x:CenterHorizontal", A(this.K));
      A(localStringBuilder, "x:CenterVertical", A(this.J));
      A(localStringBuilder, "x:StartPageNumber", this.H);
      localStringBuilder.append(" />");
    }
    if (isHasHeader())
    {
      localStringBuilder.append("<Header ");
      A(localStringBuilder, "x:Margin", this.G);
      A(localStringBuilder, "x:Data", XmlUtils.encodeXmlAttr(this.L));
      localStringBuilder.append(" />");
    }
    if (isHasFooter())
    {
      localStringBuilder.append("<Footer ");
      A(localStringBuilder, "x:Margin", this.B);
      A(localStringBuilder, "x:Data", XmlUtils.encodeXmlAttr(this.E));
      localStringBuilder.append(" />");
    }
    if (isHasPageMargins())
    {
      localStringBuilder.append("<PageMargins ");
      A(localStringBuilder, "x:Bottom", this.D);
      A(localStringBuilder, "x:Left", this.I);
      A(localStringBuilder, "x:Right", this.C);
      A(localStringBuilder, "x:Top", this.F);
      localStringBuilder.append(" />");
    }
    localStringBuilder.append("</PageSetup>");
    return localStringBuilder.toString();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\PageSetup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */