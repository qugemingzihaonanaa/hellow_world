package edu.thu.ext.excel.model;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.util.Coercions;
import edu.thu.lang.el.IExpressionReference;
import edu.thu.lang.exceptions.StdException;
import edu.thu.lang.util.TplC;
import edu.thu.model.tree.TreeNode;
import edu.thu.util.StringUtils;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class CellExpandModel
  implements Serializable
{
  private static final long serialVersionUID = 4025059764367259209L;
  Cell B;
  int V;
  IExpressionReference U;
  IExpressionReference K;
  String W;
  Cell J;
  Cell D;
  List<Cell> Z;
  List<Cell> Y;
  int P;
  int C;
  int T;
  int F;
  int G;
  int R;
  String H;
  String A;
  String O;
  boolean Q;
  List<String> M;
  List<String> X;
  List<String> N;
  List<CellBandModel> E;
  List<CellBandModel> S;
  int L;
  int I;
  
  public CellExpandModel(Cell paramCell)
  {
    this.B = paramCell;
  }
  
  public TreeNode toNode()
  {
    TreeNode localTreeNode1 = TreeNode.make("expand");
    localTreeNode1.setAttribute("minExpandHorIndex", Integer.valueOf(this.P));
    localTreeNode1.setAttribute("maxExpandHorIndex", Integer.valueOf(this.C));
    localTreeNode1.setAttribute("minExpandVerIndex", Integer.valueOf(this.T));
    localTreeNode1.setAttribute("maxExpandVerIndex", Integer.valueOf(this.F));
    localTreeNode1.setAttribute("horExpandLevel", Integer.valueOf(this.G));
    localTreeNode1.setAttribute("verExpandLevel", Integer.valueOf(this.R));
    if (this.M != null) {
      localTreeNode1.setAttribute("horDimFields", StringUtils.join(this.M, ","));
    }
    if (this.X != null) {
      localTreeNode1.setAttribute("verDimFields", StringUtils.join(this.X, ","));
    }
    localTreeNode1.setAttribute("cell", this.B);
    TreeNode localTreeNode2;
    Iterator localIterator;
    CellBandModel localCellBandModel;
    TreeNode localTreeNode3;
    TreeNode localTreeNode4;
    if (this.E != null)
    {
      localTreeNode2 = localTreeNode1.makeChild("horBands");
      localIterator = this.E.iterator();
      while (localIterator.hasNext())
      {
        localCellBandModel = (CellBandModel)localIterator.next();
        localTreeNode3 = localCellBandModel.toNode();
        if (localCellBandModel.getBranchCellPos() >= 0)
        {
          localTreeNode4 = ((Cell)this.Z.get(localCellBandModel.getBranchCellPos())).getExpandModel().toNode();
          localTreeNode3.appendChild(localTreeNode4);
        }
        localTreeNode3.setAttribute("siblingCells", StringUtils.join(localCellBandModel.getSiblingCells(this.Z), ","));
        localTreeNode2.appendChild(localTreeNode3);
      }
    }
    if (this.S != null)
    {
      localTreeNode2 = localTreeNode1.makeChild("verBands");
      localIterator = this.S.iterator();
      while (localIterator.hasNext())
      {
        localCellBandModel = (CellBandModel)localIterator.next();
        localTreeNode3 = localCellBandModel.toNode();
        if (localCellBandModel.getBranchCellPos() >= 0)
        {
          localTreeNode4 = ((Cell)this.Y.get(localCellBandModel.getBranchCellPos())).getExpandModel().toNode();
          localTreeNode3.appendChild(localTreeNode4);
        }
        localTreeNode3.setAttribute("siblingCells", StringUtils.join(localCellBandModel.getSiblingCells(this.Y), ","));
        localTreeNode2.appendChild(localTreeNode3);
      }
    }
    return localTreeNode1;
  }
  
  public String getExpandOrderField()
  {
    return this.W;
  }
  
  public void setExpandOrderField(String paramString)
  {
    this.W = paramString;
  }
  
  public String getTextField()
  {
    return this.O;
  }
  
  public void setTextField(String paramString)
  {
    this.O = paramString;
  }
  
  public IExpressionReference getTestExpr()
  {
    return this.K;
  }
  
  public void setTestExpr(IExpressionReference paramIExpressionReference)
  {
    this.K = paramIExpressionReference;
  }
  
  public boolean passTest(Map<String, Object> paramMap)
  {
    if (this.K == null) {
      return true;
    }
    return Coercions.toBoolean(TplC.evaluate(this.K, paramMap), false);
  }
  
  public int getHorChildPos()
  {
    return this.L;
  }
  
  public void setHorChildPos(int paramInt)
  {
    this.L = paramInt;
  }
  
  public int getVerChildPos()
  {
    return this.I;
  }
  
  public void setVerChildPos(int paramInt)
  {
    this.I = paramInt;
  }
  
  public List<CellBandModel> getBandModels(boolean paramBoolean)
  {
    return paramBoolean ? this.E : this.S;
  }
  
  public List<CellBandModel> getHorBandModels()
  {
    return this.E;
  }
  
  public List<CellBandModel> getVerBandModels()
  {
    return this.S;
  }
  
  public List<String> getDimFields()
  {
    return this.N;
  }
  
  public void setDimFields(List<String> paramList)
  {
    this.N = paramList;
  }
  
  public List<String> getHorDimFields()
  {
    return this.M;
  }
  
  public void setHorDimFields(List<String> paramList)
  {
    this.M = paramList;
  }
  
  public List<String> getVerDimFields()
  {
    return this.X;
  }
  
  public void setVerDimFields(List<String> paramList)
  {
    this.X = paramList;
  }
  
  public Cell getCell()
  {
    return this.B;
  }
  
  public void setCell(Cell paramCell)
  {
    this.B = paramCell;
  }
  
  public int getHorExpandLevel()
  {
    return this.G;
  }
  
  public void setHorExpandLevel(int paramInt)
  {
    this.G = paramInt;
  }
  
  public int getVerExpandLevel()
  {
    return this.R;
  }
  
  public void setVerExpandLevel(int paramInt)
  {
    this.R = paramInt;
  }
  
  public String getDsName()
  {
    return this.H;
  }
  
  public void setDsName(String paramString)
  {
    this.H = paramString;
  }
  
  public String getDsNameWithDefault()
  {
    return this.H == null ? "ds1" : this.H;
  }
  
  public String getField()
  {
    return this.A;
  }
  
  public void setField(String paramString)
  {
    this.A = paramString;
  }
  
  public boolean isExpandGroup()
  {
    return this.Q;
  }
  
  public void setExpandGroup(boolean paramBoolean)
  {
    this.Q = paramBoolean;
  }
  
  public boolean hasNoChildCell()
  {
    return (this.Z == null) && (this.Y == null);
  }
  
  public boolean isExpandHor()
  {
    return this.V == 1;
  }
  
  public boolean isExpandVer()
  {
    return this.V == 2;
  }
  
  public IExpressionReference getExpandExpr()
  {
    return this.U;
  }
  
  public void setExpandExpr(IExpressionReference paramIExpressionReference)
  {
    this.U = paramIExpressionReference;
  }
  
  public int getExpandType()
  {
    return this.V;
  }
  
  public void setExpandType(int paramInt)
  {
    this.V = paramInt;
  }
  
  public Cell getHorParent()
  {
    return this.J;
  }
  
  public void setHorParent(Cell paramCell)
  {
    this.J = paramCell;
  }
  
  public List<Cell> getHorChildren()
  {
    return this.Z;
  }
  
  public void setHorChildren(List<Cell> paramList)
  {
    this.Z = paramList;
  }
  
  public List<Cell> getVerChildren()
  {
    return this.Y;
  }
  
  public void setVerChildren(List<Cell> paramList)
  {
    this.Y = paramList;
  }
  
  public Cell getVerParent()
  {
    return this.D;
  }
  
  public void setVerParent(Cell paramCell)
  {
    this.D = paramCell;
  }
  
  void A(List<CellBandModel> paramList, int paramInt1, int paramInt2, List<Cell> paramList1)
  {
    CellBandModel localCellBandModel1 = (CellBandModel)paramList.get(paramInt1);
    CellBandModel localCellBandModel2 = localCellBandModel1.splitAt(paramInt2);
    paramList.add(paramInt1 + 1, localCellBandModel2);
    if (localCellBandModel1.getSiblingPosList() != null)
    {
      Iterator localIterator = localCellBandModel1.getSiblingPosList().iterator();
      while (localIterator.hasNext())
      {
        int i = ((Integer)localIterator.next()).intValue();
        Cell localCell = (Cell)paramList1.get(i);
        if ((localCell.getHorChildren() != null) || (localCell.getVerChildren() != null)) {
          throw Exceptions.code("excel.CAN_err_mix_sibling_band").param(localCell).param(localCellBandModel1).param(this.B);
        }
      }
    }
  }
  
  void A(List<CellBandModel> paramList, Cell paramCell, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, List<Cell> paramList1)
  {
    int j = paramList.size();
    CellBandModel localCellBandModel1;
    if (j <= paramInt4)
    {
      localCellBandModel1 = new CellBandModel();
      localCellBandModel1.setIndex(paramInt2);
      localCellBandModel1.setWidth(paramInt3);
      paramList.add(localCellBandModel1);
      j++;
    }
    for (int i = paramInt4; i < j; i++)
    {
      localCellBandModel1 = (CellBandModel)paramList.get(i);
      int k = localCellBandModel1.getIndex();
      if (k == paramInt2)
      {
        if (paramBoolean)
        {
          if ((localCellBandModel1.getBranchCellPos() >= 0) || (localCellBandModel1.getWidth() < paramInt3)) {
            throw Exceptions.code("excel.CAN_err_mixed_cell_band").param(paramCell).param(localCellBandModel1).param(this.B).param(this.V);
          }
          if (localCellBandModel1.getWidth() > paramInt3) {
            A(paramList, i, paramInt3, paramList1);
          }
          localCellBandModel1.setBranchCellPos(paramInt1);
          return;
        }
        if (localCellBandModel1.getWidth() > paramInt3)
        {
          if (localCellBandModel1.getBranchCellPos() >= 0) {
            throw Exceptions.code("excel.CAN_err_mixed_cell_band").param(paramCell).param(localCellBandModel1).param(this.B).param(this.V);
          }
          A(paramList, i, paramInt3, paramList1);
          if (paramInt4 > 0) {
            localCellBandModel1.addSiblingPos(paramInt1);
          } else {
            localCellBandModel1.addPos(paramInt1);
          }
        }
        else if (localCellBandModel1.getWidth() == paramInt3)
        {
          if (paramInt4 > 0) {
            localCellBandModel1.addSiblingPos(paramInt1);
          } else {
            localCellBandModel1.addPos(paramInt1);
          }
        }
        else
        {
          if (paramInt4 > 0) {
            localCellBandModel1.addSiblingPos(paramInt1);
          } else {
            localCellBandModel1.addPos(paramInt1);
          }
          A(paramList, paramCell, paramInt1, false, paramInt2 + localCellBandModel1.getWidth(), paramInt3 - localCellBandModel1.getWidth(), i + 1, paramList1);
        }
        return;
      }
      CellBandModel localCellBandModel2;
      if (k > paramInt2)
      {
        localCellBandModel2 = new CellBandModel();
        localCellBandModel2.setIndex(paramInt2);
        localCellBandModel2.setWidth(k - paramInt2);
        paramList.add(i, localCellBandModel2);
        i -= 2;
        j++;
      }
      else if (k + localCellBandModel1.getWidth() > paramInt2)
      {
        if (localCellBandModel1.getBranchCellPos() >= 0) {
          throw Exceptions.code("excel.CAN_err_mixed_cell_band").param(paramCell).param(localCellBandModel1).param(this.B).param(this.V);
        }
        A(paramList, i, paramInt2 - k, paramList1);
        j++;
      }
      else if (i == j - 1)
      {
        localCellBandModel2 = new CellBandModel();
        localCellBandModel2.setIndex(paramInt2);
        localCellBandModel2.setWidth(paramInt3);
        paramList.add(localCellBandModel2);
        j++;
      }
    }
  }
  
  public void initHorBandModel(int paramInt)
  {
    this.G = paramInt;
    if (this.Z == null) {
      return;
    }
    this.E = new ArrayList();
    CellBandModel localCellBandModel = new CellBandModel();
    localCellBandModel.setIndex(this.B.getRowIndex());
    localCellBandModel.setWidth(this.B.getRowspan());
    localCellBandModel.setAlignWithParent(true);
    this.E.add(localCellBandModel);
    paramInt++;
    int j = this.Z.size();
    Object localObject;
    for (int i = 0; i < j; i++)
    {
      localObject = (Cell)this.Z.get(i);
      ((Cell)localObject).getExpandModel().initHorBandModel(paramInt);
      A(this.E, (Cell)localObject, i, (((Cell)localObject).isExpandVer()) || (((Cell)localObject).hasHorChild()), ((Cell)localObject).getMinExpandHorIndex(), ((Cell)localObject).getHorExpandRange(), 0, this.Z);
    }
    Iterator localIterator1 = this.E.iterator();
    while (localIterator1.hasNext())
    {
      localObject = (CellBandModel)localIterator1.next();
      if ((((CellBandModel)localObject).getBranchCellPos() >= 0) && (((CellBandModel)localObject).getPosList() != null))
      {
        Iterator localIterator2 = ((CellBandModel)localObject).getPosList().iterator();
        while (localIterator2.hasNext())
        {
          int k = ((Integer)localIterator2.next()).intValue();
          Cell localCell = (Cell)this.Z.get(k);
          if (localCell.getRowspan() == ((CellBandModel)localObject).getWidth()) {
            ((CellBandModel)localObject).addSamePos(k);
          }
        }
      }
    }
  }
  
  public void initVerBandModel(int paramInt)
  {
    this.R = paramInt;
    if (this.Y == null) {
      return;
    }
    this.S = new ArrayList();
    CellBandModel localCellBandModel = new CellBandModel();
    localCellBandModel.setIndex(this.B.getIndex());
    localCellBandModel.setWidth(this.B.getColspan());
    localCellBandModel.setAlignWithParent(true);
    this.S.add(localCellBandModel);
    paramInt++;
    int j = this.Y.size();
    Object localObject;
    for (int i = 0; i < j; i++)
    {
      localObject = (Cell)this.Y.get(i);
      ((Cell)localObject).getExpandModel().initVerBandModel(paramInt);
      A(this.S, (Cell)localObject, i, (((Cell)localObject).isExpandHor()) || (((Cell)localObject).hasVerChild()), ((Cell)localObject).getMinExpandVerIndex(), ((Cell)localObject).getVerExpandRange(), 0, this.Y);
    }
    Iterator localIterator1 = this.S.iterator();
    while (localIterator1.hasNext())
    {
      localObject = (CellBandModel)localIterator1.next();
      if ((((CellBandModel)localObject).getBranchCellPos() >= 0) && (((CellBandModel)localObject).getPosList() != null))
      {
        Iterator localIterator2 = ((CellBandModel)localObject).getPosList().iterator();
        while (localIterator2.hasNext())
        {
          int k = ((Integer)localIterator2.next()).intValue();
          Cell localCell = (Cell)this.Y.get(k);
          if (localCell.getColspan() == ((CellBandModel)localObject).getWidth()) {
            ((CellBandModel)localObject).addSamePos(k);
          }
        }
      }
    }
  }
  
  public void addHorChild(Cell paramCell)
  {
    paramCell = paramCell.getRealCell();
    if (this.Z == null) {
      this.Z = new ArrayList();
    }
    paramCell.setHorParent(this.B);
    paramCell.getExpandModel().setHorChildPos(this.Z.size());
    this.Z.add(paramCell);
  }
  
  public void addVerChild(Cell paramCell)
  {
    paramCell = paramCell.getRealCell();
    if (this.Y == null) {
      this.Y = new ArrayList();
    }
    paramCell.setVerParent(this.B);
    paramCell.getExpandModel().setVerChildPos(this.Y.size());
    this.Y.add(paramCell);
  }
  
  public int getMaxExpandHorIndex()
  {
    return this.C;
  }
  
  public void setMaxExpandHorIndex(int paramInt)
  {
    this.C = paramInt;
  }
  
  public int getMaxExpandVerIndex()
  {
    return this.F;
  }
  
  public void setMaxExpandVerIndex(int paramInt)
  {
    this.F = paramInt;
  }
  
  public int getMinExpandHorIndex()
  {
    return this.P;
  }
  
  public void setMinExpandHorIndex(int paramInt)
  {
    this.P = paramInt;
  }
  
  public int getMinExpandVerIndex()
  {
    return this.T;
  }
  
  public void setMinExpandVerIndex(int paramInt)
  {
    this.T = paramInt;
  }
  
  public void calcExpandHorRange()
  {
    this.P = this.B.getRowIndex();
    this.C = (this.B.getRowIndex() + this.B.getMergeDown());
    if (this.Z != null)
    {
      Iterator localIterator = this.Z.iterator();
      while (localIterator.hasNext())
      {
        Cell localCell = (Cell)localIterator.next();
        localCell.calcExpandHorRange();
        this.P = Math.min(this.P, localCell.getMinExpandHorIndex());
        this.C = Math.max(this.C, localCell.getMaxExpandHorIndex());
      }
    }
  }
  
  public void calcExpandVerRange()
  {
    this.T = this.B.getIndex();
    this.F = (this.B.getIndex() + this.B.getMergeAcross());
    if (this.Y != null)
    {
      Iterator localIterator = this.Y.iterator();
      while (localIterator.hasNext())
      {
        Cell localCell = (Cell)localIterator.next();
        localCell.calcExpandVerRange();
        this.T = Math.min(this.T, localCell.getMinExpandVerIndex());
        this.F = Math.max(this.F, localCell.getMaxExpandVerIndex());
      }
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\CellExpandModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */