package edu.thu.ext.excel.model;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.util.IWrapCollection;
import edu.thu.model.Pair;
import edu.thu.model.table.IBasicCellModel;
import edu.thu.report.util.WrapCollection;
import edu.thu.util.StringUtils;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;

public class Table
  extends AbstractTable<Row>
{
  private static final long serialVersionUID = 3069906321770491037L;
  int expandedColumnCount;
  int expandedRowCount;
  int fullColumns;
  int fullRows;
  double defaultColumnWidth = 54.0D;
  double defaultRowHeight = 14.25D;
  Worksheet sheet;
  List<Cell> rootCells;
  Cell verRoot;
  Cell horRoot;
  
  public Table() {}
  
  public Table(Worksheet paramWorksheet)
  {
    this.sheet = paramWorksheet;
  }
  
  public Table copy()
  {
    Table localTable = new Table(this.sheet);
    localTable.expandedColumnCount = this.expandedColumnCount;
    localTable.expandedRowCount = this.expandedRowCount;
    localTable.fullColumns = this.fullColumns;
    localTable.fullRows = this.fullRows;
    localTable.defaultColumnWidth = this.defaultColumnWidth;
    localTable.defaultRowHeight = this.defaultRowHeight;
    localTable.sheet = this.sheet;
    localTable.cols = new WrapCollection(this.cols).call("copy").listValue();
    localTable.rows = new WrapCollection(this.rows).call("copy").listValue();
    new WrapCollection(localTable.rows).invoke("setTable", new Object[] { localTable });
    localTable.fixCell();
    return localTable;
  }
  
  public Cell getHorRoot()
  {
    return this.horRoot;
  }
  
  public void setHorRoot(Cell paramCell)
  {
    this.horRoot = paramCell;
  }
  
  public Cell getVerRoot()
  {
    return this.verRoot;
  }
  
  public void setVerRoot(Cell paramCell)
  {
    this.verRoot = paramCell;
  }
  
  public List<Cell> getRootCells()
  {
    return this.rootCells;
  }
  
  public void setRootCells(List<Cell> paramList)
  {
    this.rootCells = paramList;
  }
  
  public Worksheet getAsWorksheet()
  {
    Worksheet localWorksheet = new Worksheet();
    localWorksheet.setWorksheetName("Sheet1");
    localWorksheet.setTable(this);
    return localWorksheet;
  }
  
  public Workbook getWorkbook()
  {
    if (this.sheet == null) {
      return null;
    }
    return this.sheet.getWorkbook();
  }
  
  public Row tileToNext(Row paramRow)
  {
    int i = paramRow.getIndex();
    Row localRow = (Row)getRow(i);
    if (localRow == null)
    {
      localRow = paramRow.copy();
      localRow.setIndex(i + 1);
      localRow.setTable(this);
      addRow(localRow);
    }
    else
    {
      int k = paramRow.getColCount();
      for (int j = 0; j < k; j++)
      {
        Cell localCell1 = paramRow.getCell(j);
        Cell localCell2 = localRow.getCell(j);
        if ((localCell2 == null) || (localCell2.getRealCell() != localCell1.getRealCell()))
        {
          localCell2 = localCell1.copy();
          localCell2.setRow(localRow);
          localRow.getCells().set(j, localCell2);
          int n = localCell2.getMergeAcross();
          for (int m = 0; m < n; m++)
          {
            CellProxy localCellProxy = new CellProxy(localCell2);
            localCellProxy.setIndex(localCell2.getIndex() + m + 1);
            localRow.getCells().set(j, localCellProxy);
          }
        }
      }
    }
    return paramRow;
  }
  
  public Worksheet getSheet()
  {
    return this.sheet;
  }
  
  public void setSheet(Worksheet paramWorksheet)
  {
    this.sheet = paramWorksheet;
  }
  
  public void setExpandedColumnCount(int paramInt)
  {
    this.expandedColumnCount = paramInt;
  }
  
  public int getExpandedColumnCount()
  {
    return this.expandedColumnCount;
  }
  
  public void setExpandedRowCount(int paramInt)
  {
    this.expandedRowCount = paramInt;
  }
  
  public int getExpandedRowCount()
  {
    return this.expandedRowCount;
  }
  
  public void setFullColumns(int paramInt)
  {
    this.fullColumns = paramInt;
  }
  
  public int getFullColumns()
  {
    return this.fullColumns;
  }
  
  public void setFullRows(int paramInt)
  {
    this.fullRows = paramInt;
  }
  
  public int getFullRows()
  {
    return this.fullRows;
  }
  
  public void setDefaultColumnWidth(double paramDouble)
  {
    this.defaultColumnWidth = paramDouble;
  }
  
  public double getDefaultColumnWidth()
  {
    return this.defaultColumnWidth;
  }
  
  public void setDefaultRowHeight(double paramDouble)
  {
    this.defaultRowHeight = paramDouble;
  }
  
  public double getDefaultRowHeight()
  {
    return this.defaultRowHeight;
  }
  
  public void addRow(Row paramRow)
  {
    paramRow.setTable(this);
    this.rows.add(paramRow);
  }
  
  public Row addEmptyRow()
  {
    Row localRow = makeRow();
    addRow(localRow);
    localRow.setIndex(this.rows.size());
    return localRow;
  }
  
  public Row makeRow()
  {
    Row localRow = new Row();
    localRow.setHeight(this.defaultRowHeight);
    localRow.setCells(new ArrayList());
    localRow.setTable(this);
    return localRow;
  }
  
  public void fix()
  {
    fixCol();
    fixRow();
    fixCell();
  }
  
  public void fixCol()
  {
    int j = this.cols.size();
    if (this.cols.size() <= 0) {
      return;
    }
    Column localColumn1 = (Column)this.cols.get(0);
    Column localColumn2;
    for (int i = 0; i < localColumn1.getIndex() - 1; i++)
    {
      localColumn2 = new Column();
      localColumn2.setWidth(getDefaultColumnWidth());
      localColumn2.setIndex(localColumn1.getIndex() - i - 1);
      this.cols.add(0, localColumn2);
      j++;
    }
    while (i < j)
    {
      localColumn2 = (Column)this.cols.get(i);
      if (localColumn2.getWidth() < 0.0D) {
        localColumn2.setWidth(getDefaultColumnWidth());
      }
      if (localColumn2.getIndex() <= 0) {
        localColumn2.setIndex(i + 1);
      }
      int k;
      int m;
      Column localColumn3;
      if (localColumn2.getSpan() > 0)
      {
        k = localColumn2.getSpan();
        for (m = 0; m < k; m++)
        {
          localColumn3 = localColumn2.copy();
          i++;
          j++;
          localColumn3.setIndex(i + 1);
          this.cols.add(i, localColumn3);
        }
      }
      if (localColumn2.getIndex() > i + 1)
      {
        k = localColumn2.getIndex() - i - 1;
        for (m = 0; m < k; m++)
        {
          localColumn3 = new Column();
          localColumn3.setWidth(getDefaultColumnWidth());
          localColumn3.setIndex(i + 1);
          this.cols.add(i, localColumn3);
          i++;
          j++;
        }
      }
      i++;
    }
  }
  
  public Column makeColAt(int paramInt)
  {
    if (paramInt < 0) {
      throw Exceptions.code("excel.CAN_err_invalid_colIndex").param(paramInt);
    }
    if (paramInt < this.cols.size()) {
      return (Column)this.cols.get(paramInt);
    }
    for (int i = this.cols.size(); i <= paramInt; i++)
    {
      Column localColumn = new Column();
      localColumn.setWidth(getDefaultColumnWidth());
      localColumn.setIndex(i + 1);
      this.cols.add(localColumn);
    }
    return (Column)this.cols.get(paramInt);
  }
  
  public void fixRow()
  {
    int j = this.rows.size();
    if (j <= 0) {
      return;
    }
    for (int i = 0; i < j; i++)
    {
      Row localRow1 = (Row)this.rows.get(i);
      if (localRow1.getHeight() < 0.0D) {
        localRow1.setHeight(getDefaultRowHeight());
      }
      if (localRow1.getIndex() > i + 1)
      {
        int k = localRow1.getIndex() - i - 1;
        for (int m = 0; m < k; m++)
        {
          Row localRow2 = makeEmptyRow(i + 1);
          this.rows.add(i, localRow2);
          i++;
          j++;
        }
      }
      localRow1.setIndex(i + 1);
    }
  }
  
  Row makeEmptyRow(int paramInt)
  {
    Row localRow = Row.makeEmptyRow();
    localRow.setIndex(paramInt);
    localRow.setTable(this);
    localRow.setHeight(getDefaultRowHeight());
    return localRow;
  }
  
  public void fixEmpty()
  {
    int i = 0;
    int k = this.rows.size();
    if (k <= 0) {
      return;
    }
    removeEmptyTailRow();
    k = this.rows.size();
    Row localRow;
    int n;
    for (int j = 0; j < k; j++)
    {
      localRow = (Row)this.rows.get(j);
      n = localRow.getColCount();
      if (n > i) {
        i = n;
      }
    }
    for (j = this.rows.size() - 1; j >= 0; j--)
    {
      localRow = (Row)this.rows.get(j);
      n = localRow.getCells().size();
      Cell localCell1;
      for (int i1 = 0; i1 < n; i1++)
      {
        localCell1 = (Cell)localRow.getCells().get(i1);
        if (localCell1 == null)
        {
          Cell localCell2 = Cell.makeEmptyCell();
          localCell2.setRow(localRow);
          localCell2.setIndex(i1 + 1);
          syncCol(localCell2);
          localRow.getCells().set(i1, localCell2);
        }
      }
      for (i1 = n; i1 < i; i1++)
      {
        localCell1 = Cell.makeEmptyCell();
        localCell1.setRow(localRow);
        localCell1.setIndex(i1 + 1);
        syncCol(localCell1);
        localRow.getCells().add(localCell1);
      }
    }
    while (this.cols.size() > i) {
      this.cols.remove(this.cols.size() - 1);
    }
    for (int m = this.cols.size(); m < i; m++)
    {
      Column localColumn = new Column();
      localColumn.setWidth(getDefaultColumnWidth());
      localColumn.setIndex(m + 1);
      this.cols.add(localColumn);
    }
  }
  
  public void fixCell()
  {
    Row localRow1 = 0;
    int j = this.rows.size();
    if (j <= 0) {
      return;
    }
    Row localRow6;
    Object localObject;
    int k;
    for (int i = 0; i < j; i++)
    {
      localRow2 = (Row)this.rows.get(i);
      Row localRow3 = 0;
      localRow6 = 1;
      localObject = localRow2.getCells();
      k = ((List)localObject).size();
      for (int m = 0; m < k; m++)
      {
        Cell localCell2 = (Cell)((List)localObject).get(m);
        if (localCell2.getIndex() > 0)
        {
          int n = localCell2.getIndex() - localRow6;
          localRow6 = localCell2.getIndex();
          if (n > 0) {
            for (int i1 = 0; i1 < n; i1++)
            {
              Cell localCell3 = Cell.makeEmptyCell();
              localCell3.setRow(localRow2);
              localCell3.setIndex(localRow6 - n + i1);
              int i2 = m;
              ((List)localObject).add(i2, localCell3);
              m++;
              k++;
              syncCol(localCell3);
            }
          }
        }
        else
        {
          localCell2.setIndex(localRow6);
        }
        if (!localCell2.isIgnored())
        {
          insertMergeAcrossCell(localRow2, localCell2, m);
          expandCell(localCell2, i);
          k = ((List)localObject).size();
        }
        m += localCell2.getMergeAcross();
        localRow6 += localCell2.getMergeAcross();
        localRow3 = localRow6;
        localRow6++;
        syncCol(localCell2);
      }
      if (localRow3 > localRow1) {
        localRow1 = localRow3;
      }
    }
    Row localRow2 = localRow1;
    removeEmptyTailRow();
    for (i = this.rows.size() - 1; i >= 0; i--)
    {
      Row localRow4 = (Row)this.rows.get(i);
      localRow6 = localRow4.getCells().size();
      localObject = localRow6 == 0 ? Cell.makeEmptyCell() : (Cell)localRow4.getCells().get(localRow6 - 1);
      for (k = ((Cell)localObject).getIndex(); k < localRow1; k++)
      {
        Cell localCell1 = Cell.makeEmptyCell();
        localCell1.setRow(localRow4);
        localCell1.setIndex(k + 1);
        syncCol(localCell1);
        localRow4.getCells().add(localCell1);
      }
    }
    while (this.cols.size() > localRow2) {
      this.cols.remove(this.cols.size() - 1);
    }
    for (Row localRow5 = this.cols.size(); localRow5 < localRow2; localRow5++)
    {
      Column localColumn = new Column();
      localColumn.setWidth(getDefaultColumnWidth());
      localColumn.setIndex(localRow5 + 1);
      this.cols.add(localColumn);
    }
  }
  
  void syncCol(Cell paramCell)
  {
    if (this.cols.size() >= paramCell.getIndex())
    {
      Column localColumn = (Column)this.cols.get(paramCell.getIndex() - 1);
      if (paramCell.getStyle() == null) {
        paramCell.setStyle(localColumn.getStyle());
      }
      paramCell.setHidden(localColumn.isHidden());
    }
  }
  
  void expandCell(Cell paramCell, int paramInt)
  {
    Row localRow;
    if (paramCell.getMergeDown() + paramInt >= this.rows.size()) {
      for (i = this.rows.size(); i <= paramCell.getMergeDown() + paramInt; i++)
      {
        localRow = makeEmptyRow(i + 1);
        this.rows.add(localRow);
      }
    }
    for (int i = 0; i < paramCell.getMergeDown(); i++)
    {
      localRow = (Row)this.rows.get(paramInt + i + 1);
      insertMergeDownCell(localRow, paramCell);
    }
  }
  
  void insertMergeDownCell(Row paramRow, Cell paramCell)
  {
    CellProxy localCellProxy = new CellProxy(paramCell);
    localCellProxy.setRow(paramRow);
    localCellProxy.setIndex(paramCell.getIndex());
    List localList = paramRow.getCells();
    int j = localList.size();
    int k = 0;
    for (int i = 0; i < j; i++)
    {
      Cell localCell = (Cell)localList.get(i);
      if (localCell.getIndex() > 0) {
        k = localCell.getIndex();
      } else {
        k++;
      }
      if (k > paramCell.getIndex())
      {
        localList.add(i, localCellProxy);
        insertMergeAcrossCell(paramRow, paramCell, i);
        break;
      }
    }
    if (i == j)
    {
      localList.add(localCellProxy);
      insertMergeAcrossCell(paramRow, paramCell, i);
    }
  }
  
  void insertMergeAcrossCell(Row paramRow, Cell paramCell, int paramInt)
  {
    for (int i = 0; i < paramCell.getMergeAcross(); i++)
    {
      Cell localCell = paramRow.getCell(paramInt + i + 1);
      if ((localCell == null) || (localCell.getRealCell() != paramCell) || (localCell.getIndex() != paramInt + i + 1))
      {
        CellProxy localCellProxy = new CellProxy(paramCell);
        localCellProxy.setRow(paramRow);
        localCellProxy.setIndex(paramCell.getIndex() + i + 1);
        paramRow.getCells().add(paramInt + i + 1, localCellProxy);
      }
    }
  }
  
  public Cell getCell(int paramInt1, int paramInt2)
  {
    Row localRow = (Row)getRow(paramInt1);
    if (localRow == null) {
      return null;
    }
    return localRow.getCell(paramInt2);
  }
  
  public Cell makeCellAt(int paramInt1, int paramInt2)
  {
    Row localRow = makeRowAt(paramInt1);
    return localRow.makeCellAt(paramInt2);
  }
  
  public void addCell(int paramInt1, int paramInt2, IBasicCellModel paramIBasicCellModel)
  {
    Row localRow = makeRowAt(paramInt1);
    localRow.setCell(paramInt2, (Cell)paramIBasicCellModel);
  }
  
  public Row makeRowAt(int paramInt)
  {
    if (paramInt < 0) {
      throw Exceptions.code("excel.CAN_err_invalid_rowIndex").param(paramInt);
    }
    for (int i = this.rows.size(); i <= paramInt; i++)
    {
      Row localRow = Row.makeEmptyRow();
      localRow.setHeight(getDefaultRowHeight());
      addRow(localRow);
    }
    return (Row)this.rows.get(paramInt);
  }
  
  public Cell getCell(CellPosition paramCellPosition)
  {
    if (paramCellPosition == null) {
      return null;
    }
    return getCell(paramCellPosition.getRowPos(), paramCellPosition.getColPos());
  }
  
  public static List<RowBlock> insertBlocks(List<RowBlock> paramList, int paramInt1, int paramInt2)
  {
    ArrayList localArrayList = new ArrayList(paramList.size());
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      RowBlock localRowBlock1 = (RowBlock)paramList.get(i);
      if (localRowBlock1.getLastRowNum() >= paramInt1)
      {
        if (localRowBlock1.getFirstRowNum() >= paramInt2) {
          break;
        }
        int k = Math.max(localRowBlock1.getFirstRowNum(), paramInt1);
        int m = Math.min(localRowBlock1.getLastRowNum(), paramInt2 - 1);
        if (k <= m)
        {
          RowBlock localRowBlock2 = new RowBlock(localRowBlock1);
          localRowBlock2.setFirstRowNum(k);
          localRowBlock2.setLastRowNum(m);
          localArrayList.add(localRowBlock2);
        }
      }
    }
    return localArrayList;
  }
  
  public List<TablePiece> getTablePieces()
  {
    ArrayList localArrayList = new ArrayList();
    List localList = getSheet().getWorkbook().getRowBlocks(getSheet());
    int j = this.rows.size();
    int k = 0;
    for (int i = 0; i < j; i++)
    {
      Row localRow = (Row)this.rows.get(i);
      if (localRow.isParagraphRow())
      {
        if (i > k) {
          localArrayList.add(new TablePiece(insertBlocks(localList, k, i)));
        }
        localArrayList.add(new TablePiece(i));
        k = i + 1;
      }
    }
    if (k < j) {
      localArrayList.add(new TablePiece(insertBlocks(localList, k, j)));
    }
    return localArrayList;
  }
  
  public TableModel makeTableModel()
  {
    return new _A(0);
  }
  
  public TableModel makeTableModel(int paramInt)
  {
    return new _A(paramInt);
  }
  
  public void removeBlankRight()
  {
    int j = this.cols.size();
    for (int i = j - 1; i >= 0; i--)
    {
      if (!isColBlank(i)) {
        break;
      }
      Iterator localIterator = this.rows.iterator();
      while (localIterator.hasNext())
      {
        Row localRow = (Row)localIterator.next();
        localRow.getCells().remove(i);
      }
      this.cols.remove(i);
    }
  }
  
  public void resizeToPage(boolean paramBoolean)
  {
    PageInfo localPageInfo = new PageInfo();
    localPageInfo.setContentWidth(this.sheet.isHorPage() ? 680.0D : 476.0D);
    localPageInfo.setRefWidth(getTotalWidth());
    Iterator localIterator = this.cols.iterator();
    Object localObject;
    while (localIterator.hasNext())
    {
      localObject = (Column)localIterator.next();
      ((Column)localObject).setWidth(localPageInfo.mapRoundX(((Column)localObject).getWidth()));
    }
    if (!paramBoolean)
    {
      localIterator = this.rows.iterator();
      while (localIterator.hasNext())
      {
        localObject = (Row)localIterator.next();
        ((Row)localObject).setHeight(localPageInfo.mapY(((Row)localObject).getHeight()));
      }
    }
  }
  
  public List<List> getCellDataNotEmpty(int paramInt)
  {
    ArrayList localArrayList = new ArrayList();
    int j = getRowCount();
    for (int i = paramInt; i < j; i++)
    {
      Row localRow = (Row)getRow(i);
      if ((localRow == null) || (localRow.isEmptyData())) {
        break;
      }
      List localList = localRow.getStripedDataList();
      localArrayList.add(localList);
    }
    return localArrayList;
  }
  
  public List<List<Pair>> getStyleDataNotEmpty(int paramInt)
  {
    ArrayList localArrayList1 = new ArrayList();
    int j = getRowCount();
    for (int i = paramInt; i < j; i++)
    {
      Row localRow = (Row)getRow(i);
      if ((localRow == null) || (localRow.isEmptyData())) {
        break;
      }
      ArrayList localArrayList2 = new ArrayList(localRow.getColCount());
      Iterator localIterator = localRow.getCells().iterator();
      while (localIterator.hasNext())
      {
        Cell localCell = (Cell)localIterator.next();
        String str1 = StringUtils.strip(localCell.getData());
        String str2 = localCell.getStyleID();
        if ((str1 == null) && (str2 == null))
        {
          localArrayList1.add(null);
        }
        else
        {
          Pair localPair = new Pair(str2, str1);
          localArrayList2.add(localPair);
        }
      }
      localArrayList1.add(localArrayList2);
    }
    return localArrayList1;
  }
  
  class _A
    implements TableModel, Serializable
  {
    private static final long serialVersionUID = 5207237004173884695L;
    int B;
    
    public _A(int paramInt)
    {
      this.B = paramInt;
    }
    
    public int getRowCount()
    {
      return Table.this.getRows().size() - this.B;
    }
    
    public int getColumnCount()
    {
      return Table.this.getColCount();
    }
    
    public String getColumnName(int paramInt)
    {
      if ((paramInt >= Table.this.cols.size()) || (paramInt < 0)) {
        return null;
      }
      return ((Column)Table.this.cols.get(paramInt)).getName();
    }
    
    public Class<?> getColumnClass(int paramInt)
    {
      return Object.class;
    }
    
    public boolean isCellEditable(int paramInt1, int paramInt2)
    {
      return false;
    }
    
    public Object getValueAt(int paramInt1, int paramInt2)
    {
      Row localRow = (Row)Table.this.getRow(paramInt1 + this.B);
      if (localRow == null) {
        return null;
      }
      return localRow.getCellValue(paramInt2);
    }
    
    public void setValueAt(Object paramObject, int paramInt1, int paramInt2)
    {
      Row localRow = (Row)Table.this.getRow(paramInt1 + this.B);
      if (localRow == null) {
        return;
      }
      localRow.setCellValue(paramInt2, paramObject);
    }
    
    public void addTableModelListener(TableModelListener paramTableModelListener) {}
    
    public void removeTableModelListener(TableModelListener paramTableModelListener) {}
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\Table.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */