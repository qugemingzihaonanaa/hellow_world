package edu.thu.ext.excel.model;

import edu.thu.model.tree.TreeNode;
import edu.thu.util.StringUtils;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CellBandModel
  implements Serializable
{
  private static final long serialVersionUID = 4139517251517110531L;
  List<Integer> G;
  List<Integer> F;
  List<Integer> C;
  int D = -1;
  int A;
  int B = 1;
  boolean E;
  
  public String toString()
  {
    return "Band(index=" + this.A + ",width=" + this.B + ",branchCellPos=" + this.D + ")";
  }
  
  public TreeNode toNode()
  {
    TreeNode localTreeNode = TreeNode.make("band");
    localTreeNode.setAttribute("index", Integer.valueOf(this.A));
    localTreeNode.setAttribute("width", Integer.valueOf(this.B));
    localTreeNode.setAttribute("branchCellPos", Integer.valueOf(this.D));
    localTreeNode.setAttribute("alignWithParent", Boolean.valueOf(this.E));
    if (this.G != null) {
      localTreeNode.setAttribute("siblingPosList", StringUtils.join(this.G, ","));
    }
    if (this.F != null) {
      localTreeNode.setAttribute("posList", StringUtils.join(this.F, ","));
    }
    if (this.C != null) {
      localTreeNode.setAttribute("samePosList", StringUtils.join(this.C, ","));
    }
    return localTreeNode;
  }
  
  public boolean isAlignWithParent()
  {
    return this.E;
  }
  
  public void setAlignWithParent(boolean paramBoolean)
  {
    this.E = paramBoolean;
  }
  
  public List<Integer> getSamePosList()
  {
    return this.C;
  }
  
  public void setSamePosList(List<Integer> paramList)
  {
    this.C = paramList;
  }
  
  public int getWidth()
  {
    return this.B;
  }
  
  public void setWidth(int paramInt)
  {
    this.B = paramInt;
  }
  
  public int getIndex()
  {
    return this.A;
  }
  
  public void setIndex(int paramInt)
  {
    this.A = paramInt;
  }
  
  public List<Integer> getPosList()
  {
    return this.F;
  }
  
  public void setPosList(List<Integer> paramList)
  {
    this.F = paramList;
  }
  
  public List<Integer> getSiblingPosList()
  {
    return this.G;
  }
  
  public void setSiblingPosList(List<Integer> paramList)
  {
    this.G = paramList;
  }
  
  public int getBranchCellPos()
  {
    return this.D;
  }
  
  public void setBranchCellPos(int paramInt)
  {
    this.D = paramInt;
  }
  
  public void addSiblingPos(int paramInt)
  {
    if (this.G == null) {
      this.G = new ArrayList(3);
    }
    this.G.add(Integer.valueOf(paramInt));
  }
  
  public void addPos(int paramInt)
  {
    if (this.F == null) {
      this.F = new ArrayList(3);
    }
    this.F.add(Integer.valueOf(paramInt));
    addSiblingPos(paramInt);
  }
  
  public void addSamePos(int paramInt)
  {
    if (this.C == null) {
      this.C = new ArrayList(3);
    }
    this.C.add(Integer.valueOf(paramInt));
  }
  
  public CellBandModel splitAt(int paramInt)
  {
    CellBandModel localCellBandModel = new CellBandModel();
    localCellBandModel.setIndex(this.A + paramInt);
    localCellBandModel.setWidth(this.B - paramInt);
    localCellBandModel.setAlignWithParent(this.E);
    if (this.G != null) {
      localCellBandModel.setSiblingPosList(new ArrayList(this.G));
    }
    setWidth(paramInt);
    return localCellBandModel;
  }
  
  public boolean containsPos(int paramInt)
  {
    if (this.D == paramInt) {
      return true;
    }
    if (this.G != null) {
      return this.G.contains(Integer.valueOf(paramInt));
    }
    return false;
  }
  
  public List<Cell> getSiblingCells(List<Cell> paramList)
  {
    if (this.G == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(this.G.size());
    Iterator localIterator = this.G.iterator();
    while (localIterator.hasNext())
    {
      int i = ((Integer)localIterator.next()).intValue();
      localArrayList.add((Cell)paramList.get(i));
    }
    return localArrayList;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\CellBandModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */