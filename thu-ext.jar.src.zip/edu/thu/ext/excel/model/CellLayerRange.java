package edu.thu.ext.excel.model;

import java.io.Serializable;

public class CellLayerRange
  implements Serializable
{
  private static final long serialVersionUID = -6932073757941060469L;
  CellLayerPosition B;
  CellLayerPosition A;
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(this.B);
    localStringBuilder.append(':');
    localStringBuilder.append(this.A);
    return localStringBuilder.toString();
  }
  
  public CellLayerPosition getLtPos()
  {
    return this.B;
  }
  
  public void setLtPos(CellLayerPosition paramCellLayerPosition)
  {
    this.B = paramCellLayerPosition;
  }
  
  public CellLayerPosition getRbPos()
  {
    return this.A;
  }
  
  public void setRbPos(CellLayerPosition paramCellLayerPosition)
  {
    this.A = paramCellLayerPosition;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\CellLayerRange.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */