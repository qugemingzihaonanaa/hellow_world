package edu.thu.ext.excel.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class PageBreaks
  implements Serializable
{
  private static final long serialVersionUID = 589748153484766806L;
  List<Integer> B = new ArrayList();
  List<Integer> A = new ArrayList();
  
  public PageBreaks copy()
  {
    PageBreaks localPageBreaks = new PageBreaks();
    localPageBreaks.B = new ArrayList(this.B);
    localPageBreaks.A = new ArrayList(this.A);
    return localPageBreaks;
  }
  
  public void appendPageBreaks(PageBreaks paramPageBreaks, int paramInt)
  {
    this.B.addAll(paramPageBreaks.B);
    if (paramInt > 0)
    {
      Iterator localIterator = paramPageBreaks.A.iterator();
      while (localIterator.hasNext())
      {
        int i = ((Integer)localIterator.next()).intValue();
        addRow(i + paramInt);
      }
    }
    else
    {
      this.A.addAll(paramPageBreaks.A);
    }
  }
  
  public void addCol(int paramInt)
  {
    this.B.add(Integer.valueOf(paramInt));
  }
  
  public void addRow(int paramInt)
  {
    this.A.add(Integer.valueOf(paramInt));
  }
  
  public void moveRows(int paramInt)
  {
    int j = this.A.size();
    for (int i = 0; i < j; i++)
    {
      int k = ((Integer)this.A.get(i)).intValue() + paramInt;
      this.A.set(i, Integer.valueOf(k));
    }
  }
  
  public List<Integer> getRows()
  {
    return this.A;
  }
  
  public void setRows(List<Integer> paramList)
  {
    this.A = paramList;
  }
  
  public List<Integer> getCols()
  {
    return this.B;
  }
  
  public void setCols(List<Integer> paramList)
  {
    this.B = paramList;
  }
  
  public boolean isEmpty()
  {
    return (this.A.isEmpty()) && (this.B.isEmpty());
  }
  
  public boolean isPageBreakBeforeRow(int paramInt)
  {
    return this.A.contains(Integer.valueOf(paramInt));
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\PageBreaks.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */