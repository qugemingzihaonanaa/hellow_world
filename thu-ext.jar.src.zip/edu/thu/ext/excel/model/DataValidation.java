package edu.thu.ext.excel.model;

import java.io.Serializable;

public class DataValidation
  implements Serializable
{
  private static final long serialVersionUID = -4526843544257119768L;
  String G;
  Number H;
  Number E;
  String B;
  String C;
  String A;
  String F;
  boolean D;
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\DataValidation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */