package edu.thu.ext.excel.model;

public class Data
{
  String A;
  String B;
  
  public void setType(String paramString)
  {
    this.A = paramString;
  }
  
  public String getType()
  {
    return this.A;
  }
  
  public void setValue(String paramString)
  {
    this.B = paramString;
  }
  
  public String getVale()
  {
    return this.B;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\Data.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */