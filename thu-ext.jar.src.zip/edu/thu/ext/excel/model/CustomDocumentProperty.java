package edu.thu.ext.excel.model;

import edu.thu.lang.Variant;
import edu.thu.lang.util.JsonUtils;
import java.io.Serializable;

public class CustomDocumentProperty
  extends Variant
  implements Serializable
{
  private static final long serialVersionUID = 7446148844603504995L;
  String name;
  String type;
  String value;
  
  public CustomDocumentProperty() {}
  
  public CustomDocumentProperty(String paramString1, String paramString2, String paramString3)
  {
    this.name = paramString2;
    this.type = paramString1;
    if ((paramString3 != null) && ("datetime.tz".equals(paramString1)))
    {
      int i = paramString3.indexOf('T');
      if (i > 0) {
        paramString3 = paramString3.substring(0, i);
      }
    }
    this.value = paramString3;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public void setName(String paramString)
  {
    this.name = paramString;
  }
  
  public String getType()
  {
    return this.type;
  }
  
  public void setType(String paramString)
  {
    this.type = paramString;
  }
  
  public String getValue()
  {
    return this.value;
  }
  
  public void setValue(String paramString)
  {
    this.value = paramString;
  }
  
  public Object objectValue()
  {
    return this.value;
  }
  
  public boolean booleanValue()
  {
    return "1".equals(this.value);
  }
  
  public boolean booleanValue(boolean paramBoolean)
  {
    return booleanValue();
  }
  
  public Object toJson()
  {
    return JsonUtils.getInstance().deserialize(this.value);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\CustomDocumentProperty.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */