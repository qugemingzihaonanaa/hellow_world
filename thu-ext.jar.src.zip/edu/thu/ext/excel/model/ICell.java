package edu.thu.ext.excel.model;

import edu.thu.model.table.IBasicCellModel;
import java.util.Map;

public abstract interface ICell
  extends IBasicCellModel
{
  public abstract boolean isIgnored();
  
  public abstract String getComment();
  
  public abstract String getData();
  
  public abstract RichData getRichData();
  
  public abstract Object getValue();
  
  public abstract Object getFormatedValue(Map<String, Object> paramMap);
  
  public abstract void evaluatePrepareRow(Map<String, Object> paramMap);
  
  public abstract Object getO();
  
  public abstract String getKey();
  
  public abstract int getIndex();
  
  public abstract int getMergeAcross();
  
  public abstract int getMergeDown();
  
  public abstract String getFormula();
  
  public abstract String getDataType();
  
  public abstract String getStyleID();
  
  public abstract String getUid();
  
  public abstract Style getStyle();
  
  public abstract IRow getRow();
  
  public abstract boolean isNumberCell();
  
  public abstract boolean maybeNumberCell();
  
  public abstract boolean isStaticCell();
  
  public abstract boolean isBlank();
  
  public abstract ICell getRealCell();
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\ICell.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */