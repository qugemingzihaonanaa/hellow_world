package edu.thu.ext.excel.model;

import edu.thu.java.util.Coercions;
import java.io.Serializable;

public class RowBlock
  implements Serializable
{
  private static final long serialVersionUID = 9151135669946086906L;
  String D;
  int A;
  int C;
  NamedRange B;
  String E;
  
  public RowBlock(RowBlock paramRowBlock)
  {
    this.D = paramRowBlock.D;
    this.A = paramRowBlock.A;
    this.C = paramRowBlock.C;
    this.B = paramRowBlock.B;
    this.E = paramRowBlock.E;
  }
  
  public RowBlock(String paramString, int paramInt1, int paramInt2)
  {
    this.D = paramString;
    this.A = paramInt1;
    this.C = paramInt2;
  }
  
  public RowBlock(String paramString, NamedRange paramNamedRange)
  {
    this.A = paramNamedRange.getMinRow();
    this.C = paramNamedRange.getMaxRow();
    this.D = paramString;
    this.B = paramNamedRange;
  }
  
  public int getInnerCount()
  {
    return Coercions.toInt(this.B.getNamePart(2), 1);
  }
  
  public String getVarName()
  {
    return this.E;
  }
  
  public void setVarName(String paramString)
  {
    this.E = paramString;
  }
  
  public NamedRange getRange()
  {
    return this.B;
  }
  
  public String getType()
  {
    return this.D;
  }
  
  public void setType(String paramString)
  {
    this.D = paramString;
  }
  
  public int getFirstRowNum()
  {
    return this.A;
  }
  
  public void setFirstRowNum(int paramInt)
  {
    this.A = paramInt;
  }
  
  public int getLastRowNum()
  {
    return this.C;
  }
  
  public void setLastRowNum(int paramInt)
  {
    this.C = paramInt;
  }
  
  public boolean isEmpty()
  {
    return this.C <= this.A;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\RowBlock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */