package edu.thu.ext.excel.model;

import edu.thu.lang.el.IExpressionReference;
import java.util.Map;

public class CellProxy
  extends Cell
{
  private static final long serialVersionUID = 603454828094154249L;
  Cell cell;
  
  public CellProxy(Cell paramCell)
  {
    this.cell = paramCell;
  }
  
  public boolean isIgnored()
  {
    return true;
  }
  
  public Cell getRealCell()
  {
    return this.cell;
  }
  
  public double getFullWidth()
  {
    return this.cell.getFullWidth();
  }
  
  public String getHtml()
  {
    return this.cell.getHtml();
  }
  
  public String toString()
  {
    return this.cell.toString();
  }
  
  public Object evaluate(Map paramMap)
  {
    return this.cell.evaluate(paramMap);
  }
  
  public String getClassName(String paramString)
  {
    return this.cell.getClassName(paramString);
  }
  
  public int getColspan()
  {
    return this.cell.getColspan();
  }
  
  public String getComment()
  {
    return this.cell.getComment();
  }
  
  public Map<String, Object> getCommentVars()
  {
    return this.cell.getCommentVars();
  }
  
  public String getData()
  {
    return this.cell.getData();
  }
  
  public String getDataType()
  {
    return this.cell.getDataType();
  }
  
  public String getDisplay()
  {
    return this.cell.getDisplay();
  }
  
  public IExpressionReference getExpandExpr()
  {
    return this.cell.getExpandExpr();
  }
  
  public int getExpandType()
  {
    return this.cell.getExpandType();
  }
  
  public FieldDefinition getFieldDefinition()
  {
    return this.cell.getFieldDefinition();
  }
  
  public String getFormula()
  {
    return this.cell.getFormula();
  }
  
  public IExpressionReference getLinkExpr()
  {
    return this.cell.getLinkExpr();
  }
  
  public String getLinkExprStr()
  {
    return this.cell.getLinkExprStr();
  }
  
  public int getMergeAcross()
  {
    return this.cell.getMergeAcross();
  }
  
  public int getMergeDown()
  {
    return this.cell.getMergeDown();
  }
  
  public int getMergeStatus()
  {
    return this.cell.getMergeStatus();
  }
  
  public RichData getRichData()
  {
    return this.cell.getRichData();
  }
  
  public int getRowspan()
  {
    return this.cell.getRowspan();
  }
  
  public Style getStyle()
  {
    return this.cell.getStyle();
  }
  
  public String getStyleID()
  {
    return this.cell.getStyleID();
  }
  
  public Object getValue()
  {
    return this.cell.getValue();
  }
  
  public IExpressionReference getValueExpr()
  {
    return this.cell.getValueExpr();
  }
  
  public String getValueExprStr()
  {
    return this.cell.getValueExprStr();
  }
  
  public Object getXlsObj()
  {
    return this.cell.getXlsObj();
  }
  
  public boolean isBoolHidden()
  {
    return this.cell.isBoolHidden();
  }
  
  public boolean isHidden()
  {
    return this.cell.isHidden();
  }
  
  public boolean isRichFormat()
  {
    return this.cell.isRichFormat();
  }
  
  public boolean isStaticCell()
  {
    return this.cell.isStaticCell();
  }
  
  public boolean isExpandVer()
  {
    return this.cell.isExpandVer();
  }
  
  public boolean isExpandHor()
  {
    return this.cell.isExpandHor();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\CellProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */