package edu.thu.ext.excel.model;

import edu.thu.app.sys.UserResolver;
import edu.thu.app.sys.user.UserInfo;
import edu.thu.core.IResource;
import edu.thu.ext.hibernate.FileItem;
import edu.thu.lang.reflect.BeanInstance;
import edu.thu.orm.component.impl.FileComponent;
import edu.thu.service.util.ContextHelper;
import edu.thu.util.UrlUtils;
import java.io.Serializable;

public class ImgData
  extends ClientAnchor
  implements Serializable
{
  private static final long serialVersionUID = -5074975626012965257L;
  public static final String IMG_TYPE_PNG = "png";
  public static final String IMG_TYPE_JPG = "jpg";
  public static final String IMG_TYPE_BMP = "bmp";
  public static final String FILE_EXT_JPEG = "jpeg";
  public static final String DEFAULT_IMG_TYPE = "png";
  String K = "png";
  byte[] L;
  String N;
  Object O;
  IChartBean M;
  
  public ImgData() {}
  
  public ImgData(String paramString)
  {
    this.N = paramString;
  }
  
  public ImgData copy()
  {
    BeanInstance localBeanInstance = new BeanInstance(this);
    return (ImgData)localBeanInstance.cloneInstance(false);
  }
  
  public Object getDataExpr()
  {
    return this.O;
  }
  
  public void setDataExpr(Object paramObject)
  {
    this.O = paramObject;
  }
  
  public IChartBean getChartBean()
  {
    return this.M;
  }
  
  public void setChartBean(IChartBean paramIChartBean)
  {
    this.M = paramIChartBean;
  }
  
  public ImgData chartBean(IChartBean paramIChartBean)
  {
    this.M = paramIChartBean;
    return this;
  }
  
  public String getAlterText()
  {
    return this.N;
  }
  
  public void setAlterText(String paramString)
  {
    this.N = paramString;
  }
  
  public ImgData text(String paramString)
  {
    this.N = paramString;
    return this;
  }
  
  public ImgData empty()
  {
    this.N = null;
    this.L = null;
    return this;
  }
  
  public String toString()
  {
    return this.N == null ? "" : this.N;
  }
  
  public void init(String paramString, int paramInt1, int paramInt2, byte[] paramArrayOfByte)
  {
    this.A = paramString;
    fillCell(paramInt1, paramInt2);
    this.L = paramArrayOfByte;
  }
  
  public byte[] getData()
  {
    if (this.M != null) {
      return this.M.getImage(this.K);
    }
    return this.L;
  }
  
  public void setData(byte[] paramArrayOfByte)
  {
    this.L = paramArrayOfByte;
  }
  
  public String getImgType()
  {
    return this.K;
  }
  
  public void setImgType(String paramString)
  {
    if ("jpeg".equals(paramString)) {
      paramString = "jpg";
    }
    this.K = paramString;
  }
  
  public ImgData imgType(String paramString)
  {
    setImgType(paramString);
    return this;
  }
  
  public boolean isEmptyData()
  {
    if (this.M != null) {
      return false;
    }
    return (this.L == null) || (this.L.length <= 0);
  }
  
  public ImgData namepic(String paramString)
  {
    UserInfo localUserInfo = UserResolver.resolve(paramString);
    if (localUserInfo == null) {
      return empty();
    }
    setAlterText(localUserInfo.getHmName());
    FileComponent localFileComponent = localUserInfo.getNamePic();
    if ((localFileComponent == null) || (!localFileComponent.exists()))
    {
      this.L = null;
      return this;
    }
    byte[] arrayOfByte = localFileComponent.getFileItem().loadBytes();
    String str = UrlUtils.getExtension(localFileComponent.getFileName());
    setImgType(str);
    setData(arrayOfByte);
    return this;
  }
  
  public ImgData picfile(Object paramObject)
  {
    FileItem localFileItem = null;
    if ((paramObject instanceof FileComponent))
    {
      localObject = (FileComponent)paramObject;
      if (((FileComponent)localObject).exists()) {
        localFileItem = ((FileComponent)localObject).getFileItem();
      }
    }
    else if ((paramObject instanceof FileItem))
    {
      localFileItem = (FileItem)paramObject;
    }
    if (localFileItem == null)
    {
      this.L = null;
      return this;
    }
    Object localObject = localFileItem.loadBytes();
    String str = UrlUtils.getExtension(localFileItem.getFileName());
    setImgType(str);
    setData((byte[])localObject);
    return this;
  }
  
  public ImgData load(String paramString)
  {
    IResource localIResource = ContextHelper.getCustomizableResource(paramString);
    if ((!localIResource.exists()) || (localIResource.length() <= 0L)) {
      return empty();
    }
    String str = UrlUtils.getExtension(localIResource.getFileName());
    byte[] arrayOfByte = ContextHelper.loadBytes(localIResource.getPath());
    setImgType(str);
    setData(arrayOfByte);
    return this;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\ImgData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */