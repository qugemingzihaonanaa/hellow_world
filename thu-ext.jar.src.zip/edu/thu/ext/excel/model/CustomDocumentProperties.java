package edu.thu.ext.excel.model;

import edu.thu.math.alg.Alog;
import java.util.ArrayList;

public class CustomDocumentProperties
  extends ArrayList<CustomDocumentProperty>
{
  private static final long serialVersionUID = -1468604540223149551L;
  
  public CustomDocumentProperty getByName(String paramString)
  {
    return (CustomDocumentProperty)Alog.find(this, "name", paramString);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\CustomDocumentProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */