package edu.thu.ext.excel.model;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.util.Coercions;
import edu.thu.lang.IVariant;
import edu.thu.lang.Variant;
import edu.thu.lang.el.IExpressionReference;
import edu.thu.lang.exceptions.StdException;
import edu.thu.lang.util.ITplReference;
import edu.thu.lang.util.TplC;
import edu.thu.model.data.WxTable;
import edu.thu.model.stg.ds.DataSourceMeta;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceContext;
import edu.thu.service.SystemServiceContext;
import edu.thu.util.StringUtils;
import edu.thu.xml.dom.DomToTree;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

public class WxReportConfig
  implements Serializable
{
  private static final long serialVersionUID = -4482943204466883077L;
  static ResourceBundle O = ResourceBundle.getBundle(WxReportConfig.class.getName());
  PageMakerConfig C = new PageMakerConfig();
  SheetConfig H = new SheetConfig();
  ITplReference D;
  ITplReference L;
  ITplReference I;
  ITplReference M;
  ITplReference B;
  Map<String, ITplReference> F = new HashMap();
  Map<String, CellVarMap> E;
  Map<String, Object> J = new HashMap();
  Map<String, Style> K = new HashMap();
  Map<String, Map<String, Object>> A = new HashMap();
  Map<String, Map<String, ITplReference>> G = new HashMap();
  DataSourceMeta N;
  
  public static String c(String paramString)
  {
    try
    {
      return O.getString(paramString);
    }
    catch (Exception localException) {}
    return paramString;
  }
  
  public DataSourceMeta getDsMeta()
  {
    return this.N;
  }
  
  public void setDsMeta(DataSourceMeta paramDataSourceMeta)
  {
    this.N = paramDataSourceMeta;
  }
  
  public Map<String, Object> makeSheetProps(String paramString)
  {
    Object localObject = (Map)this.A.get(paramString);
    if (localObject == null)
    {
      localObject = new HashMap();
      this.A.put(paramString, localObject);
    }
    return (Map<String, Object>)localObject;
  }
  
  public Map<String, ITplReference> makeSheetTpls(String paramString)
  {
    Object localObject = (Map)this.G.get(paramString);
    if (localObject == null)
    {
      localObject = new HashMap();
      this.G.put(paramString, localObject);
    }
    return (Map<String, ITplReference>)localObject;
  }
  
  public Map<String, ITplReference> getSheetTpls(String paramString)
  {
    return (Map)this.G.get(paramString);
  }
  
  public ITplReference getSheetTpl(String paramString1, String paramString2)
  {
    Map localMap = (Map)this.G.get(paramString1);
    if (localMap == null) {
      return null;
    }
    return (ITplReference)localMap.get(paramString2);
  }
  
  public Map<String, Style> getStyleMap()
  {
    return this.K;
  }
  
  public Style getStyle(String paramString)
  {
    return (Style)this.K.get(paramString);
  }
  
  public List<Object> getTplContentBySelector(String paramString)
  {
    if (this.F == null) {
      return null;
    }
    Object localObject = this.F.get(paramString);
    if (localObject == null) {
      return null;
    }
    return Collections.singletonList(localObject);
  }
  
  public CellVarMap mapVar(String paramString)
  {
    if (this.E == null) {
      return null;
    }
    return (CellVarMap)this.E.get(paramString);
  }
  
  public Map<String, Object> getProperties()
  {
    return this.J;
  }
  
  public Object getProperty(String paramString)
  {
    return this.J.get(paramString);
  }
  
  public boolean getBooleanProperty(String paramString, boolean paramBoolean)
  {
    Object localObject = getProperty(paramString);
    if (localObject == null) {
      return paramBoolean;
    }
    if (localObject.equals("1")) {
      return true;
    }
    if (localObject.equals("0")) {
      return false;
    }
    return Coercions.toBoolean(localObject, paramBoolean);
  }
  
  public Map<String, ITplReference> getTpls()
  {
    return this.F;
  }
  
  public void setTpls(Map<String, ITplReference> paramMap)
  {
    this.F = paramMap;
  }
  
  public ITplReference getTpl(String paramString)
  {
    if ((this.F == null) || (paramString == null)) {
      return null;
    }
    return (ITplReference)this.F.get(paramString);
  }
  
  public PageMakerConfig getPageMaker()
  {
    return this.C;
  }
  
  public SheetConfig getSheetConfig()
  {
    return this.H;
  }
  
  public ITplReference getSheetLoopVarTpl(String paramString)
  {
    SheetConfig.Item localItem = this.H.getItem(paramString);
    if (localItem == null) {
      return null;
    }
    return localItem.getSheetLoopVarTpl();
  }
  
  public ITplReference getSheetNameTpl(String paramString)
  {
    SheetConfig.Item localItem = this.H.getItem(paramString);
    if (localItem == null) {
      return null;
    }
    return localItem.getSheetNameTpl();
  }
  
  public ITplReference getAfterTpl()
  {
    return this.I;
  }
  
  public void setAfterTpl(ITplReference paramITplReference)
  {
    this.I = paramITplReference;
  }
  
  public ITplReference getBeforeTpl()
  {
    return this.D;
  }
  
  public void setBeforeTpl(ITplReference paramITplReference)
  {
    this.D = paramITplReference;
  }
  
  public ITplReference getBeforeExpandTpl()
  {
    return this.M;
  }
  
  public void setBeforeExpandTpl(ITplReference paramITplReference)
  {
    this.M = paramITplReference;
  }
  
  public ITplReference getAfterExpandTpl()
  {
    return this.B;
  }
  
  public void setAfterExpandTpl(ITplReference paramITplReference)
  {
    this.B = paramITplReference;
  }
  
  public void parseFromSheet(TreeNode paramTreeNode, TplC paramTplC, Workbook paramWorkbook)
  {
    TreeNode localTreeNode1 = paramTreeNode.makeChild("Table");
    ExcelModelUtils.fixRowSpan(localTreeNode1);
    int j = localTreeNode1.getChildCount();
    int k = ExcelModelUtils.getRowIdx(localTreeNode1);
    if (k < 0) {
      return;
    }
    for (int i = k; i < j; i++)
    {
      TreeNode localTreeNode2 = localTreeNode1.getChild(i);
      List localList1 = ExcelModelUtils.getCellValues(localTreeNode2);
      if (localList1.size() > 0)
      {
        Object localObject = localList1.get(0);
        if ((localObject != null) && (localObject.toString().trim().startsWith("*")))
        {
          String str1 = localObject.toString().trim().substring(1).trim();
          List localList2 = A(localTreeNode1, i + 1);
          String str2 = null;
          if (localList1.size() > 1) {
            str2 = Variant.valueOf(localList1.get(1)).stripedStringValue();
          }
          if (isKey("config.styles", str1))
          {
            for (int m = 0; m < localList2.size(); m++)
            {
              List localList3 = (List)localList2.get(m);
              String str3 = Coercions.toString(localList3.get(0), null);
              if (str3 != null)
              {
                TreeNode localTreeNode3 = localTreeNode1.getChild(i + 1 + m);
                if (localTreeNode3.getChildCount() >= 2)
                {
                  String str4 = localTreeNode3.getChild(1).attribute("ss:StyleID").stripedStringValue("Default");
                  Style localStyle = paramWorkbook.getStyle(str4);
                  if (localStyle != null)
                  {
                    Map localMap = ExcelModelUtils.parseComment(localTreeNode3.getChild(1));
                    String str5 = localMap == null ? null : (String)localMap.get("cssClass");
                    localStyle = fixCssClass(localStyle, str5, paramWorkbook);
                    localStyle.setKey(str3);
                    this.K.put(str3, localStyle);
                  }
                }
              }
            }
          }
          else
          {
            parseConfig(str1, str2, localList2, localTreeNode2, paramTplC);
            i += localList2.size();
          }
        }
      }
    }
  }
  
  public Style fixCssClass(Style paramStyle, String paramString, Workbook paramWorkbook)
  {
    if (paramString == null) {
      return paramStyle;
    }
    paramStyle = paramStyle.copy();
    paramStyle.setId(null);
    paramWorkbook.addNewStyle(paramStyle);
    paramStyle.setCssClassName(paramStyle.getId() + " " + paramString);
    return paramStyle;
  }
  
  private boolean A(List<Object> paramList)
  {
    if ((paramList == null) || (paramList.isEmpty())) {
      return true;
    }
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      Object localObject = paramList.get(i);
      if ((localObject != null) && (StringUtils.strip(localObject.toString()) != null)) {
        return false;
      }
    }
    return true;
  }
  
  private List<List> A(TreeNode paramTreeNode, int paramInt)
  {
    ArrayList localArrayList = new ArrayList();
    int j = paramTreeNode.getChildCount();
    for (int i = paramInt; i < j; i++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(i);
      List localList = ExcelModelUtils.getCellValues(localTreeNode);
      if (A(localList)) {
        return localArrayList;
      }
      if ((localList.get(0) != null) && (localList.get(0).toString().trim().startsWith("*"))) {
        return localArrayList;
      }
      localArrayList.add(localList);
    }
    return localArrayList;
  }
  
  public boolean isKey(String paramString, Object paramObject)
  {
    if (paramObject == null) {
      return false;
    }
    return (paramString.equals(paramObject.toString())) || (c(paramString).equals(paramObject.toString()));
  }
  
  private void A(List<List> paramList, TplC paramTplC, Map<String, ITplReference> paramMap)
  {
    if ((paramList == null) || (paramList.isEmpty())) {
      return;
    }
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      List localList = (List)localIterator.next();
      if (localList.size() >= 2)
      {
        String str1 = StringUtils.strip(Coercions.toString(localList.get(0), null));
        String str2 = Coercions.toString(localList.get(1), "");
        if ((str1 != null) && (str2.length() > 0))
        {
          ITplReference localITplReference = A(str2, paramTplC);
          if (localITplReference != null) {
            paramMap.put(str1, localITplReference);
          }
        }
      }
    }
  }
  
  private void A(Map<String, Object> paramMap, List<List> paramList, TplC paramTplC)
  {
    if ((paramList == null) || (paramList.isEmpty())) {
      return;
    }
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      List localList = (List)localIterator.next();
      if (localList.size() >= 2)
      {
        String str1 = StringUtils.strip(Coercions.toString(localList.get(0), ""));
        String str2 = StringUtils.strip(Coercions.toString(localList.get(1), ""));
        if (str1 != null) {
          paramMap.put(str1, str2);
        }
      }
    }
  }
  
  private String B(List<List> paramList)
  {
    if ((paramList == null) || (paramList.isEmpty())) {
      return null;
    }
    List localList = (List)paramList.get(0);
    if ((localList == null) || (localList.isEmpty())) {
      return null;
    }
    String str = Coercions.toString(localList.get(0), "");
    return str;
  }
  
  private ITplReference A(List<List> paramList, TplC paramTplC)
  {
    String str = B(paramList);
    return A(str, paramTplC);
  }
  
  private ITplReference A(Object paramObject, TplC paramTplC)
  {
    String str1 = Coercions.toString(paramObject, "");
    String str2 = "<c:div>" + str1 + "</c:div>";
    TreeNode localTreeNode = DomToTree.getInstance().allowText(true).transform(str2);
    HashMap localHashMap = new HashMap(0);
    return paramTplC.compileBody(localTreeNode, localHashMap, SystemServiceContext.getInstance());
  }
  
  private Object A(Map<String, Object> paramMap, String paramString)
  {
    String str = c(paramString);
    Object localObject = paramMap.get(str);
    if (localObject == null) {
      localObject = paramMap.get(paramString);
    }
    return localObject;
  }
  
  private void B(List<List> paramList, TplC paramTplC)
  {
    if ((paramList == null) || (paramList.isEmpty())) {
      return;
    }
    IServiceContext localIServiceContext = SystemServiceContext.getInstance();
    this.E = new HashMap(paramList.size());
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      List localList = (List)localIterator.next();
      if (localList.size() >= 2)
      {
        String str1 = Coercions.toString(localList.get(0), "");
        String str2 = Coercions.toString(localList.get(1), null);
        String str3 = null;
        if (localList.size() >= 3) {
          str3 = Coercions.toString(localList.get(2), null);
        }
        if (str1.length() > 0)
        {
          CellVarMap localCellVarMap = new CellVarMap();
          IExpressionReference localIExpressionReference = paramTplC.parseEvalExpr(str2, localIServiceContext);
          localCellVarMap.setFieldExpr(localIExpressionReference);
          Map localMap = ExcelModelUtils.parseCommentStr(str3);
          localCellVarMap.A(localMap, paramTplC);
          this.E.put(str1, localCellVarMap);
        }
      }
    }
  }
  
  public void parseConfig(String paramString1, String paramString2, List<List> paramList, TreeNode paramTreeNode, TplC paramTplC)
  {
    Object localObject;
    if (isKey("config.compile", paramString1))
    {
      localObject = A(paramList, paramTplC);
      if (localObject != null) {
        TplC.runTpl((ITplReference)localObject, new HashMap(0), SystemServiceContext.getInstance());
      }
    }
    else if (isKey("config.beforeExpandTpl", paramString1))
    {
      this.M = A(paramList, paramTplC);
    }
    else if (isKey("config.afterExpandTpl", paramString1))
    {
      this.B = A(paramList, paramTplC);
    }
    else if (isKey("config.beforeTpl", paramString1))
    {
      this.D = A(paramList, paramTplC);
    }
    else if (isKey("config.afterInit", paramString1))
    {
      this.L = A(paramList, paramTplC);
    }
    else if (isKey("config.afterTpl", paramString1))
    {
      this.I = A(paramList, paramTplC);
    }
    else if (isKey("config.meta", paramString1))
    {
      localObject = B(paramList).trim();
      if (((String)localObject).length() > 0) {
        this.N = DataSourceMeta.load((String)localObject, SystemServiceContext.getInstance());
      }
    }
    else if ("tpls".equals(paramString1))
    {
      if (paramString2 == null)
      {
        A(paramList, paramTplC, this.F);
      }
      else
      {
        localObject = makeSheetTpls(paramString2);
        A(paramList, paramTplC, (Map)localObject);
      }
    }
    else if (isKey("config.props", paramString1))
    {
      A(this.J, paramList, paramTplC);
    }
    else if (isKey("config.varMap", paramString1))
    {
      B(paramList, paramTplC);
    }
    else if (isKey("sheet.props", paramString1))
    {
      if (paramString2 == null) {
        throw Exceptions.code("excel.CAN_err_missing_sheet_name_config").param(paramString1).param(paramTreeNode);
      }
      A(makeSheetProps(paramString2), paramList, paramTplC);
    }
    else if (isKey("sheet.config", paramString1))
    {
      if (paramString2 == null) {
        throw Exceptions.code("excel.CAN_err_missing_sheet_name_config").param(paramString1).param(paramTreeNode);
      }
      localObject = WxTable.parsePairsToRow(paramList);
      if (localObject != null)
      {
        SheetConfig.Item localItem = new SheetConfig.Item();
        localItem.G = paramString2;
        localItem.C = A(A((Map)localObject, "sheet.beforeTpl"), paramTplC);
        localItem.E = A(((Map)localObject).get(c("sheet.afterTpl")), paramTplC);
        localItem.D = A(((Map)localObject).get(c("sheet.testTpl")), paramTplC);
        localItem.I = A(((Map)localObject).get(c("sheet.beforeExpandTpl")), paramTplC);
        localItem.A = A(((Map)localObject).get(c("sheet.afterExpandTpl")), paramTplC);
        localItem.H = A(((Map)localObject).get(c("sheet.sheetLoopVarTpl")), paramTplC);
        localItem.J = A(((Map)localObject).get(c("sheet.sheetNameTpl")), paramTplC);
        localItem.setClassName((String)((Map)localObject).get("sheet.className"));
        localItem.setStyle((String)((Map)localObject).get("sheet.style"));
        this.H.addItem(localItem);
      }
    }
    else if (isKey("pagemaker.config", paramString1))
    {
      localObject = new WxTable();
      ((WxTable)localObject).loadData(paramList, true);
      int j = ((WxTable)localObject).getRowCount();
      for (int i = 0; i < j; i++)
      {
        PageMakerConfig.Item localItem1 = new PageMakerConfig.Item();
        localItem1.var = ((WxTable)localObject).getCellStr(i, c("pagemaker.var"));
        if (localItem1.var == null) {
          throw Exceptions.code("excel.CAN_err_pagemaker_no_var").param(localObject).param(paramTreeNode);
        }
        localItem1.pageBeginSheet = ((WxTable)localObject).getCellStr(i, c("pagemaker.page_begin_sheet"));
        localItem1.pageMiddleSheet = ((WxTable)localObject).getCellStr(i, c("pagemaker.page_middle_sheet"));
        localItem1.pageEndSheet = ((WxTable)localObject).getCellStr(i, c("pagemaker.page_end_sheet"));
        localItem1.pageAllSheet = ((WxTable)localObject).getCellStr(i, c("pagemaker.page_all_sheet"));
        localItem1.pageBeginCount = ((WxTable)localObject).getCellInt(i, c("pagemaker.page_begin_count"), 0);
        localItem1.pageMiddleCount = ((WxTable)localObject).getCellInt(i, c("pagemaker.page_middle_count"), 0);
        localItem1.pageEndCount = ((WxTable)localObject).getCellInt(i, c("pagemaker.page_end_count"), 0);
        localItem1.pageAllCount = ((WxTable)localObject).getCellInt(i, c("pagemaker.page_all_count"), 0);
        if ((localItem1.pageAllSheet == null) || (localItem1.pageAllCount <= 0)) {
          throw Exceptions.code("excel.CAN_err_pagemaker_invalid_all_count").param(localObject).param(paramTreeNode);
        }
        if ((localItem1.pageBeginSheet == null) && (localItem1.pageEndSheet == null) && (localItem1.pageMiddleSheet == null))
        {
          localItem1.pageBeginSheet = localItem1.pageAllSheet;
          localItem1.pageMiddleSheet = localItem1.pageAllSheet;
          localItem1.pageEndSheet = localItem1.pageAllSheet;
        }
        if ((localItem1.pageAllSheet.equals(localItem1.pageBeginSheet)) && (localItem1.pageAllSheet.equals(localItem1.pageMiddleSheet)) && (localItem1.pageAllSheet.equals(localItem1.pageEndSheet)))
        {
          localItem1.pageBeginCount = localItem1.pageAllCount;
          localItem1.pageMiddleCount = localItem1.pageAllCount;
          localItem1.pageEndCount = localItem1.pageAllCount;
          localItem1.singlePage = true;
        }
        if ((localItem1.pageBeginSheet != null) && (localItem1.pageBeginCount <= 0)) {
          throw Exceptions.code("excel.CAN_err_pagemaker_invalid_begin_count").param(localObject).param(paramTreeNode);
        }
        if ((localItem1.pageMiddleSheet != null) && (localItem1.pageMiddleCount <= 0)) {
          throw Exceptions.code("excel.CAN_err_pagemaker_invalid_middle_count").param(localObject).param(paramTreeNode);
        }
        if ((localItem1.pageEndSheet != null) && (localItem1.pageEndCount <= 0)) {
          throw Exceptions.code("excel.CAN_err_pagemaker_invalid_end_count").param(localObject).param(paramTreeNode);
        }
        this.C.addItem(localItem1);
      }
    }
    else
    {
      throw Exceptions.code("excel.CAN_err_invalid_config_key").param(paramString1);
    }
  }
  
  public void adjustWorkbook(TreeNode paramTreeNode)
  {
    this.C.adjustWorkbook(paramTreeNode);
  }
  
  public ITplReference getAfterInitTpl()
  {
    return this.L;
  }
  
  public void setAfterInitTpl(ITplReference paramITplReference)
  {
    this.L = paramITplReference;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\WxReportConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */