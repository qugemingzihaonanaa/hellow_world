package edu.thu.ext.excel.model;

import edu.thu.ext.excel.model.format.BuiltinFormats;
import edu.thu.ext.excel.model.format.DateUtil;
import java.text.DecimalFormat;
import java.text.FieldPosition;
import java.text.Format;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FormatHelper
{
  private static final Pattern E = Pattern.compile("[0#]+");
  private static final Pattern C = Pattern.compile("([d]{3,})", 2);
  private static final Pattern B = Pattern.compile("((A|P)[M/P]*)", 2);
  private static final Pattern D = Pattern.compile("(\\[\\$[^-\\]]*-[0-9A-Z]+\\])");
  private static final Map<String, Format> A = new HashMap();
  
  static
  {
    Format localFormat1 = _A.A;
    addFormat("00000\\-0000", localFormat1);
    addFormat("00000-0000", localFormat1);
    Format localFormat2 = _C.A;
    addFormat("[<=9999999]###\\-####;\\(###\\)\\ ###\\-####", localFormat2);
    addFormat("[<=9999999]###-####;(###) ###-####", localFormat2);
    addFormat("###\\-####;\\(###\\)\\ ###\\-####", localFormat2);
    addFormat("###-####;(###) ###-####", localFormat2);
    Format localFormat3 = _B.A;
    addFormat("000\\-00\\-0000", localFormat3);
    addFormat("000-00-0000", localFormat3);
  }
  
  public static Format getFormat(String paramString)
  {
    if ((paramString == null) || ("General".equals(paramString)) || ("@".equals(paramString))) {
      return null;
    }
    Format localFormat = (Format)A.get(paramString);
    if (localFormat != null) {
      return localFormat;
    }
    try
    {
      localFormat = C(paramString);
      return localFormat;
    }
    catch (Exception localException) {}
    return null;
  }
  
  private static Format C(String paramString)
  {
    int i = BuiltinFormats.getBuiltinFormat(paramString);
    String str1 = paramString.replaceAll("\\[[a-zA-Z]*\\]", "");
    for (Matcher localMatcher = D.matcher(str1); localMatcher.find(); localMatcher = D.matcher(str1))
    {
      String str2 = localMatcher.group();
      String str3 = str2.substring(str2.indexOf('$') + 1, str2.indexOf('-'));
      if (str3.indexOf('$') > -1)
      {
        StringBuffer localStringBuffer = new StringBuffer();
        localStringBuffer.append(str3.substring(0, str3.indexOf('$')));
        localStringBuffer.append('\\');
        localStringBuffer.append(str3.substring(str3.indexOf('$'), str3.length()));
        str3 = localStringBuffer.toString();
      }
      str1 = localMatcher.replaceAll(str3);
    }
    if ((str1 == null) || (str1.trim().length() == 0)) {
      return null;
    }
    if (DateUtil.isADateFormat(i, str1)) {
      return D(str1);
    }
    if (E.matcher(str1).find()) {
      return A(str1);
    }
    return null;
  }
  
  private static Format D(String paramString)
  {
    String str = paramString;
    str = str.replaceAll("\\\\-", "-");
    str = str.replaceAll("\\\\,", ",");
    str = str.replaceAll("\\\\ ", " ");
    str = str.replaceAll(";@", "");
    int i = 0;
    for (Matcher localMatcher1 = B.matcher(str); localMatcher1.find(); localMatcher1 = B.matcher(str))
    {
      str = localMatcher1.replaceAll("@");
      i = 1;
    }
    str = str.replaceAll("@", "a");
    Matcher localMatcher2 = C.matcher(str);
    if (localMatcher2.find())
    {
      localObject = localMatcher2.group(0);
      str = localMatcher2.replaceAll(((String)localObject).toUpperCase().replaceAll("D", "E"));
    }
    Object localObject = new StringBuffer();
    char[] arrayOfChar = str.toCharArray();
    int j = 1;
    ArrayList localArrayList = new ArrayList();
    for (int k = 0; k < arrayOfChar.length; k++)
    {
      char c = arrayOfChar[k];
      if ((c == 'h') || (c == 'H'))
      {
        j = 0;
        if (i != 0) {
          ((StringBuffer)localObject).append('h');
        } else {
          ((StringBuffer)localObject).append('H');
        }
      }
      else if (c == 'm')
      {
        if (j != 0)
        {
          ((StringBuffer)localObject).append('M');
          localArrayList.add(Integer.valueOf(((StringBuffer)localObject).length() - 1));
        }
        else
        {
          ((StringBuffer)localObject).append('m');
        }
      }
      else if ((c == 's') || (c == 'S'))
      {
        ((StringBuffer)localObject).append('s');
        for (int m = 0; m < localArrayList.size(); m++)
        {
          int n = ((Integer)localArrayList.get(m)).intValue();
          if (((StringBuffer)localObject).charAt(n) == 'M') {
            ((StringBuffer)localObject).replace(n, n + 1, "m");
          }
        }
        j = 1;
        localArrayList.clear();
      }
      else if (Character.isLetter(c))
      {
        j = 1;
        localArrayList.clear();
        if ((c == 'y') || (c == 'Y')) {
          ((StringBuffer)localObject).append('y');
        } else if ((c == 'd') || (c == 'D')) {
          ((StringBuffer)localObject).append('d');
        } else {
          ((StringBuffer)localObject).append(c);
        }
      }
      else
      {
        ((StringBuffer)localObject).append(c);
      }
    }
    str = ((StringBuffer)localObject).toString();
    try
    {
      return new SimpleDateFormat(str);
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
    return null;
  }
  
  private static Format A(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer(paramString);
    for (int i = 0; i < localStringBuffer.length(); i++)
    {
      int j = localStringBuffer.charAt(i);
      if (j == 40)
      {
        int k = localStringBuffer.indexOf(")", i);
        if ((k > -1) && (localStringBuffer.charAt(k - 1) == '_'))
        {
          localStringBuffer.deleteCharAt(k);
          localStringBuffer.deleteCharAt(k - 1);
          localStringBuffer.deleteCharAt(i);
          i--;
        }
      }
      else if ((j == 41) && (i > 0) && (localStringBuffer.charAt(i - 1) == '_'))
      {
        localStringBuffer.deleteCharAt(i);
        localStringBuffer.deleteCharAt(i - 1);
        i--;
      }
      else if ((j == 92) || (j == 34))
      {
        localStringBuffer.deleteCharAt(i);
        i--;
      }
      else if ((j == 43) && (i > 0) && (localStringBuffer.charAt(i - 1) == 'E'))
      {
        localStringBuffer.deleteCharAt(i);
        i--;
      }
    }
    try
    {
      return new DecimalFormat(localStringBuffer.toString());
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
    return null;
  }
  
  public static void addFormat(String paramString, Format paramFormat)
  {
    A.put(paramString, paramFormat);
  }
  
  static DecimalFormat B(String paramString)
  {
    DecimalFormat localDecimalFormat = new DecimalFormat(paramString);
    localDecimalFormat.setParseIntegerOnly(true);
    return localDecimalFormat;
  }
  
  private static final class _C
    extends Format
  {
    private static final long serialVersionUID = -820798622022983780L;
    public static final Format A = new _C();
    private static final DecimalFormat B = FormatHelper.B("##########");
    
    public static String A(Number paramNumber)
    {
      String str1 = B.format(paramNumber);
      StringBuffer localStringBuffer = new StringBuffer();
      int i = str1.length();
      if (i <= 4) {
        return str1;
      }
      String str4 = str1.substring(i - 4, i);
      String str3 = str1.substring(Math.max(0, i - 7), i - 4);
      String str2 = str1.substring(Math.max(0, i - 10), Math.max(0, i - 7));
      if ((str2 != null) && (str2.trim().length() > 0)) {
        localStringBuffer.append('(').append(str2).append(") ");
      }
      if ((str3 != null) && (str3.trim().length() > 0)) {
        localStringBuffer.append(str3).append('-');
      }
      localStringBuffer.append(str4);
      return localStringBuffer.toString();
    }
    
    public StringBuffer format(Object paramObject, StringBuffer paramStringBuffer, FieldPosition paramFieldPosition)
    {
      return paramStringBuffer.append(A((Number)paramObject));
    }
    
    public Object parseObject(String paramString, ParsePosition paramParsePosition)
    {
      return B.parseObject(paramString, paramParsePosition);
    }
  }
  
  private static final class _B
    extends Format
  {
    private static final long serialVersionUID = 5842426239071043434L;
    public static final Format A = new _B();
    private static final DecimalFormat B = FormatHelper.B("000000000");
    
    public static String A(Number paramNumber)
    {
      String str = B.format(paramNumber);
      StringBuffer localStringBuffer = new StringBuffer();
      localStringBuffer.append(str.substring(0, 3)).append('-');
      localStringBuffer.append(str.substring(3, 5)).append('-');
      localStringBuffer.append(str.substring(5, 9));
      return localStringBuffer.toString();
    }
    
    public StringBuffer format(Object paramObject, StringBuffer paramStringBuffer, FieldPosition paramFieldPosition)
    {
      return paramStringBuffer.append(A((Number)paramObject));
    }
    
    public Object parseObject(String paramString, ParsePosition paramParsePosition)
    {
      return B.parseObject(paramString, paramParsePosition);
    }
  }
  
  private static final class _A
    extends Format
  {
    private static final long serialVersionUID = 1422822964748552552L;
    public static final Format A = new _A();
    private static final DecimalFormat B = FormatHelper.B("000000000");
    
    public static String A(Number paramNumber)
    {
      String str = B.format(paramNumber);
      StringBuffer localStringBuffer = new StringBuffer();
      localStringBuffer.append(str.substring(0, 5)).append('-');
      localStringBuffer.append(str.substring(5, 9));
      return localStringBuffer.toString();
    }
    
    public StringBuffer format(Object paramObject, StringBuffer paramStringBuffer, FieldPosition paramFieldPosition)
    {
      return paramStringBuffer.append(A((Number)paramObject));
    }
    
    public Object parseObject(String paramString, ParsePosition paramParsePosition)
    {
      return B.parseObject(paramString, paramParsePosition);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\FormatHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */