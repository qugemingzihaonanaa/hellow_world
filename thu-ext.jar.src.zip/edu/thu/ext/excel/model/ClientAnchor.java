package edu.thu.ext.excel.model;

import edu.thu.lang.reflect.BeanInstance;
import java.io.Serializable;

public class ClientAnchor
  implements Serializable
{
  private static final long serialVersionUID = 8526908514265623506L;
  public static final int MOVE_AND_RESIZE = 0;
  public static final int MOVE_DONT_RESIZE = 2;
  public static final int DONT_MOVE_AND_RESIZE = 3;
  String A;
  double F;
  double J;
  double E;
  double H;
  int I;
  int D;
  int G;
  int C;
  int B;
  
  public ClientAnchor copy()
  {
    BeanInstance localBeanInstance = new BeanInstance(this);
    return (ClientAnchor)localBeanInstance.cloneInstance(false);
  }
  
  public double getRowDiff()
  {
    return this.H - this.J;
  }
  
  public double getColDiff()
  {
    return this.E - this.F;
  }
  
  public ClientAnchor dx1(int paramInt)
  {
    this.I = paramInt;
    return this;
  }
  
  public ClientAnchor dy1(int paramInt)
  {
    this.D = paramInt;
    return this;
  }
  
  public ClientAnchor dx2(int paramInt)
  {
    this.G = paramInt;
    return this;
  }
  
  public ClientAnchor dy2(int paramInt)
  {
    this.C = paramInt;
    return this;
  }
  
  public ClientAnchor rowDiff(double paramDouble)
  {
    this.H = (this.J + paramDouble);
    return this;
  }
  
  public ClientAnchor colDiff(double paramDouble)
  {
    this.E = (this.F + paramDouble);
    return this;
  }
  
  public ClientAnchor col1(double paramDouble)
  {
    this.F = paramDouble;
    return this;
  }
  
  public ClientAnchor col2(double paramDouble)
  {
    this.E = paramDouble;
    return this;
  }
  
  public ClientAnchor row1(double paramDouble)
  {
    this.J = paramDouble;
    return this;
  }
  
  public ClientAnchor row2(double paramDouble)
  {
    this.H = paramDouble;
    return this;
  }
  
  public String getSheetName()
  {
    return this.A;
  }
  
  public void setSheetName(String paramString)
  {
    this.A = paramString;
  }
  
  public void moveRows(int paramInt)
  {
    this.J += paramInt;
    this.H += paramInt;
  }
  
  public void fillCell(int paramInt1, int paramInt2)
  {
    this.J = paramInt1;
    this.F = paramInt2;
    this.H = (paramInt1 + 1);
    this.E = (paramInt2 + 1);
  }
  
  public int getAnchorType()
  {
    return this.B;
  }
  
  public void setAnchorType(int paramInt)
  {
    this.B = paramInt;
  }
  
  public double getCol1()
  {
    return this.F;
  }
  
  public void setCol1(double paramDouble)
  {
    this.F = paramDouble;
  }
  
  public double getCol2()
  {
    return this.E;
  }
  
  public void setCol2(double paramDouble)
  {
    this.E = paramDouble;
  }
  
  public int getDx1()
  {
    return this.I;
  }
  
  public void setDx1(int paramInt)
  {
    this.I = paramInt;
  }
  
  public int getDx2()
  {
    return this.G;
  }
  
  public void setDx2(int paramInt)
  {
    this.G = paramInt;
  }
  
  public int getDy1()
  {
    return this.D;
  }
  
  public void setDy1(int paramInt)
  {
    this.D = paramInt;
  }
  
  public int getDy2()
  {
    return this.C;
  }
  
  public void setDy2(int paramInt)
  {
    this.C = paramInt;
  }
  
  public double getRow1()
  {
    return this.J;
  }
  
  public void setRow1(double paramDouble)
  {
    this.J = paramDouble;
  }
  
  public double getRow2()
  {
    return this.H;
  }
  
  public void setRow2(double paramDouble)
  {
    this.H = paramDouble;
  }
  
  public int getIntCol1()
  {
    return (int)this.F;
  }
  
  public int getIntCol2()
  {
    return (int)this.E;
  }
  
  public int getIntRow1()
  {
    return (int)this.J;
  }
  
  public int getIntRow2()
  {
    return (int)this.H;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\ClientAnchor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */