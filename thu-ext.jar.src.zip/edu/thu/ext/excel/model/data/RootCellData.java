package edu.thu.ext.excel.model.data;

import edu.thu.ext.excel.model.Cell;

public class RootCellData
  extends CellData
{
  public RootCellData(Cell paramCell)
  {
    super(paramCell);
    setIndex(1);
    setCalcRowIndex(1);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\data\RootCellData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */