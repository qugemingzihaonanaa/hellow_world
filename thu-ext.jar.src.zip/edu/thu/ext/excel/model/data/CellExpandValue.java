package edu.thu.ext.excel.model.data;

import edu.thu.model.data.IListData;
import java.io.Serializable;
import java.util.List;

public class CellExpandValue
  implements Serializable, IListData<Object>
{
  private static final long serialVersionUID = 8721318424544671735L;
  Object B;
  IListData<Object> A;
  
  public CellExpandValue(Object paramObject, IListData<Object> paramIListData)
  {
    this.B = paramObject;
    this.A = paramIListData;
  }
  
  public Object getValue()
  {
    return this.B;
  }
  
  public List<Object> getListData()
  {
    return this.A.getListData();
  }
  
  public Object getFirstData()
  {
    List localList = this.A.getListData();
    if (localList.size() > 0) {
      return localList.get(0);
    }
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\data\CellExpandValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */