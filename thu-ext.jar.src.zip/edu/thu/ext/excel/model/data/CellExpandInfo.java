package edu.thu.ext.excel.model.data;

import java.util.ArrayList;
import java.util.List;

public class CellExpandInfo
{
  boolean F;
  CellData E;
  List<CellData> D;
  List<CellData> G;
  CellData C;
  int B;
  CellData A;
  int H;
  
  public CellExpandInfo(CellData paramCellData, boolean paramBoolean)
  {
    this.A = paramCellData;
    this.F = paramBoolean;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("parent:").append(this.E);
    if (this.D != null) {
      localStringBuilder.append(",children:").append(this.D);
    }
    return localStringBuilder.toString();
  }
  
  public String getParentOffset()
  {
    if ((this.E == null) || (this.E.isVirtualRoot())) {
      return "";
    }
    StringBuilder localStringBuilder = new StringBuilder();
    CellData localCellData = this.E;
    for (;;)
    {
      localStringBuilder.append(localCellData.getExpandIndex());
      localCellData = this.F ? localCellData.getHorParent() : localCellData.getVerParent();
      if (localCellData.isVirtualRoot()) {
        break;
      }
      localStringBuilder.append(',');
    }
    return localStringBuilder.toString();
  }
  
  public int getBandOffset()
  {
    return this.H;
  }
  
  public void setBandOffset(int paramInt)
  {
    this.H = paramInt;
  }
  
  public boolean isHor()
  {
    return this.F;
  }
  
  public CellData getParent()
  {
    return this.E;
  }
  
  public void setParent(CellData paramCellData)
  {
    this.E = paramCellData;
  }
  
  public List<CellData> getChildren()
  {
    return this.D;
  }
  
  public void setChildren(List<CellData> paramList)
  {
    this.D = paramList;
  }
  
  public List<CellData> getTreeChildren()
  {
    return this.G;
  }
  
  public void setTreeChildren(List<CellData> paramList)
  {
    this.G = paramList;
  }
  
  public CellData getTreeParent()
  {
    return this.C;
  }
  
  public void setTreeParent(CellData paramCellData)
  {
    this.C = paramCellData;
  }
  
  public int getTreeLevel()
  {
    return this.B;
  }
  
  public void setTreeLevel(int paramInt)
  {
    this.B = paramInt;
  }
  
  public CellData getCell()
  {
    return this.A;
  }
  
  public void setCell(CellData paramCellData)
  {
    this.A = paramCellData;
  }
  
  public void setHor(boolean paramBoolean)
  {
    this.F = paramBoolean;
  }
  
  CellData B(int paramInt)
  {
    CellData localCellData = getParent();
    if (localCellData == null) {
      return null;
    }
    if (localCellData.getHorExpandLevel() < paramInt) {
      return null;
    }
    while (paramInt < localCellData.getHorExpandLevel())
    {
      localCellData = localCellData.getHorExpandInfo().getParent();
      if (localCellData == null) {
        break;
      }
    }
    return localCellData;
  }
  
  CellData A(int paramInt)
  {
    CellData localCellData = getParent();
    if (localCellData == null) {
      return null;
    }
    if (localCellData.getVerExpandLevel() < paramInt) {
      return null;
    }
    while (paramInt < localCellData.getVerExpandLevel())
    {
      localCellData = localCellData.getVerExpandInfo().getParent();
      if (localCellData == null) {
        break;
      }
    }
    return localCellData;
  }
  
  public CellData getParent(int paramInt)
  {
    return this.F ? B(paramInt) : A(paramInt);
  }
  
  public boolean isSubOf(CellData paramCellData)
  {
    if (paramCellData == null) {
      return this.E == null;
    }
    return paramCellData == getParent(this.F ? paramCellData.getHorExpandLevel() : paramCellData.getVerExpandLevel());
  }
  
  public void addChild(CellData paramCellData)
  {
    if (this.D == null) {
      this.D = new ArrayList();
    }
    if (this.F) {
      paramCellData.setHorParent(this.A);
    } else {
      paramCellData.setVerParent(this.A);
    }
    this.D.add(paramCellData);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\data\CellExpandInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */