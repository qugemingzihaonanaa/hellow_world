package edu.thu.ext.excel.model.data;

import edu.thu.ext.excel.model.Cell;
import edu.thu.ext.excel.model.CellBandModel;
import edu.thu.ext.excel.model.CellExpandModel;
import edu.thu.ext.excel.model.FieldDefinition;
import edu.thu.ext.excel.model.Range;
import edu.thu.ext.excel.model.RichData;
import edu.thu.ext.excel.model.Row;
import edu.thu.ext.excel.model.Style;
import edu.thu.ext.excel.model.Workbook;
import edu.thu.ext.excel.model.Worksheet;
import edu.thu.ext.excel.model.formula.CellFormula;
import edu.thu.ext.excel.xpt.XptBuildRuntime;
import edu.thu.ext.excel.xpt.XptDataSet;
import edu.thu.java.util.Coercions;
import edu.thu.lang.Variant;
import edu.thu.lang.el.IExpressionReference;
import edu.thu.lang.reflect.BeanInstance;
import edu.thu.lang.util.TplC;
import edu.thu.model.data.IListData;
import edu.thu.model.tree.TreeNode;
import edu.thu.util.StringUtils;
import edu.thu.util.StringUtilsEx;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class CellData
  implements ICellHandle, Comparable<ICellHandle>
{
  int index;
  int mergeAcross;
  int mergeDown;
  Style style;
  Cell model;
  Object value;
  boolean evaluated;
  boolean expanded;
  Object expandObj;
  List<CellData> expandedCells;
  int expandIndex = -1;
  CellData unexpandCell;
  CellExpandInfo horExpandInfo = new CellExpandInfo(this, true);
  CellExpandInfo verExpandInfo = new CellExpandInfo(this, false);
  int calcRowIndex;
  RowData row;
  boolean horRemoved;
  boolean verRemoved;
  int horBandSpan;
  int verBandSpan;
  CellData verOrgCell;
  List<CellData> verCopyCells;
  boolean visible;
  boolean readOnly;
  boolean rowVisible;
  String comment;
  String key;
  Object object;
  String formula;
  
  public CellData() {}
  
  public CellData(Cell paramCell, Object paramObject)
  {
    if (paramCell != null)
    {
      this.index = paramCell.getIndex();
      this.mergeAcross = paramCell.getMergeAcross();
      this.mergeDown = paramCell.getMergeDown();
    }
    this.model = paramCell;
    this.value = paramObject;
    this.evaluated = true;
  }
  
  public CellData copy()
  {
    CellData localCellData = (CellData)new BeanInstance(this).cloneInstance(false);
    return localCellData;
  }
  
  public boolean isVisible()
  {
    return this.visible;
  }
  
  public boolean isReadOnly()
  {
    return this.readOnly;
  }
  
  public boolean isRowVisible()
  {
    return this.rowVisible;
  }
  
  public int compareTo(ICellHandle paramICellHandle)
  {
    int i = getRowIndex();
    int j = paramICellHandle.getRow() == null ? 0 : paramICellHandle.getRow().getIndex();
    if (i != j) {
      return i < j ? -1 : 1;
    }
    int k = getIndex();
    int m = paramICellHandle.getIndex();
    return k < m ? -1 : k == m ? 0 : 1;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("CellData:").append(hashCode()).append("::").append(this.model);
    if (this.expanded) {
      localStringBuilder.append("[").append(this.expandIndex).append("->").append(this.expandObj).append("]");
    }
    localStringBuilder.append("(").append(getFullPos()).append("):").append(this.value);
    return localStringBuilder.toString();
  }
  
  public String getFullPos()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("R").append(this.calcRowIndex);
    localStringBuilder.append("C").append(this.index);
    localStringBuilder.append("{");
    localStringBuilder.append(this.horExpandInfo.getParentOffset());
    localStringBuilder.append(';');
    localStringBuilder.append(this.verExpandInfo.getParentOffset());
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }
  
  public TreeNode toNode()
  {
    TreeNode localTreeNode1 = TreeNode.make("cell");
    localTreeNode1.setAttribute("rowIndex", Integer.valueOf(this.calcRowIndex));
    localTreeNode1.setAttribute("index", Integer.valueOf(this.index));
    if (this.model != null) {
      localTreeNode1.setAttribute("model", this.model.toString());
    }
    if (this.horRemoved) {
      localTreeNode1.setAttribute("horRemoved", Boolean.valueOf(true));
    }
    if (this.verRemoved) {
      localTreeNode1.setAttribute("verRemoved", Boolean.valueOf(true));
    }
    if (isNeedExpand())
    {
      localTreeNode1.setAttribute("expandObj", this.expandObj);
      localTreeNode1.setAttribute("expandIndex", Integer.valueOf(this.expandIndex));
    }
    localTreeNode1.setAttribute("mergeAcross", Integer.valueOf(this.mergeAcross));
    localTreeNode1.setAttribute("mergeDown", Integer.valueOf(this.mergeDown));
    if (getHorParent() != null) {
      localTreeNode1.setAttribute("horParent", getHorParent());
    }
    if (getVerParent() != null) {
      localTreeNode1.setAttribute("verParent", getVerParent());
    }
    if (this.verCopyCells != null) {
      localTreeNode1.setAttribute("verCopyCells", StringUtils.join(this.verCopyCells, ","));
    }
    Object localObject1;
    Object localObject3;
    Object localObject2;
    if (this.expandedCells != null)
    {
      localObject1 = localTreeNode1.makeChild("expanded");
      localObject3 = this.expandedCells.iterator();
      while (((Iterator)localObject3).hasNext())
      {
        localObject2 = (CellData)((Iterator)localObject3).next();
        ((TreeNode)localObject1).appendChild(((CellData)localObject2).toNode());
      }
    }
    else
    {
      localObject1 = getHorChildren();
      Object localObject4;
      Object localObject5;
      if (localObject1 != null)
      {
        localObject2 = localTreeNode1.makeChild("horChildren");
        localObject4 = ((List)localObject1).iterator();
        while (((Iterator)localObject4).hasNext())
        {
          localObject3 = (CellData)((Iterator)localObject4).next();
          localObject5 = ((CellData)localObject3).toNode();
          ((TreeNode)localObject2).appendChild((TreeNode)localObject5);
        }
      }
      localObject2 = getVerChildren();
      if (localObject2 != null)
      {
        localObject3 = localTreeNode1.makeChild("verChildren");
        localObject5 = ((List)localObject2).iterator();
        while (((Iterator)localObject5).hasNext())
        {
          localObject4 = (CellData)((Iterator)localObject5).next();
          TreeNode localTreeNode2 = ((CellData)localObject4).toNode();
          ((TreeNode)localObject3).appendChild(localTreeNode2);
        }
      }
    }
    return localTreeNode1;
  }
  
  public CellData(Cell paramCell)
  {
    this.index = paramCell.getIndex();
    this.mergeAcross = paramCell.getMergeAcross();
    this.mergeDown = paramCell.getMergeDown();
    this.model = paramCell;
    this.evaluated = false;
  }
  
  public String getUid()
  {
    return this.model.getUid();
  }
  
  public String getViewerId()
  {
    return this.model.getViewerId();
  }
  
  public String getInputorId()
  {
    return this.model.getInputorId();
  }
  
  public static CellData makeEmptyCell()
  {
    CellData localCellData = new CellData();
    return localCellData;
  }
  
  public int getEi()
  {
    return getExpandIndex();
  }
  
  public int getCi()
  {
    return getIndex();
  }
  
  public int getRi()
  {
    return getCalcRowIndex();
  }
  
  public CellData getHp()
  {
    return getHorParent();
  }
  
  public CellData getHr()
  {
    if (isVirtualRoot()) {
      return null;
    }
    CellData localCellData;
    for (Object localObject = this;; localObject = localCellData)
    {
      localCellData = ((CellData)localObject).getHorParent();
      if ((localCellData == null) || (localCellData.isVirtualRoot())) {
        return (CellData)localObject;
      }
    }
  }
  
  public CellData getVr()
  {
    if (isVirtualRoot()) {
      return null;
    }
    CellData localCellData;
    for (Object localObject = this;; localObject = localCellData)
    {
      localCellData = ((CellData)localObject).getVerParent();
      if ((localCellData == null) || (localCellData.isVirtualRoot())) {
        return (CellData)localObject;
      }
    }
  }
  
  public Object getV()
  {
    return this.value;
  }
  
  public Object getD()
  {
    if ((this.expandObj instanceof CellExpandValue)) {
      return ((CellExpandValue)this.expandObj).getFirstData();
    }
    return null;
  }
  
  public Object getE()
  {
    if ((this.expandObj instanceof CellExpandValue)) {
      return ((CellExpandValue)this.expandObj).getValue();
    }
    return this.expandObj;
  }
  
  public Object getM()
  {
    return this.model;
  }
  
  public CellData getVp()
  {
    return getVerParent();
  }
  
  public Object getO()
  {
    return this.object;
  }
  
  public void setO(Object paramObject)
  {
    this.object = paramObject;
  }
  
  public CellData getUnexpandCell()
  {
    return this.unexpandCell;
  }
  
  public void setUnexpandCell(CellData paramCellData)
  {
    this.unexpandCell = paramCellData;
  }
  
  public boolean passTest(Map<String, Object> paramMap)
  {
    if (this.model == null) {
      return true;
    }
    if (this.model.getExpandModel() == null) {
      return true;
    }
    return this.model.getExpandModel().passTest(paramMap);
  }
  
  public int getExpandRowspan()
  {
    return this.mergeDown - this.model.getMergeDown();
  }
  
  public int getExpandColspan()
  {
    return this.mergeAcross - this.model.getMergeAcross();
  }
  
  public CellExpandInfo getHorExpandInfo()
  {
    return this.horExpandInfo;
  }
  
  public CellExpandInfo getVerExpandInfo()
  {
    return this.verExpandInfo;
  }
  
  public boolean isRemoved()
  {
    return (this.horRemoved) || (this.verRemoved);
  }
  
  public boolean isHorRemoved()
  {
    return this.horRemoved;
  }
  
  public void setHorRemoved(boolean paramBoolean)
  {
    this.horRemoved = paramBoolean;
  }
  
  public boolean isVerRemoved()
  {
    return this.verRemoved;
  }
  
  public void setVerRemoved(boolean paramBoolean)
  {
    this.verRemoved = paramBoolean;
  }
  
  public void markRemoved(boolean paramBoolean)
  {
    if (paramBoolean) {
      setHorRemoved(true);
    } else {
      setVerRemoved(true);
    }
  }
  
  public boolean isNeedExpand()
  {
    return this.model.getExpandType() > 0;
  }
  
  public boolean isExpanded()
  {
    return this.expanded;
  }
  
  public int getCalcRowIndex()
  {
    return this.calcRowIndex;
  }
  
  public void setCalcRowIndex(int paramInt)
  {
    this.calcRowIndex = paramInt;
  }
  
  public int getEndRowPos()
  {
    return getEndRowIndex() - 1;
  }
  
  public int getEndColPos()
  {
    return getEndColIndex() - 1;
  }
  
  public int getEndRowIndex()
  {
    return getCalcRowIndex() + getMergeDown();
  }
  
  public int getCalcColIndex()
  {
    return getIndex();
  }
  
  public void setCalcColIndex(int paramInt)
  {
    setIndex(paramInt);
  }
  
  public int getEndColIndex()
  {
    return getIndex() + getMergeAcross();
  }
  
  public boolean isExpandedEmpty()
  {
    return (isNeedExpand()) && (this.expandedCells == null);
  }
  
  public boolean isVirtualRoot()
  {
    return (this.model != null) && (this.model.isVirtualRoot());
  }
  
  public CellData dup()
  {
    CellData localCellData = new CellData();
    localCellData.mergeAcross = this.mergeAcross;
    localCellData.mergeDown = this.mergeDown;
    localCellData.model = this.model;
    localCellData.index = this.index;
    localCellData.calcRowIndex = this.calcRowIndex;
    localCellData.value = this.value;
    localCellData.expanded = this.expanded;
    localCellData.expandObj = this.expandObj;
    localCellData.evaluated = this.evaluated;
    localCellData.expandIndex = this.expandIndex;
    localCellData.horRemoved = this.horRemoved;
    localCellData.verRemoved = this.verRemoved;
    return localCellData;
  }
  
  public TableData getTable()
  {
    return (TableData)this.row.getTable();
  }
  
  public String getSheetName()
  {
    return getTable().getSheetName();
  }
  
  public WorksheetData getSheet()
  {
    return getTable().getSheet();
  }
  
  public Range getCellRange()
  {
    int i = getRowPos();
    int j = getColPos();
    int k = i + getMergeDown();
    int m = j + getMergeAcross();
    return new Range(getSheetName(), i, j, k, m);
  }
  
  public CellData getModelLeft()
  {
    Cell localCell = getModel();
    CellData localCellData2 = this;
    CellData localCellData1;
    do
    {
      localCellData1 = localCellData2;
      localCellData2 = localCellData1.getLeftReal();
    } while ((localCellData2 != null) && (localCellData2.getModel() == localCell));
    return localCellData1;
  }
  
  public CellData getModelRight()
  {
    Cell localCell = getModel();
    CellData localCellData2 = this;
    CellData localCellData1;
    do
    {
      localCellData1 = localCellData2;
      localCellData2 = localCellData1.getRightReal();
    } while ((localCellData2 != null) && (localCellData2.getModel() == localCell));
    return localCellData1;
  }
  
  public CellData getModelUp()
  {
    Cell localCell = getModel();
    CellData localCellData2 = this;
    CellData localCellData1;
    do
    {
      localCellData1 = localCellData2;
      localCellData2 = localCellData1.getUpReal();
    } while ((localCellData2 != null) && (localCellData2.getModel() == localCell));
    return localCellData1;
  }
  
  public CellData getModelDown()
  {
    Cell localCell = getModel();
    CellData localCellData2 = this;
    CellData localCellData1;
    do
    {
      localCellData1 = localCellData2;
      localCellData2 = localCellData1.getDownReal();
    } while ((localCellData2 != null) && (localCellData2.getModel() == localCell));
    return localCellData1;
  }
  
  public Range getModelExpandRange()
  {
    int i = getModelUp().getRowPos();
    int j = getModelLeft().getColPos();
    int k = getModelRight().getEndRowPos();
    int m = getModelDown().getEndColPos();
    return new Range(getSheetName(), i, j, k, m);
  }
  
  public CellData getUpReal()
  {
    ICellHandle localICellHandle = getUp();
    return localICellHandle == null ? null : localICellHandle.getRealCell();
  }
  
  public CellData getDownReal()
  {
    ICellHandle localICellHandle = getDown();
    return localICellHandle == null ? null : localICellHandle.getRealCell();
  }
  
  public CellData getLeftReal()
  {
    ICellHandle localICellHandle = getLeft();
    return localICellHandle == null ? null : localICellHandle.getRealCell();
  }
  
  public CellData getRightReal()
  {
    ICellHandle localICellHandle = getRight();
    return localICellHandle == null ? null : localICellHandle.getRealCell();
  }
  
  public ICellHandle getUp()
  {
    RowData localRowData = this.row.getPrev();
    return localRowData == null ? null : (ICellHandle)localRowData.getCell(this.index - 1);
  }
  
  public ICellHandle getDown()
  {
    RowData localRowData = this.row.getNext();
    return localRowData == null ? null : (ICellHandle)localRowData.getCell(this.index - 1);
  }
  
  public ICellHandle getLeft()
  {
    return (ICellHandle)this.row.getCell(this.index - 2);
  }
  
  public ICellHandle getRight()
  {
    return (ICellHandle)this.row.getCell(this.index);
  }
  
  public int getExpendType()
  {
    return this.model.getExpandType();
  }
  
  public Collection<?> getExpandedSet(XptBuildRuntime paramXptBuildRuntime)
  {
    paramXptBuildRuntime.setCellData(this);
    IExpressionReference localIExpressionReference = this.model.getExpandExpr();
    if (localIExpressionReference != null)
    {
      Object localObject = TplC.evaluate(localIExpressionReference, paramXptBuildRuntime.getArgs());
      if (localObject == null) {
        return null;
      }
      if ((localObject instanceof IListData)) {
        return ((IListData)localObject).getListData();
      }
      return (localObject instanceof Collection) ? (Collection)localObject : Collections.singletonList(localObject);
    }
    if (getModelField() != null) {
      return XptDataSet.s_groupFieldValue(this.model.getExpandModel().getDsName(), getModelField(), paramXptBuildRuntime);
    }
    return null;
  }
  
  public CellData getRealCell()
  {
    return this;
  }
  
  public int getModelColIdx()
  {
    return this.model.getIndex() - 1;
  }
  
  public int getModelRowIdx()
  {
    return this.model.getRow().getIndex() - 1;
  }
  
  public int getRowspan()
  {
    return this.mergeDown + 1;
  }
  
  public int getColspan()
  {
    return this.mergeAcross + 1;
  }
  
  public void incRowspan(int paramInt)
  {
    this.mergeDown += paramInt;
  }
  
  public void incColspan(int paramInt)
  {
    this.mergeAcross += paramInt;
  }
  
  public boolean isIgnored()
  {
    return false;
  }
  
  public boolean isEvaluated()
  {
    return this.evaluated;
  }
  
  public void setEvaluated(boolean paramBoolean)
  {
    this.evaluated = paramBoolean;
  }
  
  public int getIndex()
  {
    return this.index;
  }
  
  public void setIndex(int paramInt)
  {
    this.index = paramInt;
  }
  
  public int getMergeAcross()
  {
    return this.mergeAcross;
  }
  
  public void setMergeAcross(int paramInt)
  {
    this.mergeAcross = paramInt;
  }
  
  public int getMergeDown()
  {
    return this.mergeDown;
  }
  
  public void setMergeDown(int paramInt)
  {
    this.mergeDown = paramInt;
  }
  
  public Cell getModel()
  {
    return this.model;
  }
  
  public void setModel(Cell paramCell)
  {
    this.model = paramCell;
  }
  
  public Object getValue()
  {
    return this.value;
  }
  
  public void setValue(Object paramObject)
  {
    this.value = paramObject;
  }
  
  public String getKey()
  {
    return this.key;
  }
  
  public void setKey(String paramString)
  {
    this.key = paramString;
  }
  
  public Object getExpandObj()
  {
    return this.expandObj;
  }
  
  public void setExpandObj(Object paramObject)
  {
    this.expandObj = paramObject;
    this.expanded = true;
  }
  
  public int getExpandIndex()
  {
    return this.expandIndex;
  }
  
  public void setExpandIndex(int paramInt)
  {
    this.expandIndex = paramInt;
  }
  
  public List<CellData> getChildren(boolean paramBoolean)
  {
    return paramBoolean ? getHorChildren() : getVerChildren();
  }
  
  public CellExpandInfo getExpandInfo(boolean paramBoolean)
  {
    return paramBoolean ? getHorExpandInfo() : getVerExpandInfo();
  }
  
  public CellExpandModel getExpandModel()
  {
    return getModel().getExpandModel();
  }
  
  public List<CellBandModel> getBandModels(boolean paramBoolean)
  {
    return getExpandModel().getBandModels(paramBoolean);
  }
  
  public List<CellData> getHorChildren()
  {
    return this.horExpandInfo.getChildren();
  }
  
  public void setHorChildren(List<CellData> paramList)
  {
    this.horExpandInfo.setChildren(paramList);
  }
  
  public CellData getHorParent()
  {
    return this.horExpandInfo.getParent();
  }
  
  public void setHorParent(CellData paramCellData)
  {
    this.horExpandInfo.setParent(paramCellData);
  }
  
  public List<CellData> getVerChildren()
  {
    return this.verExpandInfo.getChildren();
  }
  
  public void setVerChildren(List<CellData> paramList)
  {
    this.verExpandInfo.setChildren(paramList);
  }
  
  public boolean isHorSubOf(CellData paramCellData)
  {
    return this.horExpandInfo.isSubOf(paramCellData);
  }
  
  public boolean isVerSubOf(CellData paramCellData)
  {
    return this.verExpandInfo.isSubOf(paramCellData);
  }
  
  public boolean isMatchPath(CellData paramCellData)
  {
    if (paramCellData == null) {
      return false;
    }
    return (this.model == paramCellData.getModel()) && (this.expandIndex == paramCellData.getExpandIndex());
  }
  
  public boolean hasSameParent(CellData paramCellData)
  {
    return (isHorSubOf(paramCellData.getHorParent())) && (isVerSubOf(paramCellData.getVerParent()));
  }
  
  public int getHorExpandLevel()
  {
    return this.model.getHorExpandLevel();
  }
  
  public int getVerExpandLevel()
  {
    return this.model.getVerExpandLevel();
  }
  
  public CellData getVerParent()
  {
    return this.verExpandInfo.getParent();
  }
  
  public void setVerParent(CellData paramCellData)
  {
    this.verExpandInfo.setParent(paramCellData);
  }
  
  public RowData getRow()
  {
    return this.row;
  }
  
  public void setRow(RowData paramRowData)
  {
    this.row = paramRowData;
  }
  
  public int getRowIndex()
  {
    if (this.row == null) {
      return 0;
    }
    return this.row.getIndex();
  }
  
  public void addHorChild(CellData paramCellData)
  {
    this.horExpandInfo.addChild(paramCellData);
  }
  
  public void addVerChild(CellData paramCellData)
  {
    this.verExpandInfo.addChild(paramCellData);
  }
  
  public void addVerChildren(List<CellData> paramList)
  {
    if (paramList != null)
    {
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        CellData localCellData = (CellData)localIterator.next();
        addVerChild(localCellData);
      }
    }
  }
  
  public void addHorChildren(List<CellData> paramList)
  {
    if (paramList != null)
    {
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        CellData localCellData = (CellData)localIterator.next();
        addHorChild(localCellData);
      }
    }
  }
  
  public List<CellData> getExpandedCells()
  {
    return this.expandedCells;
  }
  
  public void setExpandedCells(List<CellData> paramList)
  {
    this.expandedCells = paramList;
  }
  
  public boolean isHorTop()
  {
    if (this.model.getHorParent() == null) {
      return false;
    }
    return this.model.getHorParent().isVirtualRoot();
  }
  
  public boolean isVerTop()
  {
    if (this.model.getVerParent() == null) {
      return false;
    }
    return this.model.getVerParent().isVirtualRoot();
  }
  
  public boolean isTopCell()
  {
    return (isHorTop()) && (isVerTop());
  }
  
  public CellData getVerOrgCell()
  {
    return this.verOrgCell;
  }
  
  public List<CellData> getVerCopyCells()
  {
    return this.verCopyCells;
  }
  
  public void setVerCopyCells(List<CellData> paramList)
  {
    this.verCopyCells = paramList;
  }
  
  public void setVerOrgCell(CellData paramCellData)
  {
    this.verOrgCell = paramCellData;
  }
  
  public void addVerCopyCell(CellData paramCellData)
  {
    if (this.verCopyCells == null) {
      this.verCopyCells = new ArrayList();
    }
    this.verCopyCells.add(paramCellData);
  }
  
  public void initVerCopyCells()
  {
    if (this.verCopyCells == null) {
      this.verCopyCells = new ArrayList();
    }
  }
  
  public CellData deepCopyVer()
  {
    CellData localCellData1 = dup();
    localCellData1.setHorParent(getHorParent());
    localCellData1.setVerParent(getVerParent());
    localCellData1.verOrgCell = (this.verOrgCell == null ? this : this.verOrgCell);
    localCellData1.verOrgCell.initVerCopyCells();
    List localList = getVerChildren();
    if (localList != null)
    {
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        CellData localCellData2 = (CellData)localIterator.next();
        CellData localCellData3 = localCellData2.deepCopyVer();
        localCellData1.addVerChild(localCellData3);
      }
    }
    return localCellData1;
  }
  
  public CellData deepCopyHor()
  {
    CellData localCellData1 = dup();
    localCellData1.setHorParent(getHorParent());
    localCellData1.setVerParent(getVerParent());
    Iterator localIterator1;
    CellData localCellData2;
    CellData localCellData3;
    if (this.verCopyCells != null)
    {
      localObject = new ArrayList();
      localIterator1 = this.verCopyCells.iterator();
      while (localIterator1.hasNext())
      {
        localCellData2 = (CellData)localIterator1.next();
        localCellData3 = localCellData2.dup();
        localCellData3.setHorParent(localCellData2.getHorParent());
        localCellData3.setVerParent(localCellData2.getVerParent());
        localCellData3.verOrgCell = localCellData1;
        ((List)localObject).add(localCellData3);
      }
      localCellData1.verCopyCells = ((List)localObject);
    }
    if (this.expandedCells != null)
    {
      localObject = new ArrayList(this.expandedCells.size());
      localIterator1 = this.expandedCells.iterator();
      while (localIterator1.hasNext())
      {
        localCellData2 = (CellData)localIterator1.next();
        localCellData3 = localCellData2.deepCopyHor();
        ((List)localObject).add(localCellData3);
      }
      localCellData1.expandedCells = ((List)localObject);
    }
    Object localObject = getHorChildren();
    if (localObject != null)
    {
      localIterator1 = ((List)localObject).iterator();
      while (localIterator1.hasNext())
      {
        localCellData2 = (CellData)localIterator1.next();
        localCellData3 = localCellData2.deepCopyHor();
        localCellData1.addHorChild(localCellData3);
        if (localCellData3.getVerCopyCells() != null)
        {
          Iterator localIterator2 = localCellData3.getVerCopyCells().iterator();
          while (localIterator2.hasNext())
          {
            CellData localCellData4 = (CellData)localIterator2.next();
            localCellData4.setHorParent(localCellData1);
          }
        }
      }
    }
    return localCellData1;
  }
  
  public Object getFormatExpr()
  {
    return this.model.getFormatExpr();
  }
  
  public FieldDefinition getFieldDefinition()
  {
    return this.model.getFieldDefinition();
  }
  
  public String getDataForXls(Object paramObject)
  {
    return Cell.getDataForXls(this.model.maybeNumberCell(), paramObject);
  }
  
  public String getDataForXls(boolean paramBoolean, Object paramObject)
  {
    return Cell.getDataForXls(paramBoolean, paramObject);
  }
  
  public String buildLink(Map<String, Object> paramMap)
  {
    return this.model.buildLink(paramMap);
  }
  
  public Object getFormatedValue(Map<String, Object> paramMap)
  {
    return formatValue(this.value, paramMap);
  }
  
  public Object formatValue(Object paramObject, Map<String, Object> paramMap)
  {
    IExpressionReference localIExpressionReference = this.model.getFormatExpr();
    if (localIExpressionReference != null)
    {
      paramMap.put("value", paramObject);
      paramMap.put("_cell", this);
      paramObject = TplC.evaluate(localIExpressionReference, paramMap);
    }
    if (paramObject == null) {
      return null;
    }
    Style localStyle = getStyle();
    if (localStyle != null) {
      paramObject = localStyle.format(paramObject);
    }
    return paramObject;
  }
  
  public Object getDirectFormatedValue(Map<String, Object> paramMap)
  {
    return directFormatValue(this.value, paramMap);
  }
  
  public Object directFormatValue(Object paramObject, Map<String, Object> paramMap)
  {
    IExpressionReference localIExpressionReference = this.model.getFormatExpr();
    if (localIExpressionReference == null) {
      return paramObject;
    }
    paramMap.put("value", paramObject);
    paramMap.put("_cell", this);
    return TplC.evaluate(localIExpressionReference, paramMap);
  }
  
  public Object evaluate(Map<String, Object> paramMap)
  {
    return this.value;
  }
  
  public String evaluateKey(Map<String, Object> paramMap)
  {
    return this.key;
  }
  
  public void evaluatePrepareRow(Map<String, Object> paramMap)
  {
    if ((this.model != null) && (this.model.getPrepareRowExpr() != null))
    {
      paramMap.put("_cell", this);
      TplC.evaluate(this.model.getPrepareRowExpr(), paramMap);
    }
  }
  
  public Object evaluateCell(XptBuildRuntime paramXptBuildRuntime)
  {
    if (this.evaluated) {
      return this.value;
    }
    this.evaluated = true;
    Map localMap = paramXptBuildRuntime.getArgs();
    localMap.put("_cell", this);
    if ((this.expanded) && (getExpendType() == 2))
    {
      localMap.put("_", this.expandObj);
    }
    else
    {
      localCellData = getHorParent();
      if ((localCellData != null) && (localCellData.isExpanded())) {
        localMap.put("_", localCellData.getExpandObj());
      } else {
        localMap.remove("_");
      }
    }
    CellData localCellData = paramXptBuildRuntime.getCellData();
    paramXptBuildRuntime.setCellData(this);
    CellFormula localCellFormula = this.model.getCellFormula();
    Object localObject1;
    if (localCellFormula != null)
    {
      this.value = localCellFormula.evaluate(paramXptBuildRuntime);
    }
    else if (this.model.isNoValueExpr())
    {
      if (isExpanded())
      {
        this.value = getE();
        localObject1 = this.model.getExpandModel().getTextField();
        if ((localObject1 != null) && (this.value != null)) {
          this.value = TplC.getProperty(this.value, (String)localObject1);
        }
      }
      else if (getModelField() != null)
      {
        this.value = XptDataSet.s_getFieldValue(this.model.getExpandModel().getDsName(), getModelField(), paramXptBuildRuntime);
      }
      else
      {
        this.value = this.model.getValue();
      }
    }
    else if (this.model.getValueExpr() != null)
    {
      this.value = TplC.evaluate(this.model.getValueExpr(), localMap);
    }
    else if (getFieldDefinition() != null)
    {
      localObject1 = getFieldDefinition();
      Object localObject2 = TplC.getToken(localMap, "entity");
      if (localObject2 != null)
      {
        Object localObject3 = TplC.getProperty(localObject2, ((FieldDefinition)localObject1).getName());
        String str = ((FieldDefinition)localObject1).getExtIndex();
        if (":value".equals(str)) {
          str = (String)this.model.getValue();
        }
        if (str != null) {
          localObject3 = TplC.getProperty(localObject3, str);
        }
        this.value = localObject3;
      }
    }
    else
    {
      this.value = this.model.getValue();
    }
    if (this.value == null) {
      this.value = evaluateDefaultValue(localMap);
    }
    if (this.model.getKeyExpr() != null) {
      this.key = Coercions.toString(TplC.evaluate(this.model.getKeyExpr(), localMap), null);
    }
    this.comment = this.model.evaluateComment(localMap);
    this.visible = this.model.evaluateVisible(localMap);
    this.readOnly = this.model.evaluateReadOnly(localMap);
    this.rowVisible = this.model.evaluateRowVisible(localMap);
    if (this.model.getStyleExpr() != null)
    {
      localObject1 = Variant.toString(TplC.evaluate(this.model.getStyleExpr(), localMap), null);
      this.style = paramXptBuildRuntime.mapStyle((String)localObject1);
    }
    if (this.model.getObjectExpr() != null) {
      this.object = TplC.evaluate(this.model.getObjectExpr(), localMap);
    }
    paramXptBuildRuntime.setCellData(localCellData);
    return this.value;
  }
  
  public Object evaluateDefaultValue(Map<String, Object> paramMap)
  {
    if (this.model.getDefaultValueExpr() != null)
    {
      paramMap.put("_cell", this);
      return TplC.evaluate(this.model.getDefaultValueExpr(), paramMap);
    }
    return null;
  }
  
  public String getModelField()
  {
    return this.model.getExpandModel().getField();
  }
  
  public List<Object> getDimValues(XptBuildRuntime paramXptBuildRuntime)
  {
    if (isVirtualRoot()) {
      return null;
    }
    CellExpandModel localCellExpandModel = this.model.getExpandModel();
    if ((localCellExpandModel == null) || (localCellExpandModel.getDimFields() == null)) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(localCellExpandModel.getDimFields().size());
    List localList = localCellExpandModel.getHorDimFields();
    int j;
    Object localObject2;
    if (localList != null)
    {
      localObject1 = getHorParent();
      j = localList.size();
      for (int i = 0; i < j; i++)
      {
        String str = (String)localList.get(i);
        if (str != null)
        {
          localObject2 = ((CellData)localObject1).getExpandObj();
          localArrayList.add(localObject2);
        }
        localObject1 = ((CellData)localObject1).getHorParent();
      }
    }
    Object localObject1 = localCellExpandModel.getVerDimFields();
    if (localObject1 != null)
    {
      CellData localCellData = getVerParent();
      int k = ((List)localObject1).size();
      for (j = 0; j < k; j++)
      {
        localObject2 = (String)((List)localObject1).get(j);
        if (localObject2 != null)
        {
          Object localObject3 = localCellData.getExpandObj();
          localArrayList.add(localObject3);
        }
        localCellData = localCellData.getVerParent();
      }
    }
    return localArrayList;
  }
  
  public List<String> getDimFields()
  {
    return this.model == null ? null : this.model.getExpandModel().getDimFields();
  }
  
  public String toXlsCell(IExpressionReference paramIExpressionReference, Map<String, Object> paramMap)
  {
    XptBuildRuntime localXptBuildRuntime = (XptBuildRuntime)paramMap.get("xptRt");
    CellData localCellData = null;
    if (localXptBuildRuntime != null)
    {
      localCellData = localXptBuildRuntime.getCellData();
      localXptBuildRuntime.setCellData(this);
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("<Cell");
    StringUtilsEx.attr(localStringBuilder, "ss:StyleID", getStyleID());
    StringUtilsEx.attr(localStringBuilder, "ss:Index", Integer.valueOf(this.index));
    StringUtilsEx.attr(localStringBuilder, "ss:Formula", getFormula());
    if (this.mergeAcross > 0) {
      StringUtilsEx.attr(localStringBuilder, "ss:MergeAcross", Integer.valueOf(this.mergeAcross));
    }
    if (this.mergeDown > 0) {
      StringUtilsEx.attr(localStringBuilder, "ss:MergeDown", Integer.valueOf(this.mergeDown));
    }
    String str = null;
    if (this.model.isStaticCell())
    {
      str = this.model.getStaticXlsCellStr();
    }
    else if (paramIExpressionReference != null)
    {
      localObject = TplC.evaluate(paramIExpressionReference, paramMap);
      if (localObject != null) {
        str = localObject.toString();
      }
    }
    Object localObject = getComment();
    if ((str == null) && (localObject == null))
    {
      localStringBuilder.append("/>");
    }
    else
    {
      localStringBuilder.append(">");
      if (str != null) {
        localStringBuilder.append(str);
      }
      if (localObject != null)
      {
        localStringBuilder.append("<Comment><Data>");
        localStringBuilder.append(StringUtilsEx.encodeXmlBr((String)localObject, "&#10;"));
        localStringBuilder.append("</Data></Comment>");
      }
      localStringBuilder.append("</Cell>");
    }
    if (localXptBuildRuntime != null) {
      localXptBuildRuntime.setCellData(localCellData);
    }
    return localStringBuilder.toString();
  }
  
  public String toWmlText(IExpressionReference paramIExpressionReference, Map<String, Object> paramMap)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    if (isStaticCell())
    {
      localStringBuilder.append(this.model.getStaticWmlCellStr());
    }
    else if (paramIExpressionReference != null)
    {
      String str = Coercions.toString(TplC.evaluate(paramIExpressionReference, paramMap), null);
      if (str != null) {
        localStringBuilder.append(str);
      }
    }
    return localStringBuilder.toString();
  }
  
  public String getClassName(String paramString)
  {
    String str1 = this.model.getCssClassName();
    Style localStyle = getStyle();
    String str2 = localStyle == null ? null : localStyle.getCssClassName(paramString);
    if (str1 != null) {
      str2 = str2 + " " + str1;
    }
    return str2;
  }
  
  public boolean isAtMergeLeft()
  {
    return getRealCell().getIndex() == this.index;
  }
  
  public boolean isStaticCell()
  {
    return this.model.isStaticCell();
  }
  
  public String getHtml()
  {
    return this.model.getHtml();
  }
  
  public int getRowPos()
  {
    return this.calcRowIndex - 1;
  }
  
  public int getColPos()
  {
    return this.index - 1;
  }
  
  public String getDisplay()
  {
    return this.model.getDisplay();
  }
  
  public Object getLinkExpr()
  {
    return this.model.getLinkExpr();
  }
  
  public Workbook getWorkbook()
  {
    return this.model.getWorksheet().getWorkbook();
  }
  
  public Style getStyle()
  {
    if (this.style != null) {
      return this.style;
    }
    return this.model.getStyle();
  }
  
  public void setStyle(Style paramStyle)
  {
    this.style = paramStyle;
  }
  
  public String getStyleID()
  {
    if (this.style != null) {
      return this.style.getId();
    }
    return this.model.getStyleID();
  }
  
  public String getComment()
  {
    return this.comment;
  }
  
  public String getData()
  {
    return this.model.getData();
  }
  
  public String getDataType()
  {
    return this.model.getDataType();
  }
  
  public String getFormula()
  {
    return this.formula;
  }
  
  public void setFormula(String paramString)
  {
    this.formula = paramString;
  }
  
  public RichData getRichData()
  {
    return this.model.getRichData();
  }
  
  public boolean isNumberCell()
  {
    return this.model.isNumberCell();
  }
  
  public boolean maybeNumberCell()
  {
    return this.model.maybeNumberCell();
  }
  
  public boolean isBlank()
  {
    if (this.model.hasBorder()) {
      return false;
    }
    if ((this.value == null) && (isStaticCell())) {
      return this.model.isBlank();
    }
    if (this.value == null) {
      return true;
    }
    return ((this.value instanceof String)) && (this.value.toString().length() <= 0);
  }
  
  public double getFullWidth()
  {
    if (this.row == null) {
      return 0.0D;
    }
    return ((TableData)this.row.getTable()).getFullWidth(getIndex() - 1, getColspan());
  }
  
  public double getFullHeight()
  {
    if (this.row == null) {
      return 0.0D;
    }
    return ((TableData)this.row.getTable()).getFullHeight(this.row.getIndex() - 1, getRowspan());
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\data\CellData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */