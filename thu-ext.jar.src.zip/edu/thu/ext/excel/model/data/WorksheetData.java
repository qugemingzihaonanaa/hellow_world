package edu.thu.ext.excel.model.data;

import edu.thu.ext.excel.model.Column;
import edu.thu.ext.excel.model.IWorksheet;
import edu.thu.ext.excel.model.ImgData;
import edu.thu.ext.excel.model.Names;
import edu.thu.ext.excel.model.PageBreaks;
import edu.thu.ext.excel.model.PageInfo;
import edu.thu.ext.excel.model.RowBlock;
import edu.thu.ext.excel.model.Table;
import edu.thu.ext.excel.model.TablePiece;
import edu.thu.ext.excel.model.Worksheet;
import edu.thu.ext.excel.model.WorksheetOptions;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class WorksheetData
  implements IWorksheet, Serializable
{
  private static final long serialVersionUID = 6175574569833451182L;
  Worksheet R;
  TableData T;
  WorkbookData U;
  String O;
  WorksheetOptions V;
  PageBreaks P;
  List<ImgData> Q;
  Names S;
  
  public WorksheetData() {}
  
  public WorksheetData(Worksheet paramWorksheet, WorkbookData paramWorkbookData)
  {
    this.R = paramWorksheet;
    this.U = paramWorkbookData;
    this.T = new TableData(paramWorksheet.getTable(), this);
  }
  
  PageBreaks B()
  {
    if (this.P != null) {
      return this.P;
    }
    if (this.R.getPageBreaks() != null) {
      this.P = this.R.getPageBreaks().copy();
    } else {
      this.P = new PageBreaks();
    }
    return this.P;
  }
  
  List<ImgData> A()
  {
    if (this.Q != null) {
      return this.Q;
    }
    this.Q = new ArrayList();
    List localList = this.R.getImgs();
    if (localList != null)
    {
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        ImgData localImgData = (ImgData)localIterator.next();
        this.Q.add(localImgData);
      }
    }
    return this.Q;
  }
  
  public void mergeWorksheetData(WorksheetData paramWorksheetData, boolean paramBoolean)
  {
    int i = getRowCount();
    if (paramBoolean) {
      B().addRow(i);
    }
    if (paramWorksheetData.getPageBreaks() != null) {
      B().appendPageBreaks(paramWorksheetData.getPageBreaks(), i);
    }
    if (paramWorksheetData.getImgs() != null)
    {
      List localList1 = A();
      List localList2 = paramWorksheetData.getImgs();
      if (localList2 != null)
      {
        Iterator localIterator = localList2.iterator();
        while (localIterator.hasNext())
        {
          ImgData localImgData = (ImgData)localIterator.next();
          localImgData = localImgData.copy();
          localImgData.moveRows(i);
          localList1.add(localImgData);
        }
      }
    }
    this.T.mergeTableData(paramWorksheetData.getTable());
  }
  
  public Names getNames()
  {
    if (this.S == null) {
      return this.R.getNames();
    }
    return this.S;
  }
  
  public void setNames(Names paramNames)
  {
    this.S = paramNames;
  }
  
  public int getRowCount()
  {
    return this.T.getRowCount();
  }
  
  public Map<String, Object> getProperties()
  {
    return this.R.getProperties();
  }
  
  public WorksheetOptions getWorksheetOptions()
  {
    return this.V == null ? this.R.getWorksheetOptions() : this.V;
  }
  
  public void setWorksheetOptions(WorksheetOptions paramWorksheetOptions)
  {
    this.V = paramWorksheetOptions;
  }
  
  public String getWorksheetName()
  {
    return this.O == null ? this.R.getWorksheetName() : this.O;
  }
  
  public void setWorksheetName(String paramString)
  {
    this.O = paramString;
  }
  
  public String getNormalName()
  {
    return this.O == null ? this.R.getNormalName() : this.O;
  }
  
  public WorkbookData getWorkbook()
  {
    return this.U;
  }
  
  public void setWorkbook(WorkbookData paramWorkbookData)
  {
    this.U = paramWorkbookData;
  }
  
  public Worksheet getModel()
  {
    return this.R;
  }
  
  public void setModel(Worksheet paramWorksheet)
  {
    this.R = paramWorksheet;
  }
  
  public TableData getTable()
  {
    return this.T;
  }
  
  public void setTable(TableData paramTableData)
  {
    this.T = paramTableData;
  }
  
  public void addRow(RowData paramRowData)
  {
    this.T.addRow(paramRowData);
  }
  
  public RowData makeRow(int paramInt)
  {
    return this.T.makeRow(paramInt);
  }
  
  public RowData getRow(int paramInt)
  {
    return (RowData)this.T.getRow(paramInt);
  }
  
  public ICellHandle getCell(int paramInt1, int paramInt2)
  {
    return this.T.getCell(paramInt1, paramInt2);
  }
  
  public boolean isBreakAtBegin()
  {
    return this.R.isBreakAtBegin();
  }
  
  public boolean isBreakAtEnd()
  {
    return this.R.isBreakAtEnd();
  }
  
  public boolean isHorPage()
  {
    return this.R.isHorPage();
  }
  
  public PageInfo newPageInfo()
  {
    return new PageInfo(this.T.getTotalWidth(), isHorPage());
  }
  
  public List<TablePiece> getTablePieces()
  {
    return this.T.getTablePieces();
  }
  
  public List<RowData> getRows()
  {
    return this.T.getRows();
  }
  
  public List<RowData> getRows(RowBlock paramRowBlock)
  {
    return this.T.getRows().subList(paramRowBlock.getFirstRowNum(), paramRowBlock.getLastRowNum() + 1);
  }
  
  public List<Column> getCols()
  {
    return this.T.getCols();
  }
  
  public RowBlock getRowBlock()
  {
    return new RowBlock("simple", 0, getRowCount() - 1);
  }
  
  public double getDefaultColumnWidth()
  {
    return this.T.getModel().getDefaultColumnWidth();
  }
  
  public double getDefaultRowHeight()
  {
    return this.T.getModel().getDefaultRowHeight();
  }
  
  public PageBreaks getPageBreaks()
  {
    return this.P != null ? this.P : this.R.getPageBreaks();
  }
  
  public void setPageBreaks(PageBreaks paramPageBreaks)
  {
    this.P = paramPageBreaks;
  }
  
  public List<ImgData> getImgs()
  {
    return this.Q != null ? this.Q : this.R.getImgs();
  }
  
  public ImgData newImg()
  {
    if (this.Q == null) {
      this.Q = (this.R.getImgs() == null ? new ArrayList() : new ArrayList(this.R.getImgs()));
    }
    ImgData localImgData = new ImgData();
    localImgData.setSheetName(getWorksheetName());
    this.Q.add(localImgData);
    return localImgData;
  }
  
  public void setImgs(List<ImgData> paramList)
  {
    this.Q = paramList;
  }
  
  public List<List<Object>> getCellDatas()
  {
    return this.T.getCellDatas();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\data\WorksheetData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */