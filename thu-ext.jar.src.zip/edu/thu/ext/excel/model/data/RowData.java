package edu.thu.ext.excel.model.data;

import edu.thu.ext.excel.model.AbstractRow;
import edu.thu.ext.excel.model.Cell;
import edu.thu.ext.excel.model.ICell;
import edu.thu.ext.excel.model.Row;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.util.StringUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class RowData
  extends AbstractRow<ICellHandle, TableData>
{
  private static final long serialVersionUID = 8646443037240237507L;
  Row H;
  
  public RowData() {}
  
  public RowData(Row paramRow)
  {
    this.H = paramRow;
  }
  
  public RowData(Row paramRow, TableData paramTableData)
  {
    this.H = paramRow;
    this.table = paramTableData;
  }
  
  public static RowData makeFromModel(Row paramRow)
  {
    RowData localRowData = new RowData();
    localRowData.H = paramRow;
    ArrayList localArrayList = new ArrayList(paramRow.getCells().size());
    Iterator localIterator = paramRow.getCells().iterator();
    while (localIterator.hasNext())
    {
      Cell localCell = (Cell)localIterator.next();
      localCell.setRow(paramRow);
      CellData localCellData = new CellData(localCell);
      localArrayList.add(localCellData);
    }
    localRowData.cells = localArrayList;
    return localRowData;
  }
  
  public boolean evaluateVisible(Map<String, Object> paramMap)
  {
    if (this.cells.isEmpty()) {
      return true;
    }
    ICellHandle localICellHandle = (ICellHandle)this.cells.get(0);
    return localICellHandle.getRealCell().isRowVisible();
  }
  
  public void evaluatePrepareRow(Map<String, Object> paramMap)
  {
    if (this.cells.isEmpty()) {
      return;
    }
    Iterator localIterator = this.cells.iterator();
    while (localIterator.hasNext())
    {
      ICellHandle localICellHandle = (ICellHandle)localIterator.next();
      if ((localICellHandle != null) && (!localICellHandle.isIgnored())) {
        localICellHandle.evaluatePrepareRow(paramMap);
      }
    }
  }
  
  public boolean isExpandAcross(CellData paramCellData, int paramInt)
  {
    if (paramInt >= this.cells.size()) {
      return false;
    }
    return ((ICellHandle)this.cells.get(paramInt)).getRealCell() == paramCellData;
  }
  
  public boolean isExpandTo(CellData paramCellData, int paramInt)
  {
    if (paramInt >= this.cells.size()) {
      return false;
    }
    if ((paramInt < this.cells.size()) && (((ICellHandle)this.cells.get(paramInt + 1)).getRealCell() == paramCellData)) {
      return false;
    }
    return ((ICellHandle)this.cells.get(paramInt)).getRealCell() == paramCellData;
  }
  
  public boolean isSameRowSpan(int paramInt1, int paramInt2)
  {
    if (paramInt2 == 0) {
      return false;
    }
    int i = ((ICellHandle)this.cells.get(paramInt1)).getRealCell().getRowspan();
    for (int j = 1; j < paramInt2; j++) {
      if (((ICellHandle)this.cells.get(paramInt1 + j)).getRealCell().getRowspan() != i) {
        return false;
      }
    }
    return true;
  }
  
  public int getModelRowIndex()
  {
    return this.H.getIndex();
  }
  
  public void safeSetCell(int paramInt, ICellHandle paramICellHandle)
  {
    paramICellHandle.setRow(this);
    for (int i = this.cells.size(); i <= paramInt; i++) {
      this.cells.add(IgnoreNullCell.INSTANCE);
    }
    this.cells.set(paramInt, paramICellHandle);
  }
  
  public Row getModel()
  {
    return this.H;
  }
  
  public void setModel(Row paramRow)
  {
    this.H = paramRow;
  }
  
  public void addCell(CellData paramCellData)
  {
    paramCellData.setRow(this);
    this.cells.add(paramCellData);
  }
  
  public void setCellAt(ICellHandle paramICellHandle)
  {
    safeSetCell(paramICellHandle.getIndex() - 1, paramICellHandle);
  }
  
  public ICellHandle makeCell(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= this.H.getColCount())) {
      throw Exceptions.code("excel.CAN_err_invalid_row_count");
    }
    for (int i = this.cells.size(); i <= paramInt; i++)
    {
      Cell localCell = this.H.getCell(paramInt);
      if (localCell.isIgnored()) {
        this.cells.add(IgnoreNullCell.INSTANCE);
      } else {
        addCell(new CellData(localCell));
      }
    }
    return (ICellHandle)this.cells.get(paramInt);
  }
  
  public double getHeight()
  {
    return this.H.getHeight();
  }
  
  public boolean isHidden()
  {
    return this.H.isHidden();
  }
  
  public boolean isParagraphRow()
  {
    return this.H.isParagraphRow();
  }
  
  public boolean isAutoFitHeight()
  {
    if (this.H == null) {
      throw Exceptions.notAllowed();
    }
    return this.H.isAutoFitHeight();
  }
  
  public boolean isBoolHidden()
  {
    return this.H.isBoolHidden();
  }
  
  public String getDisplay()
  {
    return this.H.getDisplay();
  }
  
  public CellData getFirstCell()
  {
    if (this.cells.isEmpty()) {
      return null;
    }
    ICellHandle localICellHandle = (ICellHandle)this.cells.get(0);
    return localICellHandle.isIgnored() ? null : localICellHandle.getRealCell();
  }
  
  public RowData getPrev()
  {
    return (RowData)((TableData)getTable()).getRow(this.index - 2);
  }
  
  public RowData getNext()
  {
    return (RowData)((TableData)getTable()).getRow(this.index);
  }
  
  public List<Object> getRowValues()
  {
    ArrayList localArrayList = new ArrayList(this.cells.size());
    int j = this.cells.size();
    for (int i = 0; i < j; i++)
    {
      ICell localICell = (ICell)this.cells.get(i);
      if ((localICell == null) || (localICell.isIgnored()))
      {
        localArrayList.add(null);
      }
      else
      {
        Object localObject = localICell.getValue();
        if ((localObject instanceof String)) {
          localObject = StringUtils.strip(localObject.toString());
        }
        localArrayList.add(localObject);
      }
    }
    return localArrayList;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\data\RowData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */