package edu.thu.ext.excel.model.data;

import edu.thu.ext.excel.model.RichData;
import edu.thu.ext.excel.model.Style;
import java.util.Map;

public class IgnoreCellHandle
  implements ICellHandle, Comparable<ICellHandle>
{
  int index;
  RowData row;
  CellData cell;
  
  public IgnoreCellHandle(CellData paramCellData)
  {
    this.cell = paramCellData;
  }
  
  public int compareTo(ICellHandle paramICellHandle)
  {
    int i = getRowIndex();
    int j = paramICellHandle.getRow() == null ? 0 : paramICellHandle.getRow().getIndex();
    if (i != j) {
      return i < j ? -1 : 1;
    }
    int k = getIndex();
    int m = paramICellHandle.getIndex();
    return k < m ? -1 : k == m ? 0 : 1;
  }
  
  public int getRowIndex()
  {
    return this.row == null ? 0 : this.row.getIndex();
  }
  
  public int getIndex()
  {
    return this.index;
  }
  
  public void setIndex(int paramInt)
  {
    this.index = paramInt;
  }
  
  public RowData getRow()
  {
    return this.row;
  }
  
  public void setRow(RowData paramRowData)
  {
    this.row = paramRowData;
  }
  
  public boolean isIgnored()
  {
    return true;
  }
  
  public CellData getRealCell()
  {
    return this.cell;
  }
  
  public ICellHandle generate(Map<String, Object> paramMap)
  {
    return this;
  }
  
  public void evaluatePrepareRow(Map<String, Object> paramMap)
  {
    this.cell.evaluatePrepareRow(paramMap);
  }
  
  public void incRowspan(int paramInt)
  {
    this.cell.incRowspan(paramInt);
  }
  
  public void incColspan(int paramInt)
  {
    this.cell.incColspan(paramInt);
  }
  
  public void setCell(CellData paramCellData)
  {
    this.cell = paramCellData;
  }
  
  public boolean isAtMergeLeft()
  {
    return getRealCell().getIndex() == this.index;
  }
  
  public boolean isAtMergeRight()
  {
    return getRealCell().getIndex() + getRealCell().getMergeAcross() == this.index;
  }
  
  public boolean isAtMergeTop()
  {
    return getRealCell().getRowIndex() == getRow().getIndex();
  }
  
  public boolean isAtMergeBottom()
  {
    return getRealCell().getRowIndex() + getRealCell().getMergeDown() == getRow().getIndex();
  }
  
  public int getColspan()
  {
    return this.cell.getColspan();
  }
  
  public Object getO()
  {
    return this.cell.getO();
  }
  
  public String getComment()
  {
    return this.cell.getComment();
  }
  
  public String getData()
  {
    return this.cell.getData();
  }
  
  public String getDataType()
  {
    return this.cell.getDataType();
  }
  
  public String getFormula()
  {
    return this.cell.getFormula();
  }
  
  public RichData getRichData()
  {
    return this.cell.getRichData();
  }
  
  public Style getStyle()
  {
    return this.cell.getStyle();
  }
  
  public String getStyleID()
  {
    return this.cell.getStyleID();
  }
  
  public Object getFormatedValue(Map<String, Object> paramMap)
  {
    return this.cell.getFormatedValue(paramMap);
  }
  
  public Object getValue()
  {
    return this.cell.getValue();
  }
  
  public int getMergeAcross()
  {
    return this.cell.getMergeAcross();
  }
  
  public int getMergeDown()
  {
    return this.cell.getMergeDown();
  }
  
  public boolean isNumberCell()
  {
    return this.cell.isNumberCell();
  }
  
  public boolean isStaticCell()
  {
    return this.cell.isStaticCell();
  }
  
  public String getKey()
  {
    return this.cell.getKey();
  }
  
  public String getUid()
  {
    return this.cell.getUid();
  }
  
  public boolean isBlank()
  {
    return this.cell.isBlank();
  }
  
  public boolean maybeNumberCell()
  {
    return this.cell.maybeNumberCell();
  }
  
  public int getColPos()
  {
    return this.cell.getColPos();
  }
  
  public int getRowPos()
  {
    return this.cell.getRowPos();
  }
  
  public int getRowspan()
  {
    return this.cell.getRowspan();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\data\IgnoreCellHandle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */