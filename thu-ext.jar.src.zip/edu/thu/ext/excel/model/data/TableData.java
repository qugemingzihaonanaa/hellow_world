package edu.thu.ext.excel.model.data;

import edu.thu.ext.excel.model.AbstractTable;
import edu.thu.ext.excel.model.Cell;
import edu.thu.ext.excel.model.Column;
import edu.thu.ext.excel.model.Range;
import edu.thu.ext.excel.model.Row;
import edu.thu.ext.excel.model.Table;
import edu.thu.ext.excel.model.Worksheet;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.exceptions.StdException;
import edu.thu.lang.util.IWrapCollection;
import edu.thu.model.table.IBasicCellModel;
import edu.thu.report.util.WrapCollection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TableData
  extends AbstractTable<RowData>
{
  private static final long serialVersionUID = 4839613666796528123L;
  WorksheetData sheet;
  Table model;
  CellData horRoot;
  CellData verRoot;
  
  protected TableData() {}
  
  public TableData(Table paramTable, WorksheetData paramWorksheetData)
  {
    this.model = paramTable;
    this.sheet = paramWorksheetData;
  }
  
  public WorksheetData getSheet()
  {
    return this.sheet;
  }
  
  public void setSheet(WorksheetData paramWorksheetData)
  {
    this.sheet = paramWorksheetData;
  }
  
  public CellData getHorRoot()
  {
    return this.horRoot;
  }
  
  public void setHorRoot(CellData paramCellData)
  {
    this.horRoot = paramCellData;
  }
  
  public CellData getVerRoot()
  {
    return this.verRoot;
  }
  
  public void setVerRoot(CellData paramCellData)
  {
    this.verRoot = paramCellData;
  }
  
  public static TableData makeFromModel(Table paramTable)
  {
    TableData localTableData = new TableData();
    localTableData.model = paramTable;
    ArrayList localArrayList = new ArrayList(paramTable.getRows().size());
    localTableData.rows = localArrayList;
    int j = paramTable.getRows().size();
    for (int i = 0; i < j; i++)
    {
      Row localRow = (Row)paramTable.getRows().get(i);
      Iterator localIterator = localRow.getCells().iterator();
      while (localIterator.hasNext())
      {
        Cell localCell = (Cell)localIterator.next();
        if (!localCell.isIgnored())
        {
          localCell.setRow(localRow);
          CellData localCellData = new CellData(localCell);
          addCell(localArrayList, i, localCell.getIndex(), localRow, localCellData);
          for (int k = i; k <= i + localCell.getMergeAcross(); k++) {
            for (int m = localCell.getIndex(); m <= localCell.getIndex() + localCell.getMergeAcross(); m++) {
              if ((k != i) || (m != localCell.getIndex())) {
                addCell(localArrayList, k, m, localRow, new IgnoreCellHandle(localCellData));
              }
            }
          }
        }
      }
    }
    return localTableData;
  }
  
  static void addCell(List<RowData> paramList, int paramInt1, int paramInt2, Row paramRow, ICellHandle paramICellHandle)
  {
    for (int i = paramList.size(); i <= paramInt1; i++) {
      paramList.add(new RowData());
    }
    RowData localRowData = (RowData)paramList.get(paramInt1);
    localRowData.setModel(paramRow);
    localRowData.safeSetCell(paramInt2, paramICellHandle);
  }
  
  public void fixCols()
  {
    if (this.rows.isEmpty()) {
      this.cols = new WrapCollection(this.model.getCols()).call("copy").listValue();
    }
  }
  
  public void fixCol(CellData paramCellData)
  {
    int i = paramCellData.getIndex() - 1;
    if (i < this.cols.size())
    {
      Column localColumn1 = (Column)this.cols.get(i);
      if (localColumn1 == null) {
        localColumn1 = paramCellData.getModel().getColumn();
      }
    }
    else
    {
      for (int j = this.cols.size(); j <= i; j++) {
        this.cols.add(null);
      }
      Column localColumn2 = paramCellData.getModel().getColumn();
      this.cols.set(i, localColumn2);
    }
  }
  
  int _maxColCount()
  {
    int i = 0;
    Iterator localIterator = this.rows.iterator();
    while (localIterator.hasNext())
    {
      RowData localRowData = (RowData)localIterator.next();
      int j = localRowData.getColCount();
      i = Math.max(i, j);
    }
    return i;
  }
  
  public void fixEmptyCell()
  {
    int i = _maxColCount();
    int k = this.rows.size();
    for (int j = 0; j < k; j++)
    {
      RowData localRowData = (RowData)this.rows.get(j);
      int n = localRowData.getColCount();
      Object localObject;
      for (int m = 0; m < n; m++)
      {
        localObject = (ICellHandle)localRowData.getCells().get(m);
        if (localObject == null)
        {
          CellData localCellData = CellData.makeEmptyCell();
          localCellData.setRow(localRowData);
          localCellData.setIndex(m + 1);
          localRowData.setCellAt(localCellData);
        }
      }
      for (m = n; m < i; m++)
      {
        localObject = CellData.makeEmptyCell();
        ((CellData)localObject).setIndex(m + 1);
        localRowData.addCell((CellData)localObject);
      }
    }
  }
  
  public int getFullColumns()
  {
    return this.model.getFullColumns();
  }
  
  public int getFullRows()
  {
    return this.model.getFullRows();
  }
  
  public Table getModel()
  {
    return this.model;
  }
  
  public void setModel(Table paramTable)
  {
    this.model = paramTable;
  }
  
  public String getSheetName()
  {
    return this.sheet == null ? null : this.sheet.getModel().getWorksheetName();
  }
  
  public void addRow(RowData paramRowData)
  {
    paramRowData.setTable(this);
    this.rows.add(paramRowData);
  }
  
  public RowData makeRow(int paramInt)
  {
    if (paramInt < 0) {
      throw Exceptions.code("excel.CAN_err_invalid_row_count");
    }
    for (int i = this.rows.size(); i <= paramInt; i++)
    {
      RowData localRowData = new RowData(null, this);
      localRowData.setIndex(i + 1);
      this.rows.add(localRowData);
    }
    return (RowData)this.rows.get(paramInt);
  }
  
  public void addCell(int paramInt1, int paramInt2, IBasicCellModel paramIBasicCellModel)
  {
    RowData localRowData = makeRow(paramInt1);
    localRowData.safeSetCell(paramInt2, (ICellHandle)paramIBasicCellModel);
  }
  
  public ICellHandle getCell(int paramInt1, int paramInt2)
  {
    if ((paramInt1 < 0) || (paramInt1 >= this.rows.size())) {
      return null;
    }
    return (ICellHandle)((RowData)this.rows.get(paramInt1)).getCell(paramInt2);
  }
  
  public CellData getRealCell(int paramInt1, int paramInt2)
  {
    ICellHandle localICellHandle = getCell(paramInt1, paramInt2);
    return localICellHandle == null ? null : localICellHandle.getRealCell();
  }
  
  public List<Range> collectMergeRanges()
  {
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < this.rows.size(); i++)
    {
      RowData localRowData = (RowData)this.rows.get(i);
      List localList = localRowData.getCells();
      for (int j = 0; j < localList.size(); j++)
      {
        ICellHandle localICellHandle = (ICellHandle)localList.get(j);
        if (!localICellHandle.isIgnored())
        {
          CellData localCellData = localICellHandle.getRealCell();
          if ((localCellData.getMergeAcross() > 0) || (localCellData.getMergeDown() > 0))
          {
            Range localRange = new Range(getSheetName(), localCellData.getRowPos(), localCellData.getColPos(), localCellData.getEndRowPos(), localCellData.getEndColPos());
            localArrayList.add(localRange);
            j += localCellData.getMergeAcross();
          }
        }
      }
    }
    return localArrayList;
  }
  
  public void merge(Range paramRange)
  {
    merge(paramRange.getLtRow(), paramRange.getLtCol(), paramRange.getRbRow(), paramRange.getRbCol());
  }
  
  public void merge(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    CellData localCellData = getRealCell(paramInt1, paramInt2);
    if (localCellData == null) {
      throw Exceptions.code("excel.CAN_err_invalid_cell_pos").param(paramInt1).param(paramInt2).param(getSheetName());
    }
    paramInt3 = Math.min(paramInt3, getRowCount() - 1);
    paramInt4 = Math.min(paramInt4, getColCount() - 1);
    int i = paramInt3 - localCellData.getEndRowPos();
    int j = paramInt4 - localCellData.getEndColPos();
    if ((i <= 0) && (j <= 0)) {
      return;
    }
    localCellData.incColspan(j);
    localCellData.incRowspan(i);
    for (int k = paramInt1; k <= paramInt3; k++) {
      for (int m = paramInt2; m <= paramInt4; m++)
      {
        ICellHandle localICellHandle = getCell(k, m);
        if (localICellHandle == null) {
          throw Exceptions.code("excel.CAN_err_invalid_cell_pos").param(k).param(m).param(getSheetName());
        }
        if (localICellHandle.getRealCell() != localCellData) {
          _setIgnoreCell(k, m, localCellData);
        }
      }
    }
  }
  
  void _setIgnoreCell(int paramInt1, int paramInt2, CellData paramCellData)
  {
    IgnoreCellHandle localIgnoreCellHandle = new IgnoreCellHandle(paramCellData);
    RowData localRowData = (RowData)this.rows.get(paramInt1);
    localIgnoreCellHandle.setIndex(paramInt2 + 1);
    localIgnoreCellHandle.setRow(localRowData);
    localRowData.getCells().set(paramInt2 + 1, localIgnoreCellHandle);
  }
  
  public void extendRow(int paramInt)
  {
    RowData localRowData1 = (RowData)getRow(paramInt);
    RowData localRowData2 = new RowData(localRowData1.getModel(), this);
    List localList = ((RowData)getRow(paramInt)).getCells();
    int j = localList.size();
    for (int i = 0; i < j; i++)
    {
      ICellHandle localICellHandle = (ICellHandle)localList.get(i);
      CellData localCellData = localICellHandle.getRealCell();
      Object localObject;
      if (localICellHandle.isIgnored())
      {
        localCellData.incRowspan(1);
        localObject = new IgnoreCellHandle(localCellData);
        ((IgnoreCellHandle)localObject).setIndex(localICellHandle.getIndex());
        localRowData2.setCellAt((ICellHandle)localObject);
      }
      else
      {
        localObject = localCellData.copy();
        localRowData2.setCellAt((ICellHandle)localObject);
        ((CellData)localObject).setMergeDown(0);
        while (i < ((CellData)localObject).getIndex() - 1 + ((CellData)localObject).getMergeAcross())
        {
          IgnoreCellHandle localIgnoreCellHandle = new IgnoreCellHandle((CellData)localObject);
          localIgnoreCellHandle.setIndex(i + 1);
          localRowData2.setCellAt(localIgnoreCellHandle);
          i++;
        }
      }
    }
    this.rows.add(paramInt + 1, localRowData2);
    for (i = paramInt + 1; i < this.rows.size(); i++) {
      ((RowData)this.rows.get(i)).setIndex(i + 1);
    }
  }
  
  public void removeRow(int paramInt, boolean paramBoolean)
  {
    Iterator localIterator = ((RowData)getRow(paramInt)).getCells().iterator();
    while (localIterator.hasNext())
    {
      ICellHandle localICellHandle = (ICellHandle)localIterator.next();
      if (localICellHandle.isIgnored())
      {
        localICellHandle.getRealCell().incRowspan(-1);
      }
      else
      {
        CellData localCellData = localICellHandle.getRealCell();
        if (localCellData.getMergeDown() > 0) {
          if (paramBoolean)
          {
            localCellData.incRowspan(-1);
            localCellData.setRow(null);
            ((RowData)getRow(paramInt + 1)).setCellAt(localCellData);
          }
          else
          {
            for (int i = 0; i < localCellData.getMergeDown(); i++)
            {
              RowData localRowData = (RowData)getRow(paramInt + i);
              for (int j = 0; j < localCellData.getColspan(); j++)
              {
                EmptyCellData localEmptyCellData = new EmptyCellData();
                localEmptyCellData.setModel(localCellData.getModel());
                localEmptyCellData.setIndex(j + localCellData.getIndex());
                localEmptyCellData.setRow(localRowData);
                localRowData.setCellAt(localEmptyCellData);
              }
            }
          }
        }
      }
    }
    getRows().remove(paramInt);
    while (paramInt < this.rows.size())
    {
      ((RowData)this.rows.get(paramInt)).setIndex(paramInt + 1);
      paramInt++;
    }
  }
  
  public void removeCol(int paramInt, boolean paramBoolean)
  {
    int j = getRowCount();
    for (int i = 0; i < j; i++)
    {
      RowData localRowData1 = (RowData)getRow(i);
      ICellHandle localICellHandle1 = (ICellHandle)localRowData1.getCell(paramInt);
      if (localICellHandle1.isIgnored())
      {
        localICellHandle1.getRealCell().incColspan(-1);
      }
      else
      {
        CellData localCellData = localICellHandle1.getRealCell();
        if (localCellData.getMergeAcross() > 0) {
          if (paramBoolean)
          {
            localCellData.incColspan(-1);
            localCellData.setIndex(localCellData.getIndex() + 1);
            localCellData.setRow(null);
            localRowData1.setCellAt(localCellData);
          }
          else
          {
            for (int n = 0; n < localCellData.getMergeAcross(); n++) {
              for (int i1 = 0; i1 < localCellData.getRowspan(); i1++)
              {
                RowData localRowData2 = (RowData)getRow(i + i1);
                EmptyCellData localEmptyCellData = new EmptyCellData();
                localEmptyCellData.setModel(localCellData.getModel());
                localEmptyCellData.setIndex(paramInt + n);
                localEmptyCellData.setRow(localRowData2);
                localRowData2.setCellAt(localEmptyCellData);
              }
            }
          }
        }
      }
      localRowData1.getCells().remove(paramInt);
      for (int m = paramInt; m < localRowData1.getCells().size(); m++)
      {
        ICellHandle localICellHandle2 = (ICellHandle)localRowData1.getCells().get(m);
        if (!localICellHandle2.isIgnored()) {
          localICellHandle2.setIndex(m + 1);
        }
      }
    }
    getCols().remove(paramInt);
    for (int k = paramInt; k < this.cols.size(); k++) {
      ((Column)this.cols.get(k)).setIndex(k + 1);
    }
  }
  
  public void resetIndex()
  {
    int j = getRowCount();
    for (int i = 0; i < j; i++)
    {
      RowData localRowData = (RowData)this.rows.get(i);
      localRowData.setIndex(i + 1);
      int m = localRowData.getColCount();
      for (int k = 0; k < m; k++)
      {
        ICellHandle localICellHandle = (ICellHandle)localRowData.getCell(k);
        localICellHandle.setIndex(k + 1);
      }
    }
  }
  
  public void mergeTableData(TableData paramTableData)
  {
    if (paramTableData == null) {
      return;
    }
    int i = getRowCount();
    int k = paramTableData.getRowCount();
    for (int j = 0; j < k; j++)
    {
      RowData localRowData = (RowData)paramTableData.getRow(j);
      localRowData.setIndex(localRowData.getIndex() + i);
      addRow(localRowData);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\data\TableData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */