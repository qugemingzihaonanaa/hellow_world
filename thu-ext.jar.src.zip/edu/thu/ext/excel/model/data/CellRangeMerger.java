package edu.thu.ext.excel.model.data;

import edu.thu.ext.excel.model.CellRange;
import java.util.List;

public class CellRangeMerger
{
  public List<CellRange> merge(CellData[] paramArrayOfCellData)
  {
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\data\CellRangeMerger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */