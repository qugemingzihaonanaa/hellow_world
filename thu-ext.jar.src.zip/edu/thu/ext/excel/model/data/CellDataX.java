package edu.thu.ext.excel.model.data;

import edu.thu.ext.excel.model.Cell;
import edu.thu.ext.excel.model.RichData;
import edu.thu.ext.excel.model.Style;
import java.util.Map;

public class CellDataX
  implements ICellHandle, Comparable<ICellHandle>
{
  int index;
  int mergeAcross;
  int mergeDown;
  Style style;
  Cell model;
  Object value;
  Object expandObj;
  int expandIndex = -1;
  Object object;
  CellDataX left;
  CellDataX right;
  CellDataX up;
  CellDataX down;
  CellDataX verParent;
  CellDataX horParent;
  RowData row;
  
  public int getIndex()
  {
    return 0;
  }
  
  public CellData getRealCell()
  {
    return null;
  }
  
  public RowData getRow()
  {
    return null;
  }
  
  public boolean isIgnored()
  {
    return false;
  }
  
  public void setIndex(int paramInt) {}
  
  public void setRow(RowData paramRowData) {}
  
  public String getComment()
  {
    return null;
  }
  
  public String getData()
  {
    return null;
  }
  
  public String getDataType()
  {
    return null;
  }
  
  public Object getFormatedValue(Map<String, Object> paramMap)
  {
    return null;
  }
  
  public String getFormula()
  {
    return null;
  }
  
  public String getKey()
  {
    return null;
  }
  
  public int getMergeAcross()
  {
    return 0;
  }
  
  public int getMergeDown()
  {
    return 0;
  }
  
  public Object getO()
  {
    return null;
  }
  
  public RichData getRichData()
  {
    return null;
  }
  
  public Style getStyle()
  {
    return null;
  }
  
  public String getStyleID()
  {
    return null;
  }
  
  public String getUid()
  {
    return null;
  }
  
  public Object getValue()
  {
    return null;
  }
  
  public boolean isBlank()
  {
    return false;
  }
  
  public boolean isNumberCell()
  {
    return false;
  }
  
  public boolean isStaticCell()
  {
    return false;
  }
  
  public int getRowIndex()
  {
    if (this.row == null) {
      return 0;
    }
    return this.row.getIndex();
  }
  
  public int compareTo(ICellHandle paramICellHandle)
  {
    int i = getRowIndex();
    int j = paramICellHandle.getRow() == null ? 0 : paramICellHandle.getRow().getIndex();
    if (i != j) {
      return i < j ? -1 : 1;
    }
    int k = getIndex();
    int m = paramICellHandle.getIndex();
    return k < m ? -1 : k == m ? 0 : 1;
  }
  
  public void evaluatePrepareRow(Map<String, Object> paramMap) {}
  
  public boolean maybeNumberCell()
  {
    return false;
  }
  
  public int getColPos()
  {
    return 0;
  }
  
  public int getRowPos()
  {
    return 0;
  }
  
  public int getRowspan()
  {
    return 0;
  }
  
  public int getColspan()
  {
    return 0;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\data\CellDataX.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */