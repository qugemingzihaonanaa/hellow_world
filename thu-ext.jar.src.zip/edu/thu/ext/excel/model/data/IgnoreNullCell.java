package edu.thu.ext.excel.model.data;

import edu.thu.ext.excel.model.RichData;
import edu.thu.ext.excel.model.Style;
import java.util.Map;

public class IgnoreNullCell
  implements ICellHandle
{
  static final IgnoreNullCell INSTANCE = new IgnoreNullCell();
  
  public String getComment()
  {
    return null;
  }
  
  public String getData()
  {
    return null;
  }
  
  public RichData getRichData()
  {
    return null;
  }
  
  public Object getValue()
  {
    return null;
  }
  
  public Object getFormatedValue(Map<String, Object> paramMap)
  {
    return null;
  }
  
  public void evaluatePrepareRow(Map<String, Object> paramMap) {}
  
  public Object getO()
  {
    return null;
  }
  
  public String getKey()
  {
    return null;
  }
  
  public int getMergeAcross()
  {
    return 0;
  }
  
  public int getMergeDown()
  {
    return 0;
  }
  
  public String getFormula()
  {
    return null;
  }
  
  public String getDataType()
  {
    return null;
  }
  
  public String getStyleID()
  {
    return null;
  }
  
  public String getUid()
  {
    return null;
  }
  
  public Style getStyle()
  {
    return null;
  }
  
  public boolean isNumberCell()
  {
    return false;
  }
  
  public boolean maybeNumberCell()
  {
    return false;
  }
  
  public boolean isStaticCell()
  {
    return true;
  }
  
  public boolean isBlank()
  {
    return true;
  }
  
  public int getIndex()
  {
    return 0;
  }
  
  public void setIndex(int paramInt) {}
  
  public RowData getRow()
  {
    return null;
  }
  
  public void setRow(RowData paramRowData) {}
  
  public CellData getRealCell()
  {
    return null;
  }
  
  public boolean isIgnored()
  {
    return true;
  }
  
  public int getColPos()
  {
    return 0;
  }
  
  public int getRowPos()
  {
    return 0;
  }
  
  public int getRowspan()
  {
    return 1;
  }
  
  public int getColspan()
  {
    return 1;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\data\IgnoreNullCell.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */