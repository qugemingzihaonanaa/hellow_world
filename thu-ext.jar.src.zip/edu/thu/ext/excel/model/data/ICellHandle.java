package edu.thu.ext.excel.model.data;

import edu.thu.ext.excel.model.ICell;

public abstract interface ICellHandle
  extends ICell
{
  public abstract int getIndex();
  
  public abstract void setIndex(int paramInt);
  
  public abstract RowData getRow();
  
  public abstract void setRow(RowData paramRowData);
  
  public abstract CellData getRealCell();
  
  public abstract boolean isIgnored();
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\data\ICellHandle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */