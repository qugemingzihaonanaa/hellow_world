package edu.thu.ext.excel.model.data;

import edu.thu.ext.excel.model.AbstractWorkbook;
import edu.thu.ext.excel.model.CustomDocumentProperties;
import edu.thu.ext.excel.model.DocumentProperties;
import edu.thu.ext.excel.model.ExcelModelUtils;
import edu.thu.ext.excel.model.IWorkbook;
import edu.thu.ext.excel.model.IWorksheet;
import edu.thu.ext.excel.model.Names;
import edu.thu.ext.excel.model.RowBlock;
import edu.thu.ext.excel.model.Style;
import edu.thu.ext.excel.model.Workbook;
import edu.thu.ext.excel.model.WxReportConfig;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class WorkbookData
  extends AbstractWorkbook<WorksheetData>
{
  private static final long serialVersionUID = -5279680022658972331L;
  Workbook B;
  DocumentProperties A;
  CustomDocumentProperties C;
  Names D;
  
  public WorkbookData() {}
  
  public WorkbookData(Workbook paramWorkbook)
  {
    this.B = paramWorkbook;
  }
  
  public Workbook getModel()
  {
    return this.B;
  }
  
  public WxReportConfig getWxReportConfig()
  {
    return this.B.getWxReportConfig();
  }
  
  public Collection<Style> getStyles()
  {
    return this.B.getStyles();
  }
  
  public Names getNames()
  {
    return this.D;
  }
  
  public CustomDocumentProperties getCustomDocumentProperties()
  {
    return this.C;
  }
  
  public DocumentProperties getDocumentProperties()
  {
    return this.A;
  }
  
  public void setDocumentProperties(DocumentProperties paramDocumentProperties)
  {
    this.A = paramDocumentProperties;
  }
  
  public void setCustomDocumentProperties(CustomDocumentProperties paramCustomDocumentProperties)
  {
    this.C = paramCustomDocumentProperties;
  }
  
  public void setNames(Names paramNames)
  {
    this.D = paramNames;
  }
  
  public void setModel(Workbook paramWorkbook)
  {
    this.B = paramWorkbook;
  }
  
  public List<RowBlock> getUpRowBlocks(WorksheetData paramWorksheetData, int paramInt)
  {
    return ExcelModelUtils.getUpRowBlocks(getRowBlocks(paramWorksheetData), paramInt);
  }
  
  public List<RowBlock> getDownRowBlocks(WorksheetData paramWorksheetData, int paramInt)
  {
    return ExcelModelUtils.getDownRowBlocks(getRowBlocks(paramWorksheetData), paramInt);
  }
  
  public List<RowBlock> getRowBlocks(WorksheetData paramWorksheetData)
  {
    if (paramWorksheetData == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(1);
    RowBlock localRowBlock = new RowBlock("simple", 0, paramWorksheetData.getRowCount() - 1);
    localArrayList.add(localRowBlock);
    return localArrayList;
  }
  
  public Style getStyle(String paramString)
  {
    return this.B.getStyle(paramString);
  }
  
  public Style getCellStyle(CellData paramCellData)
  {
    if (paramCellData == null) {
      return null;
    }
    return getStyle(paramCellData.getStyleID());
  }
  
  public Style getCellStyleWithDefault(CellData paramCellData)
  {
    Style localStyle = getCellStyle(paramCellData);
    if (localStyle == null) {
      localStyle = Style.EMPTY_STYLE;
    }
    return localStyle;
  }
  
  public void addSheetWithUniqueName(WorksheetData paramWorksheetData)
  {
    String str = getNewSheetName(paramWorksheetData.getWorksheetName());
    paramWorksheetData.setWorksheetName(str);
    addSheet(paramWorksheetData);
  }
  
  public String getUnusedStylePrefix()
  {
    return this.B.getUnusedStylePrefix();
  }
  
  public IWorkbook prepareForMerge()
  {
    this.B = this.B.copy();
    return this;
  }
  
  public void importWorkbook(IWorkbook paramIWorkbook)
  {
    WorkbookData localWorkbookData = (WorkbookData)paramIWorkbook;
    String str = getUnusedStylePrefix();
    Iterator localIterator = localWorkbookData.getWorksheets().iterator();
    while (localIterator.hasNext())
    {
      WorksheetData localWorksheetData = (WorksheetData)localIterator.next();
      importSheet(localWorksheetData, getNewSheetName(localWorksheetData.getWorksheetName()), str);
    }
  }
  
  public WorksheetData importSheet(IWorksheet paramIWorksheet, String paramString1, String paramString2)
  {
    WorksheetData localWorksheetData = (WorksheetData)paramIWorksheet;
    localWorksheetData.setWorkbook(this);
    localWorksheetData.setWorksheetName(paramString1);
    Iterator localIterator1 = localWorksheetData.getRows().iterator();
    while (localIterator1.hasNext())
    {
      RowData localRowData = (RowData)localIterator1.next();
      Iterator localIterator2 = localRowData.getCells().iterator();
      while (localIterator2.hasNext())
      {
        ICellHandle localICellHandle = (ICellHandle)localIterator2.next();
        if (!localICellHandle.isIgnored())
        {
          Style localStyle1 = localICellHandle.getStyle();
          String str = paramString2 + (localStyle1 == null ? "Default" : localStyle1.getId());
          if (localStyle1 != null)
          {
            Style localStyle2 = this.B.getStyle(str);
            if (localStyle2 == null)
            {
              localStyle2 = localStyle1.copy();
              localStyle2.setName(null);
              localStyle2.setId(str);
              this.B.addStyle(localStyle2);
            }
            ((CellData)localICellHandle).setStyle(localStyle2);
          }
        }
      }
    }
    this.sheets.add(localWorksheetData);
    return localWorksheetData;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\data\WorkbookData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */