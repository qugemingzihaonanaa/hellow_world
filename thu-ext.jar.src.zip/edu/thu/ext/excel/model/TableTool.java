package edu.thu.ext.excel.model;

public class TableTool<T>
{
  public void removeCol(T paramT, int paramInt) {}
  
  public void removeRow(T paramT, int paramInt) {}
  
  public void expandCol(T paramT, int paramInt1, int paramInt2, int paramInt3) {}
  
  public void expandRow(T paramT, int paramInt1, int paramInt2, int paramInt3) {}
  
  public static void main(String[] paramArrayOfString) {}
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\TableTool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */