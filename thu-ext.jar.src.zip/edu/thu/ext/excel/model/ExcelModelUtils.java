package edu.thu.ext.excel.model;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IVariant;
import edu.thu.lang.Variant;
import edu.thu.lang.exceptions.StdException;
import edu.thu.model.tree.TreeNode;
import edu.thu.text.MapVarParser;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class ExcelModelUtils
{
  static MapVarParser D = new MapVarParser(false, false);
  String C = "__";
  String B = "Worksheet";
  String A = "Styles";
  
  public static String getCellValue(TreeNode paramTreeNode)
  {
    TreeNode localTreeNode = paramTreeNode.existingChild("Data");
    if (localTreeNode == null) {
      localTreeNode = paramTreeNode.makeChild("ss:Data");
    }
    return localTreeNode == null ? null : localTreeNode.innerText();
  }
  
  public static List<Object> getCellValues(TreeNode paramTreeNode)
  {
    ArrayList localArrayList = new ArrayList();
    int j = paramTreeNode.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(i);
      int k = localTreeNode.attribute("ss:Index").intValue(0);
      if ((k < 0) || (k > 1000)) {
        throw Exceptions.code("excel.CAN_err_invalid_cell_index").param(k).param(localTreeNode);
      }
      String str = getCellValue(localTreeNode);
      if (k == 0)
      {
        localArrayList.add(str);
      }
      else
      {
        for (int m = localArrayList.size(); m < k; m++) {
          localArrayList.add(null);
        }
        localArrayList.set(k - 1, str);
      }
    }
    return localArrayList;
  }
  
  public static TreeNode getSheetNode(TreeNode paramTreeNode, String paramString, boolean paramBoolean)
  {
    int j = paramTreeNode.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(i);
      if ((localTreeNode.getName().equals("Worksheet")) && (paramString.equals(localTreeNode.getAttribute("ss:Name")))) {
        return localTreeNode;
      }
    }
    if (paramBoolean) {
      throw Exceptions.code("excel.CAN_err_unknown_sheet").param(paramString);
    }
    return null;
  }
  
  public static TreeNode getSheetNode(TreeNode paramTreeNode, String paramString)
  {
    return getSheetNode(paramTreeNode, paramString, true);
  }
  
  public static void addParent(TreeNode paramTreeNode1, TreeNode paramTreeNode2)
  {
    TreeNode localTreeNode = paramTreeNode1.getParent();
    paramTreeNode1.setParent(null);
    paramTreeNode2.appendChild(paramTreeNode1);
    localTreeNode.replaceChild(paramTreeNode1, paramTreeNode2);
  }
  
  public static void wrapChildren(TreeNode paramTreeNode1, TreeNode paramTreeNode2, int paramInt1, int paramInt2)
  {
    int j = paramInt2 - paramInt1;
    for (int i = 0; i < j; i++)
    {
      if (paramInt1 >= paramTreeNode1.getChildCount()) {
        break;
      }
      TreeNode localTreeNode = paramTreeNode1.getChild(paramInt1);
      paramTreeNode1.removeChild(localTreeNode);
      localTreeNode.setParent(null);
      paramTreeNode2.appendChild(localTreeNode);
    }
    if (paramInt1 >= paramTreeNode1.getChildCount()) {
      paramTreeNode1.appendChild(paramTreeNode2);
    } else {
      paramTreeNode1.insertChild(paramInt1, paramTreeNode2);
    }
  }
  
  public static int getRowIdx(TreeNode paramTreeNode)
  {
    int j = paramTreeNode.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(i);
      if (localTreeNode.getName().equals("Row")) {
        return i;
      }
    }
    return -1;
  }
  
  public static int getRowCount(TreeNode paramTreeNode)
  {
    int i = 0;
    int k = paramTreeNode.getChildCount();
    for (int j = 0; j < k; j++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(j);
      if (localTreeNode.getName().equals("Row")) {
        i++;
      } else if (localTreeNode.getName().startsWith("ns1:")) {
        i += localTreeNode.getChildCount();
      }
    }
    return i;
  }
  
  public static void wrapRows(TreeNode paramTreeNode1, TreeNode paramTreeNode2)
  {
    int i = getRowIdx(paramTreeNode1);
    if (i < 0) {
      return;
    }
    wrapChildren(paramTreeNode1, paramTreeNode2, i, paramTreeNode1.getChildCount());
  }
  
  public static void fix(TreeNode paramTreeNode)
  {
    D(paramTreeNode);
    C(paramTreeNode);
  }
  
  static void D(TreeNode paramTreeNode)
  {
    int j = paramTreeNode.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode1 = paramTreeNode.getChild(i);
      if (localTreeNode1.getName().equals("Worksheet"))
      {
        TreeNode localTreeNode2 = localTreeNode1.makeChild("Table");
        localTreeNode2.setAttribute("ss:ExpandedRowCount", Integer.valueOf(65536));
      }
    }
  }
  
  static void C(TreeNode paramTreeNode)
  {
    int j = paramTreeNode.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode1 = paramTreeNode.getChild(i);
      if (localTreeNode1.getName().equals("Worksheet"))
      {
        TreeNode localTreeNode2 = localTreeNode1.makeChild("Table");
        fixRowSpan(localTreeNode2);
      }
    }
  }
  
  public static void fixRowSpan(TreeNode paramTreeNode)
  {
    int j = paramTreeNode.getChildCount();
    if (j > 500000) {
      throw Exceptions.code("excel.CAN_err_table_too_many_rows").param(paramTreeNode).param(j);
    }
    int k = getRowIdx(paramTreeNode);
    if (k < 0) {
      return;
    }
    for (int i = k; i < j; i++)
    {
      TreeNode localTreeNode1 = paramTreeNode.getChild(i);
      localTreeNode1.removeAttribute("ss:Span");
      int m = localTreeNode1.attribute("ss:Index").intValue(-1);
      if (m > i - k + 1) {
        for (int n = 0; n < m - i + k - 1; n++)
        {
          TreeNode localTreeNode2 = TreeNode.make("Row");
          int i1 = i;
          if (i1 < 0) {
            i1 = 0;
          }
          paramTreeNode.insertChild(i1, localTreeNode2);
        }
      }
      localTreeNode1.removeAttribute("ss:Index");
    }
  }
  
  public static void addRowBreak(TreeNode paramTreeNode1, TreeNode paramTreeNode2)
  {
    paramTreeNode1.makeChild("PageBreaks").setAttribute("xmlns", "urn:schemas-microsoft-com:office:excel");
    paramTreeNode1.makeChild("PageBreaks").makeChild("RowBreaks").appendChild(paramTreeNode2);
  }
  
  public static Map<String, Object> parseComment(TreeNode paramTreeNode)
  {
    String str = getCommentStr(paramTreeNode);
    if (str == null) {
      return null;
    }
    return D.parseText(str);
  }
  
  public static Map<String, Object> parseCommentStr(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    return D.parseText(paramString);
  }
  
  public static String buildComment(Map<String, Object> paramMap)
  {
    if ((paramMap == null) || (paramMap.isEmpty())) {
      return null;
    }
    return D.unparseMap(paramMap);
  }
  
  public static String getCommentStr(TreeNode paramTreeNode)
  {
    if (paramTreeNode == null) {
      return null;
    }
    TreeNode localTreeNode1 = paramTreeNode.existingChild("Comment");
    if (localTreeNode1 == null) {
      return null;
    }
    TreeNode localTreeNode2 = localTreeNode1.existingChild("ss:Data");
    if (localTreeNode2 == null) {
      localTreeNode2 = localTreeNode1.existingChild("Data");
    }
    String str = localTreeNode2 == null ? null : localTreeNode2.innerText();
    return str;
  }
  
  public static void fixByComment(TreeNode paramTreeNode)
  {
    int j = paramTreeNode.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode1 = paramTreeNode.getChild(i);
      if (localTreeNode1.getName().equals("Worksheet"))
      {
        TreeNode localTreeNode2 = localTreeNode1.makeChild("Table");
        int k = getRowIdx(localTreeNode2);
        if (k < 0) {}
        while (k < localTreeNode2.getChildCount())
        {
          TreeNode localTreeNode3 = localTreeNode2.getChild(k);
          for (int m = 0; m < localTreeNode3.getChildCount(); m++)
          {
            TreeNode localTreeNode4 = localTreeNode3.getChild(m);
            Map localMap = parseComment(localTreeNode4);
            if ((localMap != null) && (localMap.containsKey("valueExpr")))
            {
              String str1 = (String)localMap.get("valueExpr");
              String str2 = "${" + str1 + "}";
              TreeNode localTreeNode5 = localTreeNode4.makeChild("Data");
              if (localTreeNode5.getAttribute("ss:Type") == null) {
                localTreeNode5.setAttribute("ss:Type", "String");
              }
              localTreeNode4.removeChildByTagName("ss:Data");
              localTreeNode5.setValue(str2);
              localTreeNode5.clearChildren();
            }
            localTreeNode4.removeChild(localTreeNode4.existingChild("Comment"));
          }
          k++;
        }
      }
    }
  }
  
  public static void wrapSheet(TreeNode paramTreeNode)
  {
    ArrayList localArrayList = new ArrayList();
    int j = paramTreeNode.getChildCount();
    for (int i = 0; i < j; i++)
    {
      localTreeNode1 = paramTreeNode.getChild(i);
      TreeNode localTreeNode2 = null;
      if (localTreeNode1.getName().startsWith("ns1:Wrap")) {
        localTreeNode2 = localTreeNode1.makeChild("Worksheet");
      } else if (localTreeNode1.getName().equals("Worksheet")) {
        localTreeNode2 = localTreeNode1;
      }
      if (localTreeNode2 != null)
      {
        String str = (String)localTreeNode2.getAttribute("ss:Name");
        str = str + "${iif(isnull(__mutli_vt),null,concat('-',__mutli_vt.count))}";
        localTreeNode2.setAttribute("ss:Name", str);
        localTreeNode1.setParent(null);
        localArrayList.add(localTreeNode1);
        paramTreeNode.removeChildByIndex(i);
        i--;
        j--;
      }
    }
    TreeNode localTreeNode1 = TreeNode.make("ns1:WrapSheets");
    localTreeNode1.appendChildren(localArrayList);
    paramTreeNode.appendChild(localTreeNode1);
  }
  
  public static void removeNamedRange(TreeNode paramTreeNode)
  {
    TreeNode localTreeNode = paramTreeNode.existingChild("Names");
    if (localTreeNode == null) {
      return;
    }
    paramTreeNode.removeChild(localTreeNode);
    B(paramTreeNode);
  }
  
  static void B(TreeNode paramTreeNode)
  {
    int j = paramTreeNode.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(i);
      if (localTreeNode.getName().equals("NamedCell"))
      {
        paramTreeNode.removeChild(localTreeNode);
        i--;
        j--;
      }
      else
      {
        B(localTreeNode);
      }
    }
  }
  
  int A(TreeNode paramTreeNode)
  {
    List localList = paramTreeNode.makeChild("Styles").children();
    int i = 0;
    int j = 0;
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      TreeNode localTreeNode = (TreeNode)localIterator.next();
      String str1 = localTreeNode.attribute("ss:ID").stringValue("");
      int k = str1.indexOf(this.C);
      if (k >= 0)
      {
        String str2 = str1.substring(k + this.C.length());
        j = Variant.valueOf(str2).intValue(0);
        if (i < j) {
          i = j;
        }
      }
    }
    return i;
  }
  
  List<TreeNode> E(TreeNode paramTreeNode)
  {
    List localList = paramTreeNode.children();
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      TreeNode localTreeNode = (TreeNode)localIterator.next();
      if (this.B.equals(localTreeNode.getName())) {
        localArrayList.add(localTreeNode);
      }
    }
    return localArrayList;
  }
  
  public void changeExcelNodeStyleId(TreeNode paramTreeNode, String paramString)
  {
    List localList = paramTreeNode.children();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      TreeNode localTreeNode = (TreeNode)localIterator.next();
      if (localTreeNode.hasAttribute("ss:StyleID"))
      {
        String str = localTreeNode.attribute("ss:StyleID").stringValue();
        str = str + paramString;
        localTreeNode.setAttribute("ss:StyleID", str);
      }
      changeExcelNodeStyleId(localTreeNode, paramString);
    }
  }
  
  public void renameExcelStyleId(TreeNode paramTreeNode, int paramInt)
  {
    String str1 = this.C + paramInt;
    TreeNode localTreeNode = paramTreeNode.makeChild(this.A);
    List localList = localTreeNode.children();
    Object localObject2 = localList.iterator();
    while (((Iterator)localObject2).hasNext())
    {
      localObject1 = (TreeNode)((Iterator)localObject2).next();
      if (((TreeNode)localObject1).hasAttribute("ss:ID"))
      {
        localObject3 = ((TreeNode)localObject1).attribute("ss:ID").stringValue("");
        localObject3 = localObject3 + str1;
        ((TreeNode)localObject1).setAttribute("ss:ID", localObject3);
        String str2;
        if (((TreeNode)localObject1).hasAttribute("ss:Name"))
        {
          str2 = ((TreeNode)localObject1).attribute("ss:Name").stringValue("");
          ((TreeNode)localObject1).setAttribute("ss:Name", str2 + str1);
        }
        if (((TreeNode)localObject1).hasAttribute("ss:Parent"))
        {
          str2 = ((TreeNode)localObject1).attribute("ss:Parent").stringValue("");
          ((TreeNode)localObject1).setAttribute("ss:Parent", str2 + str1);
        }
      }
    }
    Object localObject1 = paramTreeNode.children();
    Object localObject3 = ((List)localObject1).iterator();
    while (((Iterator)localObject3).hasNext())
    {
      localObject2 = (TreeNode)((Iterator)localObject3).next();
      if (this.B.equals(((TreeNode)localObject2).getName())) {
        changeExcelNodeStyleId((TreeNode)localObject2, str1);
      }
    }
  }
  
  public List splitLastBracket(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    String str = paramString;
    int i = 0;
    int j = paramString.lastIndexOf("(");
    int k = paramString.lastIndexOf(")");
    if ((j > 0) && (j < k))
    {
      i = Variant.valueOf(paramString.substring(j + 1, k)).intValue(0);
      if ((i > 0) || ((i == 0) && ("0".equals(paramString.substring(j + 1, k)))))
      {
        str = paramString.substring(0, j);
        str = str.trim();
      }
    }
    localArrayList.add(str);
    localArrayList.add(new Integer(i));
    return localArrayList;
  }
  
  public Map<String, Integer> findAllSheetName(TreeNode paramTreeNode)
  {
    HashMap localHashMap = new HashMap();
    List localList1 = paramTreeNode.children();
    Iterator localIterator = localList1.iterator();
    while (localIterator.hasNext())
    {
      TreeNode localTreeNode = (TreeNode)localIterator.next();
      if (this.B.equals(localTreeNode.getName()))
      {
        String str1 = localTreeNode.attribute("ss:Name").stringValue("");
        List localList2 = splitLastBracket(str1);
        String str2 = (String)localList2.get(0);
        int i = Variant.valueOf(localList2.get(1)).intValue(0);
        int j = 0;
        if (localHashMap.containsKey(str2))
        {
          j = Variant.valueOf(localHashMap.get(str2)).intValue(0);
          if (i > j)
          {
            localHashMap.remove(str2);
            localHashMap.put(str2, new Integer(i));
          }
        }
        else
        {
          localHashMap.put(str2, new Integer(i));
        }
      }
    }
    return localHashMap;
  }
  
  public void renameSheetNames(TreeNode paramTreeNode1, TreeNode paramTreeNode2)
  {
    Map localMap = findAllSheetName(paramTreeNode1);
    List localList = paramTreeNode2.children();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      TreeNode localTreeNode = (TreeNode)localIterator.next();
      if (this.B.equals(localTreeNode.getName()))
      {
        String str1 = localTreeNode.attribute("ss:Name").stringValue("");
        String str2 = (String)splitLastBracket(str1).get(0);
        if (localMap.containsKey(str2))
        {
          int i = Variant.valueOf(localMap.get(str2)).intValue(0) + 1;
          localMap.remove(str2);
          localMap.put(str2, new Integer(i));
          String str3 = str2 + " (" + i + ")";
          localTreeNode.setAttribute("ss:Name", str3);
        }
      }
    }
  }
  
  public void mergeSheet(TreeNode paramTreeNode1, TreeNode paramTreeNode2)
  {
    TreeNode localTreeNode1 = paramTreeNode1.makeChild(this.A);
    TreeNode localTreeNode2 = paramTreeNode2.makeChild(this.A);
    localTreeNode1.appendChildren(localTreeNode2.cloneChildren());
    List localList = E(paramTreeNode2);
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      TreeNode localTreeNode3 = (TreeNode)localIterator.next();
      paramTreeNode1.appendChild(localTreeNode3.cloneNode());
    }
  }
  
  public void mergeExcel(TreeNode paramTreeNode1, TreeNode paramTreeNode2)
  {
    int i = A(paramTreeNode1);
    renameExcelStyleId(paramTreeNode2, i + 1);
    renameSheetNames(paramTreeNode1, paramTreeNode2);
    mergeSheet(paramTreeNode1, paramTreeNode2);
  }
  
  public void mergeExcelFile(TreeNode paramTreeNode, File paramFile)
  {
    mergeExcel(paramTreeNode, loadFromFile(paramFile));
  }
  
  /* Error */
  public TreeNode loadFromFile(File paramFile)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aconst_null
    //   3: astore_3
    //   4: aconst_null
    //   5: astore 4
    //   7: new 536	java/io/FileInputStream
    //   10: dup
    //   11: aload_1
    //   12: invokespecial 538	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   15: astore_2
    //   16: new 541	java/io/InputStreamReader
    //   19: dup
    //   20: aload_2
    //   21: ldc_w 543
    //   24: invokespecial 545	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;Ljava/lang/String;)V
    //   27: astore_3
    //   28: invokestatic 548	edu/thu/xml/dom/DomToTree:getInstance	()Ledu/thu/xml/dom/DomToTree;
    //   31: iconst_1
    //   32: invokevirtual 554	edu/thu/xml/dom/DomToTree:allowText	(Z)Ledu/thu/xml/dom/DomToTree;
    //   35: aload_3
    //   36: invokevirtual 558	edu/thu/xml/dom/DomToTree:transform	(Ljava/io/Reader;)Ledu/thu/model/tree/TreeNode;
    //   39: astore 4
    //   41: goto +24 -> 65
    //   44: astore 5
    //   46: aload 5
    //   48: invokestatic 562	edu/thu/lang/exceptions/StdException:wrap	(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;
    //   51: athrow
    //   52: astore 6
    //   54: aload_3
    //   55: invokestatic 566	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/Reader;)V
    //   58: aload_2
    //   59: invokestatic 572	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/InputStream;)V
    //   62: aload 6
    //   64: athrow
    //   65: aload_3
    //   66: invokestatic 566	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/Reader;)V
    //   69: aload_2
    //   70: invokestatic 572	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/InputStream;)V
    //   73: aload 4
    //   75: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	76	0	this	ExcelModelUtils
    //   0	76	1	paramFile	File
    //   1	69	2	localFileInputStream	java.io.FileInputStream
    //   3	63	3	localInputStreamReader	java.io.InputStreamReader
    //   5	69	4	localTreeNode	TreeNode
    //   44	3	5	localException	Exception
    //   52	11	6	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   7	41	44	java/lang/Exception
    //   7	52	52	finally
  }
  
  /* Error */
  public void saveToFile(TreeNode paramTreeNode, File paramFile)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aconst_null
    //   3: astore 4
    //   5: new 592	java/io/FileOutputStream
    //   8: dup
    //   9: aload_2
    //   10: invokespecial 594	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   13: astore_3
    //   14: aload_1
    //   15: invokevirtual 595	edu/thu/model/tree/TreeNode:toXml	()Ljava/lang/String;
    //   18: astore 5
    //   20: new 598	java/io/OutputStreamWriter
    //   23: dup
    //   24: aload_3
    //   25: ldc_w 543
    //   28: invokespecial 600	java/io/OutputStreamWriter:<init>	(Ljava/io/OutputStream;Ljava/lang/String;)V
    //   31: astore 4
    //   33: aload 4
    //   35: ldc_w 603
    //   38: invokevirtual 605	java/io/Writer:write	(Ljava/lang/String;)V
    //   41: aload 4
    //   43: ldc_w 610
    //   46: invokevirtual 605	java/io/Writer:write	(Ljava/lang/String;)V
    //   49: aload 4
    //   51: aload 5
    //   53: invokevirtual 605	java/io/Writer:write	(Ljava/lang/String;)V
    //   56: aload 4
    //   58: invokevirtual 612	java/io/Writer:flush	()V
    //   61: goto +25 -> 86
    //   64: astore 5
    //   66: aload 5
    //   68: invokestatic 615	edu/thu/global/exceptions/Exceptions:source	(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;
    //   71: athrow
    //   72: astore 6
    //   74: aload 4
    //   76: invokestatic 618	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/Writer;)V
    //   79: aload_3
    //   80: invokestatic 621	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/OutputStream;)V
    //   83: aload 6
    //   85: athrow
    //   86: aload 4
    //   88: invokestatic 618	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/Writer;)V
    //   91: aload_3
    //   92: invokestatic 621	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/OutputStream;)V
    //   95: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	96	0	this	ExcelModelUtils
    //   0	96	1	paramTreeNode	TreeNode
    //   0	96	2	paramFile	File
    //   1	91	3	localFileOutputStream	java.io.FileOutputStream
    //   3	84	4	localOutputStreamWriter	java.io.OutputStreamWriter
    //   18	34	5	str	String
    //   64	3	5	localException	Exception
    //   72	12	6	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   5	61	64	java/lang/Exception
    //   5	72	72	finally
  }
  
  public static String encodeParamName(String paramString, boolean paramBoolean)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    int j = paramString.length();
    for (int i = 0; i < j; i++)
    {
      int k = paramString.charAt(i);
      if (k == 45)
      {
        k = 65293;
      }
      else if (k == 43)
      {
        k = 65291;
      }
      else
      {
        if ((k == 32) || (k == 12288) || (k == 9) || (k == 13) || (k == 10)) {
          continue;
        }
        if (k == 39) {
          k = 8216;
        } else if (k == 34) {
          k = 8220;
        } else if (k == 40) {
          k = 65288;
        } else if (k == 41) {
          k = 65289;
        } else if ((k == 46) && (paramBoolean)) {
          k = 65294;
        } else if (k == 186) {
          k = 176;
        }
      }
      localStringBuffer.append(k);
    }
    return localStringBuffer.toString();
  }
  
  public static List<RowBlock> getUpRowBlocks(List<RowBlock> paramList, int paramInt)
  {
    if (paramInt < 0) {
      return null;
    }
    if (paramList == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      RowBlock localRowBlock = (RowBlock)localIterator.next();
      if (localRowBlock.getLastRowNum() <= paramInt)
      {
        localArrayList.add(localRowBlock);
      }
      else
      {
        if (localRowBlock.getFirstRowNum() > paramInt) {
          break;
        }
        localArrayList.add(new RowBlock("simple", localRowBlock.getFirstRowNum(), paramInt));
      }
    }
    return localArrayList;
  }
  
  public static List<RowBlock> getDownRowBlocks(List<RowBlock> paramList, int paramInt)
  {
    if (paramList == null) {
      return null;
    }
    if (paramInt < 0) {
      return paramList;
    }
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      RowBlock localRowBlock = (RowBlock)localIterator.next();
      if (localRowBlock.getLastRowNum() <= paramInt)
      {
        localIterator.remove();
      }
      else
      {
        if (localRowBlock.getFirstRowNum() > paramInt) {
          break;
        }
        localRowBlock.setFirstRowNum(paramInt + 1);
        break;
      }
    }
    return paramList;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\ExcelModelUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */