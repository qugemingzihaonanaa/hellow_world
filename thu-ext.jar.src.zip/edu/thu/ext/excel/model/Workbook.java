package edu.thu.ext.excel.model;

import edu.thu.cache.ICacheable;
import edu.thu.core.AppEnv;
import edu.thu.ext.excel.WxReportRenderer;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.util.Coercions;
import edu.thu.math.alg.Alog;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class Workbook
  extends AbstractWorkbook<Worksheet>
  implements ICacheable
{
  private static final long serialVersionUID = -8945150465845404500L;
  FieldDefinitionList fieldDefinitions = new FieldDefinitionList();
  DocumentProperties documentProperties;
  CustomDocumentProperties customDocumentProperties = new CustomDocumentProperties();
  Map<String, Style> styles = new LinkedHashMap();
  Names names;
  WxReportConfig wxReportConfig = new WxReportConfig();
  transient Object xlsObj;
  Map<String, Object> tpls = new ConcurrentHashMap();
  long lastModified = AppEnv.currentTimeMillis();
  Object obj;
  boolean supportCache = true;
  String storePath;
  String virtualPath;
  boolean needExpand;
  
  public Workbook copy()
  {
    Workbook localWorkbook = new Workbook();
    localWorkbook.fieldDefinitions = this.fieldDefinitions.copy();
    localWorkbook.documentProperties = (this.documentProperties == null ? null : this.documentProperties.copy());
    localWorkbook.customDocumentProperties.addAll(this.customDocumentProperties);
    localWorkbook.styles = new LinkedHashMap(this.styles);
    localWorkbook.wxReportConfig = this.wxReportConfig;
    localWorkbook.tpls = new ConcurrentHashMap(this.tpls);
    localWorkbook.supportCache = false;
    localWorkbook.storePath = this.storePath;
    localWorkbook.virtualPath = this.virtualPath;
    localWorkbook.needExpand = this.needExpand;
    Iterator localIterator = this.sheets.iterator();
    while (localIterator.hasNext())
    {
      Worksheet localWorksheet = (Worksheet)localIterator.next();
      localWorksheet = localWorksheet.copy();
      localWorksheet.setWorkbook(localWorkbook);
      localWorkbook.addSheet(localWorksheet);
    }
    return localWorkbook;
  }
  
  public IWorkbook prepareForMerge()
  {
    return copy();
  }
  
  public FieldDefinitionList getFieldDefinitions()
  {
    return this.fieldDefinitions;
  }
  
  public String getVirtualPath()
  {
    return this.virtualPath;
  }
  
  public void setVirtualPath(String paramString)
  {
    this.virtualPath = paramString;
  }
  
  public String getStorePath()
  {
    return this.storePath;
  }
  
  public void setStorePath(String paramString)
  {
    this.storePath = paramString;
  }
  
  public void removeNames()
  {
    if (this.names != null) {
      this.names.clear();
    }
  }
  
  public boolean isCacheable()
  {
    return isSupportCache();
  }
  
  public boolean isSupportCache()
  {
    return this.supportCache;
  }
  
  public void setSupportCache(boolean paramBoolean)
  {
    this.supportCache = paramBoolean;
  }
  
  public boolean isNeedExpand()
  {
    return this.needExpand;
  }
  
  public void setNeedExpand(boolean paramBoolean)
  {
    this.needExpand = paramBoolean;
  }
  
  public boolean isContainsFormula()
  {
    Iterator localIterator = this.sheets.iterator();
    while (localIterator.hasNext())
    {
      Worksheet localWorksheet = (Worksheet)localIterator.next();
      if (localWorksheet.isContainsFormula()) {
        return true;
      }
    }
    return false;
  }
  
  public Object getObj()
  {
    return this.obj;
  }
  
  public void setObj(Object paramObject)
  {
    this.obj = paramObject;
  }
  
  public WxReportRenderer newRenderer()
  {
    WxReportRenderer localWxReportRenderer = new WxReportRenderer();
    localWxReportRenderer.setReportConfig(this.wxReportConfig);
    return localWxReportRenderer;
  }
  
  public long getLastModified()
  {
    return this.lastModified;
  }
  
  public void setLastModified(long paramLong)
  {
    this.lastModified = paramLong;
  }
  
  public Worksheet addSheetByName(String paramString)
  {
    Worksheet localWorksheet = new Worksheet();
    localWorksheet.setWorksheetName(paramString);
    localWorksheet.setWorkbook(this);
    if (this.sheets == null) {
      this.sheets = new ArrayList();
    }
    this.sheets.add(localWorksheet);
    return localWorksheet;
  }
  
  public Map<String, Object> getTpls()
  {
    return this.tpls;
  }
  
  public void collectFieldDefinitions()
  {
    Iterator localIterator = this.sheets.iterator();
    while (localIterator.hasNext())
    {
      Worksheet localWorksheet = (Worksheet)localIterator.next();
      localWorksheet.collectFieldDefinitions(this.fieldDefinitions);
    }
  }
  
  public Object getXlsObj()
  {
    return this.xlsObj;
  }
  
  public void setXlsObj(Object paramObject)
  {
    this.xlsObj = paramObject;
  }
  
  public WxReportConfig getWxReportConfig()
  {
    return this.wxReportConfig;
  }
  
  public List<String> getSheetNames()
  {
    return Alog.pluck(this.sheets, "worksheetName");
  }
  
  public List<NamedRange> getRangeInSheet(String paramString)
  {
    if (this.names == null) {
      return null;
    }
    return this.names.getRangeInSheet(paramString);
  }
  
  public List<NamedRange> getRangeInSheet(String paramString1, String paramString2)
  {
    if (this.names == null) {
      return null;
    }
    return this.names.getRangeInSheet(paramString1, paramString2);
  }
  
  public void initMergeStatus()
  {
    Iterator localIterator = this.sheets.iterator();
    while (localIterator.hasNext())
    {
      Worksheet localWorksheet = (Worksheet)localIterator.next();
      localWorksheet.initMergeStatus();
    }
  }
  
  public void setNames(Names paramNames)
  {
    this.names = paramNames;
  }
  
  public Names getNames()
  {
    return this.names;
  }
  
  public void addProp(CustomDocumentProperty paramCustomDocumentProperty)
  {
    this.customDocumentProperties.add(paramCustomDocumentProperty);
  }
  
  public void setCustomDocumentProperties(CustomDocumentProperties paramCustomDocumentProperties)
  {
    this.customDocumentProperties = paramCustomDocumentProperties;
  }
  
  public CustomDocumentProperties getCustomDocumentProperties()
  {
    return this.customDocumentProperties;
  }
  
  public void setDocumentProperties(DocumentProperties paramDocumentProperties)
  {
    this.documentProperties = paramDocumentProperties;
  }
  
  public DocumentProperties getDocumentProperties()
  {
    return this.documentProperties;
  }
  
  public Collection<Style> getStyles()
  {
    return this.styles.values();
  }
  
  public Style getStyle(String paramString)
  {
    return (Style)this.styles.get(paramString);
  }
  
  public void addStyle(Style paramStyle)
  {
    this.styles.put(paramStyle.getId(), paramStyle);
  }
  
  public Style getCellStyle(Cell paramCell)
  {
    if (paramCell == null) {
      return null;
    }
    return paramCell.getStyle();
  }
  
  public Style getCellStyleWithDefault(Cell paramCell)
  {
    Style localStyle = getCellStyle(paramCell);
    if (localStyle == null) {
      localStyle = Style.EMPTY_STYLE;
    }
    return localStyle;
  }
  
  public Worksheet getSheetByNormalName(String paramString)
  {
    return (Worksheet)Alog.find(this.sheets, "normalName", paramString);
  }
  
  public List<RowBlock> getUpRowBlocks(Worksheet paramWorksheet, int paramInt)
  {
    return ExcelModelUtils.getUpRowBlocks(getRowBlocks(paramWorksheet), paramInt);
  }
  
  public List<RowBlock> getDownRowBlocks(Worksheet paramWorksheet, int paramInt)
  {
    List localList = getRowBlocks(paramWorksheet);
    return ExcelModelUtils.getDownRowBlocks(localList, paramInt);
  }
  
  public boolean hasNamedRangeWithPrefix(String paramString)
  {
    if (this.names == null) {
      return false;
    }
    return this.names.hasNamedRangeWithPrefix(paramString);
  }
  
  public List<RowBlock> getRowBlocks(Worksheet paramWorksheet)
  {
    if (paramWorksheet == null) {
      return null;
    }
    Object localObject1 = getRangeInSheet(paramWorksheet.getWorksheetName());
    if (localObject1 == null) {
      localObject1 = new ArrayList(0);
    }
    ArrayList localArrayList = new ArrayList();
    int i = 0;
    Object localObject2;
    if (!((List)localObject1).isEmpty())
    {
      localObject2 = (NamedRange)((List)localObject1).get(0);
      i = ((NamedRange)localObject2).getMinRow();
    }
    if (i > 0)
    {
      localObject2 = new RowBlock("simple", 0, i - 1);
      localArrayList.add(localObject2);
    }
    int j = paramWorksheet.getRowCount();
    int k = i;
    int n = ((List)localObject1).size();
    Object localObject3;
    for (int m = 0; m < n; m++)
    {
      localObject3 = (NamedRange)((List)localObject1).get(m);
      if ((!((NamedRange)localObject3).isColMode()) && (((NamedRange)localObject3).getMinRow() >= i))
      {
        String str1 = ((NamedRange)localObject3).getName();
        String str2 = "simple";
        String str3 = null;
        if (str1.startsWith("tile."))
        {
          str2 = "tile";
          str3 = parseVarName((NamedRange)localObject3, "tile.");
        }
        else if (str1.startsWith("loop."))
        {
          str2 = "loop";
          str3 = parseVarName((NamedRange)localObject3, "loop.");
        }
        else
        {
          if (!str1.startsWith("group.")) {
            continue;
          }
          str2 = "group";
          str3 = parseVarName((NamedRange)localObject3, "group.");
        }
        if (((NamedRange)localObject3).getMaxRow() > k) {
          k = ((NamedRange)localObject3).getMaxRow();
        }
        if (k > j - 1) {
          k = j - 1;
        }
        if (i < ((NamedRange)localObject3).getMinRow())
        {
          localRowBlock = new RowBlock("simple", i, ((NamedRange)localObject3).getMinRow() - 1);
          localArrayList.add(localRowBlock);
        }
        RowBlock localRowBlock = new RowBlock(str2, (NamedRange)localObject3);
        localRowBlock.setVarName(str3);
        localArrayList.add(localRowBlock);
        i = k + 1;
      }
    }
    if (paramWorksheet.getRowCount() > k) {
      if (k == 0)
      {
        localObject3 = new RowBlock("simple", 0, paramWorksheet.getRowCount() - 1);
        localArrayList.add(localObject3);
      }
      else if (paramWorksheet.getRowCount() - 1 > k)
      {
        localObject3 = new RowBlock("simple", k + 1, paramWorksheet.getRowCount() - 1);
        localArrayList.add(localObject3);
      }
    }
    return localArrayList;
  }
  
  String parseVarName(NamedRange paramNamedRange, String paramString)
  {
    String str = paramNamedRange.getName().substring(paramString.length());
    if (str.indexOf('.') > 0) {
      str = str.substring(0, str.indexOf('.'));
    }
    return str;
  }
  
  public void compactBlank()
  {
    Iterator localIterator = this.sheets.iterator();
    while (localIterator.hasNext())
    {
      Worksheet localWorksheet = (Worksheet)localIterator.next();
      localWorksheet.getTable().removeBlankBottom();
      localWorksheet.getTable().removeBlankRight();
    }
  }
  
  public void resizeToPage(boolean paramBoolean)
  {
    Iterator localIterator = this.sheets.iterator();
    while (localIterator.hasNext())
    {
      Worksheet localWorksheet = (Worksheet)localIterator.next();
      localWorksheet.getTable().resizeToPage(paramBoolean);
    }
  }
  
  public void saveToWriter(Writer paramWriter, String paramString)
  {
    s_saveToWriter(this, paramWriter, paramString, true);
  }
  
  public String addNewStyle(Style paramStyle)
  {
    String str = paramStyle.getId();
    if (str != null) {
      throw Exceptions.code("excel.CAN_err_new_style_id_already_set").param(str);
    }
    int i = this.styles.size();
    for (str = "n" + i; this.styles.containsKey(str); str = "n" + i) {
      i++;
    }
    paramStyle.setId(str);
    this.styles.put(str, paramStyle);
    return str;
  }
  
  public String getUnusedStylePrefix()
  {
    int i = 0;
    Iterator localIterator = this.styles.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      if (str.startsWith("x"))
      {
        int j = str.indexOf('_');
        if (j >= 0)
        {
          int k = Coercions.toInt(str.substring(1, j), 0);
          if (k >= i) {
            i = k + 1;
          }
        }
      }
    }
    return "x" + i + "_";
  }
  
  public Worksheet importSheet(IWorksheet paramIWorksheet, String paramString1, String paramString2)
  {
    Worksheet localWorksheet1 = (Worksheet)paramIWorksheet;
    Workbook localWorkbook = localWorksheet1.getWorkbook();
    Worksheet localWorksheet2 = localWorksheet1.copy();
    localWorksheet2.setWorkbook(this);
    localWorksheet2.setWorksheetName(paramString1);
    Iterator localIterator1 = localWorksheet2.getRows().iterator();
    while (localIterator1.hasNext())
    {
      Row localRow = (Row)localIterator1.next();
      Iterator localIterator2 = localRow.getCells().iterator();
      while (localIterator2.hasNext())
      {
        Cell localCell = (Cell)localIterator2.next();
        String str1 = localCell.getStyleID();
        if (str1 == null) {
          str1 = "Default";
        }
        String str2 = paramString2 + str1;
        Style localStyle1 = localWorkbook.getStyle(str1);
        if (localStyle1 == null)
        {
          localCell.setStyle(null);
        }
        else
        {
          Style localStyle2 = getStyle(str2);
          if (localStyle2 == null)
          {
            localStyle2 = localStyle1.copy();
            localStyle2.setName(null);
            localStyle2.setId(str2);
            addStyle(localStyle2);
          }
          localCell.setStyle(localStyle2);
        }
      }
    }
    this.sheets.add(localWorksheet2);
    return localWorksheet2;
  }
  
  public void moveSheetTo(Worksheet paramWorksheet, int paramInt)
  {
    int i = paramWorksheet.getSheetIndex();
    if (i == paramInt) {
      return;
    }
    if ((paramInt < 0) || (paramInt >= this.sheets.size() - 1))
    {
      if (i == this.sheets.size() - 1) {
        return;
      }
      this.sheets.remove(i);
      this.sheets.add(paramWorksheet);
      return;
    }
    this.sheets.remove(i);
    if (i < paramInt) {
      this.sheets.add(paramInt - 1, paramWorksheet);
    } else {
      this.sheets.add(paramInt, paramWorksheet);
    }
  }
  
  public Worksheet importSheet(Worksheet paramWorksheet, String paramString)
  {
    return importSheet(paramWorksheet, paramString, getUnusedStylePrefix());
  }
  
  public Worksheet importSheet(Worksheet paramWorksheet)
  {
    return importSheet(paramWorksheet, getNewSheetName(paramWorksheet.getWorksheetName()));
  }
  
  public void importWorkbook(IWorkbook paramIWorkbook)
  {
    Workbook localWorkbook = (Workbook)paramIWorkbook;
    String str = getUnusedStylePrefix();
    Iterator localIterator = localWorkbook.getWorksheets().iterator();
    while (localIterator.hasNext())
    {
      Worksheet localWorksheet = (Worksheet)localIterator.next();
      importSheet(localWorksheet, getNewSheetName(localWorksheet.getWorksheetName()), str);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\Workbook.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */