package edu.thu.ext.excel.model;

import edu.thu.lang.reflect.BeanInstance;
import java.io.Serializable;

public class Column
  implements Serializable
{
  private static final long serialVersionUID = 2071495747119327340L;
  int F;
  boolean E;
  boolean G;
  boolean D;
  double C;
  Style B;
  int H;
  String A;
  
  public String getName()
  {
    return this.A;
  }
  
  public void setName(String paramString)
  {
    this.A = paramString;
  }
  
  public int getHiddenInt()
  {
    return this.E ? 1 : 0;
  }
  
  public int getAutoFitWidthInt()
  {
    return this.G ? 1 : 0;
  }
  
  public Column copy()
  {
    return (Column)new BeanInstance(this).cloneInstance(false);
  }
  
  public int getSpan()
  {
    return this.H;
  }
  
  public void setSpan(int paramInt)
  {
    this.H = paramInt;
  }
  
  public boolean isBoolHidden()
  {
    return this.E;
  }
  
  public String getHtmlStyle()
  {
    if (this.C > 0.0D) {
      return "width:" + this.C + "pt";
    }
    return null;
  }
  
  public boolean getAutoFitWidth()
  {
    return this.G;
  }
  
  public void setAutoFitWidth(boolean paramBoolean)
  {
    this.G = paramBoolean;
  }
  
  public boolean isHidden()
  {
    return this.E;
  }
  
  public void setHidden(boolean paramBoolean)
  {
    this.E = paramBoolean;
  }
  
  public int getIndex()
  {
    return this.F;
  }
  
  public void setIndex(int paramInt)
  {
    this.F = paramInt;
  }
  
  public Style getStyle()
  {
    return this.B;
  }
  
  public void setStyle(Style paramStyle)
  {
    this.B = paramStyle;
  }
  
  public double getWidth()
  {
    return this.C;
  }
  
  public void setWidth(double paramDouble)
  {
    this.C = paramDouble;
  }
  
  public boolean isDefault()
  {
    return this.D;
  }
  
  public void setIsDefault(boolean paramBoolean)
  {
    this.D = paramBoolean;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\Column.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */