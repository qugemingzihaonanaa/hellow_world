package edu.thu.ext.excel.model;

import edu.thu.java.util.Coercions;
import edu.thu.lang.IVariant;
import edu.thu.model.tree.TreeNode;
import edu.thu.util.StringUtilsEx;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class RichData
  implements Serializable
{
  private static final long serialVersionUID = -9181241649883264214L;
  static final String B = "ss:Data";
  static final String G = "ss:Type";
  static final String D = "xmlns";
  static final String C = "http://www.w3.org/TR/REC-html40";
  static final String A = "String";
  TreeNode E;
  List<RichTextPiece> F;
  
  public RichData(List<RichTextPiece> paramList)
  {
    this.F = paramList;
  }
  
  public RichData(TreeNode paramTreeNode)
  {
    this.E = paramTreeNode;
  }
  
  public void setPieces(List<RichTextPiece> paramList)
  {
    this.F = paramList;
  }
  
  public List<RichTextPiece> getPieces()
  {
    return getRichTextPieces(null);
  }
  
  public String getXml()
  {
    return getNode().toXml(false);
  }
  
  public TreeNode getNode()
  {
    if (this.E == null)
    {
      if (this.F == null) {
        return null;
      }
      TreeNode localTreeNode1 = TreeNode.make("ss:Data");
      localTreeNode1.setAttribute("ss:Type", "String");
      localTreeNode1.setAttribute("xmlns", "http://www.w3.org/TR/REC-html40");
      Iterator localIterator = this.F.iterator();
      while (localIterator.hasNext())
      {
        RichTextPiece localRichTextPiece = (RichTextPiece)localIterator.next();
        TreeNode localTreeNode2 = localRichTextPiece.toNode();
        localTreeNode1.appendChild(localTreeNode2);
      }
      this.E = localTreeNode1;
    }
    return this.E;
  }
  
  public String getInnerText()
  {
    if (this.F != null)
    {
      StringBuilder localStringBuilder = new StringBuilder();
      Iterator localIterator = this.F.iterator();
      while (localIterator.hasNext())
      {
        RichTextPiece localRichTextPiece = (RichTextPiece)localIterator.next();
        localStringBuilder.append(localRichTextPiece.getText());
      }
      return localStringBuilder.toString();
    }
    return getNode().innerText();
  }
  
  public String getInnerXml()
  {
    return getNode().innerXml(false);
  }
  
  public String getHtml()
  {
    return StringUtilsEx.replace(getInnerXml(), "\n", "<br/>");
  }
  
  public boolean isRich()
  {
    if (this.F != null) {
      return (!this.F.isEmpty()) && (!((RichTextPiece)this.F.get(0)).isOnlyText());
    }
    return this.E.getName().equals("ss:Data");
  }
  
  public String getWml(Style paramStyle)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    toWml(localStringBuilder, paramStyle);
    return localStringBuilder.toString();
  }
  
  public void toWml(StringBuilder paramStringBuilder, Style paramStyle)
  {
    Iterator localIterator = getRichTextPieces(paramStyle).iterator();
    while (localIterator.hasNext())
    {
      RichTextPiece localRichTextPiece = (RichTextPiece)localIterator.next();
      localRichTextPiece.toWml(paramStringBuilder);
    }
  }
  
  public List<RichTextPiece> getRichTextPieces(Style paramStyle)
  {
    if (this.F != null) {
      return this.F;
    }
    ArrayList localArrayList1 = new ArrayList();
    ArrayList localArrayList2 = new ArrayList();
    RichTextPiece localRichTextPiece = new RichTextPiece();
    if (paramStyle != null) {
      localRichTextPiece.B = paramStyle.getFont();
    }
    localArrayList2.add(localRichTextPiece);
    A(this.E, localArrayList2, localArrayList1);
    this.F = localArrayList1;
    return localArrayList1;
  }
  
  void A(TreeNode paramTreeNode, List<RichTextPiece> paramList1, List<RichTextPiece> paramList2)
  {
    RichTextPiece localRichTextPiece = (RichTextPiece)paramList1.get(paramList1.size() - 1);
    String str1 = paramTreeNode.getName();
    if (str1.equals("B"))
    {
      localRichTextPiece.A().setBold(true);
    }
    else if (str1.equals("I"))
    {
      localRichTextPiece.A().setItalic(true);
    }
    else if (str1.equals("Sub"))
    {
      localRichTextPiece.A().setVerticalAlign(2);
    }
    else if (str1.equals("Sup"))
    {
      localRichTextPiece.A().setVerticalAlign(1);
    }
    else if (str1.equals("U"))
    {
      localRichTextPiece.A().setUnderline(true);
    }
    else if (str1.equals("S"))
    {
      localRichTextPiece.A().setStrikeout(true);
    }
    else if (str1.equals("Font"))
    {
      String str2 = (String)paramTreeNode.getAttribute("html:Face");
      if (str2 != null) {
        localRichTextPiece.A().setFontName(str2);
      }
      String str3 = paramTreeNode.attribute("html:Size").stripedStringValue();
      if (str3 != null) {
        localRichTextPiece.A().setFontSize(Double.valueOf(Coercions.toDouble(str3, 10.0D)));
      }
      String str4 = paramTreeNode.attribute("html:Color").stripedStringValue();
      if (str4 != null) {
        localRichTextPiece.A().setFontColor(str4);
      }
    }
    if (!paramTreeNode.hasChild())
    {
      localRichTextPiece.C = paramTreeNode.stringValue();
      paramList2.add(localRichTextPiece);
    }
    else
    {
      int j = paramTreeNode.getChildCount();
      for (int i = 0; i < j; i++)
      {
        paramList1.add(localRichTextPiece.copyStyle());
        A(paramTreeNode.getChild(i), paramList1, paramList2);
        paramList1.remove(paramList1.size() - 1);
      }
    }
  }
  
  public static class RichTextPiece
    implements Serializable
  {
    private static final long serialVersionUID = -6274431426332416340L;
    Font B;
    String C;
    Object A;
    
    public RichTextPiece copyStyle()
    {
      RichTextPiece localRichTextPiece = new RichTextPiece();
      localRichTextPiece.C = this.C;
      localRichTextPiece.A = this.A;
      localRichTextPiece.B = (this.B == null ? null : this.B.copy());
      return localRichTextPiece;
    }
    
    Font A()
    {
      if (this.B == null) {
        this.B = new Font();
      }
      return this.B;
    }
    
    public Font getFont()
    {
      return this.B;
    }
    
    public void setFont(Font paramFont)
    {
      this.B = paramFont;
    }
    
    public TreeNode toNode()
    {
      if (this.B == null)
      {
        TreeNode localTreeNode = TreeNode.make("#text");
        localTreeNode.setValue(this.C);
        return localTreeNode;
      }
      return this.B.buildRichTextNode(this.C);
    }
    
    public String toWml()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      toWml(localStringBuilder);
      return localStringBuilder.toString();
    }
    
    public void toWml(StringBuilder paramStringBuilder)
    {
      if ((this.C == null) || (this.C.length() <= 0)) {
        return;
      }
      paramStringBuilder.append("<w:r>");
      if (this.B != null)
      {
        paramStringBuilder.append("<w:rPr>");
        this.B.toWmlStyle(paramStringBuilder);
        paramStringBuilder.append("</w:rPr>");
      }
      String str = StringUtilsEx.encodeXmlBr(this.C, "<w:br/>");
      paramStringBuilder.append("<w:t>").append(str).append("</w:t>");
      paramStringBuilder.append("</w:r>");
    }
    
    public Object getTextExpr()
    {
      return this.A;
    }
    
    public void setTextExpr(Object paramObject)
    {
      this.A = paramObject;
    }
    
    public String getText()
    {
      return this.C;
    }
    
    public void setText(String paramString)
    {
      this.C = paramString;
    }
    
    public boolean isOnlyText()
    {
      return this.B == null;
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\RichData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */