package edu.thu.ext.excel.model;

import edu.thu.java.util.Coercions;
import edu.thu.lang.IVariant;
import edu.thu.lang.Variant;
import edu.thu.model.stg.ds.EnumItem;
import edu.thu.model.stg.ds.EnumLoader;
import edu.thu.model.stg.ds.IEnumInfo;
import edu.thu.service.SystemServiceContext;
import edu.thu.util.StringUtils;
import edu.thu.util.StringUtilsEx;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class FieldDefinition
  implements Serializable
{
  private static final long serialVersionUID = 1987644676058373929L;
  public static final String[] FIELD_TYPES = { "int", "number", "string", "date" };
  public static final int LIST_TYPE_SINGLE = 1;
  public static final int LIST_TYPE_LIST = 2;
  public static final int LIST_TYPE_GROUP = 3;
  public static final String FIELD_TYPE_INT = "int";
  public static final String FIELD_TYPE_NUMBER = "number";
  public static final String FIELD_TYPE_STRING = "string";
  public static final String FIELD_TYPE_DATE = "date";
  public static final String DOMAIN_DEGREE = "@degree";
  public static final String DOMAIN_USER_ID = "userId";
  public static final String DOMAIN_DEPT_ID = "deptId";
  int E = 1;
  String Z;
  String G;
  String C;
  String Y;
  int F;
  Integer V;
  Double L;
  Double X;
  String H;
  boolean S;
  String A;
  boolean O;
  boolean J;
  String K;
  String W;
  Cell N;
  String Q;
  boolean D;
  String T;
  List<String> M;
  boolean P;
  Integer U;
  boolean R;
  String I;
  int B;
  
  public String getDomain()
  {
    return this.I;
  }
  
  public void setDomain(String paramString)
  {
    this.I = paramString;
  }
  
  public boolean isDynamicField()
  {
    return this.R;
  }
  
  public void setDynamicField(boolean paramBoolean)
  {
    this.R = paramBoolean;
  }
  
  public int getGroupIndex()
  {
    return this.B;
  }
  
  public void setGroupIndex(int paramInt)
  {
    this.B = paramInt;
  }
  
  public String getEnum()
  {
    return this.T;
  }
  
  public void setEnum(String paramString)
  {
    this.T = paramString;
  }
  
  public String getShortName()
  {
    return this.Q;
  }
  
  public void setShortName(String paramString)
  {
    this.Q = paramString;
  }
  
  public Integer getRows()
  {
    return this.U;
  }
  
  public void setRows(Integer paramInteger)
  {
    this.U = paramInteger;
  }
  
  public List<String> getOptions()
  {
    return this.M;
  }
  
  public void setOptions(List<String> paramList)
  {
    this.M = paramList;
  }
  
  public boolean isUseFullName()
  {
    return this.D;
  }
  
  public void setUseFullName(boolean paramBoolean)
  {
    this.D = paramBoolean;
  }
  
  public String getGroupName()
  {
    return this.Y;
  }
  
  public void setGroupName(String paramString)
  {
    this.Y = paramString;
  }
  
  public String getData()
  {
    return this.W;
  }
  
  public void setData(String paramString)
  {
    this.W = paramString;
  }
  
  public String getExtIndex()
  {
    return this.K;
  }
  
  public void setExtIndex(String paramString)
  {
    this.K = paramString;
  }
  
  public Cell getCell()
  {
    return this.N;
  }
  
  public void setCell(Cell paramCell)
  {
    this.N = paramCell;
  }
  
  public int getListType()
  {
    return this.E;
  }
  
  public void setListType(int paramInt)
  {
    this.E = paramInt;
  }
  
  public boolean isListField()
  {
    return this.E == 2;
  }
  
  public boolean isSingleField()
  {
    return this.E == 1;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("field[name=").append(this.G).append(",type=").append(this.Z);
    if (this.C != null) {
      localStringBuilder.append(",showName=").append(this.C);
    }
    localStringBuilder.append("]");
    if (this.N != null) {
      localStringBuilder.append("@").append(this.N);
    }
    return localStringBuilder.toString();
  }
  
  public boolean isAddable()
  {
    return this.O;
  }
  
  public void setAddable(boolean paramBoolean)
  {
    this.O = paramBoolean;
  }
  
  public boolean isUpdatable()
  {
    return this.J;
  }
  
  public void setUpdatable(boolean paramBoolean)
  {
    this.J = paramBoolean;
  }
  
  public void parseFrom(Map<String, Object> paramMap)
  {
    this.Z = Variant.valueOf(paramMap.get("type")).stripedStringValue();
    this.C = Variant.valueOf(paramMap.get("showName")).stripedStringValue();
    this.F = Coercions.toInt(paramMap.get("size"), 10);
    this.V = Integer.valueOf(Coercions.toInt(paramMap.get("precision"), Integer.MIN_VALUE));
    if (this.V.intValue() == Integer.MIN_VALUE) {
      this.V = null;
    }
    this.L = Double.valueOf(Coercions.toDouble(paramMap.get("max"), Double.MAX_VALUE));
    if (this.L.doubleValue() == Double.MAX_VALUE) {
      this.L = null;
    }
    this.X = Double.valueOf(Coercions.toDouble(paramMap.get("min"), Double.MIN_VALUE));
    if (this.X.doubleValue() == Double.MIN_VALUE) {
      this.X = null;
    }
    this.W = Coercions.toString(paramMap.get("data"), null);
    this.S = Coercions.toBoolean(paramMap.get("notNull"), false);
    this.A = Variant.valueOf(paramMap.get("measureUnit")).stripedStringValue();
    String str1 = Coercions.toString(paramMap.get("options"), null);
    if (str1 != null)
    {
      str1 = StringUtils.replace(str1, "、", ",");
      str1 = StringUtils.replace(str1, "，", ",");
      this.M = StringUtils.stripedSplit(str1, ',');
    }
    this.P = Variant.valueOf(paramMap.get("multiple")).booleanValue(true);
    this.T = Variant.valueOf(paramMap.get("enum")).stripedStringValue();
    String str2 = Variant.valueOf(paramMap.get("rows")).stripedStringValue();
    if (str2 != null) {
      this.U = Integer.valueOf(Coercions.toInt(str2, 4));
    }
    this.I = Variant.valueOf(paramMap.get("domain")).stripedStringValue();
  }
  
  public boolean isMultiple()
  {
    return this.P;
  }
  
  public String getDefaultValue()
  {
    return this.H;
  }
  
  public void setDefaultValue(String paramString)
  {
    this.H = paramString;
  }
  
  public Double getMax()
  {
    return this.L;
  }
  
  public void setMax(Double paramDouble)
  {
    this.L = paramDouble;
  }
  
  public String getMeasureUnit()
  {
    return this.A;
  }
  
  public void setMeasureUnit(String paramString)
  {
    this.A = paramString;
  }
  
  public Double getMin()
  {
    return this.X;
  }
  
  public void setMin(Double paramDouble)
  {
    this.X = paramDouble;
  }
  
  public String getDefStr()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("*=").append(this.G);
    if (this.K != null) {
      localStringBuilder.append('[').append(this.K).append(']');
    }
    return localStringBuilder.toString();
  }
  
  public String getName()
  {
    return this.G;
  }
  
  public void setName(String paramString)
  {
    this.G = paramString;
  }
  
  public boolean isNotNull()
  {
    return this.S;
  }
  
  public void setNotNull(boolean paramBoolean)
  {
    this.S = paramBoolean;
  }
  
  public Integer getPrecision()
  {
    return this.V;
  }
  
  public void setPrecision(Integer paramInteger)
  {
    this.V = paramInteger;
  }
  
  public String getShowName()
  {
    return this.C;
  }
  
  public void setShowName(String paramString)
  {
    this.C = paramString;
  }
  
  public int getSize()
  {
    return this.F;
  }
  
  public void setSize(int paramInt)
  {
    this.F = paramInt;
  }
  
  public String getType()
  {
    return this.Z;
  }
  
  public void setType(String paramString)
  {
    this.Z = paramString;
  }
  
  public String getIndexedGroupName()
  {
    return StringUtilsEx.padNumber(Integer.valueOf(this.B + 1), 2) + ":" + this.Y;
  }
  
  public Object getFieldData(Workbook paramWorkbook)
  {
    if (this.N == null) {
      return null;
    }
    String str1 = this.N.getNormalSheetName();
    Worksheet localWorksheet = paramWorkbook.getSheetByNormalName(str1);
    if (localWorksheet == null) {
      return null;
    }
    Cell localCell = localWorksheet.getCell(this.N.getRowPos(), this.N.getColPos());
    if (localCell == null) {
      return null;
    }
    String str2 = localCell.getData();
    if ((str2 == null) || (str2.length() <= 0)) {
      return null;
    }
    if (this.T != null)
    {
      IEnumInfo localIEnumInfo = EnumLoader.loadEnum(this.T, SystemServiceContext.getInstance());
      if (localIEnumInfo != null)
      {
        EnumItem localEnumItem = localIEnumInfo.getItemByValue(str2.trim());
        if (localEnumItem != null) {
          return localEnumItem.getId();
        }
      }
    }
    else if ((this.I != null) && (this.I.equals("@degree")))
    {
      return StringUtilsEx.parseDegree(str2);
    }
    return str2;
  }
  
  public boolean isNumberType(String paramString)
  {
    String str = this.Z;
    if (str == null) {
      str = paramString;
    }
    return ("int".equals(str)) || ("number".equals(str));
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\FieldDefinition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */