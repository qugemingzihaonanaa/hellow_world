package edu.thu.ext.excel.model;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.util.Coercions;
import edu.thu.lang.IVariant;
import edu.thu.lang.Variant;
import edu.thu.lang.exceptions.StdException;
import edu.thu.model.tree.TreeNode;
import edu.thu.model.tree.TreeNodeParser;
import edu.thu.util.StringUtilsEx;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.xml.sax.InputSource;

public class ExcelModelParser
  extends AbstractExcelModelParser
{
  protected void parseConfig(TreeNode paramTreeNode, WxReportConfig paramWxReportConfig, Workbook paramWorkbook)
  {
    TreeNode localTreeNode = ExcelModelUtils.getSheetNode(paramTreeNode, "WxReportConfig", false);
    if (localTreeNode == null) {
      return;
    }
    parseWxReportConfigSheet(localTreeNode, paramWxReportConfig, paramWorkbook);
    this.supportFormula = paramWxReportConfig.getBooleanProperty("supportFormula", this.supportFormula);
    this.supportExpand = paramWxReportConfig.getBooleanProperty("supportExpand", this.supportExpand);
    this.allowDuplicateField = paramWxReportConfig.getBooleanProperty("allowDuplicateField", this.allowDuplicateField);
    this.supportExcelFormula = paramWxReportConfig.getBooleanProperty("supportExcelFormula", false);
    paramTreeNode.removeChild(localTreeNode);
  }
  
  protected void parseWxReportConfigSheet(TreeNode paramTreeNode, WxReportConfig paramWxReportConfig, Workbook paramWorkbook)
  {
    paramWxReportConfig.parseFromSheet(paramTreeNode, getTplC(), paramWorkbook);
  }
  
  public void parseWorkbookFromInputSource(InputSource paramInputSource, Workbook paramWorkbook)
  {
    TreeNode localTreeNode = TreeNodeParser.getInstance().parseFromInputSource(paramInputSource);
    parseDocumentProperties(localTreeNode.makeChild("DocumentProperties"), paramWorkbook);
    parseCustomDocumentProperties(localTreeNode.existingChild("CustomDocumentProperties"), paramWorkbook);
    Names localNames = new Names();
    parseNames(localTreeNode.existingChild("Names"), localNames);
    paramWorkbook.setNames(localNames);
    parseStyles(localTreeNode.makeChild("Styles"), paramWorkbook);
    if (!this.onlyParseData)
    {
      if (this.useReportConfig)
      {
        parseConfig(localTreeNode, paramWorkbook.getWxReportConfig(), paramWorkbook);
        boolean bool = paramWorkbook.getWxReportConfig().getBooleanProperty("supportCache", paramWorkbook.isSupportCache());
        paramWorkbook.setSupportCache(bool);
      }
      this.wxReportConfig = paramWorkbook.getWxReportConfig();
    }
    parseWorksheets(localTreeNode, paramWorkbook);
  }
  
  public void parseWorkbook(InputStream paramInputStream, Workbook paramWorkbook)
  {
    InputSource localInputSource = new InputSource(paramInputStream);
    parseWorkbookFromInputSource(localInputSource, paramWorkbook);
  }
  
  void parseCustomDocumentProperties(TreeNode paramTreeNode, Workbook paramWorkbook)
  {
    if (paramTreeNode == null) {
      return;
    }
    int j = paramTreeNode.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(i);
      String str1 = localTreeNode.attribute("dt:dt").stripedStringValue();
      if (str1 != null)
      {
        String str2 = localTreeNode.getName();
        String str3 = localTreeNode.innerText();
        CustomDocumentProperty localCustomDocumentProperty = new CustomDocumentProperty(str1, str2, str3);
        paramWorkbook.addProp(localCustomDocumentProperty);
      }
    }
  }
  
  void parseDocumentProperties(TreeNode paramTreeNode, Workbook paramWorkbook)
  {
    String str1 = paramTreeNode.makeChild("Author").stripedStringValue();
    String str2 = paramTreeNode.makeChild("LastAuthor").stripedStringValue();
    String str3 = paramTreeNode.makeChild("Created").stripedStringValue();
    String str4 = paramTreeNode.makeChild("Version").stripedStringValue();
    DocumentProperties localDocumentProperties = new DocumentProperties();
    localDocumentProperties.setAuthor(str1);
    localDocumentProperties.setLastAuthor(str2);
    localDocumentProperties.setCreated(str3);
    localDocumentProperties.setVersion(str4);
    paramWorkbook.setDocumentProperties(localDocumentProperties);
  }
  
  public void parseNames(TreeNode paramTreeNode, Names paramNames)
  {
    if (paramTreeNode == null) {
      return;
    }
    int j = paramTreeNode.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(i);
      NamedRange localNamedRange = new NamedRange();
      localNamedRange.setName(localTreeNode.attribute("ss:Name").stringValue());
      localNamedRange.setRefersTo(localTreeNode.attribute("ss:RefersTo").stringValue());
      if (localNamedRange.parseRefersTo()) {
        paramNames.addRange(localNamedRange);
      }
    }
  }
  
  public void parsePageBreaks(TreeNode paramTreeNode, PageBreaks paramPageBreaks)
  {
    if (paramTreeNode == null) {
      return;
    }
    TreeNode localTreeNode1 = paramTreeNode.existingChild("RowBreaks");
    int j;
    if (localTreeNode1 != null)
    {
      j = localTreeNode1.getChildCount();
      for (int i = 0; i < j; i++)
      {
        TreeNode localTreeNode3 = localTreeNode1.getChild(i);
        paramPageBreaks.addRow(localTreeNode3.makeChild("Row").intValue(0));
      }
    }
    TreeNode localTreeNode2 = paramTreeNode.existingChild("ColBreaks");
    if (localTreeNode2 != null)
    {
      int k = localTreeNode2.getChildCount();
      for (j = 0; j < k; j++)
      {
        TreeNode localTreeNode4 = localTreeNode2.getChild(j);
        paramPageBreaks.addCol(localTreeNode4.makeChild("Column").intValue(0));
      }
    }
  }
  
  public void parseStyle(TreeNode paramTreeNode, Style paramStyle)
  {
    String str1 = paramTreeNode.attribute("ss:ID").stringValue();
    paramStyle.setId(str1);
    String str2 = paramTreeNode.attribute("ss:Name").stringValue();
    paramStyle.setName(str2);
    TreeNode localTreeNode1 = paramTreeNode.makeChild("Alignment");
    String str3 = Variant.valueOf(localTreeNode1.attribute("ss:Vertical")).stripedStringValue();
    paramStyle.setVerticalAlignment(str3);
    String str4 = Variant.valueOf(localTreeNode1.attribute("ss:Horizontal")).stripedStringValue();
    paramStyle.setHorizontalAlignment(str4);
    int i = localTreeNode1.attribute("ss:ShrinkToFit").intValue(0);
    paramStyle.setShrinkToFit(i == 1);
    int j = localTreeNode1.attribute("ss:WrapText").intValue(0);
    paramStyle.setWrapText(j == 1);
    int k = localTreeNode1.attribute("ss:Rotate").intValue(0);
    paramStyle.setRotate(k);
    TreeNode localTreeNode2 = paramTreeNode.makeChild("Borders");
    for (int m = 0; m < localTreeNode2.getChildCount(); m++)
    {
      localObject1 = localTreeNode2.getChild(m);
      if (((TreeNode)localObject1).attribute("ss:Position").stringValue("").equals("Bottom"))
      {
        str5 = Variant.valueOf(((TreeNode)localObject1).attribute("ss:LineStyle")).stringValue();
        n = ((TreeNode)localObject1).attribute("ss:Weight").intValue(0);
        localObject2 = ((TreeNode)localObject1).attribute("ss:Color").stripedStringValue();
        paramStyle.setBottomBorderColor((String)localObject2);
        paramStyle.setBottomBorderStyle(str5);
        paramStyle.setBottomBorderWeight(n);
      }
      if (((TreeNode)localObject1).attribute("ss:Position").stringValue("").equals("Left"))
      {
        str5 = Variant.valueOf(((TreeNode)localObject1).attribute("ss:LineStyle")).stringValue();
        n = ((TreeNode)localObject1).attribute("ss:Weight").intValue(0);
        localObject2 = ((TreeNode)localObject1).attribute("ss:Color").stripedStringValue();
        paramStyle.setLeftBorderColor((String)localObject2);
        paramStyle.setLeftBorderStyle(str5);
        paramStyle.setLeftBorderWeight(n);
      }
      if (((TreeNode)localObject1).attribute("ss:Position").stringValue("").equals("Right"))
      {
        str5 = Variant.valueOf(((TreeNode)localObject1).attribute("ss:LineStyle")).stringValue();
        n = ((TreeNode)localObject1).attribute("ss:Weight").intValue(0);
        localObject2 = ((TreeNode)localObject1).attribute("ss:Color").stripedStringValue();
        paramStyle.setRightBorderColor((String)localObject2);
        paramStyle.setRightBorderStyle(str5);
        paramStyle.setRightBorderWeight(n);
      }
      if (((TreeNode)localObject1).attribute("ss:Position").stringValue("").equals("Top"))
      {
        str5 = ((TreeNode)localObject1).attribute("ss:LineStyle").stringValue();
        n = ((TreeNode)localObject1).attribute("ss:Weight").intValue(0);
        localObject2 = ((TreeNode)localObject1).attribute("ss:Color").stripedStringValue();
        paramStyle.setTopBorderColor((String)localObject2);
        paramStyle.setTopBorderStyle(str5);
        paramStyle.setTopBorderWeight(n);
      }
      if (((TreeNode)localObject1).attribute("ss:Position").stringValue("").equals("DiagonalLeft"))
      {
        str5 = ((TreeNode)localObject1).attribute("ss:LineStyle").stringValue();
        n = ((TreeNode)localObject1).attribute("ss:Weight").intValue(0);
        localObject2 = ((TreeNode)localObject1).attribute("ss:Color").stripedStringValue();
        paramStyle.setDiagonalLeftColor((String)localObject2);
        paramStyle.setDiagonalLeftStyle(str5);
        paramStyle.setDiagonalLeftWeight(n);
      }
      if (((TreeNode)localObject1).attribute("ss:Position").stringValue("").equals("DiagonalRight"))
      {
        str5 = ((TreeNode)localObject1).attribute("ss:LineStyle").stringValue();
        n = ((TreeNode)localObject1).attribute("ss:Weight").intValue(0);
        localObject2 = ((TreeNode)localObject1).attribute("ss:Color").stripedStringValue();
        paramStyle.setDiagonalRightColor((String)localObject2);
        paramStyle.setDiagonalRightStyle(str5);
        paramStyle.setDiagonalRightWeight(n);
      }
    }
    TreeNode localTreeNode3 = paramTreeNode.makeChild("Font");
    Object localObject1 = localTreeNode3.attribute("ss:FontName").stringValue();
    if (localObject1 != null) {
      paramStyle.setFontName((String)localObject1);
    }
    String str5 = localTreeNode3.attribute("x:Family").stringValue();
    if (str5 != null) {
      paramStyle.setFontFamily(str5);
    }
    int n = Variant.valueOf(localTreeNode3.attribute("x:CharSet")).intValue(0);
    if (n > 0) {
      paramStyle.setCharSet(n);
    }
    Object localObject2 = Double.valueOf(Variant.valueOf(localTreeNode3.attribute("ss:Size")).doubleValue(n == 134 ? 10 : 0));
    if (((Double)localObject2).doubleValue() > 0.0D) {
      paramStyle.setFontSize((Double)localObject2);
    }
    String str6 = localTreeNode3.attribute("ss:Color").stripedStringValue();
    if (str6 != null) {
      paramStyle.setFontColor(str6);
    }
    int i1 = localTreeNode3.attribute("ss:Bold").intValue(0);
    int i2 = localTreeNode3.attribute("ss:Italic").intValue(0);
    String str7 = localTreeNode3.attribute("ss:Underline").stripedStringValue();
    String str8 = localTreeNode3.attribute("ss:VerticalAlign").stripedStringValue();
    if (i1 == 1) {
      paramStyle.setFontBold(true);
    }
    if (i2 == 1) {
      paramStyle.setFontItalic(true);
    }
    if (str7 != null) {
      paramStyle.setFontUnderline(str7);
    }
    if (str8 != null) {
      paramStyle.A().setXlsVerticalAlign(str8);
    }
    TreeNode localTreeNode4 = paramTreeNode.existingChild("NumberFormat");
    if (localTreeNode4 != null)
    {
      str9 = localTreeNode4.attribute("ss:Format").stringValue();
      paramStyle.setNumberFormat(str9);
    }
    String str9 = paramTreeNode.makeChild("Protection").stripedStringValue();
    paramStyle.setProtection(str9);
    TreeNode localTreeNode5 = paramTreeNode.existingChild("Interior");
    if (localTreeNode5 != null)
    {
      String str10 = localTreeNode5.attribute("ss:Color").stripedStringValue();
      paramStyle.setInteriorColor(str10);
      String str11 = localTreeNode5.attribute("ss:Pattern").stripedStringValue();
      paramStyle.setInteriorPattern(str11);
    }
  }
  
  public void parseStyles(TreeNode paramTreeNode, Workbook paramWorkbook)
  {
    for (int i = 0; i < paramTreeNode.getChildCount(); i++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(i);
      Style localStyle = new Style();
      parseStyle(localTreeNode, localStyle);
      paramWorkbook.addStyle(localStyle);
    }
  }
  
  public void parseWorksheets(TreeNode paramTreeNode, Workbook paramWorkbook)
  {
    WxReportConfig localWxReportConfig = paramWorkbook.getWxReportConfig();
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < paramTreeNode.getChildCount(); i++)
    {
      TreeNode localTreeNode1 = paramTreeNode.getChild(i);
      if (localTreeNode1.getName().equals("Worksheet"))
      {
        TreeNode localTreeNode2 = localTreeNode1;
        Worksheet localWorksheet = parseWorksheet(localTreeNode2, paramWorkbook);
        localWorksheet.setWorkbook(paramWorkbook);
        if (localWxReportConfig != null) {
          localWorksheet.setProperties(localWxReportConfig.makeSheetProps(localWorksheet.getNormalName()));
        }
        localArrayList.add(localWorksheet);
      }
    }
    paramWorkbook.setWorksheets(localArrayList);
  }
  
  Worksheet parseWorksheet(TreeNode paramTreeNode, Workbook paramWorkbook)
  {
    Worksheet localWorksheet = new Worksheet();
    String str = paramTreeNode.attribute("ss:Name").stringValue();
    localWorksheet.setWorksheetName(str);
    TreeNode localTreeNode1 = paramTreeNode.makeChild("Table");
    parseTable(localTreeNode1, localWorksheet, paramWorkbook);
    TreeNode localTreeNode2 = paramTreeNode.makeChild("WorksheetOptions");
    parseWorksheetOptions(localTreeNode2, localWorksheet);
    PageBreaks localPageBreaks = new PageBreaks();
    parsePageBreaks(paramTreeNode.existingChild("PageBreaks"), localPageBreaks);
    localWorksheet.setPageBreaks(localPageBreaks);
    TreeNode localTreeNode3 = paramTreeNode.existingChild("Names");
    if (localTreeNode3 != null)
    {
      Names localNames = new Names();
      parseNames(localTreeNode3, localNames);
      localWorksheet.setNames(localNames);
    }
    return localWorksheet;
  }
  
  public void parseWorksheetOptions(TreeNode paramTreeNode, Worksheet paramWorksheet)
  {
    WorksheetOptions localWorksheetOptions = new WorksheetOptions();
    String str1 = paramTreeNode.makeChild("Unsynced").stripedStringValue();
    localWorksheetOptions.setUnsynced(str1);
    String str2 = paramTreeNode.makeChild("Selected").stripedStringValue();
    localWorksheetOptions.setSelect(str2);
    boolean bool1 = paramTreeNode.existingChild("FitToPage") != null;
    boolean bool2 = paramTreeNode.existingChild("FreezePanes") != null;
    localWorksheetOptions.setFitToPage(bool1);
    localWorksheetOptions.setFreezePanes(bool2);
    parsePageSetup(paramTreeNode.existingChild("PageSetup"), localWorksheetOptions);
    TreeNode localTreeNode1 = paramTreeNode.existingChild("Print");
    parsePrint(localTreeNode1, localWorksheetOptions);
    int i = paramTreeNode.makeChild("SplitHorizontal").intValue(0);
    int j = paramTreeNode.makeChild("SplitVertical").intValue(0);
    localWorksheetOptions.setSplitHorizontal(i);
    localWorksheetOptions.setSplitVertical(j);
    TreeNode localTreeNode2 = paramTreeNode.makeChild("Panes");
    parsePanes(localTreeNode2, localWorksheetOptions);
    String str3 = paramTreeNode.makeChild("ProtectObjects").stripedStringValue();
    localWorksheetOptions.setProtectObjects(str3);
    String str4 = paramTreeNode.makeChild("ProtectScenarios").stripedStringValue();
    localWorksheetOptions.setProtectScenarios(str4);
    paramWorksheet.setWorksheetOptions(localWorksheetOptions);
  }
  
  public void parsePanes(TreeNode paramTreeNode, WorksheetOptions paramWorksheetOptions)
  {
    Panes localPanes = new Panes();
    for (int i = 0; i < paramTreeNode.getChildCount(); i++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(i);
      parsePane(localTreeNode, localPanes);
    }
    paramWorksheetOptions.setPanes(localPanes);
  }
  
  public void parsePageSetup(TreeNode paramTreeNode, WorksheetOptions paramWorksheetOptions)
  {
    if (paramTreeNode == null) {
      return;
    }
    PageSetup localPageSetup = new PageSetup();
    TreeNode localTreeNode1 = paramTreeNode.existingChild("Layout");
    TreeNode localTreeNode2 = paramTreeNode.existingChild("Header");
    TreeNode localTreeNode3 = paramTreeNode.existingChild("Footer");
    TreeNode localTreeNode4 = paramTreeNode.existingChild("PageMargins");
    String str3;
    if (localTreeNode1 != null)
    {
      String str1 = localTreeNode1.attribute("x:Orientation").stringValue();
      String str2 = localTreeNode1.attribute("x:CenterHorizontal").stripedStringValue();
      str3 = localTreeNode1.attribute("x:CenterVertical").stripedStringValue();
      int i = localTreeNode1.attribute("x:StartPageNumber").intValue(-1);
      if (str2 != null) {
        localPageSetup.setCenterHorizontal(Boolean.valueOf(str2.equals("1")));
      }
      if (str3 != null) {
        localPageSetup.setCenterVertical(Boolean.valueOf(str3.equals("1")));
      }
      if (i >= 0) {
        localPageSetup.setStartPageNumber(Integer.valueOf(i));
      }
      localPageSetup.setOrientation(str1);
    }
    double d1;
    if (localTreeNode2 != null)
    {
      d1 = localTreeNode2.attribute("x:Margin").doubleValue(-1.0D);
      str3 = localTreeNode2.attribute("x:Data").stringValue();
      if (d1 >= 0.0D) {
        localPageSetup.setHeaderMargin(Double.valueOf(d1));
      }
      if (str3 != null) {
        localPageSetup.setHeaderData(str3);
      }
    }
    if (localTreeNode3 != null)
    {
      d1 = localTreeNode3.attribute("x:Margin").doubleValue(-1.0D);
      str3 = localTreeNode3.attribute("x:Data").stringValue();
      if (d1 >= 0.0D) {
        localPageSetup.setFooterMargin(Double.valueOf(d1));
      }
      if (str3 != null) {
        localPageSetup.setFooterData(str3);
      }
    }
    if (localTreeNode4 != null)
    {
      d1 = localTreeNode4.attribute("x:Bottom").doubleValue(-1.0D);
      double d2 = localTreeNode4.attribute("x:Left").doubleValue(-1.0D);
      double d3 = localTreeNode4.attribute("x:Right").doubleValue(-1.0D);
      double d4 = localTreeNode4.attribute("x:Top").doubleValue(-1.0D);
      if (d1 >= 0.0D) {
        localPageSetup.setPageMarginsBottom(Double.valueOf(d1));
      }
      if (d2 >= 0.0D) {
        localPageSetup.setPageMarginsLeft(Double.valueOf(d2));
      }
      if (d3 >= 0.0D) {
        localPageSetup.setPageMarginsRight(Double.valueOf(d3));
      }
      if (d4 >= 0.0D) {
        localPageSetup.setPageMarginsTop(Double.valueOf(d4));
      }
    }
    paramWorksheetOptions.setPageSetup(localPageSetup);
  }
  
  public void parsePrint(TreeNode paramTreeNode, WorksheetOptions paramWorksheetOptions)
  {
    if (paramTreeNode == null) {
      return;
    }
    Print localPrint = new Print();
    int i = paramTreeNode.makeChild("FitWidth").intValue(-1);
    int j = paramTreeNode.makeChild("FitHeight").intValue(-1);
    if (i > 0) {
      localPrint.setFitWidth(Integer.valueOf(i));
    }
    if (j > 0) {
      localPrint.setFitHeight(Integer.valueOf(j));
    }
    String str = paramTreeNode.makeChild("CommentsLayout").stringValue();
    localPrint.setCommentsLayout(str);
    int k = paramTreeNode.makeChild("ValidPrinterInfo").intValue(-1);
    if (k >= 0) {
      localPrint.setValidPrinterInfo(Integer.valueOf(k));
    }
    int m = paramTreeNode.makeChild("PaperSizeIndex").intValue(-1);
    if (m >= 0) {
      localPrint.setPaperSizeIndex(Integer.valueOf(m));
    }
    double d = paramTreeNode.makeChild("Scale").doubleValue(-1.0D);
    if (d > 0.0D) {
      localPrint.setScale(Double.valueOf(d));
    }
    int n = paramTreeNode.makeChild("HorizontalResolution").intValue(-1);
    if (n >= 0) {
      localPrint.setHorizontalResolution(Integer.valueOf(n));
    }
    int i1 = paramTreeNode.makeChild("VerticalResolution").intValue(-1);
    if (i1 >= 0) {
      localPrint.setVerticalResolution(Integer.valueOf(i1));
    }
    boolean bool1 = paramTreeNode.existingChild("Gridlines") != null;
    boolean bool2 = paramTreeNode.existingChild("RowColHeadings") != null;
    localPrint.setGridlines(bool1);
    localPrint.setRowColHeadings(bool2);
    paramWorksheetOptions.setPrint(localPrint);
  }
  
  public void parsePane(TreeNode paramTreeNode, Panes paramPanes)
  {
    int i = Variant.valueOf(paramTreeNode.makeChild("Number")).intValue();
    int j = Variant.valueOf(paramTreeNode.makeChild("ActiveRow")).intValue(0);
    int k = Variant.valueOf(paramTreeNode.makeChild("ActiveCol")).intValue(0);
    Pane localPane = new Pane();
    localPane.setNumber(i);
    localPane.setActiveRow(j);
    localPane.setActiveCol(k);
    paramPanes.addPane(localPane);
  }
  
  void parseTable(TreeNode paramTreeNode, Worksheet paramWorksheet, Workbook paramWorkbook)
  {
    Table localTable = new Table(paramWorksheet);
    int i = paramTreeNode.attribute("ss:ExpandedColumnCount").intValue(100000);
    int j = paramTreeNode.attribute("ss:ExpandedRowCount").intValue(100);
    int k = paramTreeNode.attribute("x:FullColumns").intValue(1);
    int m = paramTreeNode.attribute("x:FullRows").intValue(1);
    double d1 = paramTreeNode.attribute("ss:DefaultColumnWidth").doubleValue(54.0D);
    double d2 = paramTreeNode.attribute("ss:DefaultRowHeight").doubleValue(14.25D);
    localTable.setExpandedColumnCount(i);
    localTable.setExpandedRowCount(j);
    localTable.setFullColumns(k);
    localTable.setFullRows(m);
    localTable.setDefaultColumnWidth(d1);
    localTable.setDefaultRowHeight(d2);
    int i1 = paramTreeNode.getChildCount();
    int i2 = 0;
    for (int n = 0; n < i1; n++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(n);
      String str = localTreeNode.getName();
      if (str.equals("Column"))
      {
        parseColumn(localTreeNode, localTable, paramWorkbook);
      }
      else if (str.equals("Row"))
      {
        i2++;
        Row localRow = parseRow(localTreeNode, localTable, paramWorkbook);
        if (localRow.getIndex() <= 0) {
          localRow.setIndex(i2);
        } else {
          i2 = localRow.getIndex();
        }
      }
      else
      {
        throw Exceptions.code("excel.CAN_err_invalid_row_node").param(paramTreeNode);
      }
    }
    localTable.fix();
    paramWorksheet.setTable(localTable);
  }
  
  public void parseColumn(TreeNode paramTreeNode, Table paramTable, Workbook paramWorkbook)
  {
    String str = paramTreeNode.attribute("ss:StyleID").stringValue();
    double d = paramTreeNode.attribute("ss:Width").doubleValue(-1.0D);
    int i = paramTreeNode.attribute("ss:AutoFitWidth").intValue(0);
    int j = paramTreeNode.attribute("ss:Span").intValue(0);
    int k = paramTreeNode.attribute("ss:Hidden").intValue(0);
    int m = paramTreeNode.attribute("ss:Index").intValue(0);
    Style localStyle = paramWorkbook.getStyle(str);
    Column localColumn = new Column();
    localColumn.setStyle(localStyle);
    localColumn.setWidth(d);
    localColumn.setAutoFitWidth(i == 1);
    localColumn.setSpan(j);
    localColumn.setHidden(k == 1);
    localColumn.setIndex(m);
    paramTable.addCol(localColumn);
  }
  
  Row parseRow(TreeNode paramTreeNode, Table paramTable, Workbook paramWorkbook)
  {
    Row localRow = new Row();
    int i = paramTreeNode.attribute("ss:Index").intValue(-1);
    if (i > 500000) {
      throw Exceptions.code("excel.CAN_err_row_index_too_large").param(i).param(paramTreeNode);
    }
    localRow.setIndex(i);
    int j = paramTreeNode.attribute("ss:AutoFitHeight").intValue(1);
    double d = paramTreeNode.attribute("ss:Height").doubleValue(-1.0D);
    int k = paramTreeNode.attribute("ss:Hidden").intValue(0);
    localRow.setHeight(d);
    localRow.setAutoFitHeight(j == 1);
    localRow.setHidden(k == 1);
    int m = paramTreeNode.attribute("ss:Span").intValue(0);
    localRow.setSpan(m);
    int n = paramTreeNode.getChildCount();
    ArrayList localArrayList = new ArrayList(n);
    int i1 = 0;
    for (int i2 = 0; i2 < n; i2++)
    {
      Cell localCell = parseCell(paramTreeNode.getChild(i2), paramWorkbook);
      i1++;
      if (localCell.getIndex() <= 0) {
        localCell.setIndex(i1);
      } else {
        i1 = localCell.getIndex();
      }
      i1 += localCell.getMergeAcross();
      localCell.setRow(localRow);
      localArrayList.add(localCell);
    }
    localRow.setCells(localArrayList);
    paramTable.addRow(localRow);
    return localRow;
  }
  
  Cell parseCell(TreeNode paramTreeNode, Workbook paramWorkbook)
  {
    Cell localCell = new Cell();
    String str1 = paramTreeNode.attribute("ss:StyleID").stringValue();
    if (str1 != null) {
      localCell.setStyle(paramWorkbook.getStyle(str1));
    }
    String str2 = paramTreeNode.attribute("ss:Formula").stringValue();
    localCell.setFormula(str2);
    String str3 = paramTreeNode.attribute("ss:HRef").stringValue();
    localCell.setHref(str3);
    int i = paramTreeNode.attribute("ss:Index").intValue(0);
    if (i > 100000) {
      throw Exceptions.code("excel.CAN_err_row_index_too_large").param(i).param(paramTreeNode);
    }
    localCell.setIndex(i);
    int j = paramTreeNode.attribute("ss:MergeAcross").intValue(0);
    int k = paramTreeNode.attribute("ss:MergeDown").intValue(0);
    localCell.setMergeAcross(j);
    localCell.setMergeDown(k);
    TreeNode localTreeNode = paramTreeNode.existingChild("Data");
    if (localTreeNode == null) {
      localTreeNode = paramTreeNode.existingChild("ss:Data");
    }
    if (localTreeNode != null)
    {
      localObject = localTreeNode.attribute("ss:Type").stripedStringValue();
      localCell.setDataType((String)localObject);
      String str4 = localTreeNode.innerText();
      if ("Number".equals(localObject))
      {
        str4 = StringUtilsEx.normNumStr(str4);
        localCell.setValue(Double.valueOf(Coercions.toDouble(str4, 0.0D)));
      }
      else
      {
        localCell.setValue(str4);
      }
      localCell.setData(str4);
    }
    Object localObject = ExcelModelUtils.parseComment(paramTreeNode);
    localCell.setCommentVars((Map)localObject);
    initCell(localCell, paramWorkbook);
    if (!this.onlyParseData) {
      localCell.initRichFormat(paramTreeNode);
    }
    return localCell;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\ExcelModelParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */