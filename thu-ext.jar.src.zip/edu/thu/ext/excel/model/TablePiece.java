package edu.thu.ext.excel.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class TablePiece
  implements Serializable
{
  private static final long serialVersionUID = -5016474119649849294L;
  int A = -1;
  List<RowBlock> B;
  
  public TablePiece(int paramInt)
  {
    this.A = paramInt;
  }
  
  public TablePiece(List<RowBlock> paramList)
  {
    this.B = paramList;
  }
  
  public TablePiece(RowBlock paramRowBlock)
  {
    this.B = new ArrayList(1);
    this.B.add(paramRowBlock);
  }
  
  public boolean isParagraph()
  {
    return this.A >= 0;
  }
  
  public List<RowBlock> getRowBlocks()
  {
    return this.B;
  }
  
  public int getParagraphRowIdx()
  {
    return this.A;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\TablePiece.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */