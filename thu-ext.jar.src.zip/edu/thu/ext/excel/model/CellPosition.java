package edu.thu.ext.excel.model;

import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import java.io.Serializable;

public class CellPosition
  implements Serializable, Comparable<CellPosition>
{
  private static final long serialVersionUID = -2324155752732882176L;
  public static CellPosition NONE = new CellPosition(0, 0);
  int C;
  int A;
  static final char[] B = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
  
  public CellPosition(int paramInt1, int paramInt2)
  {
    this.C = paramInt1;
    this.A = paramInt2;
  }
  
  public CellPosition(String paramString)
  {
    C(paramString);
  }
  
  public String getExprString(int paramInt)
  {
    return toString();
  }
  
  void C(String paramString)
  {
    int i = A(paramString);
    if (i <= 0) {
      throw Exceptions.code("excel.CAN_err_invalid_position").param(paramString);
    }
    this.A = B(paramString.substring(0, i));
    this.C = Integer.valueOf(paramString.substring(i)).intValue();
  }
  
  public int hashCode()
  {
    return this.C ^ 17 + this.A;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof CellPosition)) {
      return false;
    }
    CellPosition localCellPosition = (CellPosition)paramObject;
    return (this.C == localCellPosition.C) && (this.A == localCellPosition.A);
  }
  
  public int compareTo(CellPosition paramCellPosition)
  {
    if (this.C < paramCellPosition.C) {
      return -1;
    }
    if (this.C > paramCellPosition.C) {
      return 1;
    }
    if (this.A < paramCellPosition.A) {
      return -1;
    }
    if (this.A > paramCellPosition.A) {
      return 1;
    }
    return 0;
  }
  
  public String toString()
  {
    return A(this.A) + this.C;
  }
  
  int A(String paramString)
  {
    int j = paramString.length();
    for (int i = 0; i < j; i++)
    {
      char c = paramString.charAt(i);
      if (Character.isDigit(c)) {
        return i;
      }
    }
    return -1;
  }
  
  String A(int paramInt)
  {
    if (paramInt == Integer.MAX_VALUE) {
      return "@";
    }
    int i = 26;
    char[] arrayOfChar = new char[33];
    int j = 32;
    while (paramInt > i)
    {
      arrayOfChar[(j--)] = B[((paramInt - 1) % i)];
      paramInt /= i;
    }
    arrayOfChar[j] = B[(paramInt - 1)];
    return new String(arrayOfChar, j, 33 - j);
  }
  
  int B(String paramString)
  {
    paramString = paramString.toUpperCase();
    int i = 0;
    int j = 26;
    int m = paramString.length();
    for (int k = 0; k < m; k++) {
      i = i * j + (paramString.charAt(k) - 'A' + 1);
    }
    return i;
  }
  
  public int getColIndex()
  {
    return this.A;
  }
  
  public void setColIndex(int paramInt)
  {
    this.A = paramInt;
  }
  
  public int getRowIndex()
  {
    return this.C;
  }
  
  public void setRowIndex(int paramInt)
  {
    this.C = paramInt;
  }
  
  public int getRowPos()
  {
    return this.C - 1;
  }
  
  public void setRowPos(int paramInt)
  {
    this.C = (paramInt + 1);
  }
  
  public void setColPos(int paramInt)
  {
    this.A = (paramInt + 1);
  }
  
  public int getColPos()
  {
    return this.A - 1;
  }
  
  public void moveCol(int paramInt)
  {
    this.A += paramInt;
  }
  
  public void moveRow(int paramInt)
  {
    this.C += paramInt;
  }
  
  public static void main(String[] paramArrayOfString)
  {
    CellPosition localCellPosition = new CellPosition("AB43");
    Debug.check(localCellPosition.getRowIndex() == 43);
    Debug.check(localCellPosition.toString().equals("AB43"), localCellPosition.toString());
    Debug.check(new CellPosition("Z1").toString().equals("Z1"), new CellPosition("Z1").toString());
    Debug.check(new CellPosition("A14").toString().equals("A14"));
    Debug.trace("end");
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\CellPosition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */