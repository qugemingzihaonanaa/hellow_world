package edu.thu.ext.excel.model;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.model.table.IBasicCellModel;
import edu.thu.model.table.IBasicTableModel;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public abstract class AbstractTable<R extends IRow>
  implements Serializable, IBasicTableModel
{
  private static final long serialVersionUID = -4669305996999921611L;
  protected List<Column> cols = new ArrayList();
  protected List<R> rows = new ArrayList();
  private int B;
  private int C;
  private int A;
  
  public List<Column> getCols()
  {
    return this.cols;
  }
  
  public void setCols(List<Column> paramList)
  {
    this.cols = paramList;
  }
  
  public double getTotalWidth()
  {
    double d = 0.0D;
    Iterator localIterator = this.cols.iterator();
    while (localIterator.hasNext())
    {
      Column localColumn = (Column)localIterator.next();
      d += localColumn.getWidth();
    }
    return d;
  }
  
  public double getFullWidth(int paramInt1, int paramInt2)
  {
    if ((paramInt1 < 0) || (paramInt1 >= this.cols.size())) {
      return 0.0D;
    }
    int i = Math.min(paramInt1 + paramInt2, this.cols.size());
    double d = 0.0D;
    for (int j = paramInt1; j < i; j++) {
      d += ((Column)this.cols.get(j)).getWidth();
    }
    return d;
  }
  
  public double getFullHeight(int paramInt1, int paramInt2)
  {
    if ((paramInt1 < 0) || (paramInt1 >= this.rows.size())) {
      return 0.0D;
    }
    int i = Math.min(paramInt1 + paramInt2, this.rows.size());
    double d = 0.0D;
    for (int j = paramInt1; j < i; j++) {
      d += ((IRow)this.rows.get(j)).getHeight();
    }
    return d;
  }
  
  public void addCol(Column paramColumn)
  {
    this.cols.add(paramColumn);
  }
  
  public R getFirstRow()
  {
    if (this.rows.isEmpty()) {
      return null;
    }
    return (IRow)this.rows.get(0);
  }
  
  public R getLastRow()
  {
    if (this.rows.isEmpty()) {
      return null;
    }
    return (IRow)this.rows.get(this.rows.size() - 1);
  }
  
  public int getRowCount()
  {
    return this.rows.size();
  }
  
  public int getColCount()
  {
    return this.cols.size();
  }
  
  public int getTotalColspan()
  {
    return this.cols.size() + 1;
  }
  
  public R getRow(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= this.rows.size())) {
      return null;
    }
    return (IRow)this.rows.get(paramInt);
  }
  
  public Column getCol(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= this.cols.size())) {
      return null;
    }
    return (Column)this.cols.get(paramInt);
  }
  
  public List<R> getRows()
  {
    return this.rows;
  }
  
  public void setRows(List<R> paramList)
  {
    this.rows = paramList;
  }
  
  public List<TablePiece> getTablePieces()
  {
    ArrayList localArrayList = new ArrayList();
    int j = this.rows.size();
    int k = 0;
    for (int i = 0; i < j; i++)
    {
      IRow localIRow = (IRow)this.rows.get(i);
      if (localIRow.isParagraphRow())
      {
        if (i > k) {
          localArrayList.add(new TablePiece(new RowBlock("simple", k, i - 1)));
        }
        localArrayList.add(new TablePiece(i));
        k = i + 1;
      }
    }
    if (k < j) {
      localArrayList.add(new TablePiece(new RowBlock("simple", k, j - 1)));
    }
    return localArrayList;
  }
  
  public boolean isColBlank(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= this.cols.size())) {
      throw Exceptions.code("excel.CAN_err_invalid_colIdx").param(paramInt);
    }
    Iterator localIterator = this.rows.iterator();
    while (localIterator.hasNext())
    {
      IRow localIRow = (IRow)localIterator.next();
      ICell localICell = localIRow.getCell(paramInt);
      if (localICell.getMergeAcross() > 0) {
        return false;
      }
      if (!localICell.isBlank()) {
        return false;
      }
    }
    return true;
  }
  
  public void removeEmptyTailRow()
  {
    int j = this.rows.size();
    for (int i = j - 1; i >= 0; i--)
    {
      IRow localIRow = (IRow)this.rows.get(i);
      int k = localIRow.getColCount();
      if (k > 0) {
        break;
      }
      this.rows.remove(i);
    }
  }
  
  public void removeBlankBottom()
  {
    int j = this.rows.size();
    for (int i = j - 1; i >= 0; i--)
    {
      IRow localIRow = (IRow)this.rows.get(i);
      if (!localIRow.isBlank()) {
        break;
      }
      this.rows.remove(i);
    }
  }
  
  public List<List<Object>> getCellDatas()
  {
    ArrayList localArrayList = new ArrayList();
    int j = getRowCount();
    for (int i = 0; i < j; i++)
    {
      IRow localIRow = getRow(i);
      if (localIRow == null)
      {
        localArrayList.add(new ArrayList(0));
      }
      else
      {
        List localList = localIRow.getRowValues();
        localArrayList.add(localList);
      }
    }
    return localArrayList;
  }
  
  public int getHeaderRowCount()
  {
    return this.B;
  }
  
  public void setHeaderRowCount(int paramInt)
  {
    this.B = paramInt;
  }
  
  public int getSideColCount()
  {
    return this.C;
  }
  
  public void setSideColCount(int paramInt)
  {
    this.C = paramInt;
  }
  
  public int getSeqColCount()
  {
    return this.A;
  }
  
  public void setSeqColCount(int paramInt)
  {
    this.A = paramInt;
  }
  
  public List<? extends IBasicCellModel> getRowCells(int paramInt)
  {
    IRow localIRow = getRow(paramInt);
    if (localIRow == null) {
      return null;
    }
    return localIRow.getCells();
  }
  
  public IBasicCellModel getCellAt(int paramInt1, int paramInt2)
  {
    IRow localIRow = getRow(paramInt1);
    if (localIRow == null) {
      return null;
    }
    ICell localICell = localIRow.getCell(paramInt2);
    if (localICell == null) {
      return null;
    }
    if (localICell.isIgnored()) {
      return null;
    }
    return localICell;
  }
  
  public IBasicCellModel getCellContains(int paramInt1, int paramInt2)
  {
    IRow localIRow = getRow(paramInt1);
    if (localIRow == null) {
      return null;
    }
    ICell localICell = localIRow.getCell(paramInt2);
    if (localICell == null) {
      return null;
    }
    return localICell.getRealCell();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\AbstractTable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */