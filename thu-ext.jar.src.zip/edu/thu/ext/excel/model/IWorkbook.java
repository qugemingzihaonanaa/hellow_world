package edu.thu.ext.excel.model;

import java.io.File;
import java.util.Collection;

public abstract interface IWorkbook
{
  public abstract WxReportConfig getWxReportConfig();
  
  public abstract int getSheetCount();
  
  public abstract IWorksheet getSheet(int paramInt);
  
  public abstract Collection<Style> getStyles();
  
  public abstract Style getStyle(String paramString);
  
  public abstract void saveToFile(File paramFile);
  
  public abstract String toXml();
  
  public abstract IWorkbook prepareForMerge();
  
  public abstract IWorksheet importSheet(IWorksheet paramIWorksheet, String paramString1, String paramString2);
  
  public abstract void importWorkbook(IWorkbook paramIWorkbook);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\IWorkbook.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */