package edu.thu.ext.excel.model;

import java.io.Serializable;
import java.util.List;

public class CellLayerPosition
  implements Serializable
{
  private static final long serialVersionUID = -141225414904042488L;
  CellPosition C;
  List<CellOffsetPosition> B;
  List<CellOffsetPosition> A;
  
  public String toString()
  {
    if ((!hasHorPos()) && (!hasVerPos())) {
      return this.C.toString();
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(this.C);
    localStringBuilder.append('[');
    A(localStringBuilder, this.B);
    localStringBuilder.append(';');
    A(localStringBuilder, this.A);
    localStringBuilder.append(']');
    return localStringBuilder.toString();
  }
  
  void A(StringBuilder paramStringBuilder, List<CellOffsetPosition> paramList)
  {
    if (paramList != null)
    {
      int j = paramList.size();
      for (int i = 0; i < j; i++)
      {
        CellOffsetPosition localCellOffsetPosition = (CellOffsetPosition)paramList.get(i);
        paramStringBuilder.append(localCellOffsetPosition);
        if (i != j - 1) {
          paramStringBuilder.append(',');
        }
      }
    }
  }
  
  public boolean hasHorPos()
  {
    return (this.B != null) && (!this.B.isEmpty());
  }
  
  public boolean hasVerPos()
  {
    return (this.A != null) && (!this.A.isEmpty());
  }
  
  public List<CellOffsetPosition> getHorPosList()
  {
    return this.B;
  }
  
  public void setHorPosList(List<CellOffsetPosition> paramList)
  {
    this.B = paramList;
  }
  
  public CellPosition getPos()
  {
    return this.C;
  }
  
  public void setPos(CellPosition paramCellPosition)
  {
    this.C = paramCellPosition;
  }
  
  public List<CellOffsetPosition> getVerPosList()
  {
    return this.A;
  }
  
  public void setVerPosList(List<CellOffsetPosition> paramList)
  {
    this.A = paramList;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\CellLayerPosition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */