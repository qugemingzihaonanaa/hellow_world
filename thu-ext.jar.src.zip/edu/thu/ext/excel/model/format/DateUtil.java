package edu.thu.ext.excel.model.format;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DateUtil
{
  private static final int H = 60;
  private static final int I = 60;
  private static final int J = 24;
  private static final int C = 86400;
  private static final int A = -1;
  private static final long F = 86400000L;
  private static final Pattern B = Pattern.compile(":");
  private static final Pattern G = Pattern.compile("^\\[\\$\\-.*?\\]");
  private static final Pattern E = Pattern.compile("^\\[[a-zA-Z]+\\]");
  private static final Pattern D = Pattern.compile("^[yYmMdDhHsS\\-/,. :\"\\\\]+0?[ampAMP/]*$");
  
  public static double getExcelDate(Date paramDate)
  {
    return getExcelDate(paramDate, false);
  }
  
  public static double getExcelDate(Date paramDate, boolean paramBoolean)
  {
    GregorianCalendar localGregorianCalendar = new GregorianCalendar();
    localGregorianCalendar.setTime(paramDate);
    return A(localGregorianCalendar, paramBoolean);
  }
  
  public static double getExcelDate(Calendar paramCalendar, boolean paramBoolean)
  {
    return A((Calendar)paramCalendar.clone(), paramBoolean);
  }
  
  private static double A(Calendar paramCalendar, boolean paramBoolean)
  {
    if (((!paramBoolean) && (paramCalendar.get(1) < 1900)) || ((paramBoolean) && (paramCalendar.get(1) < 1904))) {
      return -1.0D;
    }
    double d1 = (((paramCalendar.get(11) * 60 + paramCalendar.get(12)) * 60 + paramCalendar.get(13)) * 1000 + paramCalendar.get(14)) / 8.64E7D;
    Calendar localCalendar = A(paramCalendar);
    double d2 = d1 + absoluteDay(localCalendar, paramBoolean);
    if ((!paramBoolean) && (d2 >= 60.0D)) {
      d2 += 1.0D;
    } else if (paramBoolean) {
      d2 -= 1.0D;
    }
    return d2;
  }
  
  public static Date getJavaDate(double paramDouble)
  {
    return getJavaDate(paramDouble, false);
  }
  
  public static Date getJavaDate(double paramDouble, boolean paramBoolean)
  {
    if (!isValidExcelDate(paramDouble)) {
      return null;
    }
    int i = (int)Math.floor(paramDouble);
    int j = (int)((paramDouble - i) * 8.64E7D + 0.5D);
    GregorianCalendar localGregorianCalendar = new GregorianCalendar();
    setCalendar(localGregorianCalendar, i, j, paramBoolean);
    return localGregorianCalendar.getTime();
  }
  
  public static void setCalendar(Calendar paramCalendar, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    int i = 1900;
    int j = -1;
    if (paramBoolean)
    {
      i = 1904;
      j = 1;
    }
    else if (paramInt1 < 61)
    {
      j = 0;
    }
    paramCalendar.set(i, 0, paramInt1 + j, 0, 0, 0);
    paramCalendar.set(14, paramInt2);
  }
  
  public static boolean isADateFormat(int paramInt, String paramString)
  {
    if (isInternalDateFormat(paramInt)) {
      return true;
    }
    if ((paramString == null) || (paramString.length() == 0)) {
      return false;
    }
    String str = paramString;
    StringBuilder localStringBuilder = new StringBuilder(str.length());
    for (int i = 0; i < str.length(); i++)
    {
      char c = str.charAt(i);
      if (i < str.length() - 1)
      {
        int j = str.charAt(i + 1);
        if (c == '\\') {
          switch (j)
          {
          case 32: 
          case 44: 
          case 45: 
          case 46: 
          case 92: 
            break;
          }
        }
        if ((c == ';') && (j == 64))
        {
          i++;
          continue;
        }
      }
      localStringBuilder.append(c);
    }
    str = localStringBuilder.toString();
    str = G.matcher(str).replaceAll("");
    str = E.matcher(str).replaceAll("");
    if ((str.indexOf(';') > 0) && (str.indexOf(';') < str.length() - 1)) {
      str = str.substring(0, str.indexOf(';'));
    }
    return D.matcher(str).matches();
  }
  
  public static boolean isInternalDateFormat(int paramInt)
  {
    switch (paramInt)
    {
    case 14: 
    case 15: 
    case 16: 
    case 17: 
    case 18: 
    case 19: 
    case 20: 
    case 21: 
    case 22: 
    case 45: 
    case 46: 
    case 47: 
      return true;
    }
    return false;
  }
  
  public static boolean isValidExcelDate(double paramDouble)
  {
    return paramDouble > -4.9E-324D;
  }
  
  protected static int absoluteDay(Calendar paramCalendar, boolean paramBoolean)
  {
    return paramCalendar.get(6) + A(paramCalendar.get(1), paramBoolean);
  }
  
  private static int A(int paramInt, boolean paramBoolean)
  {
    if (((!paramBoolean) && (paramInt < 1900)) || ((paramBoolean) && (paramInt < 1900))) {
      throw new IllegalArgumentException("'year' must be 1900 or greater");
    }
    int i = paramInt - 1;
    int j = i / 4 - i / 100 + i / 400 - 460;
    return 365 * (paramInt - (paramBoolean ? 1904 : 1900)) + j;
  }
  
  private static Calendar A(Calendar paramCalendar)
  {
    paramCalendar.get(11);
    paramCalendar.set(11, 0);
    paramCalendar.set(12, 0);
    paramCalendar.set(13, 0);
    paramCalendar.set(14, 0);
    paramCalendar.get(11);
    return paramCalendar;
  }
  
  public static double convertTime(String paramString)
  {
    try
    {
      return B(paramString);
    }
    catch (_A local_A)
    {
      String str = "Bad time format '" + paramString + "' expected 'HH:MM' or 'HH:MM:SS' - " + local_A.getMessage();
      throw new IllegalArgumentException(str);
    }
  }
  
  private static double B(String paramString)
    throws DateUtil._A
  {
    int i = paramString.length();
    if ((i < 4) || (i > 8)) {
      throw new _A("Bad length");
    }
    String[] arrayOfString = B.split(paramString);
    String str1;
    switch (arrayOfString.length)
    {
    case 2: 
      str1 = "00";
      break;
    case 3: 
      str1 = arrayOfString[2];
      break;
    default: 
      throw new _A("Expected 2 or 3 fields but got (" + arrayOfString.length + ")");
    }
    String str2 = arrayOfString[0];
    String str3 = arrayOfString[1];
    int j = A(str2, "hour", 24);
    int k = A(str3, "minute", 60);
    int m = A(str1, "second", 60);
    double d = m + (k + j * 60) * 60;
    return d / 86400.0D;
  }
  
  public static Date parseYYYYMMDDDate(String paramString)
  {
    try
    {
      return A(paramString);
    }
    catch (_A local_A)
    {
      String str = "Bad time format " + paramString + " expected 'YYYY/MM/DD' - " + local_A.getMessage();
      throw new IllegalArgumentException(str);
    }
  }
  
  private static Date A(String paramString)
    throws DateUtil._A
  {
    if (paramString.length() != 10) {
      throw new _A("Bad length");
    }
    String str1 = paramString.substring(0, 4);
    String str2 = paramString.substring(5, 7);
    String str3 = paramString.substring(8, 10);
    int i = A(str1, "year", 32768, 32767);
    int j = A(str2, "month", 1, 12);
    int k = A(str3, "day", 1, 31);
    GregorianCalendar localGregorianCalendar = new GregorianCalendar(i, j - 1, k, 0, 0, 0);
    localGregorianCalendar.set(14, 0);
    return localGregorianCalendar.getTime();
  }
  
  private static int A(String paramString1, String paramString2, int paramInt)
    throws DateUtil._A
  {
    return A(paramString1, paramString2, 0, paramInt - 1);
  }
  
  private static int A(String paramString1, String paramString2, int paramInt1, int paramInt2)
    throws DateUtil._A
  {
    int i;
    try
    {
      i = Integer.parseInt(paramString1);
    }
    catch (NumberFormatException localNumberFormatException)
    {
      throw new _A("Bad int format '" + paramString1 + "' for " + paramString2 + " field");
    }
    if ((i < paramInt1) || (i > paramInt2)) {
      throw new _A(paramString2 + " value (" + i + ") is outside the allowable range(0.." + paramInt2 + ")");
    }
    return i;
  }
  
  private static final class _A
    extends Exception
  {
    public _A(String paramString)
    {
      super();
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\format\DateUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */