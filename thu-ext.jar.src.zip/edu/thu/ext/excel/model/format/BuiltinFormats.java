package edu.thu.ext.excel.model.format;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class BuiltinFormats
{
  public static final int FIRST_USER_DEFINED_FORMAT_INDEX = 164;
  private static final String[] A;
  
  static
  {
    ArrayList localArrayList = new ArrayList();
    A(localArrayList, 0, "General");
    A(localArrayList, 1, "0");
    A(localArrayList, 2, "0.00");
    A(localArrayList, 3, "#,##0");
    A(localArrayList, 4, "#,##0.00");
    A(localArrayList, 5, "$#,##0_);($#,##0)");
    A(localArrayList, 6, "$#,##0_);[Red]($#,##0)");
    A(localArrayList, 7, "$#,##0.00_);($#,##0.00)");
    A(localArrayList, 8, "$#,##0.00_);[Red]($#,##0.00)");
    A(localArrayList, 9, "0%");
    A(localArrayList, 10, "0.00%");
    A(localArrayList, 11, "0.00E+00");
    A(localArrayList, 12, "# ?/?");
    A(localArrayList, 13, "# ??/??");
    A(localArrayList, 14, "m/d/yy");
    A(localArrayList, 15, "d-mmm-yy");
    A(localArrayList, 16, "d-mmm");
    A(localArrayList, 17, "mmm-yy");
    A(localArrayList, 18, "h:mm AM/PM");
    A(localArrayList, 19, "h:mm:ss AM/PM");
    A(localArrayList, 20, "h:mm");
    A(localArrayList, 21, "h:mm:ss");
    A(localArrayList, 22, "m/d/yy h:mm");
    for (int i = 23; i <= 36; i++) {
      A(localArrayList, i, "reserved-0x" + Integer.toHexString(i));
    }
    A(localArrayList, 37, "#,##0_);(#,##0)");
    A(localArrayList, 38, "#,##0_);[Red](#,##0)");
    A(localArrayList, 39, "#,##0.00_);(#,##0.00)");
    A(localArrayList, 40, "#,##0.00_);[Red](#,##0.00)");
    A(localArrayList, 41, "_(*#,##0_);_(*(#,##0);_(* \"-\"_);_(@_)");
    A(localArrayList, 42, "_($*#,##0_);_($*(#,##0);_($* \"-\"_);_(@_)");
    A(localArrayList, 43, "_(*#,##0.00_);_(*(#,##0.00);_(*\"-\"??_);_(@_)");
    A(localArrayList, 44, "_($*#,##0.00_);_($*(#,##0.00);_($*\"-\"??_);_(@_)");
    A(localArrayList, 45, "mm:ss");
    A(localArrayList, 46, "[h]:mm:ss");
    A(localArrayList, 47, "mm:ss.0");
    A(localArrayList, 48, "##0.0E+0");
    A(localArrayList, 49, "@");
    String[] arrayOfString = new String[localArrayList.size()];
    localArrayList.toArray(arrayOfString);
    A = arrayOfString;
  }
  
  private static void A(List<String> paramList, int paramInt, String paramString)
  {
    if (paramList.size() != paramInt) {
      throw new IllegalStateException("index " + paramInt + " is wrong");
    }
    paramList.add(paramString);
  }
  
  public static Map<Integer, String> getBuiltinFormats()
  {
    LinkedHashMap localLinkedHashMap = new LinkedHashMap();
    for (int i = 0; i < A.length; i++) {
      localLinkedHashMap.put(Integer.valueOf(i), A[i]);
    }
    return localLinkedHashMap;
  }
  
  public static String[] getAll()
  {
    return (String[])A.clone();
  }
  
  public static String getBuiltinFormat(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= A.length)) {
      return null;
    }
    return A[paramInt];
  }
  
  public static int getBuiltinFormat(String paramString)
  {
    String str;
    if (paramString.equalsIgnoreCase("TEXT")) {
      str = "@";
    } else {
      str = paramString;
    }
    for (int i = 0; i < A.length; i++) {
      if (str.equals(A[i])) {
        return i;
      }
    }
    return -1;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\format\BuiltinFormats.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */