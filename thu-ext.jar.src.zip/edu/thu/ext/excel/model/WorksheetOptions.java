package edu.thu.ext.excel.model;

import edu.thu.lang.reflect.BeanInstance;
import java.io.Serializable;

public class WorksheetOptions
  implements Serializable
{
  private static final long serialVersionUID = 3165385787126414270L;
  String J;
  String L;
  PageSetup M;
  Print B;
  Panes K;
  String D;
  String I;
  int C;
  int F;
  int A;
  int H;
  boolean G;
  boolean E;
  
  public PageSetup makePageSetup()
  {
    if (this.M == null) {
      this.M = new PageSetup();
    }
    return this.M;
  }
  
  public Print makePrint()
  {
    if (this.B == null) {
      this.B = new Print();
    }
    return this.B;
  }
  
  public PageSetup getPageSetup()
  {
    return this.M;
  }
  
  public void setPageSetup(PageSetup paramPageSetup)
  {
    this.M = paramPageSetup;
  }
  
  public boolean isFreezePanes()
  {
    return this.E;
  }
  
  public void setFreezePanes(boolean paramBoolean)
  {
    this.E = paramBoolean;
  }
  
  public boolean isFitToPage()
  {
    return this.G;
  }
  
  public void setFitToPage(boolean paramBoolean)
  {
    this.G = paramBoolean;
  }
  
  public int getSplitHorizontal()
  {
    return this.C;
  }
  
  public void setSplitHorizontal(int paramInt)
  {
    this.C = paramInt;
  }
  
  public int getTopRowBottomPane()
  {
    return this.F;
  }
  
  public void setTopRowBottomPane(int paramInt)
  {
    this.F = paramInt;
  }
  
  public int getSplitVertical()
  {
    return this.A;
  }
  
  public void setSplitVertical(int paramInt)
  {
    this.A = paramInt;
  }
  
  public int getLeftColumnRightPane()
  {
    return this.H;
  }
  
  public void setLeftColumnRightPane(int paramInt)
  {
    this.H = paramInt;
  }
  
  public void setPrint(Print paramPrint)
  {
    this.B = paramPrint;
  }
  
  public boolean isHorPage()
  {
    return (this.M != null) && (this.M.isHorPage());
  }
  
  public WorksheetOptions copy()
  {
    BeanInstance localBeanInstance = new BeanInstance(this);
    return (WorksheetOptions)localBeanInstance.cloneInstance(false);
  }
  
  public void setUnsynced(String paramString)
  {
    this.J = paramString;
  }
  
  public String getUnsynced()
  {
    return this.J;
  }
  
  public void setSelect(String paramString)
  {
    this.L = paramString;
  }
  
  public String getSelect()
  {
    return this.L;
  }
  
  public Print getPrint()
  {
    return this.B;
  }
  
  public void setPanes(Panes paramPanes)
  {
    this.K = paramPanes;
  }
  
  public Panes getPanes()
  {
    return this.K;
  }
  
  public void setProtectObjects(String paramString)
  {
    this.D = paramString;
  }
  
  public String getProtectObjects()
  {
    return this.D;
  }
  
  public void setProtectScenarios(String paramString)
  {
    this.I = paramString;
  }
  
  public String getProtectScenarios()
  {
    return this.I;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\WorksheetOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */