package edu.thu.ext.excel.model;

public class Comment
{
  String C;
  String B;
  Font A;
  
  public void setText(String paramString)
  {
    this.C = paramString;
  }
  
  public String getText()
  {
    return this.C;
  }
  
  public void setAuthor(String paramString)
  {
    this.B = paramString;
  }
  
  public String getAuthor()
  {
    return this.B;
  }
  
  public void setFont(Font paramFont)
  {
    this.A = paramFont;
  }
  
  public Font getFont()
  {
    return this.A;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\Comment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */