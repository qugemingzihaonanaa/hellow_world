package edu.thu.ext.excel.model;

import edu.thu.model.tree.TreeNode;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Font
  implements Serializable
{
  private static final long serialVersionUID = 7430295018851276067L;
  public static final int U_NONE = 0;
  public static final int U_SINGLE = 1;
  public static final int U_DOUBLE = 2;
  public static final int U_SINGLE_ACCOUNTING = 33;
  public static final int U_DOUBLE_ACCOUNTING = 34;
  public static final int VALIGN_NONE = 0;
  public static final int VALIGN_SUPER = 1;
  public static final int VALIGN_SUB = 2;
  public static final short BOLDWEIGHT_NORMAL = 400;
  public static final short BOLDWEIGHT_BOLD = 700;
  public static final String SUB_NAME = "Sub";
  public static final String SUP_NAME = "Sup";
  public static final String FONT_NAME = "Font";
  public static final String HTML_FACE_NAME = "html:Face";
  public static final String HTML_SIZE_NAME = "html:Size";
  public static final String HTML_COLOR_NAME = "html:Color";
  public static final String X_CHARSET_NAME = "x:CharSet";
  public static final String X_FAMILY_NAME = "x:Family";
  public static final String U_NAME = "U";
  public static final String B_NAME = "B";
  public static final String I_NAME = "I";
  public static final String S_NAME = "S";
  int G;
  int E;
  String F;
  String J;
  String C;
  boolean D;
  boolean H;
  boolean B;
  int I;
  int A;
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == null) {
      return false;
    }
    if (paramObject.getClass() != getClass()) {
      return false;
    }
    Font localFont = (Font)paramObject;
    return (this.G == localFont.G) && (this.E == localFont.E) && (this.F == null ? localFont.F == null : this.F.equals(localFont.F)) && (this.J == null ? localFont.J == null : this.J.equals(localFont.J)) && (this.C == null ? localFont.C == null : this.C.equals(localFont.C)) && (this.D == localFont.D) && (this.H == localFont.H) && (this.B == localFont.B) && (this.I == localFont.I) && (this.A == localFont.A);
  }
  
  public int hashCode()
  {
    int i = 0;
    i = this.G;
    i = 31 * i + this.E;
    i = 31 * i + (this.F != null ? this.F.hashCode() : 0);
    i = 31 * i + (this.J != null ? this.J.hashCode() : 0);
    i = 31 * i + (this.C != null ? this.C.hashCode() : 0);
    i = 31 * i + (this.D ? 1 : 0);
    i = 31 * i + (this.H ? 1 : 0);
    i = 31 * i + (this.B ? 1 : 0);
    i = 31 * i + this.I;
    i = 31 * i + this.A;
    return i;
  }
  
  public Font copy()
  {
    Font localFont = new Font();
    localFont.G = this.G;
    localFont.E = this.E;
    localFont.F = this.F;
    localFont.J = this.J;
    localFont.C = this.C;
    localFont.D = this.D;
    localFont.H = this.H;
    localFont.B = this.B;
    localFont.I = this.I;
    localFont.A = this.A;
    return localFont;
  }
  
  public TreeNode buildRichTextNode(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    if (this.H) {
      localArrayList.add(TreeNode.make("B"));
    }
    if (this.D) {
      localArrayList.add(TreeNode.make("I"));
    }
    if (this.I != 0) {
      localArrayList.add(TreeNode.make("U"));
    }
    if (this.B) {
      localArrayList.add(TreeNode.make("S"));
    }
    if (isSuperscript()) {
      localArrayList.add(TreeNode.make("Sup"));
    }
    if (isSubscript()) {
      localArrayList.add(TreeNode.make("Sub"));
    }
    if ((this.F != null) || (this.G > 0) || (this.C != null))
    {
      localTreeNode1 = TreeNode.make("Font");
      if (this.F != null) {
        localTreeNode1.setAttribute("html:Face", this.F);
      }
      if (this.J != null) {
        localTreeNode1.setAttribute("x:Family", this.J);
      }
      if (this.G > 0) {
        localTreeNode1.setAttribute("html:Size", getFontSize());
      }
      if (this.C != null) {
        localTreeNode1.setAttribute("html:Color", this.C);
      }
      localArrayList.add(localTreeNode1);
    }
    if (localArrayList.isEmpty())
    {
      localTreeNode1 = TreeNode.make("#text");
      localArrayList.add(localTreeNode1);
    }
    TreeNode localTreeNode1 = (TreeNode)localArrayList.get(localArrayList.size() - 1);
    localTreeNode1.setValue(paramString);
    Object localObject = localTreeNode1;
    for (int i = localArrayList.size() - 2; i >= 0; i--)
    {
      TreeNode localTreeNode2 = (TreeNode)localArrayList.get(i);
      localTreeNode2.appendChild((TreeNode)localObject);
      localObject = localTreeNode2;
    }
    return (TreeNode)localArrayList.get(0);
  }
  
  public void toCssStyle(StringBuilder paramStringBuilder)
  {
    if (this.F != null)
    {
      paramStringBuilder.append("font-family:");
      paramStringBuilder.append(this.F).append(";\r\n");
    }
    if (this.H) {
      paramStringBuilder.append("font-weight:bold;\r\n");
    }
    if (this.D) {
      paramStringBuilder.append("font-style:italic;\r\n");
    }
    if (this.G > 0) {
      paramStringBuilder.append("font-size:").append(this.G / 20.0D).append("pt;\r\n");
    }
    if (this.C != null) {
      paramStringBuilder.append("color:").append(this.C).append(";\r\n");
    }
    switch (this.I)
    {
    case 0: 
      break;
    case 33: 
      paramStringBuilder.append("text-decoration:underline;\r\n");
      paramStringBuilder.append("text-underline-style:single-accounting;\r\n");
      break;
    case 1: 
    default: 
      paramStringBuilder.append("text-decoration:underline;\r\n");
    }
  }
  
  public void toWmlStyle(StringBuilder paramStringBuilder)
  {
    if (this.F != null) {
      paramStringBuilder.append("<w:rFonts w:ascii=\"").append(this.F).append("\" w:fareast=\"").append(this.F).append("\" w:hint=\"fareast\"/>");
    }
    if (this.C != null) {
      paramStringBuilder.append("<w:color w:val=\"").append(this.C).append("\"/>");
    }
    if (this.G > 0) {
      paramStringBuilder.append("<w:sz w:val=\"").append(getFontSize().doubleValue() * 2.0D).append("\"/>");
    }
    if (this.H) {
      paramStringBuilder.append("<w:b/>");
    }
    if (this.D) {
      paramStringBuilder.append("<w:i/>");
    }
    if (isSubscript()) {
      paramStringBuilder.append("<w:vertAlign w:val=\"subscript\"/>");
    } else if (isSuperscript()) {
      paramStringBuilder.append("<w:vertAlign w:val=\"superscript\"/>");
    }
  }
  
  void A(StringBuilder paramStringBuilder, String paramString, Object paramObject)
  {
    if (paramObject != null) {
      paramStringBuilder.append(" ").append(paramString).append("=\"").append(paramObject).append("\"");
    }
  }
  
  String A(boolean paramBoolean)
  {
    return paramBoolean ? "1" : null;
  }
  
  public void toXlsStyle(StringBuilder paramStringBuilder)
  {
    if (this.F != null)
    {
      paramStringBuilder.append("<Font ");
      A(paramStringBuilder, "ss:FontName", this.F);
      if (this.E > 0) {
        A(paramStringBuilder, "x:CharSet", Integer.valueOf(this.E));
      }
      if (this.J != null) {
        A(paramStringBuilder, "x:Family", this.J);
      }
      A(paramStringBuilder, "ss:Size", getFontSize());
      A(paramStringBuilder, "ss:Color", this.C);
      A(paramStringBuilder, "ss:Bold", A(this.H));
      A(paramStringBuilder, "ss:Italic", A(this.D));
      A(paramStringBuilder, "ss:Underline", getXlsUnderline());
      paramStringBuilder.append(" />");
    }
  }
  
  public String getXlsUnderline()
  {
    switch (this.I)
    {
    case 0: 
      return null;
    case 1: 
      return "Single";
    case 2: 
      return "Double";
    case 33: 
      return "SingleAccounting";
    case 34: 
      return "DoubleAccounting";
    }
    return null;
  }
  
  public void setXlsUnderline(String paramString)
  {
    if (paramString == null) {
      this.I = 0;
    } else if ("Single".equals(paramString)) {
      this.I = 1;
    } else if ("Double".equals(paramString)) {
      this.I = 2;
    } else if ("SingleAccounting".equals(paramString)) {
      this.I = 33;
    } else if ("DoubleAccounting".equals(paramString)) {
      this.I = 34;
    } else {
      this.I = 0;
    }
  }
  
  public String getXlsVerticalAlign()
  {
    switch (this.A)
    {
    case 0: 
      return null;
    case 1: 
      return "Superscript";
    case 2: 
      return "Subscript";
    }
    return null;
  }
  
  public void setXlsVerticalAlign(String paramString)
  {
    if (paramString == null) {
      this.A = 0;
    } else if ("Superscript".equals(paramString)) {
      this.A = 1;
    } else if ("Subscript".equals(paramString)) {
      this.A = 2;
    } else {
      this.A = 0;
    }
  }
  
  public int getBoldWeight()
  {
    return this.H ? 700 : 400;
  }
  
  public boolean isSuperscript()
  {
    return this.A == 1;
  }
  
  public boolean isSubscript()
  {
    return this.A == 2;
  }
  
  public int getFontColorValue()
  {
    if (this.C == null) {
      return 0;
    }
    return Integer.decode(this.C).intValue();
  }
  
  public Double getFontSize()
  {
    if (this.G <= 0) {
      return null;
    }
    return Double.valueOf(this.G / 20.0D);
  }
  
  public void setFontSize(Double paramDouble)
  {
    if (paramDouble == null) {
      this.G = 0;
    } else {
      this.G = ((int)(paramDouble.doubleValue() * 20.0D));
    }
  }
  
  public boolean isUnderline()
  {
    return this.I != 0;
  }
  
  public void setUnderline(boolean paramBoolean)
  {
    this.I = (paramBoolean ? 1 : 0);
  }
  
  public int getCharSet()
  {
    return this.E;
  }
  
  public void setCharSet(int paramInt)
  {
    this.E = paramInt;
  }
  
  public String getFontName()
  {
    return this.F;
  }
  
  public void setFontName(String paramString)
  {
    this.F = paramString;
  }
  
  public String getFontFamily()
  {
    return this.J;
  }
  
  public void setFontFamily(String paramString)
  {
    this.J = paramString;
  }
  
  public String getFontColor()
  {
    return this.C;
  }
  
  public void setFontColor(String paramString)
  {
    this.C = paramString;
  }
  
  public boolean isItalic()
  {
    return this.D;
  }
  
  public void setItalic(boolean paramBoolean)
  {
    this.D = paramBoolean;
  }
  
  public boolean isBold()
  {
    return this.H;
  }
  
  public void setBold(boolean paramBoolean)
  {
    this.H = paramBoolean;
  }
  
  public boolean isStrikeout()
  {
    return this.B;
  }
  
  public void setStrikeout(boolean paramBoolean)
  {
    this.B = paramBoolean;
  }
  
  public int getFontHeight()
  {
    return this.G;
  }
  
  public void setFontHeight(int paramInt)
  {
    this.G = paramInt;
  }
  
  public int getUnderlineStyle()
  {
    return this.I;
  }
  
  public void setUnderlineStyle(int paramInt)
  {
    this.I = paramInt;
  }
  
  public int getVerticalAlign()
  {
    return this.A;
  }
  
  public void setVerticalAlign(int paramInt)
  {
    this.A = paramInt;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\Font.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */