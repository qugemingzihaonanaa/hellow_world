package edu.thu.ext.excel.model;

import java.io.Serializable;

public class Range
  implements Serializable
{
  private static final long serialVersionUID = 4927341546694179356L;
  public static final int MERGE_COL = 2;
  public static final int MERGE_ROW = 3;
  public static final int MERGE_BLOCK = 4;
  public static final int MERGE_NONE = 0;
  public static final int MERGE_INNER_ROW = 5;
  public static final int MERGE_INNER_BLOCK = 6;
  String A;
  int B = 0;
  int D = 0;
  int C = Integer.MAX_VALUE;
  int E = Integer.MAX_VALUE;
  
  public Range() {}
  
  public Range(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.A = paramString;
    this.B = paramInt1;
    this.D = paramInt2;
    this.C = paramInt3;
    this.E = paramInt4;
  }
  
  public Range(Range paramRange)
  {
    this.A = paramRange.A;
    this.B = paramRange.B;
    this.D = paramRange.D;
    this.C = paramRange.C;
    this.E = paramRange.E;
  }
  
  public Range copy()
  {
    return new Range(this);
  }
  
  public static Range row(String paramString, int paramInt1, int paramInt2)
  {
    Range localRange = new Range();
    localRange.B = paramInt1;
    localRange.C = paramInt2;
    localRange.A = paramString;
    return localRange;
  }
  
  public static Range col(String paramString, int paramInt1, int paramInt2)
  {
    Range localRange = new Range();
    localRange.D = paramInt1;
    localRange.E = paramInt2;
    localRange.A = paramString;
    return localRange;
  }
  
  public int getOccupyCellCount()
  {
    if ((isColMode()) || (isRowMode())) {
      return Integer.MAX_VALUE;
    }
    return (this.C - this.D + 1) * (this.E - this.D + 1);
  }
  
  public int getMergeStatus(int paramInt1, int paramInt2)
  {
    if ((this.B == paramInt1) && (this.D == paramInt2))
    {
      if (isSingleRow()) {
        return 2;
      }
      if (isSingleCol()) {
        return 3;
      }
      return 4;
    }
    if (contains(paramInt1, paramInt2))
    {
      if (isSingleRow()) {
        return 5;
      }
      return 6;
    }
    return 0;
  }
  
  public static final boolean isInRange(int paramInt)
  {
    return paramInt > 0;
  }
  
  public static final boolean isRangeAt(int paramInt)
  {
    return (paramInt > 0) && (paramInt < 5);
  }
  
  public static boolean isMergeMultiRow(int paramInt)
  {
    return (paramInt == 3) || (paramInt == 4);
  }
  
  public boolean containsRow(int paramInt)
  {
    return (this.B <= paramInt) && (this.C >= paramInt);
  }
  
  public boolean contains(int paramInt1, int paramInt2)
  {
    return (this.B <= paramInt1) && (this.C >= paramInt1) && (this.D <= paramInt2) && (this.E >= paramInt2);
  }
  
  public boolean containsRange(Range paramRange)
  {
    return (this.B <= paramRange.getLtRow()) && (this.C >= paramRange.getRbRow()) && (this.D <= paramRange.getLtCol()) && (this.E >= paramRange.getRbCol());
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof Range)) {
      return false;
    }
    Range localRange = (Range)paramObject;
    return (this.B == localRange.B) && (this.D == localRange.D) && (this.C == localRange.C) && (this.E == localRange.E);
  }
  
  public boolean isColMode()
  {
    return (this.B <= 0) && (this.C >= Integer.MAX_VALUE);
  }
  
  public boolean isRowMode()
  {
    return (this.D <= 0) && (this.E >= Integer.MAX_VALUE);
  }
  
  public boolean isSingleRow()
  {
    return this.B == this.C;
  }
  
  public boolean isSingleCol()
  {
    return this.D == this.E;
  }
  
  public boolean isSingleCell()
  {
    return (isSingleRow()) && (isSingleCol());
  }
  
  public boolean isManyRowCol()
  {
    return (this.C > this.B) && (this.E > this.D) && (!isColMode()) && (!isRowMode());
  }
  
  public String getRangeExpr()
  {
    String str = this.A + "!";
    if (isColMode())
    {
      if (isSingleCol()) {
        str = str + "C" + (this.D + 1);
      } else {
        str = str + "C" + (this.D + 1) + ":C" + (this.E + 1);
      }
    }
    else if (isRowMode())
    {
      if (isSingleRow()) {
        str = str + "R" + (this.B + 1);
      } else {
        str = str + "R" + (this.B + 1) + ":R" + (this.C + 1);
      }
    }
    else if (isSingleCell()) {
      str = str + "R" + (this.B + 1) + "C" + (this.D + 1);
    } else {
      str = str + "R" + (this.B + 1) + "C" + (this.D + 1) + ":" + "R" + (this.C + 1) + "C" + (this.E + 1);
    }
    return str;
  }
  
  public String toString()
  {
    return getRangeExpr();
  }
  
  public int getMinRow()
  {
    return this.B;
  }
  
  public int getMaxRow()
  {
    return this.C;
  }
  
  public int getMinCol()
  {
    return this.D;
  }
  
  public int getMaxCol()
  {
    return this.E;
  }
  
  public int getLtCol()
  {
    return this.D;
  }
  
  public void setLtCol(int paramInt)
  {
    this.D = paramInt;
  }
  
  public int getLtRow()
  {
    return this.B;
  }
  
  public void setLtRow(int paramInt)
  {
    this.B = paramInt;
  }
  
  public int getRbCol()
  {
    return this.E;
  }
  
  public void setRbCol(int paramInt)
  {
    this.E = paramInt;
  }
  
  public int getRbRow()
  {
    return this.C;
  }
  
  public void setRbRow(int paramInt)
  {
    this.C = paramInt;
  }
  
  public String getSheetName()
  {
    return this.A;
  }
  
  public void setSheetName(String paramString)
  {
    this.A = paramString;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\Range.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */