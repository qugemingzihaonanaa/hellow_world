package edu.thu.ext.excel.model;

import edu.thu.lang.reflect.BeanInstance;
import java.io.Serializable;

public class DocumentProperties
  implements Serializable
{
  private static final long serialVersionUID = 8451775656757760815L;
  String D;
  String B;
  String E;
  String A;
  String C;
  
  public DocumentProperties copy()
  {
    return (DocumentProperties)new BeanInstance(this).cloneInstance(false);
  }
  
  public String getLastSaved()
  {
    return this.C;
  }
  
  public void setLastSaved(String paramString)
  {
    this.C = paramString;
  }
  
  public void setAuthor(String paramString)
  {
    this.D = paramString;
  }
  
  public String getAuthor()
  {
    return this.D;
  }
  
  public void setLastAuthor(String paramString)
  {
    this.B = paramString;
  }
  
  public String getLastAuthor()
  {
    return this.B;
  }
  
  public void setCreated(String paramString)
  {
    this.E = paramString;
  }
  
  public String getCreated()
  {
    return this.E;
  }
  
  public void setVersion(String paramString)
  {
    this.A = paramString;
  }
  
  public String getVersion()
  {
    return this.A;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\DocumentProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */