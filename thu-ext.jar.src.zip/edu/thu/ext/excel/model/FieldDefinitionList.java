package edu.thu.ext.excel.model;

import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.util.Coercions;
import edu.thu.lang.exceptions.ErrorInfo;
import edu.thu.lang.exceptions.StdException;
import edu.thu.math.alg.Alog;
import edu.thu.model.stg.ds.EnumLoader;
import edu.thu.model.stg.ds.IEnumInfo;
import edu.thu.service.SystemServiceContext;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class FieldDefinitionList
  implements Serializable
{
  private static final long serialVersionUID = 4277356119872703172L;
  List<FieldDefinition> A = new ArrayList();
  List<FieldDefinition> C = new ArrayList();
  boolean B = false;
  
  public FieldDefinitionList copy()
  {
    FieldDefinitionList localFieldDefinitionList = new FieldDefinitionList();
    localFieldDefinitionList.A.addAll(this.A);
    localFieldDefinitionList.C.addAll(this.C);
    localFieldDefinitionList.B = this.B;
    return localFieldDefinitionList;
  }
  
  public boolean isAllowDuplicateField()
  {
    return this.B;
  }
  
  public void setAllowDuplicateField(boolean paramBoolean)
  {
    this.B = paramBoolean;
  }
  
  public List<FieldDefinition> getFieldDefinitions()
  {
    return this.A;
  }
  
  public boolean hasFieldDefinition(String paramString)
  {
    if (paramString == null) {
      return false;
    }
    Iterator localIterator = this.A.iterator();
    while (localIterator.hasNext())
    {
      FieldDefinition localFieldDefinition = (FieldDefinition)localIterator.next();
      if (paramString.equals(localFieldDefinition.getName())) {
        return true;
      }
    }
    return false;
  }
  
  public FieldDefinition getFieldDefinition(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    Iterator localIterator = this.A.iterator();
    while (localIterator.hasNext())
    {
      FieldDefinition localFieldDefinition = (FieldDefinition)localIterator.next();
      if (paramString.equals(localFieldDefinition.getName())) {
        return localFieldDefinition;
      }
    }
    return null;
  }
  
  public FieldDefinition getFieldDefinitionByShortName(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    Iterator localIterator = this.A.iterator();
    while (localIterator.hasNext())
    {
      FieldDefinition localFieldDefinition = (FieldDefinition)localIterator.next();
      if (paramString.equals(localFieldDefinition.getShortName())) {
        return localFieldDefinition;
      }
    }
    return null;
  }
  
  String A(String paramString)
  {
    return ExcelModelUtils.encodeParamName(paramString, true);
  }
  
  void B(String paramString)
  {
    Iterator localIterator = this.C.iterator();
    while (localIterator.hasNext())
    {
      FieldDefinition localFieldDefinition = (FieldDefinition)localIterator.next();
      if ((!localFieldDefinition.isUseFullName()) && (localFieldDefinition.getName().equals(paramString)))
      {
        localFieldDefinition.setName(paramString + "_" + A(localFieldDefinition.getGroupName()));
        localFieldDefinition.setUseFullName(true);
      }
    }
  }
  
  public void addFieldDefinition(String paramString, FieldDefinition paramFieldDefinition)
  {
    Debug.check(!paramFieldDefinition.isUseFullName());
    paramFieldDefinition.setGroupName(paramString);
    String str = paramFieldDefinition.getShortName();
    if (str == null) {
      throw Exceptions.code("xpt.CAN_err_field_no_name").param(paramFieldDefinition);
    }
    FieldDefinition localFieldDefinition = getFieldDefinitionByShortName(str);
    if (localFieldDefinition == null)
    {
      this.A.add(paramFieldDefinition);
      this.C.add(paramFieldDefinition);
      return;
    }
    this.C.add(paramFieldDefinition);
    if ((A(paramFieldDefinition, localFieldDefinition)) && (paramFieldDefinition.isDynamicField()))
    {
      B(str);
      this.A.add(paramFieldDefinition);
    }
    B(paramFieldDefinition, localFieldDefinition);
  }
  
  boolean A(FieldDefinition paramFieldDefinition1, FieldDefinition paramFieldDefinition2)
  {
    boolean bool = (paramFieldDefinition1.getListType() == 1) || (paramFieldDefinition2.getListType() == 1);
    if (!bool)
    {
      String str1 = paramFieldDefinition1.getExtIndex();
      String str2 = paramFieldDefinition2.getExtIndex();
      bool = (str1 == null) || (str2 == null);
      if (!bool) {
        bool = str1.equals(str2);
      }
    }
    return bool;
  }
  
  void B(FieldDefinition paramFieldDefinition1, FieldDefinition paramFieldDefinition2)
  {
    if (!paramFieldDefinition1.getName().equals(paramFieldDefinition2.getName())) {
      return;
    }
    if (!this.B)
    {
      boolean bool = (paramFieldDefinition1.getListType() == 1) || (paramFieldDefinition2.getListType() == 1);
      if (!bool)
      {
        String str1 = paramFieldDefinition1.getExtIndex();
        String str2 = paramFieldDefinition2.getExtIndex();
        bool = (str1 == null) || (str2 == null);
        if (!bool) {
          bool = str1.equals(str2);
        }
      }
      if (bool) {
        throw Exceptions.code("xpt.CAN_err_duplicate_field").param(paramFieldDefinition1).param(paramFieldDefinition2);
      }
    }
  }
  
  public void addFieldDefinition(FieldDefinition paramFieldDefinition)
  {
    if (paramFieldDefinition.getName() == null) {
      throw Exceptions.code("xpt.CAN_err_field_no_name").param(paramFieldDefinition);
    }
    if (!hasFieldDefinition(paramFieldDefinition.getName())) {
      this.A.add(paramFieldDefinition);
    }
  }
  
  public List<FieldDefinition> getFieldDefinitionsWithPrefix(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = this.A.iterator();
    while (localIterator.hasNext())
    {
      FieldDefinition localFieldDefinition = (FieldDefinition)localIterator.next();
      if (localFieldDefinition.getName().startsWith(paramString)) {
        localArrayList.add(localFieldDefinition);
      }
    }
    return localArrayList;
  }
  
  public List<String> getFieldNamesWithPrefix(String paramString)
  {
    return Alog.pluck(getFieldDefinitionsWithPrefix(paramString), "name");
  }
  
  public List<String> getFieldNames()
  {
    return Alog.pluck(this.A, "name");
  }
  
  public List<FieldDefinition> getFieldDefinitionsNotWith(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = this.A.iterator();
    while (localIterator.hasNext())
    {
      FieldDefinition localFieldDefinition = (FieldDefinition)localIterator.next();
      if (localFieldDefinition.getName().indexOf(paramString) >= 0) {
        localArrayList.add(localFieldDefinition);
      }
    }
    return localArrayList;
  }
  
  public List<FieldDefinition> getFieldsByNames(List<String> paramList)
  {
    if (paramList == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(paramList.size());
    int j = paramList.size();
    for (int i = 0; i < j; i++) {
      localArrayList.add(getFieldDefinition((String)paramList.get(i)));
    }
    return localArrayList;
  }
  
  public void updateFieldCell()
  {
    Iterator localIterator = this.C.iterator();
    while (localIterator.hasNext())
    {
      FieldDefinition localFieldDefinition = (FieldDefinition)localIterator.next();
      Cell localCell = localFieldDefinition.getCell();
      if (localCell != null) {
        localCell.setData("*=" + localFieldDefinition.getName());
      }
    }
  }
  
  public List<FieldDefinition> getAllFields()
  {
    return this.C;
  }
  
  public Map<String, IEnumInfo> getEnums()
  {
    HashMap localHashMap = new HashMap();
    Iterator localIterator = this.C.iterator();
    while (localIterator.hasNext())
    {
      FieldDefinition localFieldDefinition = (FieldDefinition)localIterator.next();
      if (localFieldDefinition.getEnum() != null)
      {
        IEnumInfo localIEnumInfo = EnumLoader.loadEnum(localFieldDefinition.getEnum(), SystemServiceContext.getInstance());
        if (localIEnumInfo != null) {
          localHashMap.put(localFieldDefinition.getName(), localIEnumInfo);
        }
      }
    }
    return localHashMap;
  }
  
  public Map<String, Object> getAllFieldData(Workbook paramWorkbook)
  {
    LinkedHashMap localLinkedHashMap = new LinkedHashMap();
    Iterator localIterator = this.C.iterator();
    while (localIterator.hasNext())
    {
      FieldDefinition localFieldDefinition = (FieldDefinition)localIterator.next();
      Object localObject1 = localFieldDefinition.getFieldData(paramWorkbook);
      if (localFieldDefinition.isListField())
      {
        Object localObject2 = localLinkedHashMap.get(localFieldDefinition.getName());
        Object localObject3;
        if (localObject2 != null)
        {
          if ((localObject2 instanceof List))
          {
            localObject3 = (List)localObject2;
          }
          else
          {
            localObject3 = new ArrayList();
            ((List)localObject3).add(localObject2);
          }
        }
        else {
          localObject3 = new ArrayList();
        }
        ((List)localObject3).add(localObject1);
        localLinkedHashMap.put(localFieldDefinition.getName(), localObject3);
      }
      else
      {
        localLinkedHashMap.put(localFieldDefinition.getName(), localObject1);
      }
    }
    return localLinkedHashMap;
  }
  
  public List<ErrorInfo> checkAllFieldData(Workbook paramWorkbook, String paramString, List<String> paramList)
  {
    ArrayList localArrayList1 = new ArrayList();
    Iterator localIterator = this.C.iterator();
    while (localIterator.hasNext())
    {
      FieldDefinition localFieldDefinition = (FieldDefinition)localIterator.next();
      if ((paramList == null) || (!paramList.contains(localFieldDefinition.getName())))
      {
        Object localObject = localFieldDefinition.getFieldData(paramWorkbook);
        if (localObject != null)
        {
          String str = localObject.toString();
          if ((str.trim().length() > 0) && (localFieldDefinition.isNumberType(paramString)))
          {
            double d = Coercions.toDouble(str, Double.MAX_VALUE);
            if (d == Double.MAX_VALUE)
            {
              ErrorInfo localErrorInfo = new ErrorInfo();
              localErrorInfo.setErrorCode("excel.CAN_err_not_number_cell");
              ArrayList localArrayList2 = new ArrayList();
              localArrayList2.add(localObject);
              localArrayList2.add(localFieldDefinition.getCell().toString());
              localErrorInfo.setExtParams(localArrayList2);
              localArrayList1.add(localErrorInfo);
            }
          }
        }
      }
    }
    return localArrayList1;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\FieldDefinitionList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */