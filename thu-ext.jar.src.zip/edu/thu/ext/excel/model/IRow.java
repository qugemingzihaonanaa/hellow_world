package edu.thu.ext.excel.model;

import java.util.List;

public abstract interface IRow
{
  public abstract int getIndex();
  
  public abstract int getColCount();
  
  public abstract ICell getCell(int paramInt);
  
  public abstract List<? extends ICell> getCells();
  
  public abstract double getHeight();
  
  public abstract boolean isHidden();
  
  public abstract boolean isParagraphRow();
  
  public abstract boolean isBlank();
  
  public abstract List<Object> getRowValues();
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\IRow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */