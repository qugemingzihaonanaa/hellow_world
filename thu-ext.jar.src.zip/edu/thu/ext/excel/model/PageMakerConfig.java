package edu.thu.ext.excel.model;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.util.TplC;
import edu.thu.model.stg.view.PageMaker;
import edu.thu.model.tree.TreeNode;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PageMakerConfig
  implements Serializable
{
  private static final long serialVersionUID = 7924756752955799014L;
  List<Item> A = new ArrayList();
  
  public List<Item> getItems()
  {
    return this.A;
  }
  
  public Map<String, PageMaker> makePageMakers(Map<String, Object> paramMap)
  {
    HashMap localHashMap = new HashMap();
    int j = this.A.size();
    for (int i = 0; i < j; i++)
    {
      Item localItem = (Item)this.A.get(i);
      PageMaker localPageMaker = localItem.A(paramMap);
      localHashMap.put(localItem.var, localPageMaker);
    }
    return localHashMap;
  }
  
  public Item getMiddlePage(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    int j = this.A.size();
    for (int i = 0; i < j; i++)
    {
      Item localItem = (Item)this.A.get(i);
      if (paramString.equals(localItem.pageMiddleSheet)) {
        return localItem;
      }
    }
    return null;
  }
  
  public void addItem(Item paramItem)
  {
    if (!paramItem.A()) {
      throw Exceptions.code("excel.CAN_err_invalid_page_maker_item").param(paramItem);
    }
    this.A.add(paramItem);
  }
  
  public void adjustWorkbook(TreeNode paramTreeNode)
  {
    int j = this.A.size();
    for (int i = 0; i < j; i++)
    {
      Item localItem = (Item)this.A.get(i);
      TreeNode localTreeNode1;
      TreeNode localTreeNode4;
      TreeNode localTreeNode5;
      TreeNode localTreeNode6;
      if (localItem.singlePage)
      {
        localTreeNode1 = ExcelModelUtils.getSheetNode(paramTreeNode, localItem.pageBeginSheet);
        int k = ExcelModelUtils.getRowCount(localTreeNode1.makeChild("Table"));
        localTreeNode4 = TreeNode.make("ns1:XlsPageSingleBreak");
        localTreeNode4.setAttribute("rowCount", Integer.valueOf(k));
        localTreeNode4.setAttribute("varName", localItem.var);
        ExcelModelUtils.addRowBreak(localTreeNode1, localTreeNode4);
        localTreeNode5 = TreeNode.make("ns1:WrapMakePageSingle");
        localTreeNode5.setAttribute("varName", localItem.var);
        ExcelModelUtils.addParent(localTreeNode1, localTreeNode5);
        localTreeNode6 = TreeNode.make("ns1:MakePageSingle");
        localTreeNode6.setAttribute("varName", localItem.var);
        ExcelModelUtils.wrapRows(localTreeNode1.makeChild("Table"), localTreeNode6);
      }
      else
      {
        if (localItem.pageBeginSheet != null)
        {
          localTreeNode1 = ExcelModelUtils.getSheetNode(paramTreeNode, localItem.pageBeginSheet);
          TreeNode localTreeNode2 = TreeNode.make("ns1:WrapMakePageBegin");
          localTreeNode2.setAttribute("varName", localItem.var);
          ExcelModelUtils.addParent(localTreeNode1, localTreeNode2);
        }
        if (localItem.pageMiddleSheet != null)
        {
          localTreeNode1 = ExcelModelUtils.getSheetNode(paramTreeNode, localItem.pageMiddleSheet);
          int m = ExcelModelUtils.getRowCount(localTreeNode1.makeChild("Table"));
          localTreeNode4 = TreeNode.make("ns1:XlsPageMiddleBreak");
          localTreeNode4.setAttribute("rowCount", Integer.valueOf(m));
          localTreeNode4.setAttribute("varName", localItem.var);
          ExcelModelUtils.addRowBreak(localTreeNode1, localTreeNode4);
          localTreeNode5 = TreeNode.make("ns1:WrapMakePageMiddle");
          localTreeNode5.setAttribute("varName", localItem.var);
          ExcelModelUtils.addParent(localTreeNode1, localTreeNode5);
          localTreeNode6 = TreeNode.make("ns1:MakePageMiddle");
          localTreeNode6.setAttribute("varName", localItem.var);
          ExcelModelUtils.wrapRows(localTreeNode1.makeChild("Table"), localTreeNode6);
        }
        TreeNode localTreeNode3;
        if (localItem.pageEndSheet != null)
        {
          localTreeNode1 = ExcelModelUtils.getSheetNode(paramTreeNode, localItem.pageEndSheet);
          localTreeNode3 = TreeNode.make("ns1:WrapMakePageEnd");
          localTreeNode3.setAttribute("varName", localItem.var);
          ExcelModelUtils.addParent(localTreeNode1, localTreeNode3);
        }
        if (localItem.pageAllSheet != null)
        {
          localTreeNode1 = ExcelModelUtils.getSheetNode(paramTreeNode, localItem.pageAllSheet);
          localTreeNode3 = TreeNode.make("ns1:WrapMakePageAll");
          localTreeNode3.setAttribute("varName", localItem.var);
          ExcelModelUtils.addParent(localTreeNode1, localTreeNode3);
        }
      }
    }
  }
  
  public static class Item
    implements Serializable
  {
    private static final long serialVersionUID = -1534512432294407994L;
    public String var;
    public String pageBeginSheet;
    public String pageMiddleSheet;
    public String pageEndSheet;
    public String pageAllSheet;
    public int pageBeginCount;
    public int pageMiddleCount;
    public int pageEndCount;
    public int pageAllCount;
    public boolean singlePage;
    
    boolean A()
    {
      return this.var != null;
    }
    
    PageMaker A(Map<String, Object> paramMap)
    {
      PageMaker localPageMaker = new PageMaker();
      localPageMaker.initViewer(TplC.getToken(paramMap, this.var));
      localPageMaker.setPageBeginCount(this.pageBeginCount);
      localPageMaker.setPageMiddleCount(this.pageMiddleCount);
      localPageMaker.setPageEndCount(this.pageEndCount);
      localPageMaker.setPageAllCount(this.pageAllCount);
      localPageMaker.setSinglePage(this.singlePage);
      return localPageMaker;
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\PageMakerConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */