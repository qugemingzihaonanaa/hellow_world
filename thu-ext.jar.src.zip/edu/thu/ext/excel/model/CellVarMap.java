package edu.thu.ext.excel.model;

import edu.thu.java.util.Coercions;
import edu.thu.lang.el.IExpressionReference;
import edu.thu.lang.util.TplC;
import edu.thu.service.IServiceContext;
import edu.thu.service.SystemServiceContext;
import edu.thu.util.StringUtils;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class CellVarMap
  implements Serializable
{
  private static final long serialVersionUID = 2035946184826551163L;
  IExpressionReference B;
  Map<String, IExpressionReference> A;
  
  public IExpressionReference getFieldExpr()
  {
    return this.B;
  }
  
  public void setFieldExpr(IExpressionReference paramIExpressionReference)
  {
    this.B = paramIExpressionReference;
  }
  
  public void parseFromCell(Cell paramCell, TplC paramTplC)
  {
    IServiceContext localIServiceContext = SystemServiceContext.getInstance();
    this.B = paramTplC.parseEvalExpr(paramCell.getData(), localIServiceContext);
    Map localMap = paramCell.getCommentVars();
    A(localMap, paramTplC);
  }
  
  void A(Map<String, Object> paramMap, TplC paramTplC)
  {
    IServiceContext localIServiceContext = SystemServiceContext.getInstance();
    if ((paramMap != null) && (!paramMap.isEmpty()))
    {
      this.A = new HashMap(paramMap.size());
      Iterator localIterator = paramMap.entrySet().iterator();
      while (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        String str = StringUtils.strip(Coercions.toString(localIterator.next(), null));
        IExpressionReference localIExpressionReference = paramTplC.parseEvalExpr(str, localIServiceContext);
        if (localIExpressionReference != null) {
          this.A.put((String)localEntry.getKey(), localIExpressionReference);
        }
      }
    }
  }
  
  public String mapFieldText(FieldDefinition paramFieldDefinition)
  {
    if (this.B == null) {
      return null;
    }
    HashMap localHashMap = new HashMap(1);
    localHashMap.put("field", paramFieldDefinition);
    return Coercions.toString(TplC.evaluate(this.B, localHashMap), null);
  }
  
  public Map<String, Object> mapVars(FieldDefinition paramFieldDefinition, Map<String, Object> paramMap)
  {
    if ((this.A == null) || (this.A.isEmpty())) {
      return paramMap;
    }
    HashMap localHashMap = new HashMap(1);
    localHashMap.put("field", paramFieldDefinition);
    localHashMap.put("vars", paramMap);
    LinkedHashMap localLinkedHashMap = new LinkedHashMap(this.A.size());
    Iterator localIterator = this.A.entrySet().iterator();
    Object localObject1;
    while (localIterator.hasNext())
    {
      localObject1 = (Map.Entry)localIterator.next();
      localObject2 = (String)((Map.Entry)localObject1).getKey();
      Object localObject3 = TplC.evaluate((IExpressionReference)((Map.Entry)localObject1).getValue(), localHashMap);
      if (localObject3 != null) {
        localLinkedHashMap.put(localObject2, Coercions.toString(localObject3, null));
      }
    }
    Object localObject2 = paramMap.keySet().iterator();
    while (((Iterator)localObject2).hasNext())
    {
      localObject1 = (String)((Iterator)localObject2).next();
      if (!((String)localObject1).startsWith("@")) {
        localLinkedHashMap.put(localObject1, paramMap.get(localObject1));
      }
    }
    return localLinkedHashMap;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\CellVarMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */