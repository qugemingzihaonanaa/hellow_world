package edu.thu.ext.excel.model;

import edu.thu.math.alg.Alog;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class Names
  implements Serializable
{
  private static final long serialVersionUID = 1354428660779333097L;
  List<NamedRange> A = new ArrayList();
  public static Comparator<NamedRange> rangeComparator = new Comparator()
  {
    public int A(NamedRange paramAnonymousNamedRange1, NamedRange paramAnonymousNamedRange2)
    {
      int i = paramAnonymousNamedRange1.getMinRow();
      int j = paramAnonymousNamedRange2.getMinRow();
      if (i < j) {
        return -1;
      }
      if (i == j) {
        return 0;
      }
      return 1;
    }
  };
  
  public void addRange(NamedRange paramNamedRange)
  {
    this.A.add(paramNamedRange);
  }
  
  public void clear()
  {
    this.A.clear();
  }
  
  public List<NamedRange> getNamedRanges()
  {
    return this.A;
  }
  
  public NamedRange getNamedRange(String paramString)
  {
    Iterator localIterator = this.A.iterator();
    while (localIterator.hasNext())
    {
      NamedRange localNamedRange = (NamedRange)localIterator.next();
      if (localNamedRange.getName().equals(paramString)) {
        return localNamedRange;
      }
    }
    return null;
  }
  
  public boolean hasNamedRangeWithPrefix(String paramString)
  {
    Iterator localIterator = this.A.iterator();
    while (localIterator.hasNext())
    {
      NamedRange localNamedRange = (NamedRange)localIterator.next();
      if (localNamedRange.getName().startsWith(paramString)) {
        return true;
      }
    }
    return false;
  }
  
  public List<NamedRange> getRangeInSheet(String paramString)
  {
    List localList = Alog.findMany(this.A, "sheetName", paramString);
    Collections.sort(localList, rangeComparator);
    return localList;
  }
  
  public List<NamedRange> getRangeWithPrefix(String paramString)
  {
    int j = this.A.size();
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < j; i++)
    {
      NamedRange localNamedRange = (NamedRange)this.A.get(i);
      if ((paramString == null) || (localNamedRange.getName().startsWith(paramString))) {
        localArrayList.add(localNamedRange);
      }
    }
    return localArrayList;
  }
  
  public List<NamedRange> getRangeInSheet(String paramString1, String paramString2)
  {
    if (paramString2 == null) {
      return getRangeInSheet(paramString1);
    }
    int j = this.A.size();
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < j; i++)
    {
      NamedRange localNamedRange = (NamedRange)this.A.get(i);
      if ((localNamedRange.getSheetName().equals(paramString1)) && (localNamedRange.getName().startsWith(paramString2))) {
        localArrayList.add(localNamedRange);
      }
    }
    return localArrayList;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\Names.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */