package edu.thu.ext.excel.model;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.util.Coercions;
import edu.thu.lang.reflect.BeanInstance;
import edu.thu.util.StringUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Row
  extends AbstractRow<Cell, Table>
{
  private static final long serialVersionUID = 4500334773546683115L;
  boolean A;
  double G;
  int E;
  int index;
  boolean D;
  int B;
  Object F;
  boolean C;
  
  public static Row makeEmptyRow()
  {
    Row localRow = new Row();
    localRow.setAutoFitHeight(false);
    localRow.setHeight(-1.0D);
    localRow.setSpan(0);
    localRow.setIndex(0);
    localRow.setCells(new ArrayList(0));
    return localRow;
  }
  
  public Row copy()
  {
    Row localRow = (Row)new BeanInstance(this).cloneInstance(false);
    localRow.setCells(new ArrayList(this.cells.size()));
    Iterator localIterator = this.cells.iterator();
    while (localIterator.hasNext())
    {
      Cell localCell = (Cell)localIterator.next();
      if (!localCell.isIgnored()) {
        localRow.addCell(localCell);
      }
    }
    return localRow;
  }
  
  public Cell makeCell(Object paramObject)
  {
    Cell localCell = new Cell();
    localCell.setStaticCell(true);
    localCell.setData(Coercions.toString(paramObject, null));
    localCell.setValue(paramObject);
    return localCell;
  }
  
  public int getNextCellIndex()
  {
    if (this.cells.size() <= 0) {
      return 1;
    }
    Cell localCell = (Cell)this.cells.get(this.cells.size() - 1);
    return localCell.getIndex() + localCell.getMergeAcross() + 1;
  }
  
  public Cell makeCellAt(int paramInt)
  {
    if (paramInt < 0) {
      throw Exceptions.code("excel.CAN_err_invalid_colIndex").param(paramInt);
    }
    int i = getNextCellIndex() - this.cells.size();
    for (int j = this.cells.size(); j <= paramInt; j++)
    {
      Cell localCell = Cell.makeEmptyCell();
      localCell.setIndex(i + j);
      localCell.setStaticCell(true);
      addCell(localCell);
    }
    return (Cell)this.cells.get(paramInt);
  }
  
  public void addCell(Cell paramCell)
  {
    paramCell.setRow(this);
    this.cells.add(paramCell);
  }
  
  public boolean evaluateVisible(Map<String, Object> paramMap)
  {
    if (this.cells.isEmpty()) {
      return true;
    }
    Cell localCell = (Cell)this.cells.get(0);
    return localCell.evaluateRowVisible(paramMap);
  }
  
  public void evaluatePrepareRow(Map<String, Object> paramMap)
  {
    if (this.cells.isEmpty()) {
      return;
    }
    Cell localCell = (Cell)this.cells.get(0);
    localCell.evaluatePrepareRow(paramMap);
  }
  
  public boolean isEmptyData()
  {
    Iterator localIterator = this.cells.iterator();
    while (localIterator.hasNext())
    {
      Cell localCell = (Cell)localIterator.next();
      if ((!localCell.isIgnored()) && (!localCell.isEmptyData())) {
        return false;
      }
    }
    return true;
  }
  
  public void clearData()
  {
    Iterator localIterator = this.cells.iterator();
    while (localIterator.hasNext())
    {
      Cell localCell = (Cell)localIterator.next();
      localCell.clearData();
    }
  }
  
  public Row getPrev()
  {
    return (Row)((Table)this.table).getRow(this.index - 2);
  }
  
  public Row getNext()
  {
    return (Row)((Table)this.table).getRow(this.index);
  }
  
  public Object getXlsObj()
  {
    return this.F;
  }
  
  public void setXlsObj(Object paramObject)
  {
    this.F = paramObject;
  }
  
  public boolean isBoolHidden()
  {
    return this.D;
  }
  
  public String getDisplay()
  {
    return isBoolHidden() ? "display:none" : "";
  }
  
  public boolean isHidden()
  {
    return this.D;
  }
  
  public void setHidden(boolean paramBoolean)
  {
    this.D = paramBoolean;
  }
  
  public int getColCount()
  {
    return getCells().size();
  }
  
  public Cell getCell(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= this.cells.size())) {
      return null;
    }
    return (Cell)this.cells.get(paramInt);
  }
  
  public void setCell(int paramInt, Cell paramCell)
  {
    if (paramInt < 0) {
      return;
    }
    while (paramInt >= this.cells.size()) {
      this.cells.add(null);
    }
    this.cells.set(paramInt, paramCell);
  }
  
  public String getCellData(int paramInt)
  {
    Cell localCell = getCell(paramInt);
    if (localCell == null) {
      return null;
    }
    return localCell.getData();
  }
  
  public Object getCellValue(int paramInt)
  {
    Cell localCell = getCell(paramInt);
    if (localCell == null) {
      return null;
    }
    return localCell.getValue();
  }
  
  public void setCellValue(int paramInt, Object paramObject)
  {
    Cell localCell = getCell(paramInt);
    if (localCell == null) {
      return;
    }
    localCell.setValue(paramObject);
  }
  
  public int getRowspan()
  {
    return this.B;
  }
  
  public void fix()
  {
    this.B = 1;
    Iterator localIterator = this.cells.iterator();
    while (localIterator.hasNext())
    {
      Cell localCell = (Cell)localIterator.next();
      if ((!localCell.isIgnored()) && (localCell.getRowspan() > this.B)) {
        this.B = localCell.getRowspan();
      }
    }
  }
  
  public double getHeight()
  {
    return this.G;
  }
  
  public void setHeight(double paramDouble)
  {
    this.G = paramDouble;
  }
  
  public void setAutoFitHeight(boolean paramBoolean)
  {
    this.A = paramBoolean;
  }
  
  public boolean isAutoFitHeight()
  {
    return this.A;
  }
  
  public void setSpan(int paramInt)
  {
    this.E = paramInt;
  }
  
  public int getSpan()
  {
    return this.E;
  }
  
  public void setIndex(int paramInt)
  {
    this.index = paramInt;
  }
  
  public int getIndex()
  {
    return this.index;
  }
  
  public Cell getFirstCell()
  {
    if (this.cells.isEmpty()) {
      return null;
    }
    return (Cell)this.cells.get(0);
  }
  
  public boolean isParagraphRow()
  {
    Cell localCell = getFirstCell();
    if (localCell == null) {
      return false;
    }
    if (localCell.getColspan() != this.cells.size()) {
      return false;
    }
    if (this.table == null) {
      return false;
    }
    return localCell.getCommentStr("h") != null;
  }
  
  public List<Cell> getCells()
  {
    return this.cells;
  }
  
  public void setCells(List<Cell> paramList)
  {
    this.cells = paramList;
  }
  
  public List<String> getDataList()
  {
    ArrayList localArrayList = new ArrayList(this.cells.size());
    int j = this.cells.size();
    for (int i = 0; i < j; i++)
    {
      Cell localCell = (Cell)this.cells.get(i);
      if (localCell.isIgnored()) {
        localArrayList.add(null);
      } else {
        localArrayList.add(localCell.getData());
      }
    }
    return localArrayList;
  }
  
  public List<String> getStripedDataList()
  {
    ArrayList localArrayList = new ArrayList(this.cells.size());
    int j = this.cells.size();
    for (int i = 0; i < j; i++)
    {
      Cell localCell = (Cell)this.cells.get(i);
      if (localCell.isIgnored()) {
        localArrayList.add(null);
      } else {
        localArrayList.add(StringUtils.strip(localCell.getData()));
      }
    }
    return localArrayList;
  }
  
  public List<Object> getRowValues()
  {
    return getStripedDataList();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\Row.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */