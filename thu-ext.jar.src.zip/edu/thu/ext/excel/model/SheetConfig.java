package edu.thu.ext.excel.model;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.exceptions.StdException;
import edu.thu.lang.util.ITplReference;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SheetConfig
  implements Serializable
{
  private static final long serialVersionUID = 6051446923809588853L;
  List<Item> A = new ArrayList();
  Map<String, Item> B = new HashMap();
  
  public List<Item> getItems()
  {
    return this.A;
  }
  
  public void addItem(Item paramItem)
  {
    if (getItem(paramItem.G) != null) {
      throw Exceptions.code("excel.CAN_err_duplicate_sheet_config").param(paramItem.G).param(paramItem);
    }
    this.A.add(paramItem);
    this.B.put(paramItem.getSheet(), paramItem);
  }
  
  public Item getItem(String paramString)
  {
    return (Item)this.B.get(paramString);
  }
  
  public static class Item
    implements Serializable
  {
    private static final long serialVersionUID = -7658754429731033200L;
    String G;
    ITplReference C;
    ITplReference E;
    ITplReference D;
    ITplReference I;
    ITplReference A;
    ITplReference H;
    ITplReference J;
    String B;
    String F;
    
    public ITplReference getSheetLoopVarTpl()
    {
      return this.H;
    }
    
    public void setSheetLoopVarTpl(ITplReference paramITplReference)
    {
      this.H = paramITplReference;
    }
    
    public ITplReference getSheetNameTpl()
    {
      return this.J;
    }
    
    public void setSheetNameTpl(ITplReference paramITplReference)
    {
      this.J = paramITplReference;
    }
    
    public ITplReference getAfterTpl()
    {
      return this.E;
    }
    
    public void setAfterTpl(ITplReference paramITplReference)
    {
      this.E = paramITplReference;
    }
    
    public ITplReference getBeforeTpl()
    {
      return this.C;
    }
    
    public void setBeforeTpl(ITplReference paramITplReference)
    {
      this.C = paramITplReference;
    }
    
    public String getSheet()
    {
      return this.G;
    }
    
    public void setSheet(String paramString)
    {
      this.G = paramString;
    }
    
    public ITplReference getTestTpl()
    {
      return this.D;
    }
    
    public void setTestTpl(ITplReference paramITplReference)
    {
      this.D = paramITplReference;
    }
    
    public String getStyle()
    {
      return this.B;
    }
    
    public void setStyle(String paramString)
    {
      this.B = paramString;
    }
    
    public String getClassName()
    {
      return this.F;
    }
    
    public void setClassName(String paramString)
    {
      this.F = paramString;
    }
    
    public ITplReference getBeforeExpandTpl()
    {
      return this.I;
    }
    
    public void setBeforeExpandTpl(ITplReference paramITplReference)
    {
      this.I = paramITplReference;
    }
    
    public ITplReference getAfterExpandTpl()
    {
      return this.A;
    }
    
    public void setAfterExpandTpl(ITplReference paramITplReference)
    {
      this.A = paramITplReference;
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\SheetConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */