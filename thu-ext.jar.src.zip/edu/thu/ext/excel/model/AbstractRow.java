package edu.thu.ext.excel.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public abstract class AbstractRow<C extends ICell, T extends AbstractTable<?>>
  implements IRow, Serializable
{
  private static final long serialVersionUID = -4022698161217945030L;
  protected List<C> cells = new ArrayList();
  protected T table;
  protected int index;
  
  public int getIndex()
  {
    return this.index;
  }
  
  public void setIndex(int paramInt)
  {
    this.index = paramInt;
  }
  
  public List<C> getCells()
  {
    return this.cells;
  }
  
  public void setCells(List<C> paramList)
  {
    this.cells = paramList;
  }
  
  public boolean isBlank()
  {
    Iterator localIterator = this.cells.iterator();
    while (localIterator.hasNext())
    {
      ICell localICell = (ICell)localIterator.next();
      if (localICell.getMergeDown() > 0) {
        return false;
      }
      if (!localICell.isBlank()) {
        return false;
      }
    }
    return true;
  }
  
  public void clear()
  {
    this.cells.clear();
  }
  
  public T getTable()
  {
    return this.table;
  }
  
  public void setTable(T paramT)
  {
    this.table = paramT;
  }
  
  public int getColCount()
  {
    return getCells().size();
  }
  
  public C getCell(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= this.cells.size())) {
      return null;
    }
    return (ICell)this.cells.get(paramInt);
  }
  
  public void setCell(int paramInt, C paramC)
  {
    if (paramInt < 0) {
      return;
    }
    while (paramInt >= this.cells.size()) {
      this.cells.add(null);
    }
    this.cells.set(paramInt, paramC);
  }
  
  public String getCellData(int paramInt)
  {
    ICell localICell = getCell(paramInt);
    if (localICell == null) {
      return null;
    }
    return localICell.getData();
  }
  
  public boolean isEmpty()
  {
    return this.cells.isEmpty();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\AbstractRow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */