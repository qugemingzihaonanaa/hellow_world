package edu.thu.ext.excel.model;

import edu.thu.model.table.IBasicTableModel;
import java.util.List;

public abstract interface IWorksheet
{
  public abstract IWorkbook getWorkbook();
  
  public abstract String getWorksheetName();
  
  public abstract int getRowCount();
  
  public abstract IRow getRow(int paramInt);
  
  public abstract WorksheetOptions getWorksheetOptions();
  
  public abstract PageBreaks getPageBreaks();
  
  public abstract double getDefaultColumnWidth();
  
  public abstract double getDefaultRowHeight();
  
  public abstract List<Column> getCols();
  
  public abstract List<ImgData> getImgs();
  
  public abstract boolean isHorPage();
  
  public abstract List<List<Object>> getCellDatas();
  
  public abstract IBasicTableModel getTable();
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\IWorksheet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */