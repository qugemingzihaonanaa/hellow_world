package edu.thu.ext.excel.model;

import java.io.Serializable;

public class PageInfo
  implements Serializable
{
  private static final long serialVersionUID = -4057886165007677591L;
  public static final double DEFAULT_XLS_PAGE_WIDTH = 476.0D;
  public static final double DEFAULT_XLS_HOR_PAGE_WIDTH = 680.0D;
  public static final double DEFAULT_HOR_PAGE_WIDTH = 14148.0D;
  public static final double DEFAULT_VER_PAGE_WIDTH = 9548.0D;
  public static final double DEFAULT_Y_RATIO = 20.058823529411764D;
  double I = 21.0D;
  double D = 29.7D;
  double B = 2.54D;
  double G = 2.0D;
  double A = 9548.0D;
  double H = 9500.0D;
  double C;
  double E;
  boolean F;
  
  public PageInfo() {}
  
  public PageInfo(double paramDouble, boolean paramBoolean)
  {
    this.A = (paramBoolean ? 14148.0D : 9548.0D);
    setRefWidth(paramDouble);
    this.E = 20.058823529411764D;
    this.F = paramBoolean;
  }
  
  public PageInfo(double paramDouble)
  {
    setRefWidth(paramDouble);
    this.E = 20.058823529411764D;
    this.F = false;
  }
  
  public boolean isHorPage()
  {
    return this.F;
  }
  
  public void setHorPage(boolean paramBoolean)
  {
    this.F = paramBoolean;
  }
  
  public double getContentWidth()
  {
    return this.A;
  }
  
  public void setContentWidth(double paramDouble)
  {
    this.A = paramDouble;
  }
  
  public double getContentHeight()
  {
    return this.H;
  }
  
  public void setContentHeight(double paramDouble)
  {
    this.H = paramDouble;
  }
  
  public void setRefWidth(double paramDouble)
  {
    this.C = (this.A / paramDouble);
  }
  
  public void setRefHeight(double paramDouble)
  {
    this.E = (this.H / paramDouble);
  }
  
  public double mapX(double paramDouble)
  {
    return this.C * paramDouble;
  }
  
  public double mapRoundX(double paramDouble)
  {
    double d = mapX(paramDouble);
    return Math.floor(d * 4.0D) / 4.0D;
  }
  
  public double mapRoundY(double paramDouble)
  {
    double d = mapY(paramDouble);
    return Math.floor(d * 4.0D) / 4.0D;
  }
  
  public double mapY(double paramDouble)
  {
    return this.E * paramDouble;
  }
  
  public double v(double paramDouble)
  {
    return paramDouble < 0.0D ? 0.0D : paramDouble;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\PageInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */