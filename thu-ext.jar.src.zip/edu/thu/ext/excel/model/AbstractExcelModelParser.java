package edu.thu.ext.excel.model;

import edu.thu.config.AppConfig;
import edu.thu.core.IResource;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.io.util.IoUtils;
import edu.thu.lang.IVariant;
import edu.thu.lang.el.IExpressionReference;
import edu.thu.lang.util.TplC;
import edu.thu.lang.xconfig.AbstractXParser;
import edu.thu.model.stg.ds.DataSourceMeta;
import edu.thu.model.stg.ds.IModelServiceContext;
import edu.thu.model.stg.ds.spi.FieldMeta;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceContext;
import edu.thu.service.SystemServiceContext;
import edu.thu.service.ThreadServiceContext;
import edu.thu.util.StringUtils;
import edu.thu.vfs.IFile;
import edu.thu.web.layout.LayoutMeta;
import edu.thu.web.layout.LayoutParser;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

public abstract class AbstractExcelModelParser
  extends AbstractXParser<Workbook>
{
  protected LayoutParser fieldParser;
  protected boolean forXpt;
  protected boolean allowDuplicateField = true;
  protected boolean checkCellAttrs;
  protected boolean useReportConfig = true;
  protected boolean onlyParseData;
  protected boolean supportFormula = true;
  protected boolean supportExpand = true;
  protected boolean supportExcelFormula = false;
  protected WxReportConfig wxReportConfig;
  
  public AbstractExcelModelParser()
  {
    super("not_need");
    newTplC(null, SystemServiceContext.getInstance());
  }
  
  protected void doConfigTplC(TplC paramTplC)
  {
    try
    {
      paramTplC.loadLib("ns1", "/_tpl/ns1.lib.xml");
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
  
  public DataSourceMeta getDsMeta()
  {
    DataSourceMeta localDataSourceMeta = super.getDsMeta();
    if ((localDataSourceMeta == null) && (this.wxReportConfig != null)) {
      localDataSourceMeta = this.wxReportConfig.getDsMeta();
    }
    if ((localDataSourceMeta == null) && (AppConfig.var("xpt.use_context_ds_meta").booleanValue(true)))
    {
      IServiceContext localIServiceContext = ThreadServiceContext.getCurrentContext();
      if ((localIServiceContext instanceof IModelServiceContext)) {
        localDataSourceMeta = ((IModelServiceContext)localIServiceContext).getDsMeta();
      }
    }
    return localDataSourceMeta;
  }
  
  public boolean isSupportExpand()
  {
    return this.supportExpand;
  }
  
  public void setSupportExpand(boolean paramBoolean)
  {
    this.supportExpand = paramBoolean;
  }
  
  public boolean isSupportFormula()
  {
    return this.supportFormula;
  }
  
  public void setSupportFormula(boolean paramBoolean)
  {
    this.supportFormula = paramBoolean;
  }
  
  public void setUseReportConfig(boolean paramBoolean)
  {
    this.useReportConfig = paramBoolean;
  }
  
  public boolean isUseReportConfig()
  {
    return this.useReportConfig;
  }
  
  public boolean isOnlyParseData()
  {
    return this.onlyParseData;
  }
  
  public void setOnlyParseData(boolean paramBoolean)
  {
    this.onlyParseData = paramBoolean;
  }
  
  public void setCheckCellAttrs(boolean paramBoolean)
  {
    this.checkCellAttrs = paramBoolean;
  }
  
  public void setAllowDuplicateField(boolean paramBoolean)
  {
    this.allowDuplicateField = paramBoolean;
  }
  
  public void setForXpt(boolean paramBoolean)
  {
    this.forXpt = paramBoolean;
  }
  
  public Workbook parseVirtualFile(String paramString)
  {
    return (Workbook)parseFromVirtualPath(paramString, false);
  }
  
  protected Workbook doParseResource(IResource paramIResource, IServiceContext paramIServiceContext)
  {
    InputStream localInputStream = null;
    try
    {
      localInputStream = paramIResource.getInputStream();
      Workbook localWorkbook1 = parseWorkbook(localInputStream);
      if (localWorkbook1 != null)
      {
        localWorkbook1.setVirtualPath(paramIResource.getStdPath());
        localWorkbook1.setStorePath(paramIResource.getPath());
      }
      Workbook localWorkbook2 = localWorkbook1;
      return localWorkbook2;
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
    finally
    {
      IoUtils.safeClose(localInputStream);
    }
  }
  
  public Workbook parseFile(File paramFile)
  {
    FileInputStream localFileInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(paramFile);
      Workbook localWorkbook = parseWorkbook(localFileInputStream);
      return localWorkbook;
    }
    catch (IOException localIOException)
    {
      throw Exceptions.source(localIOException);
    }
    finally
    {
      IoUtils.safeClose(localFileInputStream);
    }
  }
  
  public Workbook parseVFile(IFile paramIFile)
  {
    InputStream localInputStream = null;
    try
    {
      localInputStream = paramIFile.getInputStream();
      Workbook localWorkbook = parseWorkbook(localInputStream);
      return localWorkbook;
    }
    finally
    {
      IoUtils.safeClose(localInputStream);
    }
  }
  
  public Workbook parseWorkbook(InputStream paramInputStream)
  {
    TplC localTplC = getTplC();
    if ((!this.onlyParseData) && (this.forXpt)) {
      try
      {
        localTplC.loadLib("xpt", "/_tpl/xpt.lib.xml");
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
    }
    if (!this.onlyParseData)
    {
      this.fieldParser = new LayoutParser();
      this.fieldParser.setCp(localTplC);
      localObject = getDsMeta();
      if (localObject != null) {
        this.fieldParser.setLayoutMeta(new LayoutMeta((DataSourceMeta)localObject));
      }
    }
    Object localObject = new Workbook();
    parseWorkbook(paramInputStream, (Workbook)localObject);
    if (!this.onlyParseData)
    {
      ((Workbook)localObject).getFieldDefinitions().setAllowDuplicateField(this.allowDuplicateField);
      if (this.forXpt)
      {
        ((Workbook)localObject).collectFieldDefinitions();
        if (isUseNameLoop((Workbook)localObject))
        {
          this.supportFormula = this.wxReportConfig.getBooleanProperty("supportFormula", false);
          this.supportExpand = this.wxReportConfig.getBooleanProperty("supportExpand", false);
        }
        if (this.supportFormula) {
          ExcelModelHelper.A((Workbook)localObject);
        }
        if (this.supportExpand)
        {
          ExcelModelHelper.initExpandModel((Workbook)localObject);
          ((Workbook)localObject).setNeedExpand(true);
        }
      }
      ExcelModelHelper.B((Workbook)localObject);
      if (this.checkCellAttrs) {
        ExcelModelHelper.C((Workbook)localObject);
      }
    }
    return (Workbook)localObject;
  }
  
  boolean isUseNameLoop(Workbook paramWorkbook)
  {
    return (paramWorkbook.hasNamedRangeWithPrefix("loop.")) || (paramWorkbook.hasNamedRangeWithPrefix("tile.")) || (paramWorkbook.hasNamedRangeWithPrefix("group."));
  }
  
  public WxReportConfig parseConfigFromTable(Table paramTable, WxReportConfig paramWxReportConfig)
  {
    return ExcelModelHelper.parseConfigFromTable(paramTable, getTplC(), paramWxReportConfig);
  }
  
  public abstract void parseWorkbook(InputStream paramInputStream, Workbook paramWorkbook);
  
  public void parseFieldDefinition(Cell paramCell)
  {
    ExcelModelHelper.parseFieldDefinition(paramCell, this.wxReportConfig);
  }
  
  public void initCell(Cell paramCell, Workbook paramWorkbook)
  {
    TplC localTplC = getTplC();
    Map localMap = paramCell.getCommentVars();
    if (!this.onlyParseData)
    {
      parseFieldDefinition(paramCell);
      String str1;
      if (localMap != null)
      {
        str1 = (String)localMap.get("linkExpr");
        if (str1 != null) {
          paramCell.setLinkExpr(localTplC.parseEvalExpr(str1, SystemServiceContext.getInstance()));
        }
      }
      IExpressionReference localIExpressionReference;
      if ((localMap != null) && (localMap.containsKey("valueExpr")))
      {
        str1 = (String)localMap.get("valueExpr");
        localIExpressionReference = localTplC.parseEvalExpr(str1, SystemServiceContext.getInstance());
      }
      else if (paramCell.getFieldDefinition() == null)
      {
        str1 = paramCell.getData();
        localIExpressionReference = TplC.parseExpression(str1);
      }
      else
      {
        localIExpressionReference = null;
      }
      paramCell.setValueExpr(localIExpressionReference);
      String str2;
      Object localObject1;
      if ((localMap != null) && (localMap.containsKey("formatExpr")))
      {
        str2 = (String)localMap.get("formatExpr");
        localObject1 = localTplC.parseEvalExpr(str2, SystemServiceContext.getInstance());
        paramCell.setFormatExpr((IExpressionReference)localObject1);
      }
      if (localMap != null)
      {
        str2 = (String)localMap.get("commentExpr");
        if (str2 != null)
        {
          localObject1 = localTplC.parseEvalExpr(str2, SystemServiceContext.getInstance());
          paramCell.setCommentExpr((IExpressionReference)localObject1);
        }
        localObject1 = (String)localMap.get("visibleExpr");
        if (localObject1 != null)
        {
          localObject2 = localTplC.parseEvalExpr((String)localObject1, SystemServiceContext.getInstance());
          paramCell.setVisibleExpr((IExpressionReference)localObject2);
        }
        Object localObject2 = (String)localMap.get("readOnlyExpr");
        if (localObject2 != null)
        {
          localObject3 = localTplC.parseEvalExpr((String)localObject2, SystemServiceContext.getInstance());
          paramCell.setReadOnlyExpr((IExpressionReference)localObject3);
        }
        Object localObject3 = (String)localMap.get("rowVisibleExpr");
        if (localObject3 != null)
        {
          localObject4 = localTplC.parseEvalExpr((String)localObject3, SystemServiceContext.getInstance());
          paramCell.setRowVisibleExpr((IExpressionReference)localObject4);
        }
        Object localObject4 = (String)localMap.get("keyExpr");
        if (localObject4 != null)
        {
          localObject5 = localTplC.parseEvalExpr((String)localObject4, SystemServiceContext.getInstance());
          paramCell.setKeyExpr((IExpressionReference)localObject5);
        }
        Object localObject5 = (String)localMap.get("objectExpr");
        if (localObject5 != null)
        {
          localObject6 = localTplC.parseEvalExpr((String)localObject5, SystemServiceContext.getInstance());
          paramCell.setObjectExpr((IExpressionReference)localObject6);
        }
        Object localObject6 = (String)localMap.get("prepareRowExpr");
        if (localObject6 != null)
        {
          localObject7 = localTplC.parseEvalExpr((String)localObject6, SystemServiceContext.getInstance());
          paramCell.setPrepareRowExpr((IExpressionReference)localObject7);
        }
        Object localObject7 = (String)localMap.get("defaultExpr");
        if (localObject7 != null)
        {
          localObject8 = localTplC.parseEvalExpr((String)localObject7, SystemServiceContext.getInstance());
          paramCell.setDefaultValueExpr((IExpressionReference)localObject8);
        }
        Object localObject8 = (String)localMap.get("uid");
        paramCell.setUid((String)localObject8);
        String str3 = (String)localMap.get("styleExpr");
        if ((str3 != null) && (((str3.startsWith("'")) && (str3.endsWith("'"))) || ((str3.startsWith("\"")) && (str3.endsWith("\"")))))
        {
          str4 = str3.substring(1, str3.length() - 1);
          paramCell.setStyle(paramWorkbook.getWxReportConfig().getStyle(str4));
        }
        String str4 = (String)localMap.get("viewer");
        String str5 = (String)localMap.get("inputor");
        paramCell.setViewerId(str4);
        paramCell.setInputorId(str5);
        String str6 = StringUtils.strip((String)localMap.get("cssClass"));
        paramCell.setCssClassName(str6);
      }
      paramCell.initStatic();
      if (this.forXpt) {
        paramCell.initForXpt(localTplC);
      }
      if ((getDsMeta() != null) && (paramCell.getFieldDefinition() != null))
      {
        str2 = paramCell.getFieldDefinition().getName();
        if (paramCell.getFormatExpr() == null)
        {
          localObject1 = getDsMeta().getFieldMeta(str2);
          if (localObject1 != null) {
            paramCell.setFormatExpr(((FieldMeta)localObject1).getExportExpr());
          }
        }
      }
    }
    else
    {
      paramCell.setStaticCell(true);
    }
  }
  
  protected TreeNode mergeMainNode(TreeNode paramTreeNode1, TreeNode paramTreeNode2)
  {
    throw Exceptions.notAllowed();
  }
  
  protected Workbook doParse(TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    throw Exceptions.notAllowed();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\AbstractExcelModelParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */