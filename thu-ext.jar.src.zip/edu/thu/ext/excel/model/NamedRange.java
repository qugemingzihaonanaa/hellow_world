package edu.thu.ext.excel.model;

import edu.thu.lang.IVariant;
import edu.thu.lang.Variant;
import edu.thu.util.StringUtils;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NamedRange
  implements Serializable
{
  private static final long serialVersionUID = 8416511916115017667L;
  static final Logger C = LoggerFactory.getLogger(NamedRange.class);
  List<Range> A = new ArrayList();
  String D;
  String B;
  
  public NamedRange() {}
  
  public NamedRange(String paramString)
  {
    setRefersTo(paramString);
    parseRefersTo();
  }
  
  public List<Range> getRanges()
  {
    return this.A;
  }
  
  public String getRangeExpr()
  {
    String str = "=";
    Iterator localIterator = this.A.iterator();
    while (localIterator.hasNext())
    {
      Range localRange = (Range)localIterator.next();
      str = str + localRange.getRangeExpr();
      if (localIterator.hasNext()) {
        str = str + ",";
      }
    }
    return str;
  }
  
  public String[] getNameParts()
  {
    return StringUtils.split(this.D, '.');
  }
  
  public String getNamePart(int paramInt)
  {
    String[] arrayOfString = getNameParts();
    if ((paramInt < 0) || (paramInt >= arrayOfString.length)) {
      return null;
    }
    return arrayOfString[paramInt];
  }
  
  public void addRange(Range paramRange)
  {
    this.A.add(paramRange);
  }
  
  public boolean parseRefersTo()
  {
    if (this.B == null) {
      return false;
    }
    if (!this.B.startsWith("="))
    {
      C.info("excel.CAN_err_invalid_refersTo::" + this.B);
      return false;
    }
    String str1 = this.B.substring(1);
    String[] arrayOfString = str1.split(",");
    int j = arrayOfString.length;
    for (int i = 0; i < j; i++)
    {
      String str2 = arrayOfString[i].trim();
      Range localRange = D(str2);
      if (localRange != null) {
        this.A.add(localRange);
      }
    }
    return true;
  }
  
  Range D(String paramString)
  {
    String[] arrayOfString = paramString.split("!");
    if (arrayOfString.length > 2)
    {
      C.info("excel.CAN_err_invalid_refersTo::" + this.B);
      return null;
    }
    if (arrayOfString.length < 2) {
      arrayOfString = new String[] { "Sheet1", paramString };
    }
    Range localRange = new Range();
    arrayOfString[0] = StringUtils.replace(arrayOfString[0], "'", "");
    localRange.setSheetName(arrayOfString[0]);
    String str = arrayOfString[1];
    int i = str.indexOf(':');
    int[] arrayOfInt1;
    if (i < 0)
    {
      arrayOfInt1 = C(str);
      if (arrayOfInt1 == null) {
        return null;
      }
      if (arrayOfInt1[0] >= 0) {
        localRange.setLtRow(arrayOfInt1[0]);
      }
      if (arrayOfInt1[1] >= 0) {
        localRange.setLtCol(arrayOfInt1[1]);
      }
      if (arrayOfInt1[0] >= 0) {
        localRange.setRbRow(arrayOfInt1[0]);
      }
      if (arrayOfInt1[1] >= 0) {
        localRange.setRbCol(arrayOfInt1[1]);
      }
    }
    else
    {
      arrayOfInt1 = C(str.substring(0, i));
      int[] arrayOfInt2 = C(str.substring(i + 1));
      if ((arrayOfInt1 == null) || (arrayOfInt2 == null)) {
        return null;
      }
      if (arrayOfInt1[0] >= 0) {
        localRange.setLtRow(arrayOfInt1[0]);
      }
      if (arrayOfInt1[1] >= 0) {
        localRange.setLtCol(arrayOfInt1[1]);
      }
      if (arrayOfInt2[0] >= 0) {
        localRange.setRbRow(arrayOfInt2[0]);
      }
      if (arrayOfInt2[1] >= 0) {
        localRange.setRbCol(arrayOfInt2[1]);
      }
    }
    return localRange;
  }
  
  int B(String paramString)
  {
    if ((paramString.length() <= 0) || (paramString.length() > 2)) {
      return 0;
    }
    int i = paramString.charAt(0);
    int j = 0;
    if (paramString.length() > 1) {
      j = paramString.charAt(1);
    }
    if (j == 0) {
      return i - 65;
    }
    return (i - 65) * 25 + (j - 65);
  }
  
  int A(String paramString)
  {
    if (paramString.length() <= 0) {
      return 0;
    }
    return Variant.valueOf(paramString).intValue(1) - 1;
  }
  
  int[] C(String paramString)
  {
    int[] arrayOfInt = new int[2];
    if (paramString.startsWith("$"))
    {
      paramString = paramString.substring(1);
      String[] arrayOfString = StringUtils.split(paramString, '$');
      arrayOfInt[0] = -1;
      arrayOfInt[1] = -1;
      if (arrayOfString != null)
      {
        int k = arrayOfString.length;
        for (int j = 0; j < k; j++)
        {
          String str = arrayOfString[j];
          if (Character.isDigit(str.charAt(0))) {
            arrayOfInt[0] = A(str);
          } else {
            arrayOfInt[1] = B(str);
          }
        }
      }
      return arrayOfInt;
    }
    int i;
    if (paramString.startsWith("R"))
    {
      i = paramString.indexOf("C");
      if (i < 0)
      {
        arrayOfInt[0] = (Variant.valueOf(paramString.substring(1)).intValue(0) - 1);
        arrayOfInt[1] = -1;
      }
      else
      {
        arrayOfInt[0] = (Variant.valueOf(paramString.substring(1, i)).intValue(0) - 1);
        arrayOfInt[1] = (Variant.valueOf(paramString.substring(i + 1)).intValue(0) - 1);
      }
    }
    else if (paramString.startsWith("C"))
    {
      i = Variant.valueOf(paramString.substring(1)).intValue(0) - 1;
      arrayOfInt[0] = -1;
      arrayOfInt[1] = i;
    }
    else
    {
      C.info("excel.CAN_err_invalid_refersTo::{}", this.B);
      return null;
    }
    return arrayOfInt;
  }
  
  public String getSheetName()
  {
    if (this.A.isEmpty()) {
      return null;
    }
    return ((Range)this.A.get(0)).getSheetName();
  }
  
  public boolean isColMode()
  {
    if (this.A.isEmpty()) {
      return false;
    }
    return ((Range)this.A.get(0)).isColMode();
  }
  
  public boolean isRowMode()
  {
    if (this.A.isEmpty()) {
      return false;
    }
    return ((Range)this.A.get(0)).isRowMode();
  }
  
  public int getMinCol()
  {
    int i = Integer.MAX_VALUE;
    int k = this.A.size();
    for (int j = 0; j < k; j++)
    {
      Range localRange = (Range)this.A.get(j);
      if (localRange.getLtCol() < i) {
        i = localRange.getLtCol();
      }
    }
    return i;
  }
  
  public int getMaxCol()
  {
    int i = 0;
    int k = this.A.size();
    for (int j = 0; j < k; j++)
    {
      Range localRange = (Range)this.A.get(j);
      if (localRange.getRbCol() > i) {
        i = localRange.getRbCol();
      }
    }
    return i;
  }
  
  public int getMinRow()
  {
    int i = Integer.MAX_VALUE;
    int k = this.A.size();
    for (int j = 0; j < k; j++)
    {
      Range localRange = (Range)this.A.get(j);
      if (localRange.getLtRow() < i) {
        i = localRange.getLtRow();
      }
    }
    return i;
  }
  
  public int getMaxRow()
  {
    int i = 0;
    int k = this.A.size();
    for (int j = 0; j < k; j++)
    {
      Range localRange = (Range)this.A.get(j);
      if (localRange.getRbRow() > i) {
        i = localRange.getRbRow();
      }
    }
    return i;
  }
  
  public String getName()
  {
    return this.D;
  }
  
  public void setName(String paramString)
  {
    this.D = paramString;
  }
  
  public String getRefersTo()
  {
    return this.B;
  }
  
  public void setRefersTo(String paramString)
  {
    this.B = paramString;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\NamedRange.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */