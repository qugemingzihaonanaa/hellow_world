package edu.thu.ext.excel.model;

import edu.thu.global.exceptions.Exceptions;
import edu.thu.util.StringUtils;

public class CellPositionParser
{
  static CellPositionParser A = new CellPositionParser();
  
  public static CellPositionParser getInstance()
  {
    return A;
  }
  
  public CellLayerPosition parsePos(String paramString)
  {
    paramString = StringUtils.strip(paramString);
    if ((paramString == null) || (paramString.length() <= 0)) {
      throw Exceptions.code("excel.CAN_err_null_cell_position");
    }
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\CellPositionParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */