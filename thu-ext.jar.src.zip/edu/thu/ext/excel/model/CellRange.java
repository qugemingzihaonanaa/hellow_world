package edu.thu.ext.excel.model;

import java.io.Serializable;

public class CellRange
  implements Serializable
{
  private static final long serialVersionUID = -7874466547630656481L;
  CellPosition B;
  CellPosition A;
  
  public CellRange(CellPosition paramCellPosition1, CellPosition paramCellPosition2)
  {
    this.B = paramCellPosition1;
    this.A = paramCellPosition2;
  }
  
  public CellRange(CellPosition paramCellPosition)
  {
    this.B = paramCellPosition;
    this.A = paramCellPosition;
  }
  
  public CellRange()
  {
    this(new CellPosition(0, 0), new CellPosition(Integer.MAX_VALUE, Integer.MAX_VALUE));
  }
  
  public String toString()
  {
    return this.B + ":" + this.A;
  }
  
  public CellPosition getLtPos()
  {
    return this.B;
  }
  
  public void setLtPos(CellPosition paramCellPosition)
  {
    this.B = paramCellPosition;
  }
  
  public CellPosition getRbPos()
  {
    return this.A;
  }
  
  public void setRbPos(CellPosition paramCellPosition)
  {
    this.A = paramCellPosition;
  }
  
  public int getMinCol()
  {
    return this.B.getColIndex();
  }
  
  public int getMaxCol()
  {
    return this.A.getColIndex();
  }
  
  public int getMinRow()
  {
    return this.B.getRowIndex();
  }
  
  public int getMaxRow()
  {
    return this.A.getRowIndex();
  }
  
  public int getLeftPos()
  {
    return this.B.getColPos();
  }
  
  public void setLeftPos(int paramInt)
  {
    this.B.setColPos(paramInt);
  }
  
  public int getTopPos()
  {
    return this.B.getRowPos();
  }
  
  public void setTopPos(int paramInt)
  {
    this.B.setRowPos(paramInt);
  }
  
  public int getRightPos()
  {
    return this.A.getColPos();
  }
  
  public void setRightPos(int paramInt)
  {
    this.A.setColPos(paramInt);
  }
  
  public int getBottomPos()
  {
    return this.A.getRowPos();
  }
  
  public void setBottomPos(int paramInt)
  {
    this.A.setRowPos(paramInt);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\CellRange.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */