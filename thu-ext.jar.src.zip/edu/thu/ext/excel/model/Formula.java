package edu.thu.ext.excel.model;

import java.io.Serializable;

public class Formula
  implements Serializable
{
  private static final long serialVersionUID = 4870195929585959466L;
  String A;
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\Formula.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */