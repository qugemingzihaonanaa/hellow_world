package edu.thu.ext.excel.model.formula;

import edu.thu.config.AppConfig;
import edu.thu.ext.excel.model.Cell;
import edu.thu.lang.IVariant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CellFormulaHelper
{
  static final Logger A = LoggerFactory.getLogger(CellFormulaHelper.class);
  static boolean B = AppConfig.var("excel.use_formula_xparser").booleanValue(true);
  
  static
  {
    if (B) {
      A.info("excel.use_formula_xparser");
    } else {
      A.warn("excel.antlr_formula_parse_is_deprecated");
    }
  }
  
  public static CellFormula parseFormula(String paramString, Cell paramCell)
  {
    if (B) {
      return new CellFormulaXParser(paramCell).parseFormula(paramString);
    }
    CellFormulaExprParser localCellFormulaExprParser = new CellFormulaExprParser(paramString, paramCell);
    return localCellFormulaExprParser.parseFormula();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\formula\CellFormulaHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */