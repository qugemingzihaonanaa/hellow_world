package edu.thu.ext.excel.model.formula;

import edu.thu.ext.excel.model.Cell;
import edu.thu.ext.excel.model.CellPosition;
import edu.thu.ext.excel.model.formula.exprs.CellFuncExpr;
import edu.thu.ext.excel.model.formula.exprs.CellPosExpr;
import edu.thu.ext.excel.model.formula.exprs.CellRangeExpr;
import edu.thu.ext.excel.model.formula.exprs.DefaultCellFuncProvider;
import edu.thu.ext.excel.model.formula.exprs.FormulaExprs;
import edu.thu.lang.el.AbstractExcelFormulaParser;
import edu.thu.lang.el.AbstractExcelFormulaParser.Token;
import edu.thu.lang.exceptions.StdException;
import java.util.Iterator;
import java.util.List;

public class CellFormulaXParser
  extends AbstractExcelFormulaParser<ICellFormulaExpr>
{
  ICellFuncProvider funcProvider = new DefaultCellFuncProvider();
  Cell cell;
  
  public Cell getCell()
  {
    return this.cell;
  }
  
  public void setCell(Cell paramCell)
  {
    this.cell = paramCell;
  }
  
  public void setFuncProvider(ICellFuncProvider paramICellFuncProvider)
  {
    this.funcProvider = paramICellFuncProvider;
  }
  
  public ICellFuncProvider getFuncProvider()
  {
    return this.funcProvider;
  }
  
  CellFormulaXParser(Cell paramCell)
  {
    this.cell = paramCell;
  }
  
  public CellFormula parseFormula(String paramString)
  {
    try
    {
      ICellFormulaExpr localICellFormulaExpr = (ICellFormulaExpr)parseExpression(paramString);
      return new CellFormula(this.cell, localICellFormulaExpr);
    }
    catch (Exception localException)
    {
      throw new StdException("excel.CAN_err_invalid_formula").param(this.cell).cause(localException);
    }
  }
  
  protected ICellFormulaExpr newPosExpr(int paramInt1, boolean paramBoolean1, int paramInt2, boolean paramBoolean2, int paramInt3)
  {
    CellPosition localCellPosition = new CellPosition(this.cell.getRowIndex(), this.cell.getIndex());
    if (paramBoolean1) {
      localCellPosition.moveRow(paramInt2);
    } else {
      localCellPosition.setRowIndex(paramInt2);
    }
    if (paramBoolean2) {
      localCellPosition.moveCol(paramInt3);
    } else {
      localCellPosition.setColIndex(paramInt3);
    }
    return new CellPosExpr(localCellPosition);
  }
  
  protected ICellFormulaExpr newRangeExpr(int paramInt, ICellFormulaExpr paramICellFormulaExpr1, ICellFormulaExpr paramICellFormulaExpr2)
  {
    CellPosExpr localCellPosExpr1 = (CellPosExpr)paramICellFormulaExpr1;
    CellPosExpr localCellPosExpr2 = (CellPosExpr)paramICellFormulaExpr2;
    return new CellRangeExpr(localCellPosExpr1.getPos(), localCellPosExpr2.getPos());
  }
  
  protected ICellFormulaExpr newBinaryOp(int paramInt, AbstractExcelFormulaParser.Token paramToken, ICellFormulaExpr paramICellFormulaExpr1, ICellFormulaExpr paramICellFormulaExpr2)
  {
    switch (paramToken)
    {
    case LE: 
      return FormulaExprs.LTEQ_Op(paramICellFormulaExpr1, paramICellFormulaExpr2);
    case GT: 
      return FormulaExprs.LT_Op(paramICellFormulaExpr1, paramICellFormulaExpr2);
    case MULTIPLY: 
      return FormulaExprs.EQ_Op(paramICellFormulaExpr1, paramICellFormulaExpr2);
    case LT: 
      return FormulaExprs.GT_Op(paramICellFormulaExpr1, paramICellFormulaExpr2);
    case MINUS: 
      return FormulaExprs.GTEQ_Op(paramICellFormulaExpr1, paramICellFormulaExpr2);
    case NE: 
      return FormulaExprs.NOTEQ_Op(paramICellFormulaExpr1, paramICellFormulaExpr2);
    case POWER: 
      return FormulaExprs.CONCAT_Op(paramICellFormulaExpr1, paramICellFormulaExpr2);
    case ADD: 
      return FormulaExprs.ADD_Op(paramICellFormulaExpr1, paramICellFormulaExpr2);
    case CONCAT: 
      return FormulaExprs.SUB_Op(paramICellFormulaExpr1, paramICellFormulaExpr2);
    case EQ: 
      return FormulaExprs.MULT_Op(paramICellFormulaExpr1, paramICellFormulaExpr2);
    case DIVIDE: 
      return FormulaExprs.DIV_Op(paramICellFormulaExpr1, paramICellFormulaExpr2);
    case GE: 
      return FormulaExprs.EXP_Op(paramICellFormulaExpr1, paramICellFormulaExpr2);
    }
    throw new StdException("excel.err_unknown_binary_operator").param(paramToken).param(paramICellFormulaExpr1).param(paramICellFormulaExpr2).param(this);
  }
  
  protected ICellFormulaExpr newUnaryOp(int paramInt, AbstractExcelFormulaParser.Token paramToken, ICellFormulaExpr paramICellFormulaExpr)
  {
    if (paramToken == AbstractExcelFormulaParser.Token.MINUS) {
      return FormulaExprs.SUB_Op(null, paramICellFormulaExpr);
    }
    throw new StdException("excel.err_unknown_unary_operator").param(paramToken).param(paramICellFormulaExpr).param(this);
  }
  
  protected ICellFormulaExpr newValueExpr(int paramInt, Object paramObject)
  {
    return FormulaExprs.value(paramObject);
  }
  
  protected ICellFormulaExpr newFunctionExpr(int paramInt, String paramString, List<ICellFormulaExpr> paramList)
  {
    CellFuncExpr localCellFuncExpr = this.funcProvider.newFunc(paramString);
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      ICellFormulaExpr localICellFormulaExpr = (ICellFormulaExpr)localIterator.next();
      localCellFuncExpr.addArgExpr(localICellFormulaExpr);
    }
    localCellFuncExpr.endArg();
    return localCellFuncExpr;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\formula\CellFormulaXParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */