package edu.thu.ext.excel.model.formula.exprs;

import edu.thu.ext.excel.model.CellPosition;
import edu.thu.ext.excel.model.CellRange;
import edu.thu.ext.excel.model.data.CellData;
import edu.thu.ext.excel.xpt.XptBuildRuntime;
import edu.thu.ext.excel.xpt.XptExpandCell;
import edu.thu.ext.excel.xpt.XptExpandTable;
import edu.thu.model.Pair;
import java.util.List;

public class CellPosExpr
  implements ICellRangeExpr
{
  private static final long serialVersionUID = -1152024922588971542L;
  CellPosition D;
  
  public CellPosExpr(CellPosition paramCellPosition)
  {
    this.D = paramCellPosition;
  }
  
  public String getExprString(int paramInt)
  {
    return this.D.getExprString(paramInt);
  }
  
  public boolean isMultipleResult()
  {
    return false;
  }
  
  public CellPosition getPos()
  {
    return this.D;
  }
  
  public void setPosition(CellPosition paramCellPosition)
  {
    this.D = paramCellPosition;
  }
  
  public Pair<Number, Number> sumAndCountAll(XptBuildRuntime paramXptBuildRuntime)
  {
    XptExpandTable localXptExpandTable = paramXptBuildRuntime.getExpandTable();
    XptExpandCell localXptExpandCell = localXptExpandTable.getExpandCell(this.D.getRowPos(), this.D.getColPos());
    if (localXptExpandCell == null) {
      return null;
    }
    Pair localPair = localXptExpandCell.sumAndCountAllSameParent(paramXptBuildRuntime.getCellData(), paramXptBuildRuntime);
    return localPair;
  }
  
  public Number avgAll(XptBuildRuntime paramXptBuildRuntime)
  {
    Pair localPair = sumAndCountAll(paramXptBuildRuntime);
    if (localPair == null) {
      return null;
    }
    if (((Number)localPair.getSecond()).intValue() <= 0) {
      return null;
    }
    return Double.valueOf(((Number)localPair.getFirst()).doubleValue() / ((Number)localPair.getSecond()).intValue());
  }
  
  public double sumAll(XptBuildRuntime paramXptBuildRuntime)
  {
    XptExpandTable localXptExpandTable = paramXptBuildRuntime.getExpandTable();
    XptExpandCell localXptExpandCell = localXptExpandTable.getExpandCell(this.D.getRowPos(), this.D.getColPos());
    if (localXptExpandCell == null) {
      return 0.0D;
    }
    return localXptExpandCell.sumAllSameParent(paramXptBuildRuntime.getCellData(), paramXptBuildRuntime);
  }
  
  public int countAll(XptBuildRuntime paramXptBuildRuntime)
  {
    XptExpandTable localXptExpandTable = paramXptBuildRuntime.getExpandTable();
    XptExpandCell localXptExpandCell = localXptExpandTable.getExpandCell(this.D.getRowPos(), this.D.getColPos());
    if (localXptExpandCell == null) {
      return 0;
    }
    return localXptExpandCell.countAllSameParent(paramXptBuildRuntime.getCellData(), paramXptBuildRuntime);
  }
  
  public int countAllNumber(XptBuildRuntime paramXptBuildRuntime)
  {
    XptExpandTable localXptExpandTable = paramXptBuildRuntime.getExpandTable();
    XptExpandCell localXptExpandCell = localXptExpandTable.getExpandCell(this.D.getRowPos(), this.D.getColPos());
    if (localXptExpandCell == null) {
      return 0;
    }
    return localXptExpandCell.countAllNumberSameParent(paramXptBuildRuntime.getCellData(), paramXptBuildRuntime);
  }
  
  public List<CellData> getAllCells(XptBuildRuntime paramXptBuildRuntime)
  {
    XptExpandTable localXptExpandTable = paramXptBuildRuntime.getExpandTable();
    XptExpandCell localXptExpandCell = localXptExpandTable.getExpandCell(this.D.getRowPos(), this.D.getColPos());
    if (localXptExpandCell == null) {
      return null;
    }
    return localXptExpandCell.getAllCellsSameParent(paramXptBuildRuntime.getCellData(), paramXptBuildRuntime);
  }
  
  public Object getFirstValue(XptBuildRuntime paramXptBuildRuntime)
  {
    XptExpandTable localXptExpandTable = paramXptBuildRuntime.getExpandTable();
    XptExpandCell localXptExpandCell = localXptExpandTable.getExpandCell(this.D.getRowPos(), this.D.getColPos());
    if (localXptExpandCell == null) {
      return null;
    }
    return localXptExpandCell.getFirstValueSameParent(paramXptBuildRuntime.getCellData(), paramXptBuildRuntime);
  }
  
  public List<CellData> getExpandedCells(XptBuildRuntime paramXptBuildRuntime)
  {
    XptExpandTable localXptExpandTable = paramXptBuildRuntime.getExpandTable();
    XptExpandCell localXptExpandCell = localXptExpandTable.getExpandCell(this.D.getRowPos(), this.D.getColPos());
    if (localXptExpandCell == null) {
      return null;
    }
    return localXptExpandCell.getExpandedCells();
  }
  
  public CellRange getExpandedRange(XptBuildRuntime paramXptBuildRuntime)
  {
    List localList = getExpandedCells(paramXptBuildRuntime);
    CellRange localCellRange = FormulaImpls.getCellRange(localList);
    if (localCellRange == null) {
      return null;
    }
    int i = localCellRange.getMinRow();
    int j = localCellRange.getMaxRow();
    int k = localCellRange.getMinCol();
    int m = localCellRange.getMaxCol();
    CellData localCellData = (CellData)localList.get(0);
    int n = localList.size();
    if ((j - i + localCellData.getMergeDown() + 1) * (m - k + localCellData.getMergeAcross() + 1) == (localCellData.getMergeDown() + 1) * n * (localCellData.getMergeAcross() + 1)) {
      return localCellRange;
    }
    return null;
  }
  
  public List<Object> getExpandedValues(XptBuildRuntime paramXptBuildRuntime)
  {
    XptExpandTable localXptExpandTable = paramXptBuildRuntime.getExpandTable();
    XptExpandCell localXptExpandCell = localXptExpandTable.getExpandCell(this.D.getRowPos(), this.D.getColPos());
    if (localXptExpandCell == null) {
      return null;
    }
    return localXptExpandCell.getExpandedValues(paramXptBuildRuntime);
  }
  
  public List<Object> getAllValues(XptBuildRuntime paramXptBuildRuntime)
  {
    XptExpandTable localXptExpandTable = paramXptBuildRuntime.getExpandTable();
    XptExpandCell localXptExpandCell = localXptExpandTable.getExpandCell(this.D.getRowPos(), this.D.getColPos());
    if (localXptExpandCell == null) {
      return null;
    }
    return localXptExpandCell.getAllValuesSameParent(paramXptBuildRuntime.getCellData(), paramXptBuildRuntime);
  }
  
  public Object evaluate(XptBuildRuntime paramXptBuildRuntime)
  {
    return getAllValues(paramXptBuildRuntime);
  }
  
  public String getExpandedFormula(XptBuildRuntime paramXptBuildRuntime)
  {
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\formula\exprs\CellPosExpr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */