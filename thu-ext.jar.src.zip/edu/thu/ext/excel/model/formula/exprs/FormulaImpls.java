package edu.thu.ext.excel.model.formula.exprs;

import edu.thu.ext.excel.model.CellPosition;
import edu.thu.ext.excel.model.CellRange;
import edu.thu.ext.excel.model.data.CellData;
import edu.thu.ext.excel.model.formula.ICellFormulaExpr;
import java.util.Iterator;
import java.util.List;

public class FormulaImpls
{
  public static void checkNotEmpty(ICellFormulaExpr paramICellFormulaExpr) {}
  
  public static CellRange getCellRange(List<CellData> paramList)
  {
    if ((paramList == null) || (paramList.isEmpty())) {
      return null;
    }
    int i = 0;
    int j = Integer.MAX_VALUE;
    int k = 0;
    int m = Integer.MAX_VALUE;
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      CellData localCellData = (CellData)localIterator.next();
      int n = localCellData.getRowIndex();
      int i1 = localCellData.getCalcColIndex();
      if (n < i) {
        i = n;
      } else if (n > j) {
        j = n;
      }
      if (i1 < k) {
        k = i1;
      } else if (i1 > m) {
        m = i1;
      }
    }
    return new CellRange(new CellPosition(i, k), new CellPosition(j, m));
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\formula\exprs\FormulaImpls.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */