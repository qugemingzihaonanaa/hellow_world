package edu.thu.ext.excel.model.formula.exprs;

import edu.thu.ext.excel.model.formula.ICellFormulaExpr;
import edu.thu.ext.excel.xpt.XptBuildRuntime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public abstract class BinaryFormulaExpr
  implements ICellFormulaExpr
{
  private static final long serialVersionUID = -2551708626321090082L;
  ICellFormulaExpr C;
  ICellFormulaExpr A;
  String B;
  
  public BinaryFormulaExpr(String paramString, ICellFormulaExpr paramICellFormulaExpr1, ICellFormulaExpr paramICellFormulaExpr2)
  {
    this.B = paramString;
    this.C = paramICellFormulaExpr1;
    this.A = paramICellFormulaExpr2;
  }
  
  public String getExprString(int paramInt)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    if (this.C != null) {
      localStringBuilder.append(this.C.getExprString(paramInt));
    }
    localStringBuilder.append(' ');
    localStringBuilder.append(this.B);
    localStringBuilder.append(' ');
    localStringBuilder.append(this.A.getExprString(paramInt));
    return localStringBuilder.toString();
  }
  
  public ICellFormulaExpr getLeftExpr()
  {
    return this.C;
  }
  
  public void setLeftExpr(ICellFormulaExpr paramICellFormulaExpr)
  {
    this.C = paramICellFormulaExpr;
  }
  
  public ICellFormulaExpr getRightExpr()
  {
    return this.A;
  }
  
  public void setRightExpr(ICellFormulaExpr paramICellFormulaExpr)
  {
    this.A = paramICellFormulaExpr;
  }
  
  public boolean isMultipleResult()
  {
    return false;
  }
  
  protected Object binaryOp(Object paramObject1, Object paramObject2)
  {
    return null;
  }
  
  protected Object normValue(Object paramObject)
  {
    if ((paramObject instanceof Collection))
    {
      Collection localCollection = (Collection)paramObject;
      if (localCollection.isEmpty()) {
        return null;
      }
      return localCollection.iterator().next();
    }
    return paramObject;
  }
  
  public Object evaluate(XptBuildRuntime paramXptBuildRuntime)
  {
    Object localObject1 = getLeftExpr().evaluate(paramXptBuildRuntime);
    Object localObject2 = getRightExpr().evaluate(paramXptBuildRuntime);
    localObject1 = normValue(localObject1);
    localObject2 = normValue(localObject2);
    Collection localCollection;
    ArrayList localArrayList;
    Object localObject3;
    Iterator localIterator;
    Object localObject4;
    if ((localObject1 instanceof Collection))
    {
      localCollection = (Collection)localObject1;
      localArrayList = new ArrayList(localCollection.size());
      if ((localObject2 instanceof Collection))
      {
        localObject3 = (Collection)localObject2;
        localIterator = localCollection.iterator();
        localObject4 = ((Collection)localObject3).iterator();
        do
        {
          Object localObject5 = localIterator.next();
          Object localObject6 = ((Iterator)localObject4).next();
          localArrayList.add(binaryOp(localObject5, localObject6));
          if (!localIterator.hasNext()) {
            break;
          }
        } while (((Iterator)localObject4).hasNext());
      }
      else
      {
        localIterator = localCollection.iterator();
        while (localIterator.hasNext())
        {
          localObject3 = localIterator.next();
          localObject4 = binaryOp(localObject3, localObject2);
          localArrayList.add(localObject4);
        }
      }
      return localArrayList;
    }
    if ((localObject2 instanceof Collection))
    {
      localCollection = (Collection)localObject2;
      localArrayList = new ArrayList(localCollection.size());
      localIterator = localCollection.iterator();
      while (localIterator.hasNext())
      {
        localObject3 = localIterator.next();
        localObject4 = binaryOp(localObject1, localObject3);
        localArrayList.add(localObject4);
      }
      return localArrayList;
    }
    return binaryOp(localObject1, localObject2);
  }
  
  public String getExpandedFormula(XptBuildRuntime paramXptBuildRuntime)
  {
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\formula\exprs\BinaryFormulaExpr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */