package edu.thu.ext.excel.model.formula.exprs;

import edu.thu.ext.excel.model.formula.ICellFuncProvider;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import java.util.HashMap;
import java.util.Map;

public class DefaultCellFuncProvider
  implements ICellFuncProvider
{
  static Map<String, CellFuncExpr> B = new HashMap();
  Map<String, CellFuncExpr> A = new HashMap();
  
  static
  {
    regGlobalFunc(FormulaExprs.SUM());
    regGlobalFunc(FormulaExprs.COUNT());
    regGlobalFunc(FormulaExprs.ROUND());
    regGlobalFunc(FormulaExprs.AVERAGE());
    regGlobalFunc(StatFormulaExprs.NORMSINV());
    regGlobalFunc(ExFormulaExprs.COUNTA());
    regGlobalFunc(ExFormulaExprs.RANK());
  }
  
  public static void regGlobalFunc(CellFuncExpr paramCellFuncExpr)
  {
    B.put(paramCellFuncExpr.getFuncName(), paramCellFuncExpr);
  }
  
  public void regFunc(CellFuncExpr paramCellFuncExpr)
  {
    this.A.put(paramCellFuncExpr.getFuncName(), paramCellFuncExpr);
  }
  
  public CellFuncExpr newFunc(String paramString)
  {
    CellFuncExpr localCellFuncExpr = (CellFuncExpr)this.A.get(paramString);
    if (localCellFuncExpr == null) {
      localCellFuncExpr = (CellFuncExpr)B.get(paramString);
    }
    if (localCellFuncExpr == null) {
      throw Exceptions.code("excel.CAN_err_unkown_formula_function").param(paramString);
    }
    return localCellFuncExpr.newInstance();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\formula\exprs\DefaultCellFuncProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */