package edu.thu.ext.excel.model.formula.exprs;

import edu.thu.ext.excel.model.formula.ICellFormulaExpr;
import edu.thu.ext.excel.xpt.XptBuildRuntime;

public class StatFormulaExprs
{
  public static CellFuncExpr NORMSINV()
  {
    new CellFuncExpr("NORMSINV", 1)
    {
      public CellFuncExpr newInstance()
      {
        return StatFormulaExprs.NORMSINV();
      }
      
      public Object evaluate(XptBuildRuntime paramAnonymousXptBuildRuntime)
      {
        ICellFormulaExpr localICellFormulaExpr = getFirstArgExpr();
        Object localObject = localICellFormulaExpr.evaluate(paramAnonymousXptBuildRuntime);
        return null;
      }
    };
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\formula\exprs\StatFormulaExprs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */