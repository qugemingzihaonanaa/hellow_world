package edu.thu.ext.excel.model.formula.exprs;

import edu.thu.ext.excel.model.CellPosition;
import edu.thu.ext.excel.model.CellRange;
import edu.thu.ext.excel.model.data.CellData;
import edu.thu.ext.excel.xpt.XptBuildRuntime;
import edu.thu.ext.excel.xpt.XptExpandCell;
import edu.thu.ext.excel.xpt.XptExpandTable;
import edu.thu.model.Pair;
import java.util.ArrayList;
import java.util.List;

public class CellRangeExpr
  implements ICellRangeExpr
{
  private static final long serialVersionUID = -7505882681316389705L;
  CellPosition F;
  CellPosition E;
  
  public CellRangeExpr(CellPosition paramCellPosition1, CellPosition paramCellPosition2)
  {
    this.F = paramCellPosition1;
    this.E = paramCellPosition2;
  }
  
  public String getExprString(int paramInt)
  {
    return this.F.getExprString(paramInt) + ":" + this.E.getExprString(paramInt);
  }
  
  public boolean isMultipleResult()
  {
    return true;
  }
  
  public CellPosition getLtPos()
  {
    return this.F;
  }
  
  public void setLtPos(CellPosition paramCellPosition)
  {
    this.F = paramCellPosition;
  }
  
  public CellPosition getRbPos()
  {
    return this.E;
  }
  
  public CellRange getExpandedRange(XptBuildRuntime paramXptBuildRuntime)
  {
    List localList = getAllCells(paramXptBuildRuntime);
    CellRange localCellRange = FormulaImpls.getCellRange(localList);
    if (localCellRange == null) {
      return null;
    }
    int i = localCellRange.getMinRow();
    int j = localCellRange.getMaxRow();
    int k = localCellRange.getMinCol();
    int m = localCellRange.getMaxCol();
    CellData localCellData = (CellData)localList.get(0);
    int n = localList.size();
    if ((j - i + localCellData.getMergeDown() + 1) * (m - k + localCellData.getMergeAcross() + 1) == (localCellData.getMergeDown() + 1) * n * (localCellData.getMergeAcross() + 1)) {
      return localCellRange;
    }
    return localCellRange;
  }
  
  public double sumAll(XptBuildRuntime paramXptBuildRuntime)
  {
    XptExpandTable localXptExpandTable = paramXptBuildRuntime.getExpandTable();
    if (localXptExpandTable == null) {
      return 0.0D;
    }
    int i = this.F.getRowPos();
    int j = this.F.getColPos();
    int k = this.E.getRowPos();
    int m = this.E.getColPos();
    double d = 0.0D;
    for (int n = i; n <= k; n++) {
      for (int i1 = j; i1 <= m; i1++)
      {
        XptExpandCell localXptExpandCell = localXptExpandTable.getExpandCell(n, i1);
        if (localXptExpandCell != null) {
          d += localXptExpandCell.sumAllSameParent(paramXptBuildRuntime.getCellData(), paramXptBuildRuntime);
        }
      }
    }
    return d;
  }
  
  public Pair<Number, Number> sumAndCountAll(XptBuildRuntime paramXptBuildRuntime)
  {
    XptExpandTable localXptExpandTable = paramXptBuildRuntime.getExpandTable();
    if (localXptExpandTable == null) {
      return null;
    }
    int i = this.F.getRowPos();
    int j = this.F.getColPos();
    int k = this.E.getRowPos();
    int m = this.E.getColPos();
    double d1 = 0.0D;
    double d2 = 0.0D;
    for (int n = i; n <= k; n++) {
      for (int i1 = j; i1 <= m; i1++)
      {
        XptExpandCell localXptExpandCell = localXptExpandTable.getExpandCell(n, i1);
        if (localXptExpandCell != null)
        {
          Pair localPair = localXptExpandCell.sumAndCountAllSameParent(paramXptBuildRuntime.getCellData(), paramXptBuildRuntime);
          if (localPair != null)
          {
            d1 += ((Number)localPair.getFirst()).doubleValue();
            d2 += ((Number)localPair.getSecond()).intValue();
          }
        }
      }
    }
    if (d2 == 0.0D) {
      return null;
    }
    return new Pair(Double.valueOf(d1), Double.valueOf(d2));
  }
  
  public Number avgAll(XptBuildRuntime paramXptBuildRuntime)
  {
    XptExpandTable localXptExpandTable = paramXptBuildRuntime.getExpandTable();
    if (localXptExpandTable == null) {
      return null;
    }
    int i = this.F.getRowPos();
    int j = this.F.getColPos();
    int k = this.E.getRowPos();
    int m = this.E.getColPos();
    double d1 = 0.0D;
    double d2 = 0.0D;
    for (int n = i; n <= k; n++) {
      for (int i1 = j; i1 <= m; i1++)
      {
        XptExpandCell localXptExpandCell = localXptExpandTable.getExpandCell(n, i1);
        if (localXptExpandCell != null)
        {
          Pair localPair = localXptExpandCell.sumAndCountAllSameParent(paramXptBuildRuntime.getCellData(), paramXptBuildRuntime);
          d1 += ((Number)localPair.getFirst()).doubleValue();
          d2 += ((Number)localPair.getSecond()).intValue();
        }
      }
    }
    if (d2 == 0.0D) {
      return null;
    }
    return Double.valueOf(d1 / d2);
  }
  
  public int countAll(XptBuildRuntime paramXptBuildRuntime)
  {
    XptExpandTable localXptExpandTable = paramXptBuildRuntime.getExpandTable();
    int i = this.F.getRowPos();
    int j = this.F.getColPos();
    int k = this.E.getRowPos();
    int m = this.E.getColPos();
    int n = 0;
    for (int i1 = i; i1 <= k; i1++) {
      for (int i2 = j; i2 <= m; i2++)
      {
        XptExpandCell localXptExpandCell = localXptExpandTable.getExpandCell(i1, i2);
        if (localXptExpandCell != null) {
          n += localXptExpandCell.countAllSameParent(paramXptBuildRuntime.getCellData(), paramXptBuildRuntime);
        }
      }
    }
    return n;
  }
  
  public int countNotNull(XptBuildRuntime paramXptBuildRuntime)
  {
    XptExpandTable localXptExpandTable = paramXptBuildRuntime.getExpandTable();
    int i = this.F.getRowPos();
    int j = this.F.getColPos();
    int k = this.E.getRowPos();
    int m = this.E.getColPos();
    int n = 0;
    for (int i1 = i; i1 <= k; i1++) {
      for (int i2 = j; i2 <= m; i2++)
      {
        XptExpandCell localXptExpandCell = localXptExpandTable.getExpandCell(i1, i2);
        if (localXptExpandCell != null) {
          n += localXptExpandCell.countNotNull(paramXptBuildRuntime);
        }
      }
    }
    return n;
  }
  
  public int countAllNumber(XptBuildRuntime paramXptBuildRuntime)
  {
    XptExpandTable localXptExpandTable = paramXptBuildRuntime.getExpandTable();
    int i = this.F.getRowPos();
    int j = this.F.getColPos();
    int k = this.E.getRowPos();
    int m = this.E.getColPos();
    int n = 0;
    for (int i1 = i; i1 <= k; i1++) {
      for (int i2 = j; i2 <= m; i2++)
      {
        XptExpandCell localXptExpandCell = localXptExpandTable.getExpandCell(i1, i2);
        if (localXptExpandCell != null) {
          n += localXptExpandCell.countAllNumberSameParent(paramXptBuildRuntime.getCellData(), paramXptBuildRuntime);
        }
      }
    }
    return n;
  }
  
  public List<Object> getAllValues(XptBuildRuntime paramXptBuildRuntime)
  {
    XptExpandTable localXptExpandTable = paramXptBuildRuntime.getExpandTable();
    int i = this.F.getRowPos();
    int j = this.F.getColPos();
    int k = this.E.getRowPos();
    int m = this.E.getColPos();
    ArrayList localArrayList = new ArrayList();
    for (int n = i; n <= k; n++) {
      for (int i1 = j; i1 <= m; i1++)
      {
        XptExpandCell localXptExpandCell = localXptExpandTable.getExpandCell(n, i1);
        if (localXptExpandCell != null) {
          localArrayList.addAll(localXptExpandCell.getAllValuesSameParent(paramXptBuildRuntime.getCellData(), paramXptBuildRuntime));
        }
      }
    }
    return localArrayList;
  }
  
  public List<CellData> getAllCells(XptBuildRuntime paramXptBuildRuntime)
  {
    XptExpandTable localXptExpandTable = paramXptBuildRuntime.getExpandTable();
    int i = this.F.getRowPos();
    int j = this.F.getColPos();
    int k = this.E.getRowPos();
    int m = this.E.getColPos();
    ArrayList localArrayList = new ArrayList();
    for (int n = i; n <= k; n++) {
      for (int i1 = j; i1 <= m; i1++)
      {
        XptExpandCell localXptExpandCell = localXptExpandTable.getExpandCell(n, i1);
        if (localXptExpandCell != null) {
          localXptExpandCell.collectAllCellsSameParent(paramXptBuildRuntime.getCellData(), paramXptBuildRuntime, localArrayList);
        }
      }
    }
    return localArrayList;
  }
  
  public Object evaluate(XptBuildRuntime paramXptBuildRuntime)
  {
    return getAllValues(paramXptBuildRuntime);
  }
  
  public String getExpandedFormula(XptBuildRuntime paramXptBuildRuntime)
  {
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\formula\exprs\CellRangeExpr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */