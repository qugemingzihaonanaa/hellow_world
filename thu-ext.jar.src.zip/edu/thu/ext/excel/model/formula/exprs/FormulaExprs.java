package edu.thu.ext.excel.model.formula.exprs;

import edu.thu.ext.excel.model.formula.ICellFormulaExpr;
import edu.thu.ext.excel.xpt.XptBuildRuntime;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.util.Coercions;
import edu.thu.java.util.MathOps;
import edu.thu.java.util.OpUtils;
import edu.thu.lang.exceptions.StdException;
import edu.thu.math.alg.Alog;
import edu.thu.model.Pair;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class FormulaExprs
{
  public static BinaryFormulaExpr LT_Op(ICellFormulaExpr paramICellFormulaExpr1, ICellFormulaExpr paramICellFormulaExpr2)
  {
    new BinaryFormulaExpr("<", paramICellFormulaExpr1, paramICellFormulaExpr2)
    {
      private static final long serialVersionUID = -6048942546276909701L;
      
      public Object binaryOp(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        return Integer.valueOf(OpUtils.lt(paramAnonymousObject1, paramAnonymousObject2) ? 1 : 0);
      }
    };
  }
  
  public static BinaryFormulaExpr LTEQ_Op(ICellFormulaExpr paramICellFormulaExpr1, ICellFormulaExpr paramICellFormulaExpr2)
  {
    new BinaryFormulaExpr("<=", paramICellFormulaExpr1, paramICellFormulaExpr2)
    {
      private static final long serialVersionUID = -7390288966706706458L;
      
      public Object binaryOp(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        return Integer.valueOf(OpUtils.le(paramAnonymousObject1, paramAnonymousObject2) ? 1 : 0);
      }
    };
  }
  
  public static BinaryFormulaExpr GT_Op(ICellFormulaExpr paramICellFormulaExpr1, ICellFormulaExpr paramICellFormulaExpr2)
  {
    new BinaryFormulaExpr(">", paramICellFormulaExpr1, paramICellFormulaExpr2)
    {
      private static final long serialVersionUID = 5304479181781312443L;
      
      public Object binaryOp(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        return Integer.valueOf(OpUtils.gt(paramAnonymousObject1, paramAnonymousObject2) ? 1 : 0);
      }
    };
  }
  
  public static BinaryFormulaExpr GTEQ_Op(ICellFormulaExpr paramICellFormulaExpr1, ICellFormulaExpr paramICellFormulaExpr2)
  {
    new BinaryFormulaExpr(">=", paramICellFormulaExpr1, paramICellFormulaExpr2)
    {
      private static final long serialVersionUID = 5304479181781312443L;
      
      public Object binaryOp(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        return Integer.valueOf(OpUtils.ge(paramAnonymousObject1, paramAnonymousObject2) ? 1 : 0);
      }
    };
  }
  
  public static BinaryFormulaExpr EQ_Op(ICellFormulaExpr paramICellFormulaExpr1, ICellFormulaExpr paramICellFormulaExpr2)
  {
    new BinaryFormulaExpr("=", paramICellFormulaExpr1, paramICellFormulaExpr2)
    {
      private static final long serialVersionUID = 5304479181781312443L;
      
      public Object binaryOp(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        return Integer.valueOf(OpUtils.eq(paramAnonymousObject1, paramAnonymousObject2) ? 1 : 0);
      }
    };
  }
  
  public static BinaryFormulaExpr NOTEQ_Op(ICellFormulaExpr paramICellFormulaExpr1, ICellFormulaExpr paramICellFormulaExpr2)
  {
    new BinaryFormulaExpr("<>", paramICellFormulaExpr1, paramICellFormulaExpr2)
    {
      private static final long serialVersionUID = 5304479181781312443L;
      
      public Object binaryOp(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        return Integer.valueOf(OpUtils.ne(paramAnonymousObject1, paramAnonymousObject2) ? 1 : 0);
      }
    };
  }
  
  public static BinaryFormulaExpr CONCAT_Op(ICellFormulaExpr paramICellFormulaExpr1, ICellFormulaExpr paramICellFormulaExpr2)
  {
    new BinaryFormulaExpr("&", paramICellFormulaExpr1, paramICellFormulaExpr2)
    {
      private static final long serialVersionUID = 5304479181781312443L;
      
      public Object binaryOp(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        String str1 = Coercions.toString(paramAnonymousObject1, "");
        String str2 = Coercions.toString(paramAnonymousObject2, "");
        return str1 + str2;
      }
    };
  }
  
  public static ICellFormulaExpr value(Object paramObject)
  {
    new ICellFormulaExpr()
    {
      private static final long serialVersionUID = 5304479181781312443L;
      
      public Object evaluate(XptBuildRuntime paramAnonymousXptBuildRuntime)
      {
        return FormulaExprs.this;
      }
      
      public String getExprString(int paramAnonymousInt)
      {
        return String.valueOf(FormulaExprs.this);
      }
      
      public String getExpandedFormula(XptBuildRuntime paramAnonymousXptBuildRuntime)
      {
        return null;
      }
    };
  }
  
  public static BinaryFormulaExpr ADD_Op(ICellFormulaExpr paramICellFormulaExpr1, ICellFormulaExpr paramICellFormulaExpr2)
  {
    new BinaryFormulaExpr("+", paramICellFormulaExpr1, paramICellFormulaExpr2)
    {
      private static final long serialVersionUID = 5304479181781312443L;
      
      public Object binaryOp(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        return MathOps.add(paramAnonymousObject1, paramAnonymousObject2);
      }
    };
  }
  
  public static BinaryFormulaExpr SUB_Op(ICellFormulaExpr paramICellFormulaExpr1, ICellFormulaExpr paramICellFormulaExpr2)
  {
    new BinaryFormulaExpr("-", paramICellFormulaExpr1 == null ? value(Integer.valueOf(0)) : paramICellFormulaExpr1, paramICellFormulaExpr2)
    {
      private static final long serialVersionUID = 5304479181781312443L;
      
      public Object binaryOp(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        return MathOps.minus(paramAnonymousObject1, paramAnonymousObject2);
      }
    };
  }
  
  public static BinaryFormulaExpr DIV_Op(ICellFormulaExpr paramICellFormulaExpr1, ICellFormulaExpr paramICellFormulaExpr2)
  {
    new BinaryFormulaExpr("/", paramICellFormulaExpr1, paramICellFormulaExpr2)
    {
      private static final long serialVersionUID = 5304479181781312443L;
      
      public Object binaryOp(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        return MathOps.safeDivide(paramAnonymousObject1, paramAnonymousObject2);
      }
    };
  }
  
  public static BinaryFormulaExpr MULT_Op(ICellFormulaExpr paramICellFormulaExpr1, ICellFormulaExpr paramICellFormulaExpr2)
  {
    new BinaryFormulaExpr("*", paramICellFormulaExpr1, paramICellFormulaExpr2)
    {
      private static final long serialVersionUID = 5304479181781312443L;
      
      public Object binaryOp(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        return MathOps.multiply(paramAnonymousObject1, paramAnonymousObject2);
      }
    };
  }
  
  public static BinaryFormulaExpr EXP_Op(ICellFormulaExpr paramICellFormulaExpr1, ICellFormulaExpr paramICellFormulaExpr2)
  {
    new BinaryFormulaExpr("^", paramICellFormulaExpr1, paramICellFormulaExpr2)
    {
      private static final long serialVersionUID = 5304479181781312443L;
      
      public Object binaryOp(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        if (paramAnonymousObject1 == null) {
          return null;
        }
        if (paramAnonymousObject2 == null) {
          return null;
        }
        return Double.valueOf(Math.pow(Coercions.toDouble(paramAnonymousObject1, 0.0D), Coercions.toDouble(paramAnonymousObject2, 0.0D)));
      }
    };
  }
  
  public static CellFuncExpr invalidFunc(String paramString)
  {
    new CellFuncExpr(paramString)
    {
      private static final long serialVersionUID = 5304479181781312443L;
      
      public void endArg()
      {
        throw Exceptions.code("excel.CAN_err_invalid_func").param(this.K).param(this);
      }
      
      public Object evaluate(XptBuildRuntime paramAnonymousXptBuildRuntime)
      {
        throw Exceptions.notAllowed();
      }
    };
  }
  
  public static CellFuncExpr AVERAGE()
  {
    new CellFuncExpandExpr("AVERAGE")
    {
      private static final long serialVersionUID = 5304479181781312443L;
      
      public CellFuncExpr newInstance()
      {
        return FormulaExprs.AVERAGE();
      }
      
      public Object evaluate(XptBuildRuntime paramAnonymousXptBuildRuntime)
      {
        double d = 0.0D;
        int i = 0;
        Iterator localIterator = getArgExprs().iterator();
        while (localIterator.hasNext())
        {
          ICellFormulaExpr localICellFormulaExpr = (ICellFormulaExpr)localIterator.next();
          Object localObject;
          if ((localICellFormulaExpr instanceof ICellRangeExpr))
          {
            localObject = ((ICellRangeExpr)localICellFormulaExpr).sumAndCountAll(paramAnonymousXptBuildRuntime);
            if (localObject != null)
            {
              d += ((Number)((Pair)localObject).getFirst()).doubleValue();
              i = (int)(i + ((Number)((Pair)localObject).getSecond()).doubleValue());
            }
          }
          else
          {
            localObject = localICellFormulaExpr.evaluate(paramAnonymousXptBuildRuntime);
            if ((localObject instanceof Collection))
            {
              localObject = Alog.sum((Collection)localObject);
              d += Coercions.toDouble(localObject, 0.0D);
              i += ((Collection)localObject).size();
            }
            else
            {
              d += Coercions.toDouble(localObject, 0.0D);
              i++;
            }
          }
        }
        if (i == 0) {
          return null;
        }
        return Double.valueOf(d / i);
      }
    };
  }
  
  public static CellFuncExpr SUM()
  {
    new CellFuncExpandExpr("SUM")
    {
      private static final long serialVersionUID = 5304479181781312443L;
      
      public CellFuncExpr newInstance()
      {
        return FormulaExprs.SUM();
      }
      
      public Object evaluate(XptBuildRuntime paramAnonymousXptBuildRuntime)
      {
        double d = 0.0D;
        Iterator localIterator = getArgExprs().iterator();
        while (localIterator.hasNext())
        {
          ICellFormulaExpr localICellFormulaExpr = (ICellFormulaExpr)localIterator.next();
          if ((localICellFormulaExpr instanceof ICellRangeExpr))
          {
            d += ((ICellRangeExpr)localICellFormulaExpr).sumAll(paramAnonymousXptBuildRuntime);
          }
          else
          {
            Object localObject = localICellFormulaExpr.evaluate(paramAnonymousXptBuildRuntime);
            if ((localObject instanceof Collection)) {
              localObject = Alog.sum((Collection)localObject);
            }
            d += Coercions.toDouble(localObject, 0.0D);
          }
        }
        return Double.valueOf(d);
      }
    };
  }
  
  public static CellFuncExpr COUNT()
  {
    new CellFuncExpandExpr("COUNT")
    {
      private static final long serialVersionUID = 5304479181781312443L;
      
      public CellFuncExpr newInstance()
      {
        return FormulaExprs.COUNT();
      }
      
      public Object evaluate(XptBuildRuntime paramAnonymousXptBuildRuntime)
      {
        int i = 0;
        Iterator localIterator1 = getArgExprs().iterator();
        while (localIterator1.hasNext())
        {
          ICellFormulaExpr localICellFormulaExpr = (ICellFormulaExpr)localIterator1.next();
          if ((localICellFormulaExpr instanceof ICellRangeExpr))
          {
            i += ((ICellRangeExpr)localICellFormulaExpr).countAllNumber(paramAnonymousXptBuildRuntime);
          }
          else
          {
            Object localObject1 = localICellFormulaExpr.evaluate(paramAnonymousXptBuildRuntime);
            if ((localObject1 instanceof Collection))
            {
              Iterator localIterator2 = ((Collection)localObject1).iterator();
              while (localIterator2.hasNext())
              {
                Object localObject2 = localIterator2.next();
                if ((localObject2 instanceof Number)) {
                  i++;
                }
              }
            }
            else if ((localObject1 instanceof Number))
            {
              i++;
            }
          }
        }
        return Integer.valueOf(i);
      }
    };
  }
  
  public static CellFuncExpr ROUND()
  {
    new CellFuncExpr("ROUND", 2)
    {
      private static final long serialVersionUID = 5304479181781312443L;
      
      public CellFuncExpr newInstance()
      {
        return FormulaExprs.ROUND();
      }
      
      public Object evaluate(XptBuildRuntime paramAnonymousXptBuildRuntime)
      {
        double d = Coercions.toDouble(evaluateFirstArg(paramAnonymousXptBuildRuntime), 0.0D);
        int i = Coercions.toInt(evaluateSecondArg(paramAnonymousXptBuildRuntime), 0);
        return Alog.round(Double.valueOf(d), i);
      }
    };
  }
  
  public static CellFuncExpr SUMPRODUCT()
  {
    new CellFuncExpr("SUMPRODUCT")
    {
      private static final long serialVersionUID = 5304479181781312443L;
      
      public CellFuncExpr newInstance()
      {
        return FormulaExprs.SUMPRODUCT();
      }
      
      public Object evaluate(XptBuildRuntime paramAnonymousXptBuildRuntime)
      {
        ArrayList localArrayList = new ArrayList();
        Iterator localIterator1 = getArgExprs().iterator();
        while (localIterator1.hasNext())
        {
          ICellFormulaExpr localICellFormulaExpr = (ICellFormulaExpr)localIterator1.next();
          Object localObject1 = localICellFormulaExpr.evaluate(paramAnonymousXptBuildRuntime);
          if ((localObject1 instanceof Collection))
          {
            if (localArrayList.isEmpty())
            {
              localArrayList.addAll((Collection)localObject1);
            }
            else
            {
              Collection localCollection = (Collection)localObject1;
              if (localCollection.size() != localArrayList.size()) {
                throw Exceptions.code("excel.CAN_err_invalid_arg_value").param(localObject1).param(this);
              }
              int i = 0;
              Iterator localIterator2 = localCollection.iterator();
              while (localIterator2.hasNext())
              {
                Object localObject2 = localIterator2.next();
                Object localObject3 = MathOps.multiply(localArrayList.get(i), localObject2);
                localArrayList.set(i, localObject3);
                i++;
              }
            }
          }
          else {
            throw Exceptions.code("excel.CAN_err_invalid_arg_value").param(localObject1).param(this);
          }
        }
        return Alog.sum(localArrayList);
      }
    };
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\formula\exprs\FormulaExprs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */