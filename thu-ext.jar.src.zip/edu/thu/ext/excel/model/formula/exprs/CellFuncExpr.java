package edu.thu.ext.excel.model.formula.exprs;

import edu.thu.ext.excel.model.formula.ICellFormulaExpr;
import edu.thu.ext.excel.xpt.XptBuildRuntime;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.exceptions.StdException;
import edu.thu.lang.reflect.BeanInstance;
import java.util.ArrayList;
import java.util.List;

public abstract class CellFuncExpr
  implements ICellFormulaExpr
{
  private static final long serialVersionUID = -5420422578780631157L;
  String K;
  List<ICellFormulaExpr> J = new ArrayList();
  int L = -1;
  
  public CellFuncExpr(String paramString, int paramInt)
  {
    this.K = paramString;
    this.L = paramInt;
  }
  
  public CellFuncExpr(String paramString)
  {
    this.K = paramString;
  }
  
  public String getExprString(int paramInt)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(this.K);
    localStringBuilder.append('(');
    int j = this.J.size();
    for (int i = 0; i < j; i++)
    {
      ICellFormulaExpr localICellFormulaExpr = (ICellFormulaExpr)this.J.get(i);
      localStringBuilder.append(localICellFormulaExpr.getExprString(paramInt));
      if (i != j - 1) {
        localStringBuilder.append(',');
      }
    }
    localStringBuilder.append(')');
    return localStringBuilder.toString();
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(this.K);
    localStringBuilder.append(this.J);
    return localStringBuilder.toString();
  }
  
  public boolean isMultipleResult()
  {
    return false;
  }
  
  public String getFuncName()
  {
    return this.K;
  }
  
  public void setFuncName(String paramString)
  {
    this.K = paramString;
  }
  
  public ICellFormulaExpr getFirstArgExpr()
  {
    return (ICellFormulaExpr)this.J.get(0);
  }
  
  public ICellFormulaExpr getSecondArgExpr()
  {
    return (ICellFormulaExpr)this.J.get(1);
  }
  
  public Object evaluateFirstArg(XptBuildRuntime paramXptBuildRuntime)
  {
    return getFirstArgExpr().evaluate(paramXptBuildRuntime);
  }
  
  public Object evaluateSecondArg(XptBuildRuntime paramXptBuildRuntime)
  {
    return getSecondArgExpr().evaluate(paramXptBuildRuntime);
  }
  
  public List<ICellFormulaExpr> getArgExprs()
  {
    return this.J;
  }
  
  public CellFuncExpr newInstance()
  {
    CellFuncExpr localCellFuncExpr = (CellFuncExpr)new BeanInstance(this).newInstance();
    localCellFuncExpr.setFuncName(this.K);
    return localCellFuncExpr;
  }
  
  public void addArgExpr(ICellFormulaExpr paramICellFormulaExpr)
  {
    this.J.add(paramICellFormulaExpr);
  }
  
  public void endArg()
  {
    if ((this.L >= 0) && (this.J.size() != this.L)) {
      throw Exceptions.code("excel.CAN_err_invalid_formula_func_arg_count").param(this.L).param(this);
    }
  }
  
  public String getExpandedFormula(XptBuildRuntime paramXptBuildRuntime)
  {
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\formula\exprs\CellFuncExpr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */