package edu.thu.ext.excel.model.formula.exprs;

import edu.thu.ext.excel.model.CellRange;
import edu.thu.ext.excel.model.data.CellData;
import edu.thu.ext.excel.model.formula.ICellFormulaExpr;
import edu.thu.ext.excel.xpt.XptBuildRuntime;
import edu.thu.model.Pair;
import java.util.List;

public abstract interface ICellRangeExpr
  extends ICellFormulaExpr
{
  public abstract double sumAll(XptBuildRuntime paramXptBuildRuntime);
  
  public abstract Number avgAll(XptBuildRuntime paramXptBuildRuntime);
  
  public abstract Pair<Number, Number> sumAndCountAll(XptBuildRuntime paramXptBuildRuntime);
  
  public abstract int countAll(XptBuildRuntime paramXptBuildRuntime);
  
  public abstract int countAllNumber(XptBuildRuntime paramXptBuildRuntime);
  
  public abstract List<CellData> getAllCells(XptBuildRuntime paramXptBuildRuntime);
  
  public abstract List<Object> getAllValues(XptBuildRuntime paramXptBuildRuntime);
  
  public abstract CellRange getExpandedRange(XptBuildRuntime paramXptBuildRuntime);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\formula\exprs\ICellRangeExpr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */