package edu.thu.ext.excel.model.formula.exprs;

import edu.thu.ext.excel.model.formula.ICellFormulaExpr;
import edu.thu.ext.excel.xpt.XptBuildRuntime;
import edu.thu.global.Debug;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class ExFormulaExprs
{
  public static CellFuncExpr RANK()
  {
    new CellFuncExpr("RANK", 3)
    {
      public CellFuncExpr newInstance()
      {
        return ExFormulaExprs.RANK();
      }
      
      public Object evaluate(XptBuildRuntime paramAnonymousXptBuildRuntime)
      {
        ICellFormulaExpr localICellFormulaExpr1 = (ICellFormulaExpr)getArgExprs().get(0);
        ICellFormulaExpr localICellFormulaExpr2 = (ICellFormulaExpr)getArgExprs().get(1);
        Debug.check(localICellFormulaExpr1);
        Debug.check(localICellFormulaExpr2);
        Object localObject = ((CellPosExpr)localICellFormulaExpr1).getFirstValue(paramAnonymousXptBuildRuntime);
        List localList = ((CellPosExpr)localICellFormulaExpr2).getExpandedValues(paramAnonymousXptBuildRuntime);
        if ((localObject == null) || (localList == null) || (localList.isEmpty())) {
          return null;
        }
        return null;
      }
    };
  }
  
  public static CellFuncExpr COUNTA()
  {
    new CellFuncExpr("COUNTA", 1)
    {
      public CellFuncExpr newInstance()
      {
        return ExFormulaExprs.COUNTA();
      }
      
      public Object evaluate(XptBuildRuntime paramAnonymousXptBuildRuntime)
      {
        int i = 0;
        Iterator localIterator = getArgExprs().iterator();
        while (localIterator.hasNext())
        {
          ICellFormulaExpr localICellFormulaExpr = (ICellFormulaExpr)localIterator.next();
          Object localObject1;
          Object localObject3;
          Object localObject2;
          if ((localICellFormulaExpr instanceof ICellRangeExpr))
          {
            localObject1 = ((ICellRangeExpr)localICellFormulaExpr).getAllValues(paramAnonymousXptBuildRuntime);
            if (localObject1 != null)
            {
              localObject3 = ((List)localObject1).iterator();
              while (((Iterator)localObject3).hasNext())
              {
                localObject2 = ((Iterator)localObject3).next();
                if (localObject2 != null) {
                  i++;
                }
              }
            }
          }
          else
          {
            localObject1 = localICellFormulaExpr.evaluate(paramAnonymousXptBuildRuntime);
            if ((localObject1 instanceof Collection))
            {
              localObject2 = ((Collection)localObject1).iterator();
              while (((Iterator)localObject2).hasNext())
              {
                localObject3 = ((Iterator)localObject2).next();
                if (localObject3 != null) {
                  i++;
                }
              }
            }
            else if (localObject1 != null)
            {
              i++;
            }
          }
        }
        return Integer.valueOf(i);
      }
    };
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\formula\exprs\ExFormulaExprs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */