package edu.thu.ext.excel.model.formula.exprs;

import edu.thu.ext.excel.model.formula.ICellFormulaExpandSupport;
import edu.thu.ext.excel.model.formula.ICellFormulaExpr;
import edu.thu.ext.excel.xpt.XptBuildRuntime;
import java.util.List;

public abstract class CellFuncExpandExpr
  extends CellFuncExpr
  implements ICellFormulaExpandSupport
{
  private static final long serialVersionUID = -5547439252838968097L;
  
  public CellFuncExpandExpr(String paramString)
  {
    super(paramString);
  }
  
  public CellFuncExpandExpr(String paramString, int paramInt)
  {
    super(paramString, paramInt);
  }
  
  public String getExpandedFormula(XptBuildRuntime paramXptBuildRuntime)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(getFuncName()).append("(");
    int j = getArgExprs().size();
    for (int i = 0; i < j; i++)
    {
      ICellFormulaExpr localICellFormulaExpr = (ICellFormulaExpr)getArgExprs().get(i);
      if ((localICellFormulaExpr instanceof ICellRangeExpr))
      {
        ICellRangeExpr localICellRangeExpr = (ICellRangeExpr)localICellFormulaExpr;
        localStringBuilder.append(localICellRangeExpr.getExpandedRange(paramXptBuildRuntime));
      }
      else
      {
        return null;
      }
      if (i < j - 1) {
        localStringBuilder.append(",");
      }
    }
    localStringBuilder.append(")");
    return localStringBuilder.toString();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\formula\exprs\CellFuncExpandExpr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */