package edu.thu.ext.excel.model.formula;

import edu.thu.ext.excel.model.Cell;
import edu.thu.ext.excel.model.CellPosition;
import edu.thu.ext.excel.model.formula.exprs.CellFuncExpr;
import edu.thu.ext.excel.model.formula.exprs.CellPosExpr;
import edu.thu.ext.excel.model.formula.exprs.CellRangeExpr;
import edu.thu.ext.excel.model.formula.exprs.DefaultCellFuncProvider;
import edu.thu.ext.excel.model.formula.exprs.FormulaExprs;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.exceptions.StdException;
import org.antlr.runtime.ANTLRStringStream;
import org.antlr.runtime.BaseRecognizer;
import org.antlr.runtime.BitSet;
import org.antlr.runtime.CommonTokenStream;
import org.antlr.runtime.DFA;
import org.antlr.runtime.NoViableAltException;
import org.antlr.runtime.Parser;
import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.RecognizerSharedState;
import org.antlr.runtime.Token;
import org.antlr.runtime.TokenStream;

public class CellFormulaExprParser
  extends Parser
{
  public static final String[] tokenNames = { "<invalid>", "<EOR>", "<DOWN>", "<UP>", "LT", "LTEQ", "GT", "GTEQ", "EQ", "NOTEQ", "CONCAT", "SUB", "ADD", "DIV", "MULT", "EXP", "LPAREN", "RPAREN", "INTEGER", "NUMBER", "STRING", "TRUE", "FALSE", "PERCENT", "ROWCOLNAME", "ROWNAME", "COLNAME", "FUNCNAME", "COMMA", "LETTER", "DIGIT", "ESCAPE_SEQUENCE", "WS", "':'", "'['", "']'" };
  public static final int INTEGER = 18;
  public static final int LT = 4;
  public static final int ROWNAME = 25;
  public static final int PERCENT = 23;
  public static final int CONCAT = 10;
  public static final int LETTER = 29;
  public static final int NUMBER = 19;
  public static final int LTEQ = 5;
  public static final int SUB = 11;
  public static final int GTEQ = 7;
  public static final int MULT = 14;
  public static final int EOF = -1;
  public static final int TRUE = 21;
  public static final int LPAREN = 16;
  public static final int ROWCOLNAME = 24;
  public static final int ESCAPE_SEQUENCE = 31;
  public static final int RPAREN = 17;
  public static final int NOTEQ = 9;
  public static final int WS = 32;
  public static final int T__33 = 33;
  public static final int T__34 = 34;
  public static final int T__35 = 35;
  public static final int EXP = 15;
  public static final int COMMA = 28;
  public static final int COLNAME = 26;
  public static final int GT = 6;
  public static final int DIGIT = 30;
  public static final int FUNCNAME = 27;
  public static final int EQ = 8;
  public static final int DIV = 13;
  public static final int FALSE = 22;
  public static final int STRING = 20;
  public static final int ADD = 12;
  ICellFuncProvider funcProvider = new DefaultCellFuncProvider();
  Cell cell;
  protected _A dfa9 = new _A(this);
  static final String DFA9_eotS = "\022￿";
  static final String DFA9_eofS = "\001￿\001\005\002￿\001\005\004￿\001\005\003￿\002\005\002￿\001\005";
  static final String DFA9_minS = "\001\030\001\004\002\022\001\004\002￿\001\022\001\032\001\004\002#\001\022\002\004\001\032\001#\001\004";
  static final String DFA9_maxS = "\001\031\002\"\001\022\001!\002￿\001\022\001\032\001\"\002#\001\022\002!\001\032\001#\001!";
  static final String DFA9_acceptS = "\005￿\001\001\001\002\013￿";
  static final String DFA9_specialS = "\022￿}>";
  static final String[] DFA9_transitionS = { "\001\001\001\002", "\f\005\001￿\001\005\001\004\t￿\001\005\004￿\001\006\001\003", "\001\b\007￿\001\t\007￿\001\007", "\001\n", "\f\005\001￿\001\005\n￿\001\005\004￿\001\006", "", "", "\001\013", "\001\t", "\f\005\001￿\001\005\001\r\t￿\001\005\004￿\001\006\001\f", "\001\016", "\001\017", "\001\020", "\f\005\001￿\001\005\n￿\001\005\004￿\001\006", "\f\005\001￿\001\005\n￿\001\005\004￿\001\006", "\001\t", "\001\021", "\f\005\001￿\001\005\n￿\001\005\004￿\001\006" };
  static final short[] DFA9_eot = DFA.unpackEncodedString("\022￿");
  static final short[] DFA9_eof = DFA.unpackEncodedString("\001￿\001\005\002￿\001\005\004￿\001\005\003￿\002\005\002￿\001\005");
  static final char[] DFA9_min = DFA.unpackEncodedStringToUnsignedChars("\001\030\001\004\002\022\001\004\002￿\001\022\001\032\001\004\002#\001\022\002\004\001\032\001#\001\004");
  static final char[] DFA9_max = DFA.unpackEncodedStringToUnsignedChars("\001\031\002\"\001\022\001!\002￿\001\022\001\032\001\"\002#\001\022\002!\001\032\001#\001!");
  static final short[] DFA9_accept = DFA.unpackEncodedString("\005￿\001\001\001\002\013￿");
  static final short[] DFA9_special = DFA.unpackEncodedString("\022￿}>");
  static final short[][] DFA9_transition;
  public static final BitSet FOLLOW_expr_in_formula31 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_boolExpr_in_expr43 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_concatExpr_in_boolExpr60 = new BitSet(new long[] { 1010L });
  public static final BitSet FOLLOW_LT_in_boolExpr66 = new BitSet(new long[] { 192747520L });
  public static final BitSet FOLLOW_concatExpr_in_boolExpr72 = new BitSet(new long[] { 1010L });
  public static final BitSet FOLLOW_LTEQ_in_boolExpr79 = new BitSet(new long[] { 192747520L });
  public static final BitSet FOLLOW_concatExpr_in_boolExpr85 = new BitSet(new long[] { 1010L });
  public static final BitSet FOLLOW_GT_in_boolExpr92 = new BitSet(new long[] { 192747520L });
  public static final BitSet FOLLOW_concatExpr_in_boolExpr98 = new BitSet(new long[] { 1010L });
  public static final BitSet FOLLOW_GTEQ_in_boolExpr105 = new BitSet(new long[] { 192747520L });
  public static final BitSet FOLLOW_concatExpr_in_boolExpr111 = new BitSet(new long[] { 1010L });
  public static final BitSet FOLLOW_EQ_in_boolExpr118 = new BitSet(new long[] { 192747520L });
  public static final BitSet FOLLOW_concatExpr_in_boolExpr124 = new BitSet(new long[] { 1010L });
  public static final BitSet FOLLOW_NOTEQ_in_boolExpr131 = new BitSet(new long[] { 192747520L });
  public static final BitSet FOLLOW_concatExpr_in_boolExpr137 = new BitSet(new long[] { 1010L });
  public static final BitSet FOLLOW_sumExpr_in_concatExpr158 = new BitSet(new long[] { 1026L });
  public static final BitSet FOLLOW_CONCAT_in_concatExpr164 = new BitSet(new long[] { 192747520L });
  public static final BitSet FOLLOW_sumExpr_in_concatExpr170 = new BitSet(new long[] { 1026L });
  public static final BitSet FOLLOW_multExpr_in_sumExpr192 = new BitSet(new long[] { 6146L });
  public static final BitSet FOLLOW_SUB_in_sumExpr198 = new BitSet(new long[] { 192747520L });
  public static final BitSet FOLLOW_multExpr_in_sumExpr204 = new BitSet(new long[] { 6146L });
  public static final BitSet FOLLOW_ADD_in_sumExpr211 = new BitSet(new long[] { 192747520L });
  public static final BitSet FOLLOW_multExpr_in_sumExpr216 = new BitSet(new long[] { 6146L });
  public static final BitSet FOLLOW_expExpr_in_multExpr237 = new BitSet(new long[] { 24578L });
  public static final BitSet FOLLOW_DIV_in_multExpr243 = new BitSet(new long[] { 192747520L });
  public static final BitSet FOLLOW_expExpr_in_multExpr249 = new BitSet(new long[] { 24578L });
  public static final BitSet FOLLOW_MULT_in_multExpr256 = new BitSet(new long[] { 192747520L });
  public static final BitSet FOLLOW_expExpr_in_multExpr262 = new BitSet(new long[] { 24578L });
  public static final BitSet FOLLOW_unaryOperation_in_expExpr282 = new BitSet(new long[] { 32770L });
  public static final BitSet FOLLOW_EXP_in_expExpr288 = new BitSet(new long[] { 192747520L });
  public static final BitSet FOLLOW_unaryOperation_in_expExpr294 = new BitSet(new long[] { 32770L });
  public static final BitSet FOLLOW_ADD_in_unaryOperation312 = new BitSet(new long[] { 192747520L });
  public static final BitSet FOLLOW_operand_in_unaryOperation318 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_SUB_in_unaryOperation325 = new BitSet(new long[] { 192747520L });
  public static final BitSet FOLLOW_operand_in_unaryOperation331 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_operand_in_unaryOperation342 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_literal_in_operand362 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_percent_in_operand373 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_LPAREN_in_operand380 = new BitSet(new long[] { 192747520L });
  public static final BitSet FOLLOW_expr_in_operand385 = new BitSet(new long[] { 131072L });
  public static final BitSet FOLLOW_RPAREN_in_operand387 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_rangeExpr_in_operand398 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_funcExpr_in_operand410 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_INTEGER_in_literal426 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_NUMBER_in_literal433 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_STRING_in_literal440 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_TRUE_in_literal447 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_FALSE_in_literal454 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_NUMBER_in_percent469 = new BitSet(new long[] { 8388608L });
  public static final BitSet FOLLOW_PERCENT_in_percent471 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_posExpr_in_rangeExpr488 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_posExpr_in_rangeExpr499 = new BitSet(new long[] { 8589934592L });
  public static final BitSet FOLLOW_33_in_rangeExpr501 = new BitSet(new long[] { 50331648L });
  public static final BitSet FOLLOW_posExpr_in_rangeExpr507 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_ROWCOLNAME_in_posExpr523 = new BitSet(new long[] { 17180131330L });
  public static final BitSet FOLLOW_34_in_posExpr526 = new BitSet(new long[] { 262144L });
  public static final BitSet FOLLOW_INTEGER_in_posExpr532 = new BitSet(new long[] { 34359738368L });
  public static final BitSet FOLLOW_35_in_posExpr538 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_INTEGER_in_posExpr545 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_ROWNAME_in_posExpr561 = new BitSet(new long[] { 17247240192L });
  public static final BitSet FOLLOW_34_in_posExpr564 = new BitSet(new long[] { 262144L });
  public static final BitSet FOLLOW_INTEGER_in_posExpr570 = new BitSet(new long[] { 34359738368L });
  public static final BitSet FOLLOW_35_in_posExpr575 = new BitSet(new long[] { 67108864L });
  public static final BitSet FOLLOW_INTEGER_in_posExpr583 = new BitSet(new long[] { 67108864L });
  public static final BitSet FOLLOW_COLNAME_in_posExpr592 = new BitSet(new long[] { 17180131330L });
  public static final BitSet FOLLOW_34_in_posExpr595 = new BitSet(new long[] { 262144L });
  public static final BitSet FOLLOW_INTEGER_in_posExpr601 = new BitSet(new long[] { 34359738368L });
  public static final BitSet FOLLOW_35_in_posExpr607 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_INTEGER_in_posExpr615 = new BitSet(new long[] { 2L });
  public static final BitSet FOLLOW_FUNCNAME_in_funcExpr629 = new BitSet(new long[] { 65536L });
  public static final BitSet FOLLOW_LPAREN_in_funcExpr634 = new BitSet(new long[] { 192878592L });
  public static final BitSet FOLLOW_expr_in_funcExpr641 = new BitSet(new long[] { 268566528L });
  public static final BitSet FOLLOW_COMMA_in_funcExpr647 = new BitSet(new long[] { 192747520L });
  public static final BitSet FOLLOW_expr_in_funcExpr653 = new BitSet(new long[] { 268566528L });
  public static final BitSet FOLLOW_RPAREN_in_funcExpr663 = new BitSet(new long[] { 2L });
  
  static
  {
    int i = DFA9_transitionS.length;
    DFA9_transition = new short[i][];
    for (int j = 0; j < i; j++) {
      DFA9_transition[j] = DFA.unpackEncodedString(DFA9_transitionS[j]);
    }
  }
  
  public CellFormulaExprParser(TokenStream paramTokenStream)
  {
    this(paramTokenStream, new RecognizerSharedState());
  }
  
  public CellFormulaExprParser(TokenStream paramTokenStream, RecognizerSharedState paramRecognizerSharedState)
  {
    super(paramTokenStream, paramRecognizerSharedState);
  }
  
  public String[] getTokenNames()
  {
    return tokenNames;
  }
  
  public String getGrammarFileName()
  {
    return "E:\\reference\\ref-source\\Antlr\\CellFormulaExpr.g";
  }
  
  public Cell getCell()
  {
    return this.cell;
  }
  
  public void setCell(Cell paramCell)
  {
    this.cell = paramCell;
  }
  
  public void setFuncProvider(ICellFuncProvider paramICellFuncProvider)
  {
    this.funcProvider = paramICellFuncProvider;
  }
  
  public ICellFuncProvider getFuncProvider()
  {
    return this.funcProvider;
  }
  
  CellFormulaExprParser(String paramString, Cell paramCell)
  {
    super(new CommonTokenStream(new CellFormulaExprLexer(new ANTLRStringStream(paramString))), new RecognizerSharedState());
    this.cell = paramCell;
  }
  
  public CellFormula parseFormula()
  {
    try
    {
      CellFormula localCellFormula = formula();
      return localCellFormula;
    }
    catch (Exception localException)
    {
      throw Exceptions.code("excel.CAN_err_invalid_formula").param(this.cell).cause(localException);
    }
  }
  
  public final CellFormula formula()
    throws RecognitionException
  {
    CellFormula localCellFormula = null;
    ICellFormulaExpr localICellFormulaExpr = null;
    try
    {
      pushFollow(FOLLOW_expr_in_formula31);
      localICellFormulaExpr = expr();
      this.state._fsp -= 1;
      localCellFormula = new CellFormula(this.cell, localICellFormulaExpr);
    }
    catch (RecognitionException localRecognitionException)
    {
      reportError(localRecognitionException);
      recover(this.input, localRecognitionException);
    }
    return localCellFormula;
  }
  
  public final ICellFormulaExpr expr()
    throws RecognitionException
  {
    Object localObject = null;
    ICellFormulaExpr localICellFormulaExpr = null;
    try
    {
      pushFollow(FOLLOW_boolExpr_in_expr43);
      localICellFormulaExpr = boolExpr();
      this.state._fsp -= 1;
      localObject = localICellFormulaExpr;
    }
    catch (RecognitionException localRecognitionException)
    {
      reportError(localRecognitionException);
      recover(this.input, localRecognitionException);
    }
    return (ICellFormulaExpr)localObject;
  }
  
  public final ICellFormulaExpr boolExpr()
    throws RecognitionException
  {
    Object localObject = null;
    ICellFormulaExpr localICellFormulaExpr = null;
    try
    {
      pushFollow(FOLLOW_concatExpr_in_boolExpr60);
      localICellFormulaExpr = concatExpr();
      this.state._fsp -= 1;
      localObject = localICellFormulaExpr;
      for (;;)
      {
        int i = 7;
        switch (this.input.LA(1))
        {
        case 4: 
          i = 1;
          break;
        case 5: 
          i = 2;
          break;
        case 6: 
          i = 3;
          break;
        case 7: 
          i = 4;
          break;
        case 8: 
          i = 5;
          break;
        case 9: 
          i = 6;
        }
        switch (i)
        {
        case 1: 
          match(this.input, 4, FOLLOW_LT_in_boolExpr66);
          pushFollow(FOLLOW_concatExpr_in_boolExpr72);
          localICellFormulaExpr = concatExpr();
          this.state._fsp -= 1;
          localObject = FormulaExprs.LT_Op((ICellFormulaExpr)localObject, localICellFormulaExpr);
          break;
        case 2: 
          match(this.input, 5, FOLLOW_LTEQ_in_boolExpr79);
          pushFollow(FOLLOW_concatExpr_in_boolExpr85);
          localICellFormulaExpr = concatExpr();
          this.state._fsp -= 1;
          localObject = FormulaExprs.LTEQ_Op((ICellFormulaExpr)localObject, localICellFormulaExpr);
          break;
        case 3: 
          match(this.input, 6, FOLLOW_GT_in_boolExpr92);
          pushFollow(FOLLOW_concatExpr_in_boolExpr98);
          localICellFormulaExpr = concatExpr();
          this.state._fsp -= 1;
          localObject = FormulaExprs.GT_Op((ICellFormulaExpr)localObject, localICellFormulaExpr);
          break;
        case 4: 
          match(this.input, 7, FOLLOW_GTEQ_in_boolExpr105);
          pushFollow(FOLLOW_concatExpr_in_boolExpr111);
          localICellFormulaExpr = concatExpr();
          this.state._fsp -= 1;
          localObject = FormulaExprs.GTEQ_Op((ICellFormulaExpr)localObject, localICellFormulaExpr);
          break;
        case 5: 
          match(this.input, 8, FOLLOW_EQ_in_boolExpr118);
          pushFollow(FOLLOW_concatExpr_in_boolExpr124);
          localICellFormulaExpr = concatExpr();
          this.state._fsp -= 1;
          localObject = FormulaExprs.EQ_Op((ICellFormulaExpr)localObject, localICellFormulaExpr);
          break;
        case 6: 
          match(this.input, 9, FOLLOW_NOTEQ_in_boolExpr131);
          pushFollow(FOLLOW_concatExpr_in_boolExpr137);
          localICellFormulaExpr = concatExpr();
          this.state._fsp -= 1;
          localObject = FormulaExprs.NOTEQ_Op((ICellFormulaExpr)localObject, localICellFormulaExpr);
        }
      }
    }
    catch (RecognitionException localRecognitionException)
    {
      reportError(localRecognitionException);
      recover(this.input, localRecognitionException);
    }
    return (ICellFormulaExpr)localObject;
  }
  
  public final ICellFormulaExpr concatExpr()
    throws RecognitionException
  {
    Object localObject = null;
    ICellFormulaExpr localICellFormulaExpr = null;
    try
    {
      pushFollow(FOLLOW_sumExpr_in_concatExpr158);
      localICellFormulaExpr = sumExpr();
      this.state._fsp -= 1;
      for (localObject = localICellFormulaExpr;; localObject = FormulaExprs.CONCAT_Op((ICellFormulaExpr)localObject, localICellFormulaExpr))
      {
        int i = 2;
        int j = this.input.LA(1);
        if (j == 10) {
          i = 1;
        }
        switch (i)
        {
        case 1: 
          match(this.input, 10, FOLLOW_CONCAT_in_concatExpr164);
          pushFollow(FOLLOW_sumExpr_in_concatExpr170);
          localICellFormulaExpr = sumExpr();
          this.state._fsp -= 1;
        }
      }
    }
    catch (RecognitionException localRecognitionException)
    {
      reportError(localRecognitionException);
      recover(this.input, localRecognitionException);
    }
    return (ICellFormulaExpr)localObject;
  }
  
  public final ICellFormulaExpr sumExpr()
    throws RecognitionException
  {
    Object localObject = null;
    ICellFormulaExpr localICellFormulaExpr = null;
    try
    {
      pushFollow(FOLLOW_multExpr_in_sumExpr192);
      localICellFormulaExpr = multExpr();
      this.state._fsp -= 1;
      localObject = localICellFormulaExpr;
      for (;;)
      {
        int i = 3;
        int j = this.input.LA(1);
        if (j == 11) {
          i = 1;
        } else if (j == 12) {
          i = 2;
        }
        switch (i)
        {
        case 1: 
          match(this.input, 11, FOLLOW_SUB_in_sumExpr198);
          pushFollow(FOLLOW_multExpr_in_sumExpr204);
          localICellFormulaExpr = multExpr();
          this.state._fsp -= 1;
          localObject = FormulaExprs.SUB_Op((ICellFormulaExpr)localObject, localICellFormulaExpr);
          break;
        case 2: 
          match(this.input, 12, FOLLOW_ADD_in_sumExpr211);
          pushFollow(FOLLOW_multExpr_in_sumExpr216);
          localICellFormulaExpr = multExpr();
          this.state._fsp -= 1;
          localObject = FormulaExprs.ADD_Op((ICellFormulaExpr)localObject, localICellFormulaExpr);
        }
      }
    }
    catch (RecognitionException localRecognitionException)
    {
      reportError(localRecognitionException);
      recover(this.input, localRecognitionException);
    }
    return (ICellFormulaExpr)localObject;
  }
  
  public final ICellFormulaExpr multExpr()
    throws RecognitionException
  {
    Object localObject = null;
    ICellFormulaExpr localICellFormulaExpr = null;
    try
    {
      pushFollow(FOLLOW_expExpr_in_multExpr237);
      localICellFormulaExpr = expExpr();
      this.state._fsp -= 1;
      localObject = localICellFormulaExpr;
      for (;;)
      {
        int i = 3;
        int j = this.input.LA(1);
        if (j == 13) {
          i = 1;
        } else if (j == 14) {
          i = 2;
        }
        switch (i)
        {
        case 1: 
          match(this.input, 13, FOLLOW_DIV_in_multExpr243);
          pushFollow(FOLLOW_expExpr_in_multExpr249);
          localICellFormulaExpr = expExpr();
          this.state._fsp -= 1;
          localObject = FormulaExprs.DIV_Op((ICellFormulaExpr)localObject, localICellFormulaExpr);
          break;
        case 2: 
          match(this.input, 14, FOLLOW_MULT_in_multExpr256);
          pushFollow(FOLLOW_expExpr_in_multExpr262);
          localICellFormulaExpr = expExpr();
          this.state._fsp -= 1;
          localObject = FormulaExprs.MULT_Op((ICellFormulaExpr)localObject, localICellFormulaExpr);
        }
      }
    }
    catch (RecognitionException localRecognitionException)
    {
      reportError(localRecognitionException);
      recover(this.input, localRecognitionException);
    }
    return (ICellFormulaExpr)localObject;
  }
  
  public final ICellFormulaExpr expExpr()
    throws RecognitionException
  {
    Object localObject = null;
    ICellFormulaExpr localICellFormulaExpr = null;
    try
    {
      pushFollow(FOLLOW_unaryOperation_in_expExpr282);
      localICellFormulaExpr = unaryOperation();
      this.state._fsp -= 1;
      for (localObject = localICellFormulaExpr;; localObject = FormulaExprs.EXP_Op((ICellFormulaExpr)localObject, localICellFormulaExpr))
      {
        int i = 2;
        int j = this.input.LA(1);
        if (j == 15) {
          i = 1;
        }
        switch (i)
        {
        case 1: 
          match(this.input, 15, FOLLOW_EXP_in_expExpr288);
          pushFollow(FOLLOW_unaryOperation_in_expExpr294);
          localICellFormulaExpr = unaryOperation();
          this.state._fsp -= 1;
        }
      }
    }
    catch (RecognitionException localRecognitionException)
    {
      reportError(localRecognitionException);
      recover(this.input, localRecognitionException);
    }
    return (ICellFormulaExpr)localObject;
  }
  
  public final ICellFormulaExpr unaryOperation()
    throws RecognitionException
  {
    Object localObject = null;
    ICellFormulaExpr localICellFormulaExpr = null;
    try
    {
      int i = 3;
      switch (this.input.LA(1))
      {
      case 12: 
        i = 1;
        break;
      case 11: 
        i = 2;
        break;
      case 16: 
      case 18: 
      case 19: 
      case 20: 
      case 21: 
      case 22: 
      case 24: 
      case 25: 
      case 27: 
        i = 3;
        break;
      case 13: 
      case 14: 
      case 15: 
      case 17: 
      case 23: 
      case 26: 
      default: 
        NoViableAltException localNoViableAltException = new NoViableAltException("", 6, 0, this.input);
        throw localNoViableAltException;
      }
      switch (i)
      {
      case 1: 
        match(this.input, 12, FOLLOW_ADD_in_unaryOperation312);
        pushFollow(FOLLOW_operand_in_unaryOperation318);
        localICellFormulaExpr = operand();
        this.state._fsp -= 1;
        localObject = localICellFormulaExpr;
        break;
      case 2: 
        match(this.input, 11, FOLLOW_SUB_in_unaryOperation325);
        pushFollow(FOLLOW_operand_in_unaryOperation331);
        localICellFormulaExpr = operand();
        this.state._fsp -= 1;
        localObject = FormulaExprs.SUB_Op(null, localICellFormulaExpr);
        break;
      case 3: 
        pushFollow(FOLLOW_operand_in_unaryOperation342);
        localICellFormulaExpr = operand();
        this.state._fsp -= 1;
        localObject = localICellFormulaExpr;
      }
    }
    catch (RecognitionException localRecognitionException)
    {
      reportError(localRecognitionException);
      recover(this.input, localRecognitionException);
    }
    return (ICellFormulaExpr)localObject;
  }
  
  public final ICellFormulaExpr operand()
    throws RecognitionException
  {
    Object localObject = null;
    ICellFormulaExpr localICellFormulaExpr = null;
    CellFuncExpr localCellFuncExpr = null;
    try
    {
      int i = 5;
      switch (this.input.LA(1))
      {
      case 18: 
      case 20: 
      case 21: 
      case 22: 
        i = 1;
        break;
      case 19: 
        int j = this.input.LA(2);
        if (j == 23)
        {
          i = 2;
        }
        else if ((j == -1) || ((j >= 4) && (j <= 15)) || (j == 17) || (j == 28))
        {
          i = 1;
        }
        else
        {
          NoViableAltException localNoViableAltException2 = new NoViableAltException("", 7, 2, this.input);
          throw localNoViableAltException2;
        }
        break;
      case 16: 
        i = 3;
        break;
      case 24: 
      case 25: 
        i = 4;
        break;
      case 27: 
        i = 5;
        break;
      case 17: 
      case 23: 
      case 26: 
      default: 
        NoViableAltException localNoViableAltException1 = new NoViableAltException("", 7, 0, this.input);
        throw localNoViableAltException1;
      }
      switch (i)
      {
      case 1: 
        pushFollow(FOLLOW_literal_in_operand362);
        localICellFormulaExpr = literal();
        this.state._fsp -= 1;
        localObject = localICellFormulaExpr;
        break;
      case 2: 
        pushFollow(FOLLOW_percent_in_operand373);
        localICellFormulaExpr = percent();
        this.state._fsp -= 1;
        localObject = localICellFormulaExpr;
        break;
      case 3: 
        match(this.input, 16, FOLLOW_LPAREN_in_operand380);
        pushFollow(FOLLOW_expr_in_operand385);
        localICellFormulaExpr = expr();
        this.state._fsp -= 1;
        match(this.input, 17, FOLLOW_RPAREN_in_operand387);
        localObject = localICellFormulaExpr;
        break;
      case 4: 
        pushFollow(FOLLOW_rangeExpr_in_operand398);
        localICellFormulaExpr = rangeExpr();
        this.state._fsp -= 1;
        localObject = localICellFormulaExpr;
        break;
      case 5: 
        pushFollow(FOLLOW_funcExpr_in_operand410);
        localCellFuncExpr = funcExpr();
        this.state._fsp -= 1;
        localObject = localCellFuncExpr;
      }
    }
    catch (RecognitionException localRecognitionException)
    {
      reportError(localRecognitionException);
      recover(this.input, localRecognitionException);
    }
    return (ICellFormulaExpr)localObject;
  }
  
  public final ICellFormulaExpr literal()
    throws RecognitionException
  {
    ICellFormulaExpr localICellFormulaExpr = null;
    Token localToken1 = null;
    Token localToken2 = null;
    Token localToken3 = null;
    try
    {
      int i = 5;
      switch (this.input.LA(1))
      {
      case 18: 
        i = 1;
        break;
      case 19: 
        i = 2;
        break;
      case 20: 
        i = 3;
        break;
      case 21: 
        i = 4;
        break;
      case 22: 
        i = 5;
        break;
      default: 
        NoViableAltException localNoViableAltException = new NoViableAltException("", 8, 0, this.input);
        throw localNoViableAltException;
      }
      switch (i)
      {
      case 1: 
        localToken1 = (Token)match(this.input, 18, FOLLOW_INTEGER_in_literal426);
        localICellFormulaExpr = FormulaExprs.value(Long.valueOf(Long.parseLong(localToken1 != null ? localToken1.getText() : null)));
        break;
      case 2: 
        localToken2 = (Token)match(this.input, 19, FOLLOW_NUMBER_in_literal433);
        localICellFormulaExpr = FormulaExprs.value(Double.valueOf(Double.parseDouble(localToken2 != null ? localToken2.getText() : null)));
        break;
      case 3: 
        localToken3 = (Token)match(this.input, 20, FOLLOW_STRING_in_literal440);
        localICellFormulaExpr = FormulaExprs.value(localToken3 != null ? localToken3.getText() : null);
        break;
      case 4: 
        match(this.input, 21, FOLLOW_TRUE_in_literal447);
        localICellFormulaExpr = FormulaExprs.value(Boolean.valueOf(true));
        break;
      case 5: 
        match(this.input, 22, FOLLOW_FALSE_in_literal454);
        localICellFormulaExpr = FormulaExprs.value(Boolean.valueOf(false));
      }
    }
    catch (RecognitionException localRecognitionException)
    {
      reportError(localRecognitionException);
      recover(this.input, localRecognitionException);
    }
    return localICellFormulaExpr;
  }
  
  public final ICellFormulaExpr percent()
    throws RecognitionException
  {
    ICellFormulaExpr localICellFormulaExpr = null;
    Token localToken = null;
    try
    {
      localToken = (Token)match(this.input, 19, FOLLOW_NUMBER_in_percent469);
      match(this.input, 23, FOLLOW_PERCENT_in_percent471);
      localICellFormulaExpr = FormulaExprs.value(Double.valueOf(Double.parseDouble(localToken != null ? localToken.getText() : null) * 0.01D));
    }
    catch (RecognitionException localRecognitionException)
    {
      reportError(localRecognitionException);
      recover(this.input, localRecognitionException);
    }
    return localICellFormulaExpr;
  }
  
  public final ICellFormulaExpr rangeExpr()
    throws RecognitionException
  {
    Object localObject = null;
    CellPosition localCellPosition1 = null;
    CellPosition localCellPosition2 = null;
    CellPosition localCellPosition3 = null;
    try
    {
      int i = 2;
      i = this.dfa9.predict(this.input);
      switch (i)
      {
      case 1: 
        pushFollow(FOLLOW_posExpr_in_rangeExpr488);
        localCellPosition1 = posExpr();
        this.state._fsp -= 1;
        localObject = new CellPosExpr(localCellPosition1);
        break;
      case 2: 
        pushFollow(FOLLOW_posExpr_in_rangeExpr499);
        localCellPosition2 = posExpr();
        this.state._fsp -= 1;
        match(this.input, 33, FOLLOW_33_in_rangeExpr501);
        pushFollow(FOLLOW_posExpr_in_rangeExpr507);
        localCellPosition3 = posExpr();
        this.state._fsp -= 1;
        localObject = new CellRangeExpr(localCellPosition2, localCellPosition3);
      }
    }
    catch (RecognitionException localRecognitionException)
    {
      reportError(localRecognitionException);
      recover(this.input, localRecognitionException);
    }
    return (ICellFormulaExpr)localObject;
  }
  
  public final CellPosition posExpr()
    throws RecognitionException
  {
    CellPosition localCellPosition = null;
    Token localToken1 = null;
    Token localToken2 = null;
    try
    {
      int i = 2;
      int j = this.input.LA(1);
      if (j == 24)
      {
        i = 1;
      }
      else if (j == 25)
      {
        i = 2;
      }
      else
      {
        NoViableAltException localNoViableAltException = new NoViableAltException("", 13, 0, this.input);
        throw localNoViableAltException;
      }
      int k;
      int m;
      switch (i)
      {
      case 1: 
        localCellPosition = new CellPosition(this.cell.getRowIndex(), this.cell.getIndex());
        match(this.input, 24, FOLLOW_ROWCOLNAME_in_posExpr523);
        k = 3;
        m = this.input.LA(1);
        if (m == 34) {
          k = 1;
        } else if (m == 18) {
          k = 2;
        }
        switch (k)
        {
        case 1: 
          match(this.input, 34, FOLLOW_34_in_posExpr526);
          localToken1 = (Token)match(this.input, 18, FOLLOW_INTEGER_in_posExpr532);
          localCellPosition.moveCol(Integer.parseInt(localToken1 != null ? localToken1.getText() : null));
          match(this.input, 35, FOLLOW_35_in_posExpr538);
          break;
        case 2: 
          localToken1 = (Token)match(this.input, 18, FOLLOW_INTEGER_in_posExpr545);
          localCellPosition.setColIndex(Integer.parseInt(localToken1 != null ? localToken1.getText() : null));
        }
        break;
      case 2: 
        localCellPosition = new CellPosition(this.cell.getRowIndex(), this.cell.getIndex());
        match(this.input, 25, FOLLOW_ROWNAME_in_posExpr561);
        k = 3;
        m = this.input.LA(1);
        if (m == 34) {
          k = 1;
        } else if (m == 18) {
          k = 2;
        }
        switch (k)
        {
        case 1: 
          match(this.input, 34, FOLLOW_34_in_posExpr564);
          localToken2 = (Token)match(this.input, 18, FOLLOW_INTEGER_in_posExpr570);
          localCellPosition.moveRow(Integer.parseInt(localToken2 != null ? localToken2.getText() : null));
          match(this.input, 35, FOLLOW_35_in_posExpr575);
          break;
        case 2: 
          localToken2 = (Token)match(this.input, 18, FOLLOW_INTEGER_in_posExpr583);
          localCellPosition.setRowIndex(Integer.parseInt(localToken2 != null ? localToken2.getText() : null));
        }
        match(this.input, 26, FOLLOW_COLNAME_in_posExpr592);
        int n = 3;
        int i1 = this.input.LA(1);
        if (i1 == 34) {
          n = 1;
        } else if (i1 == 18) {
          n = 2;
        }
        switch (n)
        {
        case 1: 
          match(this.input, 34, FOLLOW_34_in_posExpr595);
          localToken1 = (Token)match(this.input, 18, FOLLOW_INTEGER_in_posExpr601);
          localCellPosition.moveCol(Integer.parseInt(localToken1 != null ? localToken1.getText() : null));
          match(this.input, 35, FOLLOW_35_in_posExpr607);
          break;
        case 2: 
          localToken1 = (Token)match(this.input, 18, FOLLOW_INTEGER_in_posExpr615);
          localCellPosition.setColIndex(Integer.parseInt(localToken1 != null ? localToken1.getText() : null));
        }
        break;
      }
    }
    catch (RecognitionException localRecognitionException)
    {
      reportError(localRecognitionException);
      recover(this.input, localRecognitionException);
    }
    return localCellPosition;
  }
  
  public final CellFuncExpr funcExpr()
    throws RecognitionException
  {
    CellFuncExpr localCellFuncExpr = null;
    Token localToken = null;
    ICellFormulaExpr localICellFormulaExpr = null;
    try
    {
      localToken = (Token)match(this.input, 27, FOLLOW_FUNCNAME_in_funcExpr629);
      localCellFuncExpr = this.funcProvider.newFunc(localToken != null ? localToken.getText() : null);
      match(this.input, 16, FOLLOW_LPAREN_in_funcExpr634);
      int i = 2;
      int j = this.input.LA(1);
      if (((j >= 11) && (j <= 12)) || (j == 16) || ((j >= 18) && (j <= 22)) || ((j >= 24) && (j <= 25)) || (j == 27)) {
        i = 1;
      }
      switch (i)
      {
      case 1: 
        pushFollow(FOLLOW_expr_in_funcExpr641);
        localICellFormulaExpr = expr();
        this.state._fsp -= 1;
        localCellFuncExpr.addArgExpr(localICellFormulaExpr);
        for (;;)
        {
          int k = 2;
          int m = this.input.LA(1);
          if (m == 28) {
            k = 1;
          }
          switch (k)
          {
          case 1: 
            match(this.input, 28, FOLLOW_COMMA_in_funcExpr647);
            pushFollow(FOLLOW_expr_in_funcExpr653);
            localICellFormulaExpr = expr();
            this.state._fsp -= 1;
            localCellFuncExpr.addArgExpr(localICellFormulaExpr);
          }
        }
      }
      match(this.input, 17, FOLLOW_RPAREN_in_funcExpr663);
      localCellFuncExpr.endArg();
    }
    catch (RecognitionException localRecognitionException)
    {
      reportError(localRecognitionException);
      recover(this.input, localRecognitionException);
    }
    return localCellFuncExpr;
  }
  
  class _A
    extends DFA
  {
    public _A(BaseRecognizer paramBaseRecognizer)
    {
      this.recognizer = paramBaseRecognizer;
      this.decisionNumber = 9;
      this.eot = CellFormulaExprParser.DFA9_eot;
      this.eof = CellFormulaExprParser.DFA9_eof;
      this.min = CellFormulaExprParser.DFA9_min;
      this.max = CellFormulaExprParser.DFA9_max;
      this.accept = CellFormulaExprParser.DFA9_accept;
      this.special = CellFormulaExprParser.DFA9_special;
      this.transition = CellFormulaExprParser.DFA9_transition;
    }
    
    public String getDescription()
    {
      return "107:1: rangeExpr returns [ICellFormulaExpr value] : (e= posExpr | e1= posExpr ':' e2= posExpr );";
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\formula\CellFormulaExprParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */