package edu.thu.ext.excel.model.formula;

import edu.thu.ext.excel.xpt.XptBuildRuntime;
import java.io.Serializable;

public abstract interface ICellFormulaExpr
  extends Serializable, ICellFormulaExpandSupport
{
  public abstract String getExprString(int paramInt);
  
  public abstract Object evaluate(XptBuildRuntime paramXptBuildRuntime);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\formula\ICellFormulaExpr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */