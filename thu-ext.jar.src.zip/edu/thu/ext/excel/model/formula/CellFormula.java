package edu.thu.ext.excel.model.formula;

import edu.thu.ext.excel.model.Cell;
import edu.thu.ext.excel.xpt.XptBuildRuntime;

public class CellFormula
  implements ICellFormulaExpr
{
  private static final long serialVersionUID = 5248567196588252848L;
  Cell H;
  ICellFormulaExpr I;
  
  public CellFormula(Cell paramCell, ICellFormulaExpr paramICellFormulaExpr)
  {
    this.H = paramCell;
    this.I = paramICellFormulaExpr;
  }
  
  public Cell getCell()
  {
    return this.H;
  }
  
  public void setCell(Cell paramCell)
  {
    this.H = paramCell;
  }
  
  public ICellFormulaExpr getExpr()
  {
    return this.I;
  }
  
  public void setExpr(ICellFormulaExpr paramICellFormulaExpr)
  {
    this.I = paramICellFormulaExpr;
  }
  
  public String getExprString(int paramInt)
  {
    return this.I.getExprString(paramInt);
  }
  
  public Object evaluate(XptBuildRuntime paramXptBuildRuntime)
  {
    return this.I.evaluate(paramXptBuildRuntime);
  }
  
  public String getExpandedFormula(XptBuildRuntime paramXptBuildRuntime)
  {
    return this.I.getExpandedFormula(paramXptBuildRuntime);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\formula\CellFormula.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */