package edu.thu.ext.excel.model.formula;

import org.antlr.runtime.BaseRecognizer;
import org.antlr.runtime.CharStream;
import org.antlr.runtime.DFA;
import org.antlr.runtime.EarlyExitException;
import org.antlr.runtime.Lexer;
import org.antlr.runtime.MismatchedSetException;
import org.antlr.runtime.NoViableAltException;
import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.RecognizerSharedState;

public class CellFormulaExprLexer
  extends Lexer
{
  public static final int INTEGER = 18;
  public static final int LT = 4;
  public static final int ROWNAME = 25;
  public static final int PERCENT = 23;
  public static final int CONCAT = 10;
  public static final int LETTER = 29;
  public static final int NUMBER = 19;
  public static final int LTEQ = 5;
  public static final int SUB = 11;
  public static final int GTEQ = 7;
  public static final int MULT = 14;
  public static final int EOF = -1;
  public static final int TRUE = 21;
  public static final int LPAREN = 16;
  public static final int ROWCOLNAME = 24;
  public static final int ESCAPE_SEQUENCE = 31;
  public static final int RPAREN = 17;
  public static final int NOTEQ = 9;
  public static final int T__33 = 33;
  public static final int WS = 32;
  public static final int T__34 = 34;
  public static final int T__35 = 35;
  public static final int EXP = 15;
  public static final int COMMA = 28;
  public static final int COLNAME = 26;
  public static final int GT = 6;
  public static final int FUNCNAME = 27;
  public static final int DIGIT = 30;
  public static final int DIV = 13;
  public static final int EQ = 8;
  public static final int FALSE = 22;
  public static final int STRING = 20;
  public static final int ADD = 12;
  protected _A dfa11 = new _A(this);
  static final String DFA11_eotS = "\004￿\002\n\001 \001!\002\n\001￿\001\"\001#\002￿\001'\001)\n￿\004\n\001.\n￿\004\n\001￿\0023\002\n\001￿\0026\001￿";
  static final String DFA11_eofS = "7￿";
  static final String DFA11_minS = "\001\t\003￿\001R\003A\001R\001A\001￿\0010\001.\002￿\002=\n￿\002U\002L\001A\n￿\002E\002S\001￿\002A\002E\001￿\002A\001￿";
  static final String DFA11_maxS = "\001z\003￿\001r\001a\002z\001r\001a\001￿\0029\002￿\001>\001=\n￿\002u\002l\001z\n￿\002e\002s\001￿\002z\002e\001￿\002z\001￿";
  static final String DFA11_acceptS = "\001￿\001\001\001\002\001\003\006￿\001\t\002￿\001\f\001\r\002￿\001\021\001\024\001\025\001\026\001\027\001\030\001\032\001\033\001\034\001\035\005￿\001\006\001\007\001\031\001\n\001\013\001\016\001\017\001\022\001\020\001\023\004￿\001\b\004￿\001\004\002￿\001\005";
  static final String DFA11_specialS = "7￿}>";
  static final String[] DFA11_transitionS = { "\002\016\002￿\001\016\022￿\001\016\001￿\001\r\002￿\001\032\001\022\001￿\001\027\001\030\001\024\001\026\001\031\001\013\001￿\001\025\n\f\001\001\001￿\001\017\001\021\001\020\002￿\002\n\001\007\002\n\001\t\013\n\001\006\001\n\001\b\006\n\001\002\001￿\001\003\001\023\002￿\005\n\001\005\r\n\001\004\006\n", "", "", "", "\001\034\037￿\001\033", "\001\036\037￿\001\035", "\002\n\001\037\027\n\006￿\032\n", "\032\n\006￿\032\n", "\001\034\037￿\001\033", "\001\036\037￿\001\035", "", "\n#", "\001$\001￿\n\f", "", "", "\001&\001%", "\001(", "", "", "", "", "", "", "", "", "", "", "\001+\037￿\001*", "\001+\037￿\001*", "\001-\037￿\001,", "\001-\037￿\001,", "\032\n\006￿\032\n", "", "", "", "", "", "", "", "", "", "", "\0010\037￿\001/", "\0010\037￿\001/", "\0012\037￿\0011", "\0012\037￿\0011", "", "\032\n\006￿\032\n", "\032\n\006￿\032\n", "\0015\037￿\0014", "\0015\037￿\0014", "", "\032\n\006￿\032\n", "\032\n\006￿\032\n", "" };
  static final short[] DFA11_eot = DFA.unpackEncodedString("\004￿\002\n\001 \001!\002\n\001￿\001\"\001#\002￿\001'\001)\n￿\004\n\001.\n￿\004\n\001￿\0023\002\n\001￿\0026\001￿");
  static final short[] DFA11_eof = DFA.unpackEncodedString("7￿");
  static final char[] DFA11_min = DFA.unpackEncodedStringToUnsignedChars("\001\t\003￿\001R\003A\001R\001A\001￿\0010\001.\002￿\002=\n￿\002U\002L\001A\n￿\002E\002S\001￿\002A\002E\001￿\002A\001￿");
  static final char[] DFA11_max = DFA.unpackEncodedStringToUnsignedChars("\001z\003￿\001r\001a\002z\001r\001a\001￿\0029\002￿\001>\001=\n￿\002u\002l\001z\n￿\002e\002s\001￿\002z\002e\001￿\002z\001￿");
  static final short[] DFA11_accept = DFA.unpackEncodedString("\001￿\001\001\001\002\001\003\006￿\001\t\002￿\001\f\001\r\002￿\001\021\001\024\001\025\001\026\001\027\001\030\001\032\001\033\001\034\001\035\005￿\001\006\001\007\001\031\001\n\001\013\001\016\001\017\001\022\001\020\001\023\004￿\001\b\004￿\001\004\002￿\001\005");
  static final short[] DFA11_special = DFA.unpackEncodedString("7￿}>");
  static final short[][] DFA11_transition;
  
  static
  {
    int i = DFA11_transitionS.length;
    DFA11_transition = new short[i][];
    for (int j = 0; j < i; j++) {
      DFA11_transition[j] = DFA.unpackEncodedString(DFA11_transitionS[j]);
    }
  }
  
  public CellFormulaExprLexer() {}
  
  public CellFormulaExprLexer(CharStream paramCharStream)
  {
    this(paramCharStream, new RecognizerSharedState());
  }
  
  public CellFormulaExprLexer(CharStream paramCharStream, RecognizerSharedState paramRecognizerSharedState)
  {
    super(paramCharStream, paramRecognizerSharedState);
  }
  
  public String getGrammarFileName()
  {
    return "E:\\reference\\ref-source\\Antlr\\CellFormulaExpr.g";
  }
  
  public final void mT__33()
    throws RecognitionException
  {
    int i = 33;
    int j = 0;
    match(58);
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mT__34()
    throws RecognitionException
  {
    int i = 34;
    int j = 0;
    match(91);
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mT__35()
    throws RecognitionException
  {
    int i = 35;
    int j = 0;
    match(93);
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mTRUE()
    throws RecognitionException
  {
    int i = 21;
    int j = 0;
    MismatchedSetException localMismatchedSetException;
    if ((this.input.LA(1) == 84) || (this.input.LA(1) == 116))
    {
      this.input.consume();
    }
    else
    {
      localMismatchedSetException = new MismatchedSetException(null, this.input);
      recover(localMismatchedSetException);
      throw localMismatchedSetException;
    }
    if ((this.input.LA(1) == 82) || (this.input.LA(1) == 114))
    {
      this.input.consume();
    }
    else
    {
      localMismatchedSetException = new MismatchedSetException(null, this.input);
      recover(localMismatchedSetException);
      throw localMismatchedSetException;
    }
    if ((this.input.LA(1) == 85) || (this.input.LA(1) == 117))
    {
      this.input.consume();
    }
    else
    {
      localMismatchedSetException = new MismatchedSetException(null, this.input);
      recover(localMismatchedSetException);
      throw localMismatchedSetException;
    }
    if ((this.input.LA(1) == 69) || (this.input.LA(1) == 101))
    {
      this.input.consume();
    }
    else
    {
      localMismatchedSetException = new MismatchedSetException(null, this.input);
      recover(localMismatchedSetException);
      throw localMismatchedSetException;
    }
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mFALSE()
    throws RecognitionException
  {
    int i = 22;
    int j = 0;
    MismatchedSetException localMismatchedSetException;
    if ((this.input.LA(1) == 70) || (this.input.LA(1) == 102))
    {
      this.input.consume();
    }
    else
    {
      localMismatchedSetException = new MismatchedSetException(null, this.input);
      recover(localMismatchedSetException);
      throw localMismatchedSetException;
    }
    if ((this.input.LA(1) == 65) || (this.input.LA(1) == 97))
    {
      this.input.consume();
    }
    else
    {
      localMismatchedSetException = new MismatchedSetException(null, this.input);
      recover(localMismatchedSetException);
      throw localMismatchedSetException;
    }
    if ((this.input.LA(1) == 76) || (this.input.LA(1) == 108))
    {
      this.input.consume();
    }
    else
    {
      localMismatchedSetException = new MismatchedSetException(null, this.input);
      recover(localMismatchedSetException);
      throw localMismatchedSetException;
    }
    if ((this.input.LA(1) == 83) || (this.input.LA(1) == 115))
    {
      this.input.consume();
    }
    else
    {
      localMismatchedSetException = new MismatchedSetException(null, this.input);
      recover(localMismatchedSetException);
      throw localMismatchedSetException;
    }
    if ((this.input.LA(1) == 69) || (this.input.LA(1) == 101))
    {
      this.input.consume();
    }
    else
    {
      localMismatchedSetException = new MismatchedSetException(null, this.input);
      recover(localMismatchedSetException);
      throw localMismatchedSetException;
    }
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mROWNAME()
    throws RecognitionException
  {
    int i = 25;
    int j = 0;
    match(82);
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mCOLNAME()
    throws RecognitionException
  {
    int i = 26;
    int j = 0;
    match(67);
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mROWCOLNAME()
    throws RecognitionException
  {
    int i = 24;
    int j = 0;
    match("RC");
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mFUNCNAME()
    throws RecognitionException
  {
    int i = 27;
    int j = 0;
    for (int k = 0;; k++)
    {
      int m = 2;
      int n = this.input.LA(1);
      if (((n >= 65) && (n <= 90)) || ((n >= 97) && (n <= 122))) {
        m = 1;
      }
      switch (m)
      {
      case 1: 
        mLETTER();
        break;
      default: 
        if (k >= 1) {
          break label110;
        }
        EarlyExitException localEarlyExitException = new EarlyExitException(1, this.input);
        throw localEarlyExitException;
      }
    }
    label110:
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mINTEGER()
    throws RecognitionException
  {
    int i = 18;
    int j = 0;
    int k = 2;
    int m = this.input.LA(1);
    if (m == 45) {
      k = 1;
    }
    switch (k)
    {
    case 1: 
      mSUB();
    }
    for (int n = 0;; n++)
    {
      int i1 = 2;
      int i2 = this.input.LA(1);
      if ((i2 >= 48) && (i2 <= 57)) {
        i1 = 1;
      }
      switch (i1)
      {
      case 1: 
        mDIGIT();
        break;
      default: 
        if (n >= 1) {
          break label147;
        }
        EarlyExitException localEarlyExitException = new EarlyExitException(3, this.input);
        throw localEarlyExitException;
      }
    }
    label147:
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mNUMBER()
    throws RecognitionException
  {
    int i = 19;
    int j = 0;
    for (int k = 0;; k++)
    {
      m = 2;
      n = this.input.LA(1);
      if ((n >= 48) && (n <= 57)) {
        m = 1;
      }
      switch (m)
      {
      case 1: 
        mDIGIT();
        break;
      default: 
        if (k >= 1) {
          break label98;
        }
        EarlyExitException localEarlyExitException1 = new EarlyExitException(4, this.input);
        throw localEarlyExitException1;
      }
    }
    label98:
    int m = 2;
    int n = this.input.LA(1);
    if (n == 46) {
      m = 1;
    }
    switch (m)
    {
    case 1: 
      match(46);
      for (int i1 = 0;; i1++)
      {
        int i2 = 2;
        int i3 = this.input.LA(1);
        if ((i3 >= 48) && (i3 <= 57)) {
          i2 = 1;
        }
        switch (i2)
        {
        case 1: 
          mDIGIT();
          break;
        default: 
          if (i1 >= 1) {
            break label243;
          }
          EarlyExitException localEarlyExitException2 = new EarlyExitException(5, this.input);
          throw localEarlyExitException2;
        }
      }
    }
    label243:
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mSTRING()
    throws RecognitionException
  {
    int i = 20;
    int j = 0;
    match(34);
    for (;;)
    {
      int k = 3;
      int m = this.input.LA(1);
      if (m == 34) {
        k = 3;
      } else if (m == 92) {
        k = 1;
      } else if (((m >= 0) && (m <= 33)) || ((m >= 35) && (m <= 91)) || ((m >= 93) && (m <= 65535))) {
        k = 2;
      }
      switch (k)
      {
      case 1: 
        mESCAPE_SEQUENCE();
        break;
      case 2: 
        if (((this.input.LA(1) < 0) || (this.input.LA(1) > 91)) && ((this.input.LA(1) < 93) || (this.input.LA(1) > 65535))) {
          break label194;
        }
        this.input.consume();
      }
    }
    label194:
    MismatchedSetException localMismatchedSetException = new MismatchedSetException(null, this.input);
    recover(localMismatchedSetException);
    throw localMismatchedSetException;
    match(34);
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mWS()
    throws RecognitionException
  {
    int i = 32;
    int j = 0;
    for (int k = 0;; k++)
    {
      int m = 2;
      int n = this.input.LA(1);
      if (((n >= 9) && (n <= 10)) || (n == 13) || (n == 32)) {
        m = 1;
      }
      Object localObject;
      switch (m)
      {
      case 1: 
        if (((this.input.LA(1) >= 9) && (this.input.LA(1) <= 10)) || (this.input.LA(1) == 13) || (this.input.LA(1) == 32))
        {
          this.input.consume();
        }
        else
        {
          localObject = new MismatchedSetException(null, this.input);
          recover((RecognitionException)localObject);
          throw ((Throwable)localObject);
        }
        break;
      default: 
        if (k >= 1) {
          break label199;
        }
        localObject = new EarlyExitException(8, this.input);
        throw ((Throwable)localObject);
      }
    }
    label199:
    skip();
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mNOTEQ()
    throws RecognitionException
  {
    int i = 9;
    int j = 0;
    match("<>");
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mLTEQ()
    throws RecognitionException
  {
    int i = 5;
    int j = 0;
    match("<=");
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mGTEQ()
    throws RecognitionException
  {
    int i = 7;
    int j = 0;
    match(">=");
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mEQ()
    throws RecognitionException
  {
    int i = 8;
    int j = 0;
    match(61);
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mLT()
    throws RecognitionException
  {
    int i = 4;
    int j = 0;
    match(60);
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mGT()
    throws RecognitionException
  {
    int i = 6;
    int j = 0;
    match(62);
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mCONCAT()
    throws RecognitionException
  {
    int i = 10;
    int j = 0;
    match(38);
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mEXP()
    throws RecognitionException
  {
    int i = 15;
    int j = 0;
    match(94);
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mMULT()
    throws RecognitionException
  {
    int i = 14;
    int j = 0;
    match(42);
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mDIV()
    throws RecognitionException
  {
    int i = 13;
    int j = 0;
    match(47);
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mADD()
    throws RecognitionException
  {
    int i = 12;
    int j = 0;
    match(43);
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mSUB()
    throws RecognitionException
  {
    int i = 11;
    int j = 0;
    match(45);
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mLPAREN()
    throws RecognitionException
  {
    int i = 16;
    int j = 0;
    match(40);
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mRPAREN()
    throws RecognitionException
  {
    int i = 17;
    int j = 0;
    match(41);
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mCOMMA()
    throws RecognitionException
  {
    int i = 28;
    int j = 0;
    match(44);
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mPERCENT()
    throws RecognitionException
  {
    int i = 23;
    int j = 0;
    match(37);
    this.state.type = i;
    this.state.channel = j;
  }
  
  public final void mLETTER()
    throws RecognitionException
  {
    int i = 2;
    int j = this.input.LA(1);
    if ((j >= 97) && (j <= 122))
    {
      i = 1;
    }
    else if ((j >= 65) && (j <= 90))
    {
      i = 2;
    }
    else
    {
      NoViableAltException localNoViableAltException = new NoViableAltException("", 9, 0, this.input);
      throw localNoViableAltException;
    }
    switch (i)
    {
    case 1: 
      matchRange(97, 122);
      break;
    case 2: 
      matchRange(65, 90);
    }
  }
  
  public final void mDIGIT()
    throws RecognitionException
  {
    matchRange(48, 57);
  }
  
  public final void mESCAPE_SEQUENCE()
    throws RecognitionException
  {
    int i = 5;
    int j = this.input.LA(1);
    NoViableAltException localNoViableAltException;
    if (j == 92)
    {
      switch (this.input.LA(2))
      {
      case 116: 
        i = 1;
        break;
      case 110: 
        i = 2;
        break;
      case 34: 
        i = 3;
        break;
      case 39: 
        i = 4;
        break;
      case 92: 
        i = 5;
        break;
      default: 
        localNoViableAltException = new NoViableAltException("", 10, 1, this.input);
        throw localNoViableAltException;
        break;
      }
    }
    else
    {
      localNoViableAltException = new NoViableAltException("", 10, 0, this.input);
      throw localNoViableAltException;
    }
    switch (i)
    {
    case 1: 
      match(92);
      match(116);
      break;
    case 2: 
      match(92);
      match(110);
      break;
    case 3: 
      match(92);
      match(34);
      break;
    case 4: 
      match(92);
      match(39);
      break;
    case 5: 
      match(92);
      match(92);
    }
  }
  
  public void mTokens()
    throws RecognitionException
  {
    int i = 29;
    i = this.dfa11.predict(this.input);
    switch (i)
    {
    case 1: 
      mT__33();
      break;
    case 2: 
      mT__34();
      break;
    case 3: 
      mT__35();
      break;
    case 4: 
      mTRUE();
      break;
    case 5: 
      mFALSE();
      break;
    case 6: 
      mROWNAME();
      break;
    case 7: 
      mCOLNAME();
      break;
    case 8: 
      mROWCOLNAME();
      break;
    case 9: 
      mFUNCNAME();
      break;
    case 10: 
      mINTEGER();
      break;
    case 11: 
      mNUMBER();
      break;
    case 12: 
      mSTRING();
      break;
    case 13: 
      mWS();
      break;
    case 14: 
      mNOTEQ();
      break;
    case 15: 
      mLTEQ();
      break;
    case 16: 
      mGTEQ();
      break;
    case 17: 
      mEQ();
      break;
    case 18: 
      mLT();
      break;
    case 19: 
      mGT();
      break;
    case 20: 
      mCONCAT();
      break;
    case 21: 
      mEXP();
      break;
    case 22: 
      mMULT();
      break;
    case 23: 
      mDIV();
      break;
    case 24: 
      mADD();
      break;
    case 25: 
      mSUB();
      break;
    case 26: 
      mLPAREN();
      break;
    case 27: 
      mRPAREN();
      break;
    case 28: 
      mCOMMA();
      break;
    case 29: 
      mPERCENT();
    }
  }
  
  class _A
    extends DFA
  {
    public _A(BaseRecognizer paramBaseRecognizer)
    {
      this.recognizer = paramBaseRecognizer;
      this.decisionNumber = 11;
      this.eot = CellFormulaExprLexer.DFA11_eot;
      this.eof = CellFormulaExprLexer.DFA11_eof;
      this.min = CellFormulaExprLexer.DFA11_min;
      this.max = CellFormulaExprLexer.DFA11_max;
      this.accept = CellFormulaExprLexer.DFA11_accept;
      this.special = CellFormulaExprLexer.DFA11_special;
      this.transition = CellFormulaExprLexer.DFA11_transition;
    }
    
    public String getDescription()
    {
      return "1:1: Tokens : ( T__33 | T__34 | T__35 | TRUE | FALSE | ROWNAME | COLNAME | ROWCOLNAME | FUNCNAME | INTEGER | NUMBER | STRING | WS | NOTEQ | LTEQ | GTEQ | EQ | LT | GT | CONCAT | EXP | MULT | DIV | ADD | SUB | LPAREN | RPAREN | COMMA | PERCENT );";
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\formula\CellFormulaExprLexer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */