package edu.thu.ext.excel.model.formula;

import edu.thu.ext.excel.xpt.XptBuildRuntime;

public abstract interface ICellFormulaExpandSupport
{
  public abstract String getExpandedFormula(XptBuildRuntime paramXptBuildRuntime);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\formula\ICellFormulaExpandSupport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */