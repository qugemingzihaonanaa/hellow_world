package edu.thu.ext.excel.model;

import java.io.Serializable;

public class Print
  implements Serializable
{
  private static final long serialVersionUID = -4680032422052657776L;
  Integer H;
  Integer I;
  Integer C;
  Integer J;
  Double E;
  String G;
  boolean F;
  boolean B;
  Integer A;
  Integer D;
  
  public Integer getFitWidth()
  {
    return this.A;
  }
  
  public void setFitWidth(Integer paramInteger)
  {
    this.A = paramInteger;
  }
  
  public Integer getFitHeight()
  {
    return this.D;
  }
  
  public void setFitHeight(Integer paramInteger)
  {
    this.D = paramInteger;
  }
  
  public String getCommentsLayout()
  {
    return this.G;
  }
  
  public void setCommentsLayout(String paramString)
  {
    this.G = paramString;
  }
  
  public boolean isGridlines()
  {
    return this.F;
  }
  
  public void setGridlines(boolean paramBoolean)
  {
    this.F = paramBoolean;
  }
  
  public boolean isRowColHeadings()
  {
    return this.B;
  }
  
  public void setRowColHeadings(boolean paramBoolean)
  {
    this.B = paramBoolean;
  }
  
  public Integer getValidPrinterInfo()
  {
    return this.H;
  }
  
  public void setValidPrinterInfo(Integer paramInteger)
  {
    this.H = paramInteger;
  }
  
  public Integer getPaperSizeIndex()
  {
    return this.I;
  }
  
  public void setPaperSizeIndex(Integer paramInteger)
  {
    this.I = paramInteger;
  }
  
  public Integer getHorizontalResolution()
  {
    return this.C;
  }
  
  public void setHorizontalResolution(Integer paramInteger)
  {
    this.C = paramInteger;
  }
  
  public Integer getVerticalResolution()
  {
    return this.J;
  }
  
  public void setVerticalResolution(Integer paramInteger)
  {
    this.J = paramInteger;
  }
  
  public Double getScale()
  {
    return this.E;
  }
  
  public void setScale(Double paramDouble)
  {
    this.E = paramDouble;
  }
  
  public String toXls()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("<Print>");
    if (this.A != null) {
      localStringBuilder.append("<FitWidth>").append(this.A).append("</FitWidth>");
    }
    if (this.D != null) {
      localStringBuilder.append("<FitHeight>").append(this.D).append("</FitHeight>");
    }
    if (this.G != null) {
      localStringBuilder.append("<CommentsLayout>").append(this.G).append("</CommentsLayout>");
    }
    if (this.H != null) {
      localStringBuilder.append("<ValidPrinterInfo>").append(this.H).append("</ValidPrinterInfo>");
    }
    if (this.I != null) {
      localStringBuilder.append("<PaperSizeIndex>").append(this.I).append("</PaperSizeIndex>");
    }
    if (this.E != null) {
      localStringBuilder.append("<Scale>").append(this.E.intValue()).append("</Scale>");
    }
    if (this.C != null) {
      localStringBuilder.append("<HorizontalResolution>").append(this.C).append("</HorizontalResolution>");
    }
    if (this.J != null) {
      localStringBuilder.append("<VerticalResolution>").append(this.J).append("</VerticalResolution>");
    }
    if (this.F) {
      localStringBuilder.append("<Gridlines/>");
    }
    if (this.B) {
      localStringBuilder.append("<RowColHeadings/>");
    }
    localStringBuilder.append("</Print>");
    return localStringBuilder.toString();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\Print.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */