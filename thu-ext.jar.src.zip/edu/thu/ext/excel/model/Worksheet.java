package edu.thu.ext.excel.model;

import edu.thu.lang.reflect.BeanInstance;
import edu.thu.lang.util.IWrapCollection;
import edu.thu.report.util.WrapCollection;
import edu.thu.util.StringUtils;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Worksheet
  implements IWorksheet, Serializable
{
  private static final long serialVersionUID = -7733214705683918957L;
  String C;
  WorksheetOptions N;
  Table L = new Table(this);
  Object K;
  Workbook M;
  List<Range> J;
  List<ImgData> E;
  PageBreaks B;
  Object D;
  Range G;
  boolean A;
  boolean I;
  Map<String, Object> F;
  Names H;
  
  public String toString()
  {
    return "Worksheet[" + this.C + "]";
  }
  
  public Names getNames()
  {
    return this.H;
  }
  
  public void setNames(Names paramNames)
  {
    this.H = paramNames;
  }
  
  public WxReportConfig getWxReportConfig()
  {
    return this.M == null ? null : this.M.getWxReportConfig();
  }
  
  public Map<String, Object> getProperties()
  {
    return this.F;
  }
  
  public void setProperties(Map<String, Object> paramMap)
  {
    this.F = paramMap;
  }
  
  public boolean isContainsFormula()
  {
    return this.I;
  }
  
  public void setContainsFormula(boolean paramBoolean)
  {
    this.I = paramBoolean;
  }
  
  public boolean isNeedExpand()
  {
    return this.A;
  }
  
  public void setNeedExpand(boolean paramBoolean)
  {
    this.A = paramBoolean;
  }
  
  public Range getEditRange()
  {
    return this.G;
  }
  
  public void setEditRange(Range paramRange)
  {
    this.G = paramRange;
  }
  
  public Object getObj()
  {
    return this.D;
  }
  
  public void setObj(Object paramObject)
  {
    this.D = paramObject;
  }
  
  public Workbook getAsWorkbook()
  {
    Workbook localWorkbook;
    if (this.M == null)
    {
      localWorkbook = new Workbook();
    }
    else
    {
      localBeanInstance = new BeanInstance(this.M);
      localWorkbook = (Workbook)localBeanInstance.cloneInstance(false);
    }
    BeanInstance localBeanInstance = new BeanInstance(this);
    localWorkbook.getWorksheets().clear();
    Worksheet localWorksheet = (Worksheet)localBeanInstance.cloneInstance(false);
    localWorksheet.setWorkbook(localWorkbook);
    localWorkbook.getWorksheets().add(localWorksheet);
    return localWorkbook;
  }
  
  public List<NamedRange> getNamedRanges(String paramString)
  {
    if (this.H != null)
    {
      List localList = this.H.getRangeWithPrefix(paramString);
      if ((localList != null) && (!localList.isEmpty())) {
        return localList;
      }
    }
    return this.M.getRangeInSheet(this.C, paramString);
  }
  
  public NamedRange getNamedRange(String paramString)
  {
    if (this.H != null)
    {
      localList = this.H.getRangeWithPrefix(paramString);
      if ((localList != null) && (!localList.isEmpty())) {
        return (NamedRange)localList.get(0);
      }
    }
    List localList = getNamedRanges(paramString);
    if ((localList == null) || (localList.isEmpty())) {
      return null;
    }
    return (NamedRange)localList.get(0);
  }
  
  public Worksheet copy()
  {
    Worksheet localWorksheet = (Worksheet)new BeanInstance(this).cloneInstance(false);
    localWorksheet.N = (this.N == null ? null : this.N.copy());
    localWorksheet.L = this.L.copy();
    localWorksheet.J = (this.J == null ? null : new WrapCollection(this.J).invoke("copy").listValue());
    localWorksheet.E = (this.E == null ? null : new WrapCollection(this.E).invoke("copy").listValue());
    localWorksheet.B = (this.B == null ? null : this.B.copy());
    return localWorksheet;
  }
  
  public void setImgs(List<ImgData> paramList)
  {
    if (paramList == null)
    {
      this.E = null;
    }
    else
    {
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        ImgData localImgData = (ImgData)localIterator.next();
        addImg(localImgData);
      }
    }
  }
  
  public RowBlock getRowBlock()
  {
    return new RowBlock("simple", 0, getRowCount() - 1);
  }
  
  public PageBreaks getPageBreaks()
  {
    return this.B;
  }
  
  public void setPageBreaks(PageBreaks paramPageBreaks)
  {
    this.B = paramPageBreaks;
  }
  
  public List<ImgData> getImgs()
  {
    return this.E;
  }
  
  public void addImg(ImgData paramImgData)
  {
    if (this.E == null) {
      this.E = new ArrayList();
    }
    paramImgData.setSheetName(this.C);
    this.E.add(paramImgData);
  }
  
  public ImgData newImg()
  {
    ImgData localImgData = new ImgData();
    addImg(localImgData);
    return localImgData;
  }
  
  public PageInfo newPageInfo()
  {
    return new PageInfo(this.L.getTotalWidth(), isHorPage());
  }
  
  public void collectFieldDefinitions(FieldDefinitionList paramFieldDefinitionList)
  {
    int i = getSheetIndex();
    String str = getNormalName();
    Iterator localIterator1 = this.L.getRows().iterator();
    while (localIterator1.hasNext())
    {
      Row localRow = (Row)localIterator1.next();
      Iterator localIterator2 = localRow.getCells().iterator();
      while (localIterator2.hasNext())
      {
        Cell localCell = (Cell)localIterator2.next();
        if (!localCell.isIgnored())
        {
          FieldDefinition localFieldDefinition = localCell.getFieldDefinition();
          if (localFieldDefinition != null)
          {
            localFieldDefinition.setGroupIndex(i);
            paramFieldDefinitionList.addFieldDefinition(str, localFieldDefinition);
          }
        }
      }
    }
  }
  
  public Cell getCellByPackedData(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    Iterator localIterator1 = this.L.getRows().iterator();
    while (localIterator1.hasNext())
    {
      Row localRow = (Row)localIterator1.next();
      Iterator localIterator2 = localRow.getCells().iterator();
      while (localIterator2.hasNext())
      {
        Cell localCell = (Cell)localIterator2.next();
        if (paramString.equals(localCell.getPackedData())) {
          return localCell;
        }
      }
    }
    return null;
  }
  
  public List<Range> getMergedRanges()
  {
    return this.J;
  }
  
  public void setMergedRanges(List<Range> paramList)
  {
    this.J = paramList;
  }
  
  public Range findMergeRange(int paramInt1, int paramInt2)
  {
    if (this.J == null) {
      return null;
    }
    int j = this.J.size();
    for (int i = 0; i < j; i++)
    {
      Range localRange = (Range)this.J.get(i);
      int k = localRange.getMergeStatus(paramInt1, paramInt2);
      if (Range.isInRange(k)) {
        return localRange;
      }
    }
    return null;
  }
  
  public Range findMergeRangeAt(int paramInt1, int paramInt2)
  {
    if (this.J == null) {
      return null;
    }
    int j = this.J.size();
    for (int i = 0; i < j; i++)
    {
      Range localRange = (Range)this.J.get(i);
      int k = localRange.getMergeStatus(paramInt1, paramInt2);
      if (Range.isRangeAt(k)) {
        return localRange;
      }
    }
    return null;
  }
  
  public int findMergeStatus(int paramInt1, int paramInt2)
  {
    if (this.J == null) {
      return -1;
    }
    int j = this.J.size();
    for (int i = 0; i < j; i++)
    {
      Range localRange = (Range)this.J.get(i);
      int k = localRange.getMergeStatus(paramInt1, paramInt2);
      if (Range.isInRange(k)) {
        return k;
      }
    }
    return 0;
  }
  
  public boolean testInMergeRange(int paramInt1, int paramInt2)
  {
    return findMergeStatus(paramInt1, paramInt2) != 0;
  }
  
  public void initMergeStatus()
  {
    if ((this.J == null) || (this.J.isEmpty())) {
      return;
    }
    int j = getRowCount();
    for (int i = 0; i < j; i++)
    {
      Row localRow = (Row)this.L.getRows().get(i);
      for (int k = 0; k < localRow.getColCount(); k++)
      {
        Cell localCell = localRow.getCell(k);
        localCell.setMergeStatus(findMergeStatus(i, k));
      }
    }
  }
  
  public Workbook getWorkbook()
  {
    return this.M;
  }
  
  public void setWorkbook(Workbook paramWorkbook)
  {
    this.M = paramWorkbook;
  }
  
  public Object getXlsObj()
  {
    return this.K;
  }
  
  public void setXlsObj(Object paramObject)
  {
    this.K = paramObject;
  }
  
  public int getRowCount()
  {
    return this.L.getRows().size();
  }
  
  public void setWorksheetName(String paramString)
  {
    this.C = paramString;
    if (this.J != null) {
      new WrapCollection(this.J).invoke("setSheetName", new Object[] { paramString });
    }
    if (this.E != null) {
      new WrapCollection(this.E).invoke("setSheetName", new Object[] { paramString });
    }
  }
  
  public String getWorksheetName()
  {
    return this.C;
  }
  
  public void setWorksheetOptions(WorksheetOptions paramWorksheetOptions)
  {
    this.N = paramWorksheetOptions;
  }
  
  public WorksheetOptions getWorksheetOptions()
  {
    return this.N;
  }
  
  public void setTable(Table paramTable)
  {
    this.L = paramTable;
    paramTable.setSheet(this);
  }
  
  public int getColCount()
  {
    return this.L.getColCount();
  }
  
  public List<Row> getRows()
  {
    return this.L.getRows();
  }
  
  public Table getTable()
  {
    return this.L;
  }
  
  public List<List<Object>> getCellDatas()
  {
    return this.L.getCellDatas();
  }
  
  public List<TablePiece> getTablePieces()
  {
    return this.L.getTablePieces();
  }
  
  public Row getRow(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= getRowCount())) {
      return null;
    }
    return (Row)this.L.getRows().get(paramInt);
  }
  
  public List<Row> getRows(RowBlock paramRowBlock)
  {
    return this.L.getRows().subList(paramRowBlock.getFirstRowNum(), paramRowBlock.getLastRowNum() + 1);
  }
  
  public Cell getCell(CellPosition paramCellPosition)
  {
    return this.L.getCell(paramCellPosition);
  }
  
  public Cell getCell(int paramInt1, int paramInt2)
  {
    Row localRow = getRow(paramInt1);
    if (localRow == null) {
      return null;
    }
    return localRow.getCell(paramInt2);
  }
  
  public List<String> getRowData(int paramInt)
  {
    Row localRow = getRow(paramInt);
    if (localRow == null) {
      return null;
    }
    int j = localRow.getColCount();
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < j; i++)
    {
      Cell localCell = localRow.getCell(i);
      if (localCell == null) {
        localArrayList.add(null);
      } else {
        localArrayList.add(localCell.getData());
      }
    }
    return localArrayList;
  }
  
  public boolean isPageBreakBeforeRow(int paramInt)
  {
    return this.B.isPageBreakBeforeRow(paramInt);
  }
  
  public boolean isBreakAtBegin()
  {
    return (this.C.startsWith("|")) || (this.C.startsWith("|@"));
  }
  
  public boolean isBreakAtEnd()
  {
    return this.C.endsWith("|");
  }
  
  public boolean isHorPage()
  {
    return (this.N != null) && (this.N.isHorPage());
  }
  
  public String getNormalName()
  {
    String str = StringUtils.replace(this.C, "@", "");
    str = StringUtils.replace(str, "|", "");
    return str;
  }
  
  public int getSheetIndex()
  {
    return this.M.getWorksheets().indexOf(this);
  }
  
  public boolean isSpecial()
  {
    return (this.C.startsWith("@")) || (this.C.startsWith("|@"));
  }
  
  public double getDefaultColumnWidth()
  {
    return this.L.getDefaultColumnWidth();
  }
  
  public double getDefaultRowHeight()
  {
    return this.L.getDefaultRowHeight();
  }
  
  public void setDefaultColumnWidth(double paramDouble)
  {
    this.L.setDefaultColumnWidth(paramDouble);
  }
  
  public void setDefaultRowHeight(double paramDouble)
  {
    this.L.setDefaultRowHeight(paramDouble);
  }
  
  public List<Column> getCols()
  {
    return this.L.getCols();
  }
  
  public CellRange getValidRange(CellRange paramCellRange)
  {
    CellRange localCellRange = new CellRange();
    if (paramCellRange.getLeftPos() < 0) {
      localCellRange.setLeftPos(0);
    }
    if (paramCellRange.getRightPos() >= this.L.getColCount()) {
      localCellRange.setRightPos(this.L.getColCount() - 1);
    }
    if (paramCellRange.getTopPos() < 0) {
      localCellRange.setTopPos(0);
    }
    if (paramCellRange.getBottomPos() >= this.L.getRowCount()) {
      localCellRange.setBottomPos(this.L.getRowCount() - 1);
    }
    return localCellRange;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\Worksheet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */