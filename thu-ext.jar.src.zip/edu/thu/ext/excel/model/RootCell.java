package edu.thu.ext.excel.model;

public class RootCell
  extends Cell
{
  private static final long serialVersionUID = 2124039299693077177L;
  
  public RootCell()
  {
    setIndex(1);
  }
  
  public boolean isVirtualRoot()
  {
    return true;
  }
  
  public String toString()
  {
    return "RootCell@" + hashCode();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\RootCell.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */