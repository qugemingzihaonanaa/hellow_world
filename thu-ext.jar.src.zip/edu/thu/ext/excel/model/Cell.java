package edu.thu.ext.excel.model;

import edu.thu.ext.excel.model.formula.CellFormula;
import edu.thu.global.Debug;
import edu.thu.java.util.Coercions;
import edu.thu.lang.IVariant;
import edu.thu.lang.Variant;
import edu.thu.lang.el.IExpressionReference;
import edu.thu.lang.reflect.BeanInstance;
import edu.thu.lang.util.TplC;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceContext;
import edu.thu.service.SystemServiceContext;
import edu.thu.util.StringUtils;
import edu.thu.util.StringUtilsEx;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Cell
  implements ICell, Serializable
{
  private static final long serialVersionUID = -5153692718094110612L;
  public static final Cell EMPTY_CELL = ;
  int index;
  int mergeAcross;
  int mergeDown;
  Style style;
  String formula;
  String href;
  String data;
  String dataType;
  Map<String, Object> commentVars;
  Row row;
  boolean hidden;
  boolean ignored;
  Object value;
  IExpressionReference valueExpr;
  IExpressionReference keyExpr;
  IExpressionReference linkExpr;
  Object xlsObj;
  FieldDefinition fieldDefinition;
  int mergeStatus;
  CellExpandModel expandModel;
  boolean richFormat;
  boolean staticCell;
  RichData richData;
  IExpressionReference styleExpr;
  IExpressionReference formatExpr;
  IExpressionReference commentExpr;
  IExpressionReference visibleExpr;
  IExpressionReference readOnlyExpr;
  IExpressionReference rowVisibleExpr;
  IExpressionReference objectExpr;
  IExpressionReference prepareRowExpr;
  IExpressionReference defaultValueExpr;
  CellFormula cellFormula;
  String cssClassName;
  String viewerId;
  String inputorId;
  String uid;
  boolean noValueExpr;
  Object object;
  
  public Cell copy()
  {
    return (Cell)new BeanInstance(this).cloneInstance(false);
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("cell[").append(this.row == null ? null : Integer.valueOf(this.row.getIndex())).append(",").append(this.index).append("]:").append(this.data);
    if (this.formula != null) {
      localStringBuilder.append(this.formula);
    }
    localStringBuilder.append("@").append(getSheetName());
    return localStringBuilder.toString();
  }
  
  public TreeNode toNode()
  {
    TreeNode localTreeNode1 = TreeNode.make("cell");
    localTreeNode1.setAttribute("index", Integer.valueOf(this.index));
    if (this.row != null) {
      localTreeNode1.setAttribute("rowIndex", Integer.valueOf(this.row.getIndex()));
    }
    if (this.data != null) {
      localTreeNode1.setAttribute("data", this.data);
    }
    if (this.formula != null) {
      localTreeNode1.setAttribute("formula", this.formula);
    }
    localTreeNode1.setAttribute("sheet", getSheetName());
    localTreeNode1.setAttribute("mergeAcross", Integer.valueOf(this.mergeAcross));
    localTreeNode1.setAttribute("mergeDown", Integer.valueOf(this.mergeDown));
    if (this.expandModel != null)
    {
      localTreeNode1.setAttribute("horChildPos", Integer.valueOf(this.expandModel.getHorChildPos()));
      localTreeNode1.setAttribute("verChildPos", Integer.valueOf(this.expandModel.getVerChildPos()));
      localTreeNode1.setAttribute("horExpandRange", Integer.valueOf(getHorExpandRange()));
      localTreeNode1.setAttribute("verExpandRange", Integer.valueOf(getVerExpandRange()));
    }
    List localList = getHorChildren();
    Object localObject3;
    Object localObject2;
    Object localObject4;
    if (localList != null)
    {
      localObject1 = localTreeNode1.makeChild("horChildren");
      localObject3 = localList.iterator();
      while (((Iterator)localObject3).hasNext())
      {
        localObject2 = (Cell)((Iterator)localObject3).next();
        localObject4 = ((Cell)localObject2).toNode();
        ((TreeNode)localObject1).appendChild((TreeNode)localObject4);
      }
    }
    Object localObject1 = getVerChildren();
    if (localObject1 != null)
    {
      localObject2 = localTreeNode1.makeChild("verChildren");
      localObject4 = ((List)localObject1).iterator();
      while (((Iterator)localObject4).hasNext())
      {
        localObject3 = (Cell)((Iterator)localObject4).next();
        TreeNode localTreeNode2 = ((Cell)localObject3).toNode();
        ((TreeNode)localObject2).appendChild(localTreeNode2);
      }
    }
    return localTreeNode1;
  }
  
  public String getUid()
  {
    return this.uid;
  }
  
  public void setUid(String paramString)
  {
    this.uid = paramString;
  }
  
  public Object getO()
  {
    return this.object;
  }
  
  public void setO(Object paramObject)
  {
    this.object = paramObject;
  }
  
  public IExpressionReference getObjectExpr()
  {
    return this.objectExpr;
  }
  
  public void setObjectExpr(IExpressionReference paramIExpressionReference)
  {
    this.objectExpr = paramIExpressionReference;
  }
  
  public IExpressionReference getPrepareRowExpr()
  {
    return this.prepareRowExpr;
  }
  
  public void setPrepareRowExpr(IExpressionReference paramIExpressionReference)
  {
    this.prepareRowExpr = paramIExpressionReference;
  }
  
  public IExpressionReference getStyleExpr()
  {
    return this.styleExpr;
  }
  
  public void setStyleExpr(IExpressionReference paramIExpressionReference)
  {
    this.styleExpr = paramIExpressionReference;
  }
  
  public IExpressionReference getKeyExpr()
  {
    return this.keyExpr;
  }
  
  public void setKeyExpr(IExpressionReference paramIExpressionReference)
  {
    this.keyExpr = paramIExpressionReference;
  }
  
  public IExpressionReference getDefaultValueExpr()
  {
    return this.defaultValueExpr;
  }
  
  public void setDefaultValueExpr(IExpressionReference paramIExpressionReference)
  {
    this.defaultValueExpr = paramIExpressionReference;
  }
  
  public boolean isVirtualRoot()
  {
    return false;
  }
  
  public void setCssClassName(String paramString)
  {
    this.cssClassName = paramString;
  }
  
  public int getHorExpandLevel()
  {
    return this.expandModel == null ? 0 : this.expandModel.getHorExpandLevel();
  }
  
  public int getVerExpandLevel()
  {
    return this.expandModel == null ? 0 : this.expandModel.getVerExpandLevel();
  }
  
  public void setVerExpandLevel(int paramInt)
  {
    _checkAllowExpand();
    this.expandModel.setVerExpandLevel(paramInt);
  }
  
  public String getSheetName()
  {
    if (this.row == null) {
      return "";
    }
    Worksheet localWorksheet = ((Table)this.row.getTable()).getSheet();
    return localWorksheet == null ? null : localWorksheet.getWorksheetName();
  }
  
  public String getNormalSheetName()
  {
    if (this.row == null) {
      return "";
    }
    return ((Table)this.row.getTable()).getSheet().getNormalName();
  }
  
  public void clearData()
  {
    this.staticCell = true;
    this.data = null;
    this.value = null;
    this.richData = null;
  }
  
  public boolean hasNoData()
  {
    return (this.data == null) || (this.data.trim().length() <= 0);
  }
  
  public Worksheet getWorksheet()
  {
    return ((Table)getRow().getTable()).getSheet();
  }
  
  public boolean isInEditRange()
  {
    Range localRange = getWorksheet().getEditRange();
    if (localRange == null) {
      return false;
    }
    Cell localCell = getRealCell();
    return localRange.contains(localCell.getRowIndex() - 1, localCell.getIndex() - 1);
  }
  
  public String getEnum()
  {
    if (this.commentVars == null) {
      return null;
    }
    return (String)this.commentVars.get("enum");
  }
  
  public int getRowPos()
  {
    return getRowIndex() - 1;
  }
  
  public int getColPos()
  {
    return getIndex() - 1;
  }
  
  public boolean isBlank()
  {
    if (!this.staticCell) {
      return false;
    }
    return (this.richData == null) && ((this.data == null) || (this.data.trim().length() <= 0)) && (!hasBorder());
  }
  
  public boolean isEmptyData()
  {
    return StringUtils.strip(this.data) == null;
  }
  
  public boolean hasBorder()
  {
    Style localStyle = getStyle();
    return localStyle == null ? false : localStyle.hasBorder();
  }
  
  public double getFullWidth()
  {
    if (this.row == null) {
      return 0.0D;
    }
    return ((Table)this.row.getTable()).getFullWidth(getIndex() - 1, getColspan());
  }
  
  public Column getColumn()
  {
    if (this.row == null) {
      return null;
    }
    return ((Table)this.row.getTable()).getCol(getIndex() - 1);
  }
  
  public double getFullHeight()
  {
    if (this.row == null) {
      return 0.0D;
    }
    return ((Table)this.row.getTable()).getFullHeight(this.row.getIndex() - 1, getRowspan());
  }
  
  public double getDefaultRowHeight()
  {
    return ((Table)this.row.getTable()).getDefaultRowHeight();
  }
  
  public double getDefaultColumnWidth()
  {
    return ((Table)this.row.getTable()).getDefaultColumnWidth();
  }
  
  public String toWmlText(IExpressionReference paramIExpressionReference, Map<String, Object> paramMap)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    if (isStaticCell())
    {
      localStringBuilder.append(getStaticWmlCellStr());
    }
    else if (paramIExpressionReference != null)
    {
      String str = Coercions.toString(TplC.evaluate(paramIExpressionReference, paramMap), null);
      if (str != null) {
        localStringBuilder.append(str);
      }
    }
    return localStringBuilder.toString();
  }
  
  public String getStaticWmlCellStr()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    if ((this.richFormat) && (this.richData != null))
    {
      this.richData.toWml(localStringBuilder, getStyle());
    }
    else if ((this.data != null) && (this.data.length() > 0))
    {
      String str = StringUtilsEx.encodeXmlBr(this.data, "<w:br/>");
      localStringBuilder.append("<w:r>");
      localStringBuilder.append("<w:rPr>");
      Style localStyle = getStyle();
      if (localStyle != null) {
        localStringBuilder.append(localStyle.getWmlFontStyle());
      }
      localStringBuilder.append("</w:rPr>");
      localStringBuilder.append("<w:t>").append(str).append("</w:t></w:r>");
    }
    return localStringBuilder.toString();
  }
  
  public CellFormula getCellFormula()
  {
    return this.cellFormula;
  }
  
  public void setCellFormula(CellFormula paramCellFormula)
  {
    this.cellFormula = paramCellFormula;
  }
  
  public String getComment()
  {
    String str = ExcelModelUtils.buildComment(this.commentVars);
    return str;
  }
  
  public int getEndColIndex()
  {
    return getIndex() + getMergeAcross();
  }
  
  public int getEndRowIndex()
  {
    return getRowIndex() + getMergeDown();
  }
  
  public String getCellDef()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("<Cell");
    StringUtilsEx.attr(localStringBuilder, "ss:StyleID", getStyleID());
    StringUtilsEx.attr(localStringBuilder, "ss:Index", Integer.valueOf(this.index));
    if (this.mergeAcross > 0) {
      StringUtilsEx.attr(localStringBuilder, "ss:MergeAcross", Integer.valueOf(this.mergeAcross));
    }
    if (this.mergeDown > 0) {
      StringUtilsEx.attr(localStringBuilder, "ss:MergeDown", Integer.valueOf(this.mergeDown));
    }
    StringUtilsEx.attr(localStringBuilder, "ss:Formula", this.formula);
    String str1 = null;
    if ((this.richFormat) && (this.richData != null)) {
      str1 = StringUtilsEx.replaceBr(this.richData.getXml(), "&#10;");
    } else if ((this.data != null) && (this.data.length() > 0)) {
      str1 = getDataForXls(isNumberCell(), this.data);
    }
    String str2 = getComment();
    if ((str1 == null) && (str2 == null))
    {
      localStringBuilder.append("/>");
    }
    else
    {
      localStringBuilder.append(">");
      if (str1 != null) {
        localStringBuilder.append(str1);
      }
      if (str2 != null) {
        localStringBuilder.append("<Comment><Data>").append(StringUtilsEx.encodeXmlBr(str2, "&#10;")).append("</Data></Comment>");
      }
      localStringBuilder.append("</Cell>");
    }
    return localStringBuilder.toString();
  }
  
  public String toXlsCell(IExpressionReference paramIExpressionReference, Map<String, Object> paramMap)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("<Cell");
    StringUtilsEx.attr(localStringBuilder, "ss:StyleID", getStyleID());
    StringUtilsEx.attr(localStringBuilder, "ss:Index", Integer.valueOf(this.index));
    if (this.mergeAcross > 0) {
      StringUtilsEx.attr(localStringBuilder, "ss:MergeAcross", Integer.valueOf(this.mergeAcross));
    }
    if (this.mergeDown > 0) {
      StringUtilsEx.attr(localStringBuilder, "ss:MergeDown", Integer.valueOf(this.mergeDown));
    }
    String str = null;
    if (isStaticCell())
    {
      str = getStaticXlsCellStr();
    }
    else if (paramIExpressionReference != null)
    {
      localObject = TplC.evaluate(paramIExpressionReference, paramMap);
      if (localObject != null) {
        str = localObject.toString();
      }
    }
    Object localObject = evaluateComment(paramMap);
    if ((str == null) && (localObject == null))
    {
      localStringBuilder.append("/>");
    }
    else
    {
      localStringBuilder.append(">");
      if (str != null) {
        localStringBuilder.append(str);
      }
      if (localObject != null)
      {
        localStringBuilder.append("<Comment><Data>");
        localStringBuilder.append(StringUtilsEx.encodeXmlBr((String)localObject, "&#10;"));
        localStringBuilder.append("</Data></Comment>");
      }
      localStringBuilder.append("</Cell>");
    }
    return localStringBuilder.toString();
  }
  
  public String getStaticXlsCellStr()
  {
    String str = null;
    if ((this.richFormat) && (this.richData != null)) {
      str = this.richData.getXml();
    } else if ((this.data != null) && (this.data.length() > 0)) {
      str = getDataForXls(isNumberCell(), this.data);
    }
    return str;
  }
  
  public String getDataForXls(Object paramObject)
  {
    return getDataForXls(maybeNumberCell(), paramObject);
  }
  
  public static String getDataForXls(boolean paramBoolean, Object paramObject)
  {
    if (paramObject == null) {
      return null;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("<Data");
    paramBoolean = (paramBoolean) && ((paramObject instanceof Number));
    StringUtilsEx.attr(localStringBuilder, "ss:Type", paramBoolean ? "Number" : "String");
    localStringBuilder.append(">");
    if (paramBoolean)
    {
      localStringBuilder.append(paramObject);
    }
    else
    {
      String str = StringUtilsEx.encodeXmlBr(paramObject.toString(), "&#10;");
      localStringBuilder.append(str);
    }
    localStringBuilder.append("</Data>");
    return localStringBuilder.toString();
  }
  
  public boolean isNumberCell()
  {
    return "Number".equals(this.dataType);
  }
  
  public boolean maybeNumberCell()
  {
    if ((this.fieldDefinition != null) && (this.fieldDefinition.getType() != null)) {
      return this.fieldDefinition.isNumberType(null);
    }
    return (this.dataType == null) || (isNumberCell());
  }
  
  public String getHtml()
  {
    if ((this.richFormat) && (this.richData != null)) {
      return this.richData.getHtml();
    }
    return StringUtilsEx.encodeHtmlText(this.data);
  }
  
  public Cell getRealCell()
  {
    return this;
  }
  
  public boolean isExpandHor()
  {
    return (this.expandModel != null) && (this.expandModel.isExpandHor());
  }
  
  public boolean isExpandVer()
  {
    return (this.expandModel != null) && (this.expandModel.isExpandVer());
  }
  
  public boolean isAtMergeTopLeft()
  {
    return (isAtMergeTop()) && (isAtMergeLeft());
  }
  
  public boolean isAtMergeTopRight()
  {
    return (isAtMergeTop()) && (isAtMergeRight());
  }
  
  public boolean isAtMergeBottomLeft()
  {
    return (isAtMergeBottom()) && (isAtMergeLeft());
  }
  
  public boolean isAtMergeBottomRight()
  {
    return (isAtMergeBottom()) && (isAtMergeRight());
  }
  
  public boolean isAtMergeLeft()
  {
    return getRealCell().getIndex() == getIndex();
  }
  
  public boolean isAtMergeRight()
  {
    return getRealCell().getIndex() + getRealCell().getMergeAcross() == getIndex();
  }
  
  public boolean isAtMergeTop()
  {
    return getRealCell().getRowIndex() == getRow().getIndex();
  }
  
  public boolean isAtMergeBottom()
  {
    return getRealCell().getRowIndex() + getRealCell().getMergeDown() == getRow().getIndex();
  }
  
  public Cell getUp()
  {
    Row localRow = this.row.getPrev();
    return localRow == null ? null : localRow.getCell(this.index - 1);
  }
  
  public Cell getDown()
  {
    Row localRow = this.row.getNext();
    return localRow == null ? null : localRow.getCell(this.index - 1);
  }
  
  public Cell getLeft()
  {
    return this.row.getCell(this.index - 2);
  }
  
  public Cell getRight()
  {
    return this.row.getCell(this.index);
  }
  
  public Cell getLeftReal()
  {
    Cell localCell = getLeft();
    if (localCell == null) {
      return null;
    }
    return localCell.getRealCell();
  }
  
  public Cell getRightReal()
  {
    Cell localCell = getRight();
    if (localCell == null) {
      return null;
    }
    return localCell.getRealCell();
  }
  
  public Cell getUpReal()
  {
    Cell localCell = getUp();
    return localCell == null ? null : localCell.getRealCell();
  }
  
  public Cell getDownReal()
  {
    Cell localCell = getDown();
    return localCell == null ? null : localCell.getRealCell();
  }
  
  public Cell getPrevRealInRow()
  {
    for (Cell localCell = getLeft(); (localCell != null) && (localCell.isIgnored()); localCell = localCell.getLeft()) {}
    return localCell;
  }
  
  public Cell getNextRealInRow()
  {
    for (Cell localCell = getRight(); (localCell != null) && (localCell.isIgnored()); localCell = localCell.getRight()) {}
    return localCell;
  }
  
  public String getHref()
  {
    return this.href;
  }
  
  public void setHref(String paramString)
  {
    this.href = paramString;
  }
  
  public IExpressionReference getVisibleExpr()
  {
    return this.visibleExpr;
  }
  
  public void setVisibleExpr(IExpressionReference paramIExpressionReference)
  {
    this.visibleExpr = paramIExpressionReference;
  }
  
  public IExpressionReference getReadOnlyExpr()
  {
    return this.readOnlyExpr;
  }
  
  public void setReadOnlyExpr(IExpressionReference paramIExpressionReference)
  {
    this.readOnlyExpr = paramIExpressionReference;
  }
  
  public Object getRowVisibleExpr()
  {
    return this.rowVisibleExpr;
  }
  
  public void setRowVisibleExpr(IExpressionReference paramIExpressionReference)
  {
    this.rowVisibleExpr = paramIExpressionReference;
  }
  
  public IExpressionReference getCommentExpr()
  {
    return this.commentExpr;
  }
  
  public void setCommentExpr(IExpressionReference paramIExpressionReference)
  {
    this.commentExpr = paramIExpressionReference;
  }
  
  public String getKey()
  {
    return null;
  }
  
  public String evaluateKey(Map<String, Object> paramMap)
  {
    if (this.keyExpr == null) {
      return null;
    }
    paramMap.put("_cell", this);
    return Coercions.toString(TplC.evaluate(this.keyExpr, paramMap), null);
  }
  
  public String evaluateComment(Map<String, Object> paramMap)
  {
    if (this.commentExpr == null) {
      return null;
    }
    paramMap.put("_cell", this);
    return Coercions.toString(TplC.evaluate(this.commentExpr, paramMap), null);
  }
  
  public boolean evaluateVisible(Map<String, Object> paramMap)
  {
    if (this.visibleExpr == null) {
      return true;
    }
    paramMap.put("_cell", this);
    return Coercions.toBoolean(TplC.evaluate(this.visibleExpr, paramMap), true);
  }
  
  public boolean evaluateReadOnly(Map<String, Object> paramMap)
  {
    if (this.readOnlyExpr == null) {
      return false;
    }
    paramMap.put("_cell", this);
    return Coercions.toBoolean(TplC.evaluate(this.commentExpr, paramMap), false);
  }
  
  public boolean evaluateRowVisible(Map<String, Object> paramMap)
  {
    if (this.rowVisibleExpr == null) {
      return true;
    }
    paramMap.put("_cell", this);
    return Coercions.toBoolean(TplC.evaluate(this.rowVisibleExpr, paramMap), true);
  }
  
  public void evaluatePrepareRow(Map<String, Object> paramMap)
  {
    if (this.prepareRowExpr == null) {
      return;
    }
    paramMap.put("_cell", this);
    TplC.evaluate(this.prepareRowExpr, paramMap);
  }
  
  public String buildLink(Map<String, Object> paramMap)
  {
    if (this.linkExpr == null) {
      return null;
    }
    paramMap.put("_cell", this);
    return Coercions.toString(TplC.evaluate(this.linkExpr, paramMap), null);
  }
  
  public IExpressionReference getFormatExpr()
  {
    return this.formatExpr;
  }
  
  public void setFormatExpr(IExpressionReference paramIExpressionReference)
  {
    this.formatExpr = paramIExpressionReference;
  }
  
  public Object formatValue(Object paramObject, Map<String, Object> paramMap)
  {
    IExpressionReference localIExpressionReference = getFormatExpr();
    if (localIExpressionReference == null)
    {
      if (paramObject == null) {
        return null;
      }
      Style localStyle = getStyle();
      if (localStyle != null) {
        paramObject = localStyle.format(paramObject);
      }
      return paramObject;
    }
    paramMap.put("value", paramObject);
    paramMap.put("_cell", this);
    return TplC.evaluate(localIExpressionReference, paramMap);
  }
  
  public Object getFormatedValue(Map<String, Object> paramMap)
  {
    Object localObject = evaluate(paramMap);
    return formatValue(localObject, paramMap);
  }
  
  public Object directFormatValue(Object paramObject, Map<String, Object> paramMap)
  {
    IExpressionReference localIExpressionReference = getFormatExpr();
    if (localIExpressionReference == null) {
      return paramObject;
    }
    paramMap.put("value", paramObject);
    paramMap.put("_cell", this);
    return TplC.evaluate(localIExpressionReference, paramMap);
  }
  
  public Object getDirectFormatedValue(Map<String, Object> paramMap)
  {
    Object localObject = evaluate(paramMap);
    return directFormatValue(localObject, paramMap);
  }
  
  public RichData getRichData()
  {
    return this.richData;
  }
  
  public void setRichData(RichData paramRichData)
  {
    this.richData = paramRichData;
  }
  
  public boolean isStaticCell()
  {
    return this.staticCell;
  }
  
  public void setStaticCell(boolean paramBoolean)
  {
    this.staticCell = paramBoolean;
  }
  
  public boolean isRichFormat()
  {
    return this.richFormat;
  }
  
  public void setRichFormat(boolean paramBoolean)
  {
    this.richFormat = paramBoolean;
  }
  
  public IExpressionReference getExpandExpr()
  {
    return this.expandModel == null ? null : this.expandModel.getExpandExpr();
  }
  
  public int getExpandType()
  {
    return this.expandModel == null ? 0 : this.expandModel.getExpandType();
  }
  
  public String getExpandOrderField()
  {
    return this.expandModel == null ? null : this.expandModel.getExpandOrderField();
  }
  
  public boolean isNeedExpand()
  {
    int i = getExpandType();
    return (i == 1) || (i == 2) || (i == 8599) || (i == 8600);
  }
  
  public int getRowIndex()
  {
    return this.row == null ? 1 : this.row.getIndex();
  }
  
  public Row getRow()
  {
    return this.row;
  }
  
  public void setRow(Row paramRow)
  {
    this.row = paramRow;
  }
  
  public int getMergeStatus()
  {
    return this.mergeStatus;
  }
  
  public void setMergeStatus(int paramInt)
  {
    this.mergeStatus = paramInt;
  }
  
  public Object getXlsObj()
  {
    return this.xlsObj;
  }
  
  public void setXlsObj(Object paramObject)
  {
    this.xlsObj = paramObject;
  }
  
  public static Cell makeEmptyCell()
  {
    Cell localCell = new Cell();
    localCell.setStaticCell(true);
    return localCell;
  }
  
  public boolean isBoolHidden()
  {
    return this.hidden;
  }
  
  public String getDisplay()
  {
    return null;
  }
  
  public boolean isHidden()
  {
    return this.hidden;
  }
  
  public void setHidden(boolean paramBoolean)
  {
    this.hidden = paramBoolean;
  }
  
  public Object getValue()
  {
    return this.value;
  }
  
  public void setValue(Object paramObject)
  {
    this.value = paramObject;
  }
  
  public int getRowspan()
  {
    return this.mergeDown + 1;
  }
  
  public int getColspan()
  {
    return this.mergeAcross + 1;
  }
  
  public IExpressionReference getValueExpr()
  {
    return this.valueExpr;
  }
  
  public void setValueExpr(IExpressionReference paramIExpressionReference)
  {
    this.valueExpr = paramIExpressionReference;
  }
  
  public boolean isIgnored()
  {
    return this.ignored;
  }
  
  public void setIgnored(boolean paramBoolean)
  {
    this.ignored = paramBoolean;
  }
  
  public Map<String, Object> getCommentVars()
  {
    return this.commentVars;
  }
  
  public void setCommentVars(Map<String, Object> paramMap)
  {
    this.commentVars = paramMap;
  }
  
  public void setCommentVar(String paramString, Object paramObject)
  {
    if (this.commentVars == null) {
      this.commentVars = new HashMap();
    }
    this.commentVars.put(paramString, paramObject);
  }
  
  public void removeCommentVar(String paramString)
  {
    if (this.commentVars != null) {
      this.commentVars.remove(paramString);
    }
  }
  
  public void setComment(String paramString)
  {
    if (this.commentVars != null) {
      this.commentVars = null;
    }
    this.commentVars = ExcelModelUtils.parseCommentStr(paramString);
  }
  
  public void setIndex(int paramInt)
  {
    this.index = paramInt;
  }
  
  public int getIndex()
  {
    return this.index;
  }
  
  public void setMergeAcross(int paramInt)
  {
    this.mergeAcross = paramInt;
  }
  
  public int getMergeAcross()
  {
    return this.mergeAcross;
  }
  
  public void setMergeDown(int paramInt)
  {
    this.mergeDown = paramInt;
  }
  
  public int getMergeDown()
  {
    return this.mergeDown;
  }
  
  public void setStyle(Style paramStyle)
  {
    this.style = paramStyle;
  }
  
  public String getStyleID()
  {
    return this.style == null ? null : this.style.getId();
  }
  
  public String getCssClassName()
  {
    return this.cssClassName;
  }
  
  public String getClassName(String paramString)
  {
    String str = this.style == null ? null : this.style.getCssClassName(paramString);
    if (this.cssClassName != null) {
      str = str + " " + this.cssClassName;
    }
    return str;
  }
  
  public void setFormula(String paramString)
  {
    this.formula = paramString;
  }
  
  public String getFormula()
  {
    return this.formula;
  }
  
  public String getPackedData()
  {
    if (this.data == null) {
      return null;
    }
    String str = this.data;
    str = StringUtils.replace(str, "\r", "");
    str = StringUtils.replace(str, "\n", "");
    str = StringUtils.replace(str, "\t", "");
    str = StringUtils.replace(str, " ", "");
    str = StringUtils.replace(str, "　", "");
    return StringUtils.strip(str);
  }
  
  public String getData()
  {
    return this.data;
  }
  
  public void setData(String paramString)
  {
    this.data = paramString;
  }
  
  public String getDataType()
  {
    return this.dataType;
  }
  
  public void setDataType(String paramString)
  {
    this.dataType = paramString;
  }
  
  public Style getStyle()
  {
    return this.style;
  }
  
  public IExpressionReference getLinkExpr()
  {
    return this.linkExpr;
  }
  
  public void setLinkExpr(IExpressionReference paramIExpressionReference)
  {
    this.linkExpr = paramIExpressionReference;
  }
  
  public Object evaluate(Map<String, Object> paramMap)
  {
    Object localObject1 = null;
    if (this.fieldDefinition != null)
    {
      Object localObject2 = null;
      Object localObject3 = TplC.getToken(paramMap, "entity");
      if (localObject3 != null)
      {
        localObject2 = TplC.getProperty(localObject3, this.fieldDefinition.getName());
        String str = this.fieldDefinition.getExtIndex();
        if (":value".equals(str)) {
          str = (String)getValue();
        }
        if (str != null) {
          localObject2 = TplC.getProperty(localObject2, str);
        }
      }
      localObject1 = localObject2;
    }
    else if (this.valueExpr != null)
    {
      paramMap.put("_cell", this);
      localObject1 = TplC.evaluate(this.valueExpr, paramMap);
    }
    if (localObject1 == null) {
      localObject1 = evaluateDefaultValue(paramMap);
    }
    return localObject1;
  }
  
  public Object evaluateDefaultValue(Map<String, Object> paramMap)
  {
    if (this.defaultValueExpr != null)
    {
      paramMap.put("_cell", this);
      return TplC.evaluate(this.defaultValueExpr, paramMap);
    }
    return null;
  }
  
  public String getValueExprStr()
  {
    if (this.commentVars == null) {
      return this.data;
    }
    String str = (String)this.commentVars.get("valueExpr");
    if (str != null) {
      return "${" + str + "}";
    }
    return this.data;
  }
  
  public String getLinkExprStr()
  {
    if (this.commentVars == null) {
      return null;
    }
    String str = (String)this.commentVars.get("linkExpr");
    if (str != null) {
      return "${" + str + "}";
    }
    return null;
  }
  
  public void initForXpt(TplC paramTplC)
  {
    this.expandModel = new CellExpandModel(this);
    if (this.commentVars != null)
    {
      IServiceContext localIServiceContext = SystemServiceContext.getInstance();
      String str1 = (String)this.commentVars.get("styleExpr");
      IExpressionReference localIExpressionReference1 = paramTplC.parseEvalExpr(str1, localIServiceContext);
      String str2 = (String)this.commentVars.get("viewer");
      String str3 = (String)this.commentVars.get("inputor");
      String str4 = (String)this.commentVars.get("expandExpr");
      IExpressionReference localIExpressionReference2 = paramTplC.parseEvalExpr(str4, localIServiceContext);
      String str5 = (String)this.commentVars.get("expandType");
      String str6 = (String)this.commentVars.get("expandOrderField");
      IExpressionReference localIExpressionReference3 = paramTplC.parseEvalExpr((String)this.commentVars.get("testExpr"), localIServiceContext);
      int i = (ExcelModelConstants.EXPAND_TYPES.indexOf(str5) + 1) % 4;
      setStyleExpr(localIExpressionReference1);
      this.viewerId = str2;
      this.inputorId = str3;
      if (i != 0)
      {
        this.expandModel.setExpandExpr(localIExpressionReference2);
        this.expandModel.setExpandType(i);
        this.expandModel.setExpandOrderField(str6);
      }
      this.expandModel.setTestExpr(localIExpressionReference3);
      List localList1 = Variant.valueOf(this.commentVars.get("horDimFields")).listValue();
      List localList2 = Variant.valueOf(this.commentVars.get("verDimFields")).listValue();
      this.expandModel.setHorDimFields(localList1);
      this.expandModel.setVerDimFields(localList2);
      String str7 = (String)this.commentVars.get("field");
      String str8 = (String)this.commentVars.get("ds");
      String str9 = (String)this.commentVars.get("textField");
      this.expandModel.setField(str7);
      this.expandModel.setDsName(str8);
      this.expandModel.setTextField(str9);
      if (str9 != null) {
        Debug.traceErr("excel.CAN_err_textField_is_deprecated::" + this);
      }
    }
  }
  
  public void initRichFormat(TreeNode paramTreeNode)
  {
    TreeNode localTreeNode = paramTreeNode.existingChild("ss:Data");
    this.richFormat = (localTreeNode != null);
    if ((this.staticCell) && (this.richFormat)) {
      this.richData = new RichData(localTreeNode);
    }
  }
  
  public void initStatic()
  {
    this.staticCell = (this.fieldDefinition == null);
    if ((this.commentVars != null) && (this.commentVars.containsKey("valueExpr"))) {
      this.staticCell = false;
    }
    if ((this.data != null) && (this.data.contains("${"))) {
      this.staticCell = false;
    }
    this.noValueExpr = this.staticCell;
  }
  
  public FieldDefinition getFieldDefinition()
  {
    return this.fieldDefinition;
  }
  
  public void setFieldDefinition(FieldDefinition paramFieldDefinition)
  {
    this.fieldDefinition = paramFieldDefinition;
  }
  
  public String getCommentStr(String paramString)
  {
    return StringUtils.strip(Coercions.toString(this.commentVars == null ? null : this.commentVars.get(paramString), null));
  }
  
  public Integer getSectionStyle()
  {
    String str = getCommentStr("h");
    return str == null ? null : Integer.valueOf(Coercions.toInt(str, 1));
  }
  
  public Integer getOutlineLevel()
  {
    Integer localInteger = getSectionStyle();
    if (localInteger == null) {
      return null;
    }
    int i = localInteger.intValue() - 1;
    if (i < 0) {
      i = 0;
    }
    return Integer.valueOf(i);
  }
  
  public void initExpandModel()
  {
    _checkAllowExpand();
  }
  
  void _checkAllowExpand()
  {
    if (this.expandModel == null) {
      this.expandModel = new CellExpandModel(this);
    }
  }
  
  public CellExpandModel getExpandModel()
  {
    return this.expandModel;
  }
  
  public Cell getHorParent()
  {
    return this.expandModel == null ? null : this.expandModel.getHorParent();
  }
  
  public void setHorParent(Cell paramCell)
  {
    _checkAllowExpand();
    this.expandModel.setHorParent(paramCell);
  }
  
  public List<Cell> getHorChildren()
  {
    return this.expandModel == null ? null : this.expandModel.getHorChildren();
  }
  
  public void setHorChildren(List<Cell> paramList)
  {
    _checkAllowExpand();
    this.expandModel.setHorChildren(paramList);
  }
  
  public List<Cell> getVerChildren()
  {
    return this.expandModel == null ? null : this.expandModel.getVerChildren();
  }
  
  public void setVerChildren(List<Cell> paramList)
  {
    _checkAllowExpand();
    this.expandModel.setVerChildren(paramList);
  }
  
  public Cell getVerParent()
  {
    return this.expandModel == null ? null : this.expandModel.getVerParent();
  }
  
  public void setVerParent(Cell paramCell)
  {
    _checkAllowExpand();
    this.expandModel.setVerParent(paramCell);
  }
  
  public void addHorChild(Cell paramCell)
  {
    _checkAllowExpand();
    this.expandModel.addHorChild(paramCell);
  }
  
  public void addVerChild(Cell paramCell)
  {
    _checkAllowExpand();
    this.expandModel.addVerChild(paramCell);
  }
  
  public void initHorBandModel()
  {
    if (this.expandModel != null) {
      this.expandModel.initHorBandModel(0);
    }
  }
  
  public void initVerBandModel()
  {
    if (this.expandModel != null) {
      this.expandModel.initVerBandModel(0);
    }
  }
  
  public void calcExpandHorRange()
  {
    if (this.expandModel != null) {
      this.expandModel.calcExpandHorRange();
    }
  }
  
  public void calcExpandVerRange()
  {
    if (this.expandModel != null) {
      this.expandModel.calcExpandVerRange();
    }
  }
  
  public int getMinExpandHorIndex()
  {
    if (this.expandModel == null) {
      return getRowIndex();
    }
    return this.expandModel.getMinExpandHorIndex();
  }
  
  public int getMaxExpandHorIndex()
  {
    if (this.expandModel == null) {
      return getRowIndex() + getMergeDown();
    }
    return this.expandModel.getMaxExpandHorIndex();
  }
  
  public int getMinExpandVerIndex()
  {
    if (this.expandModel == null) {
      return getIndex();
    }
    return this.expandModel.getMinExpandVerIndex();
  }
  
  public int getMaxExpandVerIndex()
  {
    if (this.expandModel == null) {
      return getIndex() + getMergeAcross();
    }
    return this.expandModel.getMaxExpandVerIndex();
  }
  
  public boolean isWithinHorRangeOf(Cell paramCell)
  {
    paramCell = paramCell.getRealCell();
    int i = getRowIndex();
    return (i >= paramCell.getMinExpandHorIndex()) && (i + getMergeDown() <= paramCell.getMaxExpandHorIndex());
  }
  
  public boolean isWithinVerRangeOf(Cell paramCell)
  {
    paramCell = paramCell.getRealCell();
    int i = getIndex();
    return (i >= paramCell.getMinExpandVerIndex()) && (i + getMergeAcross() <= paramCell.getMaxExpandVerIndex());
  }
  
  public int getHorIntersectType(Cell paramCell)
  {
    int i = getMinExpandHorIndex();
    int j = getMaxExpandHorIndex();
    int k = paramCell.getMinExpandHorIndex();
    int m = paramCell.getMaxExpandHorIndex();
    if ((j < k) || (i > m)) {
      return 1;
    }
    if ((i == k) && (j == m)) {
      return 3;
    }
    if ((i >= k) && (j <= m)) {
      return 4;
    }
    if ((i <= k) && (j >= m)) {
      return 5;
    }
    return 2;
  }
  
  public int getVerIntersectType(Cell paramCell)
  {
    int i = getMinExpandVerIndex();
    int j = getMaxExpandVerIndex();
    int k = paramCell.getMinExpandVerIndex();
    int m = paramCell.getMaxExpandVerIndex();
    if ((j < k) || (i > m)) {
      return 1;
    }
    if ((i == k) && (j == m)) {
      return 3;
    }
    if ((i >= k) && (j <= m)) {
      return 4;
    }
    if ((i <= k) && (j >= m)) {
      return 5;
    }
    return 2;
  }
  
  public boolean isHorSubOf(Cell paramCell)
  {
    Cell localCell = getHorParent();
    if (localCell == null) {
      return false;
    }
    if (localCell.getRealCell() == paramCell.getRealCell()) {
      return true;
    }
    return localCell.isHorSubOf(paramCell);
  }
  
  public boolean isVerSubOf(Cell paramCell)
  {
    Cell localCell = getVerParent();
    if (localCell == null) {
      return false;
    }
    if (localCell.getRealCell() == paramCell.getRealCell()) {
      return true;
    }
    return localCell.isVerSubOf(paramCell);
  }
  
  public int getHorExpandRange()
  {
    int i = getMinExpandHorIndex();
    int j = getMaxExpandHorIndex();
    return j - i + 1;
  }
  
  public int getVerExpandRange()
  {
    int i = getMinExpandVerIndex();
    int j = getMaxExpandVerIndex();
    return j - i + 1;
  }
  
  public int getHorOffsetInRange()
  {
    return getRowIndex() - getMinExpandHorIndex();
  }
  
  public int getVerOffsetInRange()
  {
    return getIndex() - getMinExpandVerIndex();
  }
  
  public boolean hasNoChildCell()
  {
    return (this.expandModel == null) || (this.expandModel.hasNoChildCell());
  }
  
  public String getAssignedHorParent()
  {
    return getCommentStr("horParent");
  }
  
  public String getAssignedVerParent()
  {
    return getCommentStr("verParent");
  }
  
  public Cell findDefaultHorParent()
  {
    Cell localCell;
    for (Object localObject = this;; localObject = localCell)
    {
      localCell = ((Cell)localObject).getLeft();
      if (localCell == null) {
        return null;
      }
      if (localCell.isExpandVer()) {
        return localCell;
      }
      if ((localCell.getHorParent() != null) && (localCell.getAssignedHorParent() != null)) {
        return localCell;
      }
    }
  }
  
  public Cell findDefaultVerParent()
  {
    Cell localCell;
    for (Object localObject = this;; localObject = localCell)
    {
      localCell = ((Cell)localObject).getUp();
      if (localCell == null) {
        return null;
      }
      if (localCell.isExpandHor()) {
        return localCell;
      }
      if ((localCell.getVerParent() != null) && (localCell.getAssignedVerParent() != null)) {
        return localCell;
      }
    }
  }
  
  public boolean hasHorChild()
  {
    List localList = getHorChildren();
    return (localList != null) && (localList.size() > 0);
  }
  
  public boolean hasVerChild()
  {
    List localList = getVerChildren();
    return (localList != null) && (localList.size() > 0);
  }
  
  public boolean isNoValueExpr()
  {
    return this.noValueExpr;
  }
  
  public String getViewerId()
  {
    return this.viewerId;
  }
  
  public void setViewerId(String paramString)
  {
    this.viewerId = paramString;
  }
  
  public String getInputorId()
  {
    return this.inputorId;
  }
  
  public void setInputorId(String paramString)
  {
    this.inputorId = paramString;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\Cell.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */