package edu.thu.ext.excel.model;

import java.io.Serializable;

public class CellOffsetPosition
  implements Serializable
{
  private static final long serialVersionUID = -8504951495478489110L;
  CellPosition C;
  boolean A;
  int B;
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(this.C);
    localStringBuilder.append(':');
    if ((this.A) && (this.B > 0)) {
      localStringBuilder.append('+');
    }
    localStringBuilder.append(this.B);
    return localStringBuilder.toString();
  }
  
  public int getOffset()
  {
    return this.B;
  }
  
  public void setOffset(int paramInt)
  {
    this.B = paramInt;
  }
  
  public CellPosition getPos()
  {
    return this.C;
  }
  
  public void setPos(CellPosition paramCellPosition)
  {
    this.C = paramCellPosition;
  }
  
  public boolean isRelative()
  {
    return this.A;
  }
  
  public void setRelative(boolean paramBoolean)
  {
    this.A = paramBoolean;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\CellOffsetPosition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */