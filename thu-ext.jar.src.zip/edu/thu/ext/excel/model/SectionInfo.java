package edu.thu.ext.excel.model;

import java.io.Serializable;

public class SectionInfo
  implements Serializable
{
  private static final long serialVersionUID = -8954037156430571598L;
  String B;
  int A;
  
  public SectionInfo() {}
  
  public SectionInfo(int paramInt, String paramString)
  {
    this.A = paramInt;
    this.B = paramString;
  }
  
  public int getStyle()
  {
    return this.A;
  }
  
  public void setStyle(int paramInt)
  {
    this.A = paramInt;
  }
  
  public String getText()
  {
    return this.B;
  }
  
  public void setText(String paramString)
  {
    this.B = paramString;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\SectionInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */