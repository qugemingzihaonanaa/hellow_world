package edu.thu.ext.excel.model;

import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.util.Coercions;
import edu.thu.lang.util.ITplReference;
import edu.thu.lang.util.TplC;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.SystemServiceContext;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class AbstractWorkbook<T extends IWorksheet>
  implements Serializable, IWorkbook
{
  private static final long serialVersionUID = -7179161673379394448L;
  protected List<T> sheets = new ArrayList();
  
  public int getSheetCount()
  {
    return this.sheets.size();
  }
  
  public T getSheet(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= this.sheets.size())) {
      return null;
    }
    return (IWorksheet)this.sheets.get(paramInt);
  }
  
  public int getSheetIndex(String paramString)
  {
    int j = this.sheets.size();
    for (int i = 0; i < j; i++)
    {
      IWorksheet localIWorksheet = (IWorksheet)this.sheets.get(i);
      if (localIWorksheet.getWorksheetName().equals(paramString)) {
        return i;
      }
    }
    return -1;
  }
  
  public boolean hasSheet(String paramString)
  {
    return getSheetIndex(paramString) >= 0;
  }
  
  public T getSheetByName(String paramString)
  {
    int i = getSheetIndex(paramString);
    if (i < 0) {
      return null;
    }
    return (IWorksheet)this.sheets.get(i);
  }
  
  public List<T> getSheets()
  {
    return this.sheets;
  }
  
  public void setSheets(List<T> paramList)
  {
    this.sheets = paramList;
  }
  
  public List<T> getWorksheets()
  {
    return this.sheets;
  }
  
  public void setWorksheets(List<T> paramList)
  {
    this.sheets = paramList;
  }
  
  public void addSheet(T paramT)
  {
    this.sheets.add(paramT);
  }
  
  public T removeSheetByName(String paramString)
  {
    IWorksheet localIWorksheet = getSheetByName(paramString);
    if (localIWorksheet == null) {
      return null;
    }
    this.sheets.remove(localIWorksheet);
    return localIWorksheet;
  }
  
  public String getNewSheetName(String paramString)
  {
    if (paramString == null) {
      paramString = "Sheet";
    }
    String str1 = paramString;
    String str2 = paramString;
    int i = 1;
    int j = paramString.indexOf('(');
    if (j >= 0)
    {
      str1 = paramString.substring(0, j);
      k = paramString.indexOf(')', j);
      if (k > 0)
      {
        int m = Coercions.toInt(paramString.substring(j + 1, k), 0);
        i = m + 1;
      }
    }
    int k = _getLastSeq(str1);
    if (k >= 0)
    {
      i = k + 1;
      str2 = str1 + "(" + i + ")";
    }
    while (hasSheet(str2))
    {
      str2 = str1 + "(" + i + ")";
      i++;
    }
    return str2;
  }
  
  int _getLastSeq(String paramString)
  {
    int i = -1;
    if (this.sheets.size() > 0)
    {
      IWorksheet localIWorksheet = (IWorksheet)this.sheets.get(this.sheets.size() - 1);
      String str = localIWorksheet.getWorksheetName();
      int j = str.indexOf('(');
      if ((j >= 0) && (paramString.equals(str.substring(0, j))))
      {
        int k = str.indexOf(')', j);
        if (k > 0) {
          i = Coercions.toInt(str.substring(j + 1, k), 0);
        }
      }
    }
    return i;
  }
  
  /* Error */
  public void saveToResource(edu.thu.core.IResource paramIResource)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_1
    //   3: invokeinterface 158 1 0
    //   8: astore_2
    //   9: aload_0
    //   10: aload_2
    //   11: invokevirtual 164	edu/thu/ext/excel/model/AbstractWorkbook:saveToStream	(Ljava/io/OutputStream;)V
    //   14: goto +18 -> 32
    //   17: astore_3
    //   18: aload_3
    //   19: invokestatic 168	edu/thu/global/exceptions/Exceptions:source	(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;
    //   22: athrow
    //   23: astore 4
    //   25: aload_2
    //   26: invokestatic 174	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/OutputStream;)V
    //   29: aload 4
    //   31: athrow
    //   32: aload_2
    //   33: invokestatic 174	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/OutputStream;)V
    //   36: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	37	0	this	AbstractWorkbook
    //   0	37	1	paramIResource	edu.thu.core.IResource
    //   1	32	2	localOutputStream	OutputStream
    //   17	2	3	localException	Exception
    //   23	7	4	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   2	14	17	java/lang/Exception
    //   2	23	23	finally
  }
  
  public void saveToStream(OutputStream paramOutputStream)
  {
    try
    {
      saveToWriter(new OutputStreamWriter(paramOutputStream, "UTF-8"), "UTF-8");
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  /* Error */
  public void saveToVFile(edu.thu.vfs.IFile paramIFile)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_1
    //   3: invokeinterface 205 1 0
    //   8: invokeinterface 211 1 0
    //   13: pop
    //   14: aload_1
    //   15: invokeinterface 215 1 0
    //   20: astore_2
    //   21: aload_0
    //   22: aload_2
    //   23: invokevirtual 164	edu/thu/ext/excel/model/AbstractWorkbook:saveToStream	(Ljava/io/OutputStream;)V
    //   26: goto +18 -> 44
    //   29: astore_3
    //   30: aload_3
    //   31: invokestatic 168	edu/thu/global/exceptions/Exceptions:source	(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;
    //   34: athrow
    //   35: astore 4
    //   37: aload_2
    //   38: invokestatic 174	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/OutputStream;)V
    //   41: aload 4
    //   43: athrow
    //   44: aload_2
    //   45: invokestatic 174	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/OutputStream;)V
    //   48: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	49	0	this	AbstractWorkbook
    //   0	49	1	paramIFile	edu.thu.vfs.IFile
    //   1	44	2	localOutputStream	OutputStream
    //   29	2	3	localException	Exception
    //   35	7	4	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   2	26	29	java/lang/Exception
    //   2	35	35	finally
  }
  
  /* Error */
  public void saveToFile(java.io.File paramFile)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_1
    //   3: invokevirtual 220	java/io/File:getParentFile	()Ljava/io/File;
    //   6: invokevirtual 226	java/io/File:mkdirs	()Z
    //   9: pop
    //   10: new 227	java/io/FileOutputStream
    //   13: dup
    //   14: aload_1
    //   15: invokespecial 229	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   18: astore_2
    //   19: aload_0
    //   20: aload_2
    //   21: invokevirtual 164	edu/thu/ext/excel/model/AbstractWorkbook:saveToStream	(Ljava/io/OutputStream;)V
    //   24: goto +18 -> 42
    //   27: astore_3
    //   28: aload_3
    //   29: invokestatic 168	edu/thu/global/exceptions/Exceptions:source	(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;
    //   32: athrow
    //   33: astore 4
    //   35: aload_2
    //   36: invokestatic 174	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/OutputStream;)V
    //   39: aload 4
    //   41: athrow
    //   42: aload_2
    //   43: invokestatic 174	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/OutputStream;)V
    //   46: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	47	0	this	AbstractWorkbook
    //   0	47	1	paramFile	java.io.File
    //   1	42	2	localFileOutputStream	java.io.FileOutputStream
    //   27	2	3	localException	Exception
    //   33	7	4	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   2	24	27	java/lang/Exception
    //   2	33	33	finally
  }
  
  public String toXml()
  {
    StringWriter localStringWriter = new StringWriter();
    saveToWriter(localStringWriter, "UTF-8");
    return localStringWriter.toString();
  }
  
  public void saveToWriter(Writer paramWriter, String paramString)
  {
    s_saveToWriter(this, paramWriter, paramString, false);
  }
  
  public static void s_saveToWriter(Object paramObject, Writer paramWriter, String paramString, boolean paramBoolean)
  {
    HashMap localHashMap = new HashMap();
    TplC localTplC = new TplC();
    localTplC.loadLib("xls_gen", "/_tpl/xls_gen.lib.xml");
    TreeNode localTreeNode = TreeNode.make("xls_gen:ExportWorkbook");
    if (paramBoolean) {
      localTreeNode.setAttribute("cp:exportDef", "${true}");
    }
    localHashMap.put("workbook", paramObject);
    localHashMap.put("encoding", paramString);
    localHashMap.put("$out", paramWriter);
    ITplReference localITplReference = localTplC.compileNode(localTreeNode, SystemServiceContext.getInstance());
    TplC.runTpl(localITplReference, localHashMap, SystemServiceContext.getInstance());
    try
    {
      paramWriter.flush();
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\AbstractWorkbook.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */