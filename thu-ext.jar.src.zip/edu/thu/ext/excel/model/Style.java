package edu.thu.ext.excel.model;

import edu.thu.global.Debug;
import edu.thu.lang.reflect.BeanInstance;
import edu.thu.util.StringUtils;
import edu.thu.xml.XmlUtils;
import java.io.Serializable;
import java.text.Format;
import java.util.List;

public class Style
  implements Serializable
{
  private static final long serialVersionUID = 6752253799368403920L;
  public static Style EMPTY_STYLE = new Style();
  int P = -1;
  String U;
  String G;
  String I;
  String O;
  String Z;
  Font b;
  String g;
  Format M;
  boolean L;
  boolean D;
  String f;
  String X;
  String T;
  String F;
  int h;
  int E;
  int A;
  int W;
  String J;
  String e;
  String K;
  String S;
  String B;
  int Q;
  String _;
  String a;
  int R;
  String N;
  String d;
  String V;
  String C;
  boolean H;
  String Y;
  int c;
  
  public int getRotate()
  {
    return this.c;
  }
  
  public void setRotate(int paramInt)
  {
    this.c = paramInt;
  }
  
  public void setCssClassName(String paramString)
  {
    this.Y = paramString;
  }
  
  public String getCssClassName(String paramString)
  {
    if (this.Y != null) {
      return paramString + "_" + this.Y;
    }
    return paramString + "_" + this.U;
  }
  
  public Style copy()
  {
    return (Style)new BeanInstance(this).cloneInstance(false);
  }
  
  public boolean isNewlyCreated()
  {
    return this.H;
  }
  
  public void setNewlyCreated(boolean paramBoolean)
  {
    this.H = paramBoolean;
  }
  
  public String getInteriorPattern()
  {
    return this.C;
  }
  
  public void setInteriorPattern(String paramString)
  {
    this.C = paramString;
  }
  
  public int getStyleIndex()
  {
    return this.P;
  }
  
  public void setStyleIndex(int paramInt)
  {
    this.P = paramInt;
  }
  
  public void setId(String paramString)
  {
    this.U = paramString;
  }
  
  public String getId()
  {
    return this.U;
  }
  
  public String getKey()
  {
    return this.I;
  }
  
  public void setKey(String paramString)
  {
    this.I = paramString;
  }
  
  public void setName(String paramString)
  {
    this.G = paramString;
  }
  
  public String getName()
  {
    return this.G;
  }
  
  public String getInteriorColor()
  {
    return this.V;
  }
  
  public void setInteriorColor(String paramString)
  {
    this.V = paramString;
  }
  
  public Font getFont()
  {
    return this.b;
  }
  
  public void setFont(Font paramFont)
  {
    this.b = paramFont;
  }
  
  public String getFontColor()
  {
    return this.b == null ? null : this.b.getFontColor();
  }
  
  Font A()
  {
    if (this.b == null) {
      this.b = new Font();
    }
    return this.b;
  }
  
  public void setFontColor(String paramString)
  {
    A().setFontColor(paramString);
  }
  
  public boolean isWrapText()
  {
    return this.L;
  }
  
  public void setWrapText(boolean paramBoolean)
  {
    this.L = paramBoolean;
  }
  
  public void setVerticalAlignment(String paramString)
  {
    this.O = paramString;
  }
  
  public String getVerticalAlignment()
  {
    return this.O;
  }
  
  public void setHorizontalAlignment(String paramString)
  {
    this.Z = paramString;
  }
  
  public String getHorizontalAlignment()
  {
    return this.Z;
  }
  
  public boolean isFontStrikeout()
  {
    return this.b == null ? false : this.b.isStrikeout();
  }
  
  public void setFontStrikeout(boolean paramBoolean)
  {
    A().setStrikeout(paramBoolean);
  }
  
  public boolean isFontBold()
  {
    return this.b == null ? false : this.b.isBold();
  }
  
  public void setFontBold(boolean paramBoolean)
  {
    A().setBold(paramBoolean);
  }
  
  public boolean isFontItalic()
  {
    return this.b == null ? false : this.b.isItalic();
  }
  
  public void setFontItalic(boolean paramBoolean)
  {
    A().setItalic(paramBoolean);
  }
  
  public String getFontUnderline()
  {
    return this.b == null ? null : A().getXlsUnderline();
  }
  
  public void setFontUnderline(String paramString)
  {
    A().setXlsUnderline(paramString);
  }
  
  public void setFontName(String paramString)
  {
    A().setFontName(paramString);
  }
  
  public void setFontFamily(String paramString)
  {
    A().setFontFamily(paramString);
  }
  
  public String getFontName()
  {
    return this.b == null ? null : this.b.getFontName();
  }
  
  public void setCharSet(int paramInt)
  {
    A().setCharSet(paramInt);
  }
  
  public int getCharSet()
  {
    return this.b == null ? 0 : this.b.getCharSet();
  }
  
  public void setFontSize(Double paramDouble)
  {
    A().setFontSize(paramDouble);
  }
  
  public Double getFontSize()
  {
    return this.b == null ? null : this.b.getFontSize();
  }
  
  public void setNumberFormat(String paramString)
  {
    this.g = paramString;
    String str = StringUtils.strip(this.g);
    if ((str != null) && (str.endsWith("_"))) {
      str = str.substring(0, str.length() - 1);
    }
    this.M = FormatHelper.getFormat(str);
  }
  
  public String getNumberFormat()
  {
    return this.g;
  }
  
  public Format getNumberFormatObj()
  {
    return this.M;
  }
  
  public Object format(Object paramObject)
  {
    if (this.M == null) {
      return paramObject;
    }
    if ((paramObject instanceof Number)) {
      paramObject = this.M.format(paramObject);
    }
    return paramObject;
  }
  
  public void setBottomBorderStyle(String paramString)
  {
    this.f = paramString;
  }
  
  public String getBottomBorderStyle()
  {
    return this.f;
  }
  
  public void setTopBorderStyle(String paramString)
  {
    this.X = paramString;
  }
  
  public String getTopBorderStyle()
  {
    return this.X;
  }
  
  public void setLeftBorderStyle(String paramString)
  {
    this.T = paramString;
  }
  
  public String getLeftBorderStyle()
  {
    return this.T;
  }
  
  public void setRightBorderStyle(String paramString)
  {
    this.F = paramString;
  }
  
  public String getRightBorderStyle()
  {
    return this.F;
  }
  
  public void setBottomBorderWeight(int paramInt)
  {
    this.h = paramInt;
  }
  
  public int getBottomBorderWeight()
  {
    return this.h;
  }
  
  public void setTopBorderWeight(int paramInt)
  {
    this.E = paramInt;
  }
  
  public int getTopBorderWeight()
  {
    return this.E;
  }
  
  public void setLeftBorderWeight(int paramInt)
  {
    this.A = paramInt;
  }
  
  public int getLeftBorderWeight()
  {
    return this.A;
  }
  
  public void setRightBorderWeight(int paramInt)
  {
    this.W = paramInt;
  }
  
  public int getRightBorderWeight()
  {
    return this.W;
  }
  
  public void setLeftBorderColor(String paramString)
  {
    this.J = paramString;
  }
  
  public String getLeftBorderColor()
  {
    return this.J;
  }
  
  public void setRightBorderColor(String paramString)
  {
    this.e = paramString;
  }
  
  public String getRightBorderColor()
  {
    return this.e;
  }
  
  public void setTopBorderColor(String paramString)
  {
    this.K = paramString;
  }
  
  public String getTopBorderColor()
  {
    return this.K;
  }
  
  public void setBottomBorderColor(String paramString)
  {
    this.S = paramString;
  }
  
  public String getBottomBorderColor()
  {
    return this.S;
  }
  
  public void setProtection(String paramString)
  {
    this.d = paramString;
  }
  
  public String getProtection()
  {
    return this.d;
  }
  
  public String getDiagonalLeftStyle()
  {
    return this.B;
  }
  
  public void setDiagonalLeftStyle(String paramString)
  {
    this.B = paramString;
  }
  
  public int getDiagonalLeftWeight()
  {
    return this.Q;
  }
  
  public void setDiagonalLeftWeight(int paramInt)
  {
    this.Q = paramInt;
  }
  
  public String getDiagonalLeftColor()
  {
    return this._;
  }
  
  public void setDiagonalLeftColor(String paramString)
  {
    this._ = paramString;
  }
  
  public String getDiagonalRightStyle()
  {
    return this.a;
  }
  
  public void setDiagonalRightStyle(String paramString)
  {
    this.a = paramString;
  }
  
  public int getDiagonalRightWeight()
  {
    return this.R;
  }
  
  public void setDiagonalRightWeight(int paramInt)
  {
    this.R = paramInt;
  }
  
  public String getDiagonalRightColor()
  {
    return this.N;
  }
  
  public void setDiagonalRightColor(String paramString)
  {
    this.N = paramString;
  }
  
  String A(String paramString)
  {
    return A(paramString, null);
  }
  
  String A(String paramString1, String paramString2)
  {
    int j = ExcelModelConstants.CSS_TRANS.size();
    for (int i = 0; i < j; i++)
    {
      String[] arrayOfString = (String[])ExcelModelConstants.CSS_TRANS.get(i);
      if (arrayOfString[0].equals(paramString1)) {
        return arrayOfString[1];
      }
    }
    return paramString2;
  }
  
  String B(String paramString1, String paramString2)
  {
    return paramString1 != null ? paramString1 : paramString2;
  }
  
  void A(StringBuilder paramStringBuilder, String paramString1, String paramString2)
  {
    paramString1 = A(paramString1);
    if (paramString1 == null) {
      return;
    }
    paramString2 = A(paramString2);
    if (paramString2 == null) {
      return;
    }
    paramStringBuilder.append(paramString1).append(":").append(paramString2).append(";\r\n");
  }
  
  void A(StringBuilder paramStringBuilder, String paramString, Object paramObject)
  {
    if (paramObject != null) {
      paramStringBuilder.append(" ").append(paramString).append("=\"").append(paramObject).append("\"");
    }
  }
  
  String A(boolean paramBoolean)
  {
    return paramBoolean ? "1" : null;
  }
  
  public boolean hasBorder()
  {
    return (this.f != null) || (this.X != null) || (this.T != null) || (this.F != null) || (this.B != null) || (this.a != null);
  }
  
  public boolean isShrinkToFit()
  {
    return this.D;
  }
  
  public void setShrinkToFit(boolean paramBoolean)
  {
    this.D = paramBoolean;
  }
  
  public String toXlsStyle(String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("<Style");
    String str = paramString + "_" + this.U;
    A(localStringBuilder, "ss:ID", str);
    A(localStringBuilder, "ss:Name", this.G);
    localStringBuilder.append(">");
    if ((this.Z != null) || (this.O != null) || (this.L) || (this.D))
    {
      localStringBuilder.append("<Alignment ");
      A(localStringBuilder, "ss:Horizontal", this.Z);
      A(localStringBuilder, "ss:Vertical", this.O);
      A(localStringBuilder, "ss:WrapText", A(this.L));
      A(localStringBuilder, "ss:ShrinkToFit", A(this.D));
      A(localStringBuilder, "ss:Rotate", this.c != 0 ? String.valueOf(this.c) : null);
      localStringBuilder.append("/>");
    }
    if (hasBorder())
    {
      localStringBuilder.append("<Borders>");
      localStringBuilder.append("<Border ");
      A(localStringBuilder, "ss:Position", "Bottom");
      A(localStringBuilder, "ss:LineStyle", this.f);
      A(localStringBuilder, "ss:Weight", Integer.valueOf(this.h));
      A(localStringBuilder, "ss:Color", this.S);
      localStringBuilder.append("/>");
      localStringBuilder.append("<Border ");
      A(localStringBuilder, "ss:Position", "Left");
      A(localStringBuilder, "ss:LineStyle", this.T);
      A(localStringBuilder, "ss:Weight", Integer.valueOf(this.A));
      A(localStringBuilder, "ss:Color", this.J);
      localStringBuilder.append("/>");
      localStringBuilder.append("<Border ");
      A(localStringBuilder, "ss:Position", "Right");
      A(localStringBuilder, "ss:LineStyle", this.F);
      A(localStringBuilder, "ss:Weight", Integer.valueOf(this.W));
      A(localStringBuilder, "ss:Color", this.e);
      localStringBuilder.append("/>");
      localStringBuilder.append("<Border ");
      A(localStringBuilder, "ss:Position", "Top");
      A(localStringBuilder, "ss:LineStyle", this.X);
      A(localStringBuilder, "ss:Weight", Integer.valueOf(this.E));
      A(localStringBuilder, "ss:Color", this.K);
      localStringBuilder.append("/>");
      if (this.B != null)
      {
        localStringBuilder.append("<Border ");
        A(localStringBuilder, "ss:Position", "DiagonalLeft");
        A(localStringBuilder, "ss:LineStyle", this.B);
        A(localStringBuilder, "ss:Weight", Integer.valueOf(this.Q));
        localStringBuilder.append("/>");
      }
      if (this.a != null)
      {
        localStringBuilder.append("<Border ");
        A(localStringBuilder, "ss:Position", "DiagonalRight");
        A(localStringBuilder, "ss:LineStyle", this.a);
        A(localStringBuilder, "ss:Weight", Integer.valueOf(this.R));
        localStringBuilder.append("/>");
      }
      localStringBuilder.append("</Borders>");
    }
    if (this.b != null) {
      this.b.toXlsStyle(localStringBuilder);
    }
    if (this.g != null) {
      localStringBuilder.append("<NumberFormat ss:Format=\"").append(XmlUtils.encodeXmlAttr(this.g)).append("\" />");
    }
    if (this.d != null) {
      localStringBuilder.append("<Protection>").append(this.d).append("</Protection>");
    }
    if (this.V != null)
    {
      localStringBuilder.append("<Interior");
      A(localStringBuilder, "ss:Color", this.V);
      A(localStringBuilder, "ss:Pattern", this.C);
      localStringBuilder.append(" />");
    }
    localStringBuilder.append("</Style>");
    return localStringBuilder.toString();
  }
  
  public String toCss(String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    String str = paramString + "_" + this.U;
    localStringBuilder.append(".").append(str);
    localStringBuilder.append("{\r\n");
    A(localStringBuilder, "verticalAlignment", this.O);
    A(localStringBuilder, "horizontalAlignment", this.Z);
    if (this.b != null) {
      this.b.toCssStyle(localStringBuilder);
    }
    if (this.L) {
      localStringBuilder.append("white-space:normal;\r\n");
    }
    if (this.V != null) {
      localStringBuilder.append("background-color:").append(this.V).append(";\r\n");
    }
    if (isAllBorderSameStyle())
    {
      if (this.E > 0) {
        localStringBuilder.append("border:").append(this.E).append("px ").append(A(this.X, "solid")).append(" ").append(B(this.K, "black")).append(";\r\n");
      }
    }
    else
    {
      if (this.E > 0) {
        localStringBuilder.append("border-top:").append(this.E).append("px ").append(A(this.X, "solid")).append(" ").append(B(this.K, "black")).append(";\r\n");
      }
      if (this.h > 0) {
        localStringBuilder.append("border-bottom:").append(this.h).append("px ").append(A(this.f, "solid")).append(" ").append(B(this.S, "black")).append(";\r\n");
      }
      if (this.A > 0) {
        localStringBuilder.append("border-left:").append(this.A).append("px ").append(A(this.T, "solid")).append(" ").append(B(this.J, "black")).append(";\r\n");
      }
      if (this.W > 0) {
        localStringBuilder.append("border-right:").append(this.W).append("px ").append(A(this.F, "solid")).append(" ").append(B(this.e, "black")).append(";\r\n");
      }
    }
    localStringBuilder.append("}\r\n");
    return localStringBuilder.toString();
  }
  
  public boolean hasFontStyle()
  {
    return this.b != null;
  }
  
  public String getWmlFontStyle()
  {
    if (this.b == null) {
      return null;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    this.b.toWmlStyle(localStringBuilder);
    return localStringBuilder.toString();
  }
  
  public String getWmlPrStyle()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    if ((this.Z != null) && (!this.Z.equals("Justify")) && (!this.Z.equals("Distributed"))) {
      localStringBuilder.append("<w:jc w:val=\"").append(this.Z.toLowerCase()).append("\"/>");
    }
    return localStringBuilder.toString();
  }
  
  public String getWmlTcStyle()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    if ((this.O != null) && (!this.O.equals("Justify")) && (!this.O.equals("Distributed"))) {
      localStringBuilder.append("<w:vAlign w:val=\"").append(this.O.toLowerCase()).append("\"/>");
    }
    if (this.D) {
      localStringBuilder.append("<w:tcFitText/>");
    }
    if (this.V != null) {
      localStringBuilder.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"").append(this.V).append("\"/>");
    }
    if ((this.f == null) || (this.X == null) || (this.T == null) || (this.F == null))
    {
      localStringBuilder.append("<w:tcBorders>");
      if (this.f == null) {
        localStringBuilder.append("<w:bottom w:val=\"nil\"/>");
      }
      if (this.X == null) {
        localStringBuilder.append("<w:top w:val=\"nil\"/>");
      }
      if (this.T == null) {
        localStringBuilder.append("<w:left w:val=\"nil\"/>");
      }
      if (this.F == null) {
        localStringBuilder.append("<w:right w:val=\"nil\"/>");
      }
      localStringBuilder.append("</w:tcBorders>");
    }
    return localStringBuilder.toString();
  }
  
  public boolean isAllBorderSameStyle()
  {
    if (this.T != null)
    {
      if ((!this.T.equals(this.X)) || (!this.T.equals(this.F)) || (!this.T.equals(this.f))) {
        return false;
      }
    }
    else if ((this.X != null) || (this.F != null) || (this.f != null)) {
      return false;
    }
    if (this.J != null)
    {
      if ((!this.J.equals(this.K)) || (!this.J.equals(this.e)) || (!this.J.equals(this.S))) {
        return false;
      }
    }
    else if ((this.K != null) || (this.e != null) || (this.S != null)) {
      return false;
    }
    return (this.A == this.E) && (this.A == this.W) && (this.A == this.h);
  }
  
  public void setBorderWeight(int paramInt)
  {
    setLeftBorderWeight(paramInt);
    setRightBorderWeight(paramInt);
    setTopBorderWeight(paramInt);
    setBottomBorderWeight(paramInt);
  }
  
  public void setBorderColor(String paramString)
  {
    setLeftBorderColor(paramString);
    setTopBorderColor(paramString);
    setRightBorderColor(paramString);
    setBottomBorderColor(paramString);
  }
  
  public void setBorderStyle(String paramString)
  {
    setLeftBorderStyle(paramString);
    setRightBorderStyle(paramString);
    setTopBorderStyle(paramString);
    setBottomBorderStyle(paramString);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Style localStyle = new Style();
    localStyle.setNumberFormat("0_ ");
    Object localObject = localStyle.format(Double.valueOf(1.3D));
    Debug.trace(localObject);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\Style.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */