package edu.thu.ext.excel.model;

import edu.thu.ext.excel.model.formula.CellFormula;
import edu.thu.ext.excel.model.formula.CellFormulaHelper;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.util.Coercions;
import edu.thu.lang.IVariant;
import edu.thu.lang.Variant;
import edu.thu.lang.el.IExpressionReference;
import edu.thu.lang.exceptions.StdException;
import edu.thu.lang.util.TplC;
import edu.thu.math.alg.Alog;
import edu.thu.text.StringParser;
import edu.thu.util.StringUtils;
import edu.thu.web.layout.ColumnLayout;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class ExcelModelHelper
{
  static void B(Workbook paramWorkbook)
  {
    Iterator localIterator1 = paramWorkbook.getWorksheets().iterator();
    while (localIterator1.hasNext())
    {
      Worksheet localWorksheet = (Worksheet)localIterator1.next();
      List localList1 = paramWorkbook.getRangeInSheet(localWorksheet.getWorksheetName(), "range.");
      if (localList1 != null)
      {
        Iterator localIterator2 = localList1.iterator();
        while (localIterator2.hasNext())
        {
          NamedRange localNamedRange = (NamedRange)localIterator2.next();
          String str = localNamedRange.getNamePart(1);
          Style localStyle = paramWorkbook.getWxReportConfig().getStyle(str);
          if (localStyle != null)
          {
            List localList2 = localNamedRange.getRanges();
            Iterator localIterator3 = localList2.iterator();
            while (localIterator3.hasNext())
            {
              Range localRange = (Range)localIterator3.next();
              int i = Math.min(localRange.getMaxRow(), localWorksheet.getRowCount());
              for (int j = localRange.getMinRow(); j <= i; j++)
              {
                Row localRow = localWorksheet.getRow(j);
                int k = Math.min(localRow.getColCount(), localRange.getMaxCol());
                for (int m = localRange.getMinCol(); m <= k; m++)
                {
                  Cell localCell = localRow.getCell(m);
                  localCell.setStyle(localStyle);
                }
              }
            }
          }
        }
      }
    }
  }
  
  static void C(Workbook paramWorkbook)
  {
    Iterator localIterator1 = paramWorkbook.getWorksheets().iterator();
    while (localIterator1.hasNext())
    {
      Worksheet localWorksheet = (Worksheet)localIterator1.next();
      Iterator localIterator2 = localWorksheet.getTable().getRows().iterator();
      while (localIterator2.hasNext())
      {
        Row localRow = (Row)localIterator2.next();
        Iterator localIterator3 = localRow.getCells().iterator();
        while (localIterator3.hasNext())
        {
          Cell localCell = (Cell)localIterator3.next();
          Map localMap = localCell.getCommentVars();
          if ((localMap != null) && (!ExcelModelConstants.XPT_CELL_ATTRS.containsAll(localMap.keySet())))
          {
            ArrayList localArrayList = new ArrayList(localMap.keySet());
            localArrayList.removeAll(ExcelModelConstants.XPT_CELL_ATTRS);
            throw Exceptions.code("xpt.CAN_err_unknown_var_names").param(localArrayList).param(localCell);
          }
        }
      }
    }
  }
  
  static ColumnLayout A(String paramString)
  {
    paramString = StringUtils.strip(paramString);
    if ((paramString == null) || (!paramString.startsWith("*="))) {
      return null;
    }
    String str1 = paramString.substring(2);
    if (str1.startsWith("P_")) {
      str1 = "p_" + str1.substring(2);
    }
    boolean bool = str1.startsWith("p_");
    String str2 = ExcelModelUtils.encodeParamName(str1, bool);
    String str3 = null;
    int i = str2.indexOf('[');
    if (i > 0)
    {
      int j = str2.indexOf(']');
      if (j < 0) {
        throw Exceptions.code("xpt.CAN_err_invalid_field_name").param(paramString);
      }
      str3 = str2.substring(i + 1, j);
    }
    String str4 = i > 0 ? str2.substring(0, i) : str2;
    String str5 = str4.startsWith("p_") ? str4.substring(2) : str4;
    ColumnLayout localColumnLayout = new ColumnLayout();
    localColumnLayout.setFieldName(str4);
    localColumnLayout.setExtInfo(str3);
    localColumnLayout.setShowName(str5);
    localColumnLayout.setAddable(true);
    localColumnLayout.setUpdatable(true);
    localColumnLayout.setExCell(bool);
    return localColumnLayout;
  }
  
  public static WxReportConfig parseConfigFromTable(Table paramTable, TplC paramTplC, WxReportConfig paramWxReportConfig)
  {
    int j = paramTable.getRowCount();
    for (int i = 0; i < j; i++)
    {
      Row localRow1 = (Row)paramTable.getRow(i);
      List localList1 = localRow1.getDataList();
      if ((localList1 != null) && (!localList1.isEmpty()))
      {
        String str1 = (String)localList1.get(0);
        if ((str1 != null) && (str1.toString().trim().startsWith("*")))
        {
          String str2 = str1.toString().trim().substring(1).trim();
          List localList2 = paramTable.getCellDataNotEmpty(i + 1);
          String str3 = null;
          if (localList1.size() > 1) {
            str3 = Variant.valueOf(localList1.get(1)).stripedStringValue();
          }
          if (paramWxReportConfig.isKey("config.styles", str2))
          {
            for (int k = 0; k < localList2.size(); k++)
            {
              List localList3 = (List)localList2.get(k);
              String str4 = Coercions.toString(localList3.get(0), null);
              if (str4 != null)
              {
                Row localRow2 = (Row)paramTable.getRow(i + 1 + k);
                if (localRow2.getCells().size() >= 2)
                {
                  Style localStyle = localRow2.getCell(1).getStyle();
                  if (localStyle == null) {
                    localStyle = paramTable.getWorkbook().getStyle("Default");
                  }
                  if (localStyle != null)
                  {
                    String str5 = localRow2.getCell(1).getCommentStr("cssClass");
                    localStyle = paramWxReportConfig.fixCssClass(localStyle, str5, paramTable.getWorkbook());
                    paramWxReportConfig.K.put(str4, localStyle);
                  }
                }
              }
            }
          }
          else
          {
            paramWxReportConfig.parseConfig(str2, str3, localList2, null, paramTplC);
            i += localList2.size();
          }
        }
      }
    }
    return paramWxReportConfig;
  }
  
  static void A(Workbook paramWorkbook)
  {
    Iterator localIterator1 = paramWorkbook.getWorksheets().iterator();
    while (localIterator1.hasNext())
    {
      Worksheet localWorksheet = (Worksheet)localIterator1.next();
      Iterator localIterator2 = localWorksheet.getTable().getRows().iterator();
      while (localIterator2.hasNext())
      {
        Row localRow = (Row)localIterator2.next();
        Iterator localIterator3 = localRow.getCells().iterator();
        while (localIterator3.hasNext())
        {
          Cell localCell = (Cell)localIterator3.next();
          if (localCell.getFormula() != null)
          {
            String str = localCell.getFormula();
            if (!str.startsWith("=")) {
              throw Exceptions.code("excel.CAN_err_invalid_formula_format").param(localCell);
            }
            CellFormula localCellFormula = A(str.substring(1), localCell);
            localCell.setCellFormula(localCellFormula);
            localCell.setStaticCell(false);
          }
        }
      }
    }
  }
  
  static CellFormula A(String paramString, Cell paramCell)
  {
    return CellFormulaHelper.parseFormula(paramString, paramCell);
  }
  
  static void A(Cell paramCell)
  {
    Cell localCell;
    for (Object localObject = paramCell;; localObject = localCell)
    {
      localCell = ((Cell)localObject).getHorParent();
      if ((localCell == null) || (localCell.isVirtualRoot())) {
        break;
      }
      if (localCell == paramCell) {
        throw Exceptions.code("excel.CAN_err_exists_hor_loop").param(paramCell);
      }
    }
    for (localObject = paramCell;; localObject = localCell)
    {
      localCell = ((Cell)localObject).getVerParent();
      if ((localCell == null) || (localCell.isVirtualRoot())) {
        break;
      }
      if (localCell == paramCell) {
        throw Exceptions.code("excel.CAN_err_exists_ver_loop").param(paramCell);
      }
    }
  }
  
  public static void initExpandModel(Workbook paramWorkbook)
  {
    Iterator localIterator1 = paramWorkbook.getWorksheets().iterator();
    while (localIterator1.hasNext())
    {
      Worksheet localWorksheet = (Worksheet)localIterator1.next();
      ArrayList localArrayList = new ArrayList();
      boolean bool1 = false;
      boolean bool2 = false;
      RootCell localRootCell1 = new RootCell();
      RootCell localRootCell2 = new RootCell();
      Iterator localIterator2 = localWorksheet.getRows().iterator();
      while (localIterator2.hasNext())
      {
        Row localRow = (Row)localIterator2.next();
        Iterator localIterator3 = localRow.getCells().iterator();
        while (localIterator3.hasNext())
        {
          Cell localCell = (Cell)localIterator3.next();
          if (!localCell.isIgnored())
          {
            localCell.initExpandModel();
            if ((localCell.isNeedExpand()) || (localCell.getExpandModel().getField() != null)) {
              localCell.setStaticCell(false);
            }
            String str1 = localCell.getCommentStr("horParent");
            Object localObject1;
            Object localObject2;
            if (str1 == null)
            {
              localObject1 = localCell.findDefaultHorParent();
            }
            else if ("none".equals(str1))
            {
              localObject1 = null;
            }
            else
            {
              localObject2 = new CellPosition(str1);
              localObject1 = localWorksheet.getCell((CellPosition)localObject2);
              if (localObject1 == null) {
                throw Exceptions.code("excel.CAN_err_invalid_cell_hor_parent").param(localObject2).param(localCell);
              }
            }
            if (localObject1 != null)
            {
              localObject1 = ((Cell)localObject1).getRealCell();
              ((Cell)localObject1).addHorChild(localCell);
            }
            else
            {
              localObject1 = localRootCell1;
              localRootCell1.addHorChild(localCell);
            }
            String str2 = localCell.getCommentStr("verParent");
            if (str2 == null)
            {
              localObject2 = localCell.findDefaultVerParent();
            }
            else if ("none".equals(str2))
            {
              localObject2 = null;
            }
            else
            {
              CellPosition localCellPosition = new CellPosition(str2);
              localObject2 = localWorksheet.getCell(localCellPosition);
              if (localObject2 == null) {
                throw Exceptions.code("excel.CAN_err_invalid_cell_ver_parent").param(localCellPosition).param(localCell);
              }
            }
            if (localObject2 != null)
            {
              localObject2 = ((Cell)localObject2).getRealCell();
              ((Cell)localObject2).addVerChild(localCell);
            }
            else
            {
              localObject2 = localRootCell2;
              localRootCell2.addVerChild(localCell);
            }
            A(localCell);
            if ((localObject2 == localRootCell2) && (localObject1 == localRootCell1)) {
              localArrayList.add(localCell);
            }
            if (localCell.isNeedExpand()) {
              bool1 = true;
            }
            if (localCell.getCellFormula() != null) {
              bool2 = true;
            }
          }
        }
      }
      localWorksheet.setNeedExpand(bool1);
      localWorksheet.setContainsFormula(bool2);
      localWorksheet.getTable().setRootCells(localArrayList);
      localWorksheet.getTable().setHorRoot(localRootCell1);
      localWorksheet.getTable().setVerRoot(localRootCell2);
      localRootCell1.calcExpandHorRange();
      localRootCell2.calcExpandVerRange();
      localRootCell1.setMergeDown(localRootCell1.getHorExpandRange() - 1);
      localRootCell2.setMergeAcross(localRootCell2.getVerExpandRange() - 1);
      localRootCell1.initHorBandModel();
      localRootCell2.initVerBandModel();
      initDimFields(paramWorkbook);
    }
  }
  
  public static void initDimFields(Workbook paramWorkbook)
  {
    Iterator localIterator1 = paramWorkbook.getWorksheets().iterator();
    while (localIterator1.hasNext())
    {
      Worksheet localWorksheet = (Worksheet)localIterator1.next();
      Iterator localIterator2 = localWorksheet.getRows().iterator();
      while (localIterator2.hasNext())
      {
        Row localRow = (Row)localIterator2.next();
        Iterator localIterator3 = localRow.getCells().iterator();
        while (localIterator3.hasNext())
        {
          Cell localCell1 = (Cell)localIterator3.next();
          if (!localCell1.isIgnored())
          {
            localCell1.initExpandModel();
            if ((localCell1.getExpandModel().getHorDimFields() == null) && (localCell1.getExpandModel().getVerDimFields() == null))
            {
              String str = localCell1.getExpandModel().getDsNameWithDefault();
              Object localObject2 = new ArrayList();
              ArrayList localArrayList1 = new ArrayList();
              Cell localCell2;
              for (Object localObject1 = localCell1;; localObject1 = localCell2)
              {
                localCell2 = ((Cell)localObject1).getHorParent();
                if ((localCell2 == null) || (localCell2.isVirtualRoot())) {
                  break;
                }
                if (str.equals(localCell2.getExpandModel().getDsNameWithDefault()))
                {
                  localArrayList1.add(localCell2.getExpandModel().getField());
                  if ((localCell2.getExpandModel().getHorDimFields() != null) && (!localCell2.getExpandModel().getHorDimFields().isEmpty()))
                  {
                    localArrayList1.addAll(localCell2.getExpandModel().getHorDimFields());
                    break;
                  }
                }
                else
                {
                  localArrayList1.add(null);
                }
              }
              Alog.removeNullTail(localArrayList1);
              if (localArrayList1.size() > localCell1.getExpandModel().getHorExpandLevel()) {
                throw Exceptions.code("excel.CAN_err_invalid_hor_dim_fields").param(localArrayList1).param(localCell1);
              }
              ((List)localObject2).addAll(localArrayList1);
              if (localArrayList1.isEmpty()) {
                localArrayList1 = null;
              }
              localCell1.getExpandModel().setHorDimFields(localArrayList1);
              ArrayList localArrayList2 = new ArrayList();
              for (localObject1 = localCell1;; localObject1 = localCell2)
              {
                localCell2 = ((Cell)localObject1).getVerParent();
                if ((localCell2 == null) || (localCell2.isVirtualRoot())) {
                  break;
                }
                if (str.equals(localCell2.getExpandModel().getDsNameWithDefault()))
                {
                  localArrayList2.add(localCell2.getExpandModel().getField());
                  if ((localCell2.getExpandModel().getVerDimFields() != null) && (!localCell2.getExpandModel().getVerDimFields().isEmpty()))
                  {
                    localArrayList2.addAll(localCell2.getExpandModel().getVerDimFields());
                    break;
                  }
                }
                else
                {
                  localArrayList2.add(null);
                }
              }
              Alog.removeNullTail(localArrayList2);
              if (localArrayList2.size() > localCell1.getExpandModel().getVerExpandLevel()) {
                throw Exceptions.code("excel.CAN_err_invalid_ver_dim_fields").param(localArrayList2).param(localCell1);
              }
              ((List)localObject2).addAll(localArrayList2);
              if (localArrayList2.isEmpty()) {
                localArrayList2 = null;
              }
              localCell1.getExpandModel().setVerDimFields(localArrayList2);
              localObject2 = Alog.compact((Collection)localObject2);
              if (((List)localObject2).isEmpty()) {
                localObject2 = null;
              }
              localCell1.getExpandModel().setDimFields((List)localObject2);
            }
          }
        }
      }
    }
  }
  
  public static void parseFieldDefinition(Cell paramCell, WxReportConfig paramWxReportConfig)
  {
    Map localMap = paramCell.getCommentVars();
    String str1 = paramCell.getData();
    str1 = StringUtils.strip(str1);
    if ((str1 == null) || (!str1.startsWith("*="))) {
      return;
    }
    FieldDefinition localFieldDefinition = new FieldDefinition();
    localFieldDefinition.setCell(paramCell);
    localFieldDefinition.setAddable(true);
    localFieldDefinition.setUpdatable(true);
    StringParser localStringParser = new StringParser(str1.substring(2));
    localStringParser.skipBlank();
    if (localStringParser.peekChar() == 64)
    {
      localStringParser.readChar();
      localFieldDefinition.setAddable(false);
      localFieldDefinition.setUpdatable(false);
    }
    String str2 = localStringParser.readTill('[');
    str2 = str2.trim();
    if (str2.startsWith("P_")) {
      str2 = "p_" + str2.substring(2);
    }
    boolean bool = str2.startsWith("p_");
    str2 = ExcelModelUtils.encodeParamName(str2, bool);
    String str3 = bool ? str2.substring(2) : str2;
    localFieldDefinition.setName(str2);
    localFieldDefinition.setShortName(str2);
    localFieldDefinition.setShowName(str3);
    localFieldDefinition.setDynamicField(bool);
    Object localObject;
    if (localStringParser.readChar() == 91)
    {
      localObject = localStringParser.readTill(']');
      localObject = ((String)localObject).trim();
      localFieldDefinition.setListType(2);
      localFieldDefinition.setExtIndex((String)localObject);
      localStringParser.readChar();
    }
    if (!localStringParser.isEnd()) {
      throw Exceptions.code("excel.CAN_err_invalid_field_definition").param(str1).param(paramCell);
    }
    if ((paramWxReportConfig != null) && (str2.startsWith("#")))
    {
      localObject = paramWxReportConfig.mapVar(str2);
      if (localObject != null)
      {
        str2 = ((CellVarMap)localObject).mapFieldText(localFieldDefinition);
        localMap = ((CellVarMap)localObject).mapVars(localFieldDefinition, localMap);
        localFieldDefinition.setName(str2);
        localFieldDefinition.setShortName(str2);
      }
    }
    if (localMap != null) {
      localFieldDefinition.parseFrom(localMap);
    }
    if (str2 != null) {
      paramCell.setFieldDefinition(localFieldDefinition);
    }
    if (localFieldDefinition.getOptions() != null)
    {
      if (localFieldDefinition.getType() == null) {
        localFieldDefinition.setType("string");
      }
    }
    else
    {
      IExpressionReference localIExpressionReference;
      if (localFieldDefinition.getEnum() != null)
      {
        if (localFieldDefinition.getType() == null) {
          localFieldDefinition.setType("int");
        }
        if (paramCell.getFormatExpr() == null)
        {
          localObject = "${$enum(\"" + localFieldDefinition.getEnum() + "\").getItemValue(value)}";
          localIExpressionReference = TplC.parseExpression((String)localObject);
          paramCell.setFormatExpr(localIExpressionReference);
        }
      }
      else if (localFieldDefinition.getDomain() != null)
      {
        if (localFieldDefinition.getDomain().equals("@degree"))
        {
          if (paramCell.getFormatExpr() == null)
          {
            localObject = "${StringUtils.formatDegree(value)}";
            localIExpressionReference = TplC.parseExpression((String)localObject);
            paramCell.setFormatExpr(localIExpressionReference);
          }
        }
        else if (localFieldDefinition.getDomain().equals("userId"))
        {
          if (paramCell.getFormatExpr() == null)
          {
            localObject = "${$user(value).hmName}";
            localIExpressionReference = TplC.parseExpression((String)localObject);
            paramCell.setFormatExpr(localIExpressionReference);
          }
        }
        else if ((localFieldDefinition.getDomain().equals("deptId")) && (paramCell.getFormatExpr() == null))
        {
          localObject = "${$dept(value).name}";
          localIExpressionReference = TplC.parseExpression((String)localObject);
          paramCell.setFormatExpr(localIExpressionReference);
        }
      }
    }
  }
  
  public static List<List<Object>> parseDataList(Table paramTable, int paramInt)
  {
    ArrayList localArrayList1 = new ArrayList();
    int i = paramInt;
    int j = paramTable.getRowCount();
    while (i < j)
    {
      Row localRow = (Row)paramTable.getRow(i);
      ArrayList localArrayList2 = new ArrayList();
      if (localRow.getColCount() <= 0)
      {
        localArrayList1.add(localArrayList2);
      }
      else
      {
        Iterator localIterator = localRow.getCells().iterator();
        while (localIterator.hasNext())
        {
          Cell localCell = (Cell)localIterator.next();
          if (!localCell.isIgnored()) {
            localArrayList2.add(localCell.getData());
          }
        }
        localArrayList1.add(localArrayList2);
      }
      i++;
    }
    return localArrayList1;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\ExcelModelHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */