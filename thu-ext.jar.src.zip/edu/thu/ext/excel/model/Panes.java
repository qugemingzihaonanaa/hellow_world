package edu.thu.ext.excel.model;

import java.io.Serializable;
import java.util.List;

public class Panes
  implements Serializable
{
  private static final long serialVersionUID = 4475473339429455247L;
  List<Pane> A;
  Pane B;
  
  public void addPane(Pane paramPane)
  {
    this.B = paramPane;
  }
  
  public Pane getPane()
  {
    return this.B;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\Panes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */