package edu.thu.ext.excel.model;

public abstract interface IChartBean
{
  public static final String IMG_TYPE_PNG = "png";
  public static final String IMG_TYPE_JPG = "jpg";
  public static final String IMG_TYPE_BMP = "bmp";
  
  public abstract byte[] getImage(String paramString);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\IChartBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */