package edu.thu.ext.excel.model;

import java.io.Serializable;

public class Pane
  implements Serializable
{
  private static final long serialVersionUID = 6818364306376891818L;
  int B;
  int A;
  int C;
  
  public void setNumber(int paramInt)
  {
    this.B = paramInt;
  }
  
  public int getNumber()
  {
    return this.B;
  }
  
  public void setActiveRow(int paramInt)
  {
    this.A = paramInt;
  }
  
  public int getActiveRow()
  {
    return this.A;
  }
  
  public void setActiveCol(int paramInt)
  {
    this.C = paramInt;
  }
  
  public int getActiveCol()
  {
    return this.C;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\model\Pane.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */