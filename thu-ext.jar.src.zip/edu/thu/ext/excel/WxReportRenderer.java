package edu.thu.ext.excel;

import edu.thu.ext.excel.model.PageMakerConfig;
import edu.thu.ext.excel.model.PageMakerConfig.Item;
import edu.thu.ext.excel.model.SectionInfo;
import edu.thu.ext.excel.model.SheetConfig;
import edu.thu.ext.excel.model.SheetConfig.Item;
import edu.thu.ext.excel.model.WxReportConfig;
import edu.thu.java.util.Coercions;
import edu.thu.lang.IVariant;
import edu.thu.lang.Variant;
import edu.thu.lang.util.TplC;
import edu.thu.model.data.WxTable;
import edu.thu.model.stg.view.PageMaker;
import edu.thu.service.IServiceContext;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class WxReportRenderer
{
  Map<String, PageMaker> A = new HashMap();
  WxReportConfig D;
  List<SectionInfo> E = new ArrayList();
  int B;
  String C;
  
  public WxReportRenderer() {}
  
  public WxReportRenderer(WxReportConfig paramWxReportConfig)
  {
    this.D = paramWxReportConfig;
  }
  
  public String getRenderType()
  {
    return this.C;
  }
  
  public void setRenderType(String paramString)
  {
    this.C = paramString;
  }
  
  public void incRowCount()
  {
    this.B += 1;
  }
  
  public int getRowCount()
  {
    return this.B;
  }
  
  public List<SectionInfo> getCurrentSections()
  {
    return this.E;
  }
  
  public SectionInfo enterSection(int paramInt, String paramString)
  {
    this.E.add(new SectionInfo(paramInt, paramString));
    if (this.E.size() <= 1) {
      return null;
    }
    return (SectionInfo)this.E.remove(0);
  }
  
  public void setReportConfig(WxReportConfig paramWxReportConfig)
  {
    this.D = paramWxReportConfig;
  }
  
  public WxReportConfig getReportConfig()
  {
    return this.D;
  }
  
  public SheetConfig.Item getSheetConfig(String paramString)
  {
    if (this.D == null) {
      return null;
    }
    return this.D.getSheetConfig().getItem(paramString);
  }
  
  public Object getVar(Map<String, Object> paramMap, String paramString)
  {
    return TplC.getToken(paramMap, paramString);
  }
  
  public void initPageMakers(Map<String, Object> paramMap)
  {
    if (this.D == null) {
      return;
    }
    Map localMap = this.D.getPageMaker().makePageMakers(paramMap);
    setPageMakers(localMap);
  }
  
  public void createPageMaker(Map<String, Object> paramMap)
  {
    String str = (String)paramMap.get("varName");
    if (str == null) {
      str = "loopData";
    }
    int i = Variant.valueOf(paramMap.get("pageAllCount")).intValue(0);
    int j = Variant.valueOf(paramMap.get("pageBeginCount")).intValue(0);
    int k = Variant.valueOf(paramMap.get("pageMiddleCount")).intValue(0);
    int m = Variant.valueOf(paramMap.get("pageEndCount")).intValue(0);
    PageMaker localPageMaker = new PageMaker();
    localPageMaker.setPageAllCount(i);
    localPageMaker.setPageBeginCount(j);
    localPageMaker.setPageEndCount(m);
    localPageMaker.setPageMiddleCount(k);
    localPageMaker.initViewer(TplC.getToken(paramMap, str));
    addPageMaker(str, localPageMaker);
  }
  
  public PageMaker getPageMaker(String paramString)
  {
    if (this.A == null) {
      return null;
    }
    PageMaker localPageMaker = (PageMaker)this.A.get(paramString);
    return localPageMaker;
  }
  
  public void addPageMaker(String paramString, PageMaker paramPageMaker)
  {
    this.A.put(paramString, paramPageMaker);
  }
  
  public void setPageMakers(Map<String, PageMaker> paramMap)
  {
    this.A = paramMap;
  }
  
  public WxTable makeWxTable(Collection paramCollection)
  {
    if (paramCollection == null) {
      return null;
    }
    ArrayList localArrayList = (paramCollection instanceof List) ? (List)paramCollection : new ArrayList(paramCollection);
    WxTable localWxTable = new WxTable();
    localWxTable.setData(localArrayList);
    return localWxTable;
  }
  
  public boolean enterBeginPage(String paramString, Map<String, Object> paramMap)
  {
    PageMaker localPageMaker = getPageMaker(paramString);
    if (localPageMaker == null) {
      return false;
    }
    if (!localPageMaker.hasPageBegin()) {
      return false;
    }
    List localList = localPageMaker.getBeginPage();
    paramMap.put("_pageVarName", paramString);
    paramMap.put(paramString, localList);
    paramMap.put("loopData", localList);
    paramMap.put("_currentPage", Integer.valueOf(1));
    paramMap.put("_pageCount", Integer.valueOf(localPageMaker.getPageCount()));
    paramMap.put("_pageType", "begin");
    return true;
  }
  
  public boolean enterEndPage(String paramString, Map<String, Object> paramMap)
  {
    PageMaker localPageMaker = getPageMaker(paramString);
    if (localPageMaker == null) {
      return false;
    }
    if (!localPageMaker.hasPageEnd()) {
      return false;
    }
    List localList = localPageMaker.getEndPage();
    paramMap.put("_pageVarName", paramString);
    paramMap.put(paramString, localList);
    paramMap.put("loopData", localList);
    paramMap.put("_currentPage", Integer.valueOf(localPageMaker.getPageCount()));
    paramMap.put("_pageCount", Integer.valueOf(localPageMaker.getPageCount()));
    paramMap.put("_pageType", "end");
    return true;
  }
  
  public boolean enterAllPage(String paramString, Map<String, Object> paramMap)
  {
    PageMaker localPageMaker = getPageMaker(paramString);
    if (localPageMaker == null) {
      return false;
    }
    if (!localPageMaker.hasPageAll()) {
      return false;
    }
    List localList = localPageMaker.getAllPage();
    paramMap.put("_pageVarName", paramString);
    paramMap.put(paramString, localList);
    paramMap.put("loopData", localList);
    paramMap.put("_currentPage", Integer.valueOf(1));
    paramMap.put("_pageCount", Integer.valueOf(localPageMaker.getPageCount()));
    paramMap.put("_pageType", "all");
    return true;
  }
  
  public boolean enterMiddlePage(String paramString, Map<String, Object> paramMap)
  {
    PageMaker localPageMaker = getPageMaker(paramString);
    if (localPageMaker == null) {
      return false;
    }
    if (!localPageMaker.hasPageMiddle()) {
      return false;
    }
    paramMap.put("_pageVarName", paramString);
    paramMap.put(paramString, null);
    paramMap.put("loopData", null);
    paramMap.put("_pageMiddleIt", localPageMaker.getPageMiddleIterator());
    paramMap.put("_pageCount", Integer.valueOf(localPageMaker.getPageCount()));
    paramMap.put("_pageType", "middle");
    return true;
  }
  
  public boolean enterSinglePage(String paramString, Map<String, Object> paramMap)
  {
    PageMaker localPageMaker = getPageMaker(paramString);
    if (localPageMaker == null) {
      return false;
    }
    if (!localPageMaker.isSinglePage()) {
      return false;
    }
    paramMap.put("_pageVarName", paramString);
    paramMap.put(paramString, null);
    paramMap.put("loopData", null);
    paramMap.put("_pageSingleIt", localPageMaker.getPageSingleIterator());
    paramMap.put("_pageCount", Integer.valueOf(localPageMaker.getPageCount()));
    paramMap.put("_pageType", "single");
    return true;
  }
  
  public boolean enterSheet(String paramString, Map<String, Object> paramMap, IServiceContext paramIServiceContext)
  {
    return enterSheet(paramString, paramMap, paramIServiceContext, false);
  }
  
  public boolean enterSheet(String paramString, Map<String, Object> paramMap, IServiceContext paramIServiceContext, boolean paramBoolean)
  {
    paramMap.put("_pageType", null);
    Object localObject2;
    if (paramBoolean)
    {
      localObject2 = getReportConfig().getSheetConfig().getItems().iterator();
      while (((Iterator)localObject2).hasNext())
      {
        localObject1 = (SheetConfig.Item)((Iterator)localObject2).next();
        if (((SheetConfig.Item)localObject1).getSheet().equals(paramString))
        {
          if (((SheetConfig.Item)localObject1).getTestTpl() != null)
          {
            localObject3 = TplC.runTpl(((SheetConfig.Item)localObject1).getTestTpl(), paramMap, paramIServiceContext);
            if (!Coercions.toBoolean(localObject3, true)) {
              return false;
            }
          }
          if (((SheetConfig.Item)localObject1).getBeforeTpl() != null) {
            TplC.runTpl(((SheetConfig.Item)localObject1).getBeforeTpl(), paramMap, paramIServiceContext);
          }
        }
      }
    }
    Object localObject1 = getReportConfig().getPageMaker();
    Object localObject3 = ((PageMakerConfig)localObject1).getItems().iterator();
    while (((Iterator)localObject3).hasNext())
    {
      localObject2 = (PageMakerConfig.Item)((Iterator)localObject3).next();
      if ((((PageMakerConfig.Item)localObject2).pageBeginSheet != null) && (((PageMakerConfig.Item)localObject2).pageBeginSheet.equals(paramString)))
      {
        if (((PageMakerConfig.Item)localObject2).singlePage) {
          return enterSinglePage(((PageMakerConfig.Item)localObject2).var, paramMap);
        }
        return enterBeginPage(((PageMakerConfig.Item)localObject2).var, paramMap);
      }
      if ((((PageMakerConfig.Item)localObject2).pageMiddleSheet != null) && (((PageMakerConfig.Item)localObject2).pageMiddleSheet.equals(paramString))) {
        return enterMiddlePage(((PageMakerConfig.Item)localObject2).var, paramMap);
      }
      if ((((PageMakerConfig.Item)localObject2).pageEndSheet != null) && (((PageMakerConfig.Item)localObject2).pageEndSheet.equals(paramString))) {
        return enterEndPage(((PageMakerConfig.Item)localObject2).var, paramMap);
      }
      if ((((PageMakerConfig.Item)localObject2).pageAllSheet != null) && (((PageMakerConfig.Item)localObject2).pageAllSheet.equals(paramString))) {
        return enterAllPage(((PageMakerConfig.Item)localObject2).var, paramMap);
      }
    }
    return true;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\WxReportRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */