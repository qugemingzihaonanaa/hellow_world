package edu.thu.ext.excel.xpt;

import edu.thu.ext.excel.model.data.CellData;
import edu.thu.java.util.Coercions;
import edu.thu.model.Pair;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class XptExpandCell
{
  List<CellData> A = new ArrayList();
  CellData B;
  
  public XptExpandCell(CellData paramCellData)
  {
    this.B = paramCellData;
  }
  
  public int calcMinExpandColIndex()
  {
    int i = 0;
    int k = this.A.size();
    for (int j = 0; j < k; j++)
    {
      int m = ((CellData)this.A.get(j)).getCalcColIndex();
      if (m < i) {
        i = m;
      }
    }
    return i;
  }
  
  public int calcMaxExpandColIndex()
  {
    int i = 0;
    int k = this.A.size();
    for (int j = 0; j < k; j++)
    {
      int m = ((CellData)this.A.get(j)).getEndColIndex();
      if (m > i) {
        i = m;
      }
    }
    return i;
  }
  
  public int calcMinExpandRowIndex()
  {
    int i = 0;
    int k = this.A.size();
    for (int j = 0; j < k; j++)
    {
      int m = ((CellData)this.A.get(j)).getCalcRowIndex();
      if (m < i) {
        i = m;
      }
    }
    return i;
  }
  
  public int calcMaxExpandRowIndex()
  {
    int i = 0;
    int k = this.A.size();
    for (int j = 0; j < k; j++)
    {
      int m = ((CellData)this.A.get(j)).getEndRowIndex();
      if (m > i) {
        i = m;
      }
    }
    return i;
  }
  
  public CellData getInitCell()
  {
    return this.B;
  }
  
  public List<CellData> getExpandedCells()
  {
    return this.A;
  }
  
  public void addData(CellData paramCellData)
  {
    this.A.add(paramCellData);
  }
  
  public void addDataList(List<CellData> paramList)
  {
    this.A.addAll(paramList);
  }
  
  public double sumAll(XptBuildRuntime paramXptBuildRuntime)
  {
    double d1 = 0.0D;
    int j = this.A.size();
    for (int i = 0; i < j; i++)
    {
      double d2 = Coercions.toDouble(((CellData)this.A.get(i)).evaluateCell(paramXptBuildRuntime), 0.0D);
      d1 += d2;
    }
    return d1;
  }
  
  public int countAll(XptBuildRuntime paramXptBuildRuntime)
  {
    return this.A.size();
  }
  
  public int countNotNull(XptBuildRuntime paramXptBuildRuntime)
  {
    int i = 0;
    int k = this.A.size();
    for (int j = 0; j < k; j++)
    {
      Object localObject = ((CellData)this.A.get(j)).evaluateCell(paramXptBuildRuntime);
      if (localObject != null) {
        i++;
      }
    }
    return i;
  }
  
  public int countAllNumber(XptBuildRuntime paramXptBuildRuntime)
  {
    int i = 0;
    int k = this.A.size();
    for (int j = 0; j < k; j++)
    {
      Object localObject = ((CellData)this.A.get(j)).evaluateCell(paramXptBuildRuntime);
      if ((localObject instanceof Number)) {
        i++;
      }
    }
    return i;
  }
  
  public List<Object> getAllValues(XptBuildRuntime paramXptBuildRuntime)
  {
    ArrayList localArrayList = new ArrayList(this.A.size());
    int j = this.A.size();
    for (int i = 0; i < j; i++)
    {
      Object localObject = ((CellData)this.A.get(i)).evaluateCell(paramXptBuildRuntime);
      localArrayList.add(localObject);
    }
    return localArrayList;
  }
  
  public double sumAllSameParent(CellData paramCellData, XptBuildRuntime paramXptBuildRuntime)
  {
    if ((paramCellData.isTopCell()) || (paramCellData == null)) {
      return sumAll(paramXptBuildRuntime);
    }
    double d1 = 0.0D;
    int j = this.A.size();
    for (int i = 0; i < j; i++)
    {
      CellData localCellData = (CellData)this.A.get(i);
      if (localCellData.hasSameParent(paramCellData))
      {
        double d2 = Coercions.toDouble(localCellData.evaluateCell(paramXptBuildRuntime), 0.0D);
        d1 += d2;
      }
    }
    return d1;
  }
  
  public Pair<Number, Number> sumAndCountAllSameParent(CellData paramCellData, XptBuildRuntime paramXptBuildRuntime)
  {
    if ((paramCellData.isTopCell()) || (paramCellData == null)) {
      return new Pair(Double.valueOf(sumAll(paramXptBuildRuntime)), Integer.valueOf(countAll(paramXptBuildRuntime)));
    }
    double d1 = 0.0D;
    int i = 0;
    int k = this.A.size();
    for (int j = 0; j < k; j++)
    {
      CellData localCellData = (CellData)this.A.get(j);
      if (localCellData.hasSameParent(paramCellData))
      {
        i++;
        double d2 = Coercions.toDouble(localCellData.evaluateCell(paramXptBuildRuntime), 0.0D);
        d1 += d2;
      }
    }
    return new Pair(Double.valueOf(d1), Integer.valueOf(i));
  }
  
  public int countAllSameParent(CellData paramCellData, XptBuildRuntime paramXptBuildRuntime)
  {
    if ((paramCellData == null) || (paramCellData.isTopCell())) {
      return countAll(paramXptBuildRuntime);
    }
    int i = 0;
    int k = this.A.size();
    for (int j = 0; j < k; j++)
    {
      CellData localCellData = (CellData)this.A.get(j);
      if (localCellData.hasSameParent(paramCellData)) {
        i++;
      }
    }
    return i;
  }
  
  public int countAllNumberSameParent(CellData paramCellData, XptBuildRuntime paramXptBuildRuntime)
  {
    if ((paramCellData == null) || (paramCellData.isTopCell())) {
      return countAll(paramXptBuildRuntime);
    }
    int i = 0;
    int k = this.A.size();
    for (int j = 0; j < k; j++)
    {
      CellData localCellData = (CellData)this.A.get(j);
      if (localCellData.hasSameParent(paramCellData))
      {
        Object localObject = localCellData.evaluateCell(paramXptBuildRuntime);
        if ((localObject instanceof Number)) {
          i++;
        }
      }
    }
    return i;
  }
  
  public int countNotNullSameParent(CellData paramCellData, XptBuildRuntime paramXptBuildRuntime)
  {
    if ((paramCellData == null) || (paramCellData.isTopCell())) {
      return countNotNull(paramXptBuildRuntime);
    }
    int i = 0;
    int k = this.A.size();
    for (int j = 0; j < k; j++)
    {
      CellData localCellData = (CellData)this.A.get(j);
      if (localCellData.hasSameParent(paramCellData))
      {
        Object localObject = localCellData.evaluateCell(paramXptBuildRuntime);
        if (localObject != null) {
          i++;
        }
      }
    }
    return i;
  }
  
  public void collectAllCellsSameParent(CellData paramCellData, XptBuildRuntime paramXptBuildRuntime, List<CellData> paramList)
  {
    if ((paramCellData == null) || (paramCellData.isTopCell()))
    {
      paramList.addAll(this.A);
      return;
    }
    int j = this.A.size();
    for (int i = 0; i < j; i++)
    {
      CellData localCellData = (CellData)this.A.get(i);
      if (localCellData.hasSameParent(paramCellData)) {
        paramList.add(localCellData);
      }
    }
  }
  
  public List<CellData> getAllCellsSameParent(CellData paramCellData, XptBuildRuntime paramXptBuildRuntime)
  {
    ArrayList localArrayList = new ArrayList();
    collectAllCellsSameParent(paramCellData, paramXptBuildRuntime, localArrayList);
    return localArrayList;
  }
  
  public List<Object> getExpandedValues(XptBuildRuntime paramXptBuildRuntime)
  {
    ArrayList localArrayList = new ArrayList(getExpandedCells().size());
    Iterator localIterator = getExpandedCells().iterator();
    while (localIterator.hasNext())
    {
      CellData localCellData = (CellData)localIterator.next();
      Object localObject = localCellData.evaluateCell(paramXptBuildRuntime);
      localArrayList.add(localObject);
    }
    return localArrayList;
  }
  
  public Object getFirstValueSameParent(CellData paramCellData, XptBuildRuntime paramXptBuildRuntime)
  {
    CellData localCellData = getFirstCellSameParent(paramCellData, paramXptBuildRuntime);
    if (localCellData == null) {
      return null;
    }
    return localCellData.evaluateCell(paramXptBuildRuntime);
  }
  
  public CellData getFirstCellSameParent(CellData paramCellData, XptBuildRuntime paramXptBuildRuntime)
  {
    int j = this.A.size();
    for (int i = 0; i < j; i++)
    {
      CellData localCellData = (CellData)this.A.get(i);
      if (paramCellData == null) {
        return localCellData;
      }
      if (localCellData.hasSameParent(paramCellData)) {
        return localCellData;
      }
    }
    return null;
  }
  
  public List<Object> getAllValuesSameParent(CellData paramCellData, XptBuildRuntime paramXptBuildRuntime)
  {
    if ((paramCellData == null) || (paramCellData.isTopCell())) {
      return getAllValues(paramXptBuildRuntime);
    }
    ArrayList localArrayList = new ArrayList();
    int j = this.A.size();
    for (int i = 0; i < j; i++)
    {
      CellData localCellData = (CellData)this.A.get(i);
      if (localCellData.hasSameParent(paramCellData))
      {
        Object localObject = localCellData.evaluateCell(paramXptBuildRuntime);
        localArrayList.add(localObject);
      }
    }
    return localArrayList;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\xpt\XptExpandCell.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */