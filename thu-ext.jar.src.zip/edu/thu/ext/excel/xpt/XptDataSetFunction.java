package edu.thu.ext.excel.xpt;

import edu.thu.ext.excel.model.data.CellData;
import edu.thu.model.data.IFunction;
import java.lang.reflect.Array;
import java.util.Map;

public abstract class XptDataSetFunction
  implements IFunction
{
  private static final long serialVersionUID = -8907767498120709049L;
  
  protected XptBuildRuntime getXptRt(Map paramMap)
  {
    return (XptBuildRuntime)paramMap.get("xptRt");
  }
  
  protected String getFieldName(Object paramObject)
  {
    return (String)Array.get(paramObject, 0);
  }
  
  protected CellData getCellData(Map paramMap)
  {
    return getXptRt(paramMap).getCellData();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\xpt\XptDataSetFunction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */