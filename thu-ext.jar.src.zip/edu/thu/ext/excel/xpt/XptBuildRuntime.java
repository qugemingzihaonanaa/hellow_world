package edu.thu.ext.excel.xpt;

import edu.thu.ext.excel.model.Cell;
import edu.thu.ext.excel.model.ImgData;
import edu.thu.ext.excel.model.Style;
import edu.thu.ext.excel.model.Table;
import edu.thu.ext.excel.model.Worksheet;
import edu.thu.ext.excel.model.WxReportConfig;
import edu.thu.ext.excel.model.data.CellData;
import edu.thu.ext.excel.model.data.WorksheetData;
import edu.thu.service.IServiceContext;
import java.util.Map;

public class XptBuildRuntime
{
  XptExpandTable K;
  int D;
  int C;
  int F;
  int B;
  Map<String, Object> H;
  CellData G;
  int L;
  int I;
  boolean E;
  WxReportConfig J;
  IServiceContext A;
  
  public XptBuildRuntime() {}
  
  public XptBuildRuntime(Table paramTable)
  {
    this.K = new XptExpandTable(paramTable);
  }
  
  public IServiceContext getContext()
  {
    return this.A;
  }
  
  public void setContext(IServiceContext paramIServiceContext)
  {
    this.A = paramIServiceContext;
  }
  
  public WorksheetData getWorkSheetData()
  {
    return (WorksheetData)this.H.get("worksheetData");
  }
  
  public Worksheet getWorksheet()
  {
    WorksheetData localWorksheetData = getWorkSheetData();
    if (localWorksheetData == null) {
      return null;
    }
    return localWorksheetData.getModel();
  }
  
  public WxReportConfig getWxReportConfig()
  {
    return this.J;
  }
  
  public void setWxReportConfig(WxReportConfig paramWxReportConfig)
  {
    this.J = paramWxReportConfig;
  }
  
  public Style mapStyle(String paramString)
  {
    if (this.J == null) {
      return null;
    }
    return this.J.getStyle(paramString);
  }
  
  public boolean isHasRemovedCell()
  {
    return this.E;
  }
  
  public void setHasRemovedCell(boolean paramBoolean)
  {
    this.E = paramBoolean;
  }
  
  public int getRootRowspan()
  {
    return this.L;
  }
  
  public void setRootRowspan(int paramInt)
  {
    this.L = paramInt;
  }
  
  public int getRootColspan()
  {
    return this.I;
  }
  
  public void setRootColspan(int paramInt)
  {
    this.I = paramInt;
  }
  
  public void incRootRowspan(int paramInt)
  {
    this.L += paramInt;
  }
  
  public void incRootColspan(int paramInt)
  {
    this.I += paramInt;
  }
  
  public CellData getC()
  {
    return this.G;
  }
  
  public CellData getCellData()
  {
    return this.G;
  }
  
  public void setCellData(CellData paramCellData)
  {
    this.G = paramCellData;
  }
  
  public CellData getHr()
  {
    return this.G == null ? null : this.G.getHr();
  }
  
  public CellData getVr()
  {
    return this.G == null ? null : this.G.getVr();
  }
  
  public CellData getHp()
  {
    return this.G == null ? null : this.G.getHorParent();
  }
  
  public CellData getVp()
  {
    return this.G == null ? null : this.G.getVerParent();
  }
  
  public Object getHpv()
  {
    CellData localCellData = getHp();
    return localCellData == null ? null : localCellData.evaluateCell(this);
  }
  
  public Object getHpe()
  {
    CellData localCellData = getHp();
    return localCellData == null ? null : localCellData.getExpandObj();
  }
  
  public Object getVpe()
  {
    CellData localCellData = getVp();
    return localCellData == null ? null : localCellData.getExpandObj();
  }
  
  public Object getVpv()
  {
    CellData localCellData = getVp();
    return localCellData == null ? null : localCellData.evaluateCell(this);
  }
  
  public Object getCellValue()
  {
    return this.G == null ? null : this.G.evaluateCell(this);
  }
  
  public Cell getCellModel()
  {
    return this.G == null ? null : this.G.getModel();
  }
  
  public Map<String, Object> getArgs()
  {
    return this.H;
  }
  
  public void setArgs(Map<String, Object> paramMap)
  {
    this.H = paramMap;
    this.H.put("xptRt", this);
  }
  
  public void incHorExpandLevel()
  {
    this.F += 1;
  }
  
  public void decHorExpandLevel()
  {
    this.F -= 1;
  }
  
  public void incVerExpandLevel()
  {
    this.B += 1;
  }
  
  public void decVerExpandLevel()
  {
    this.B -= 1;
  }
  
  public int getHorExpandLevel()
  {
    return this.F;
  }
  
  public void setHorExpandLevel(int paramInt)
  {
    this.F = paramInt;
  }
  
  public int getVerExpandLevel()
  {
    return this.B;
  }
  
  public void setVerExpandLevel(int paramInt)
  {
    this.B = paramInt;
  }
  
  public int getOffset(boolean paramBoolean)
  {
    return paramBoolean ? this.D : this.C;
  }
  
  public void setOffset(boolean paramBoolean, int paramInt)
  {
    if (paramBoolean) {
      this.D = paramInt;
    } else {
      this.C = paramInt;
    }
  }
  
  public int getHorOffset()
  {
    return this.D;
  }
  
  public void setHorOffset(int paramInt)
  {
    this.D = paramInt;
  }
  
  public int getVerOffset()
  {
    return this.C;
  }
  
  public void setVerOffset(int paramInt)
  {
    this.C = paramInt;
  }
  
  public void incHorOffset(int paramInt)
  {
    this.D += paramInt;
  }
  
  public void incVerOffset(int paramInt)
  {
    this.C += paramInt;
  }
  
  public XptExpandTable getExpandTable()
  {
    return this.K;
  }
  
  public void setExpandTable(XptExpandTable paramXptExpandTable)
  {
    this.K = paramXptExpandTable;
  }
  
  public ImgData newImg()
  {
    ImgData localImgData = this.G.getSheet().newImg();
    localImgData.setRow1(this.G.getCalcRowIndex() - 1);
    localImgData.setCol1(this.G.getCalcColIndex() - 1);
    localImgData.setRow2(localImgData.getRow1() + this.G.getRowspan());
    localImgData.setCol2(localImgData.getCol1() + this.G.getColspan());
    return localImgData;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\xpt\XptBuildRuntime.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */