package edu.thu.ext.excel.xpt;

import java.util.Collection;

public class XptDataSet
{
  public static Object s_getFieldValue(String paramString1, String paramString2, XptBuildRuntime paramXptBuildRuntime)
  {
    return null;
  }
  
  public static Collection s_groupFieldValue(String paramString1, String paramString2, XptBuildRuntime paramXptBuildRuntime)
  {
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\xpt\XptDataSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */