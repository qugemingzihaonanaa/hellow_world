package edu.thu.ext.excel.xpt;

import edu.thu.ext.excel.model.Cell;
import edu.thu.ext.excel.model.Column;
import edu.thu.ext.excel.model.ExcelModelConstants;
import edu.thu.ext.excel.model.Row;
import edu.thu.ext.excel.model.Table;
import edu.thu.ext.excel.model.data.CellData;
import edu.thu.ext.excel.model.data.RootCellData;
import edu.thu.ext.excel.model.data.RowData;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.exceptions.StdException;
import java.util.ArrayList;
import java.util.List;

public class XptExpandTable
  implements ExcelModelConstants
{
  List<List<XptExpandCell>> I;
  List<CellData> D = new ArrayList();
  Table E;
  CellData J;
  CellData F;
  List<Column> H = new ArrayList();
  List<RowData> G = new ArrayList();
  
  public XptExpandTable(Table paramTable)
  {
    A(paramTable);
  }
  
  public List<Column> getCols()
  {
    return this.H;
  }
  
  public void setCols(List<Column> paramList)
  {
    this.H = paramList;
  }
  
  public List<RowData> getRows()
  {
    return this.G;
  }
  
  public void setRows(List<RowData> paramList)
  {
    this.G = paramList;
  }
  
  public void addCol(int paramInt1, int paramInt2)
  {
    for (int i = 0; i < paramInt2; i++)
    {
      Column localColumn = this.E.getCol(paramInt1 - 1 + i);
      if (localColumn == null) {
        throw Exceptions.code("excel.CAN_err_invalid_col").param(paramInt1 - 1 + i).param(this.E);
      }
      this.H.add(localColumn);
    }
  }
  
  public void addRow(int paramInt1, int paramInt2)
  {
    for (int i = 0; i < paramInt2; i++)
    {
      Row localRow = (Row)this.E.getRow(paramInt1 - 1 + i);
      if (localRow == null) {
        throw Exceptions.code("excel.CAN_err_invalid_row").param(paramInt1 - 1 + i).param(this.E);
      }
      this.G.add(new RowData(localRow));
    }
  }
  
  public CellData getHorRoot()
  {
    return this.J;
  }
  
  public CellData getVerRoot()
  {
    return this.F;
  }
  
  void A(Table paramTable)
  {
    this.E = paramTable;
    this.J = new RootCellData(paramTable.getHorRoot());
    this.F = new RootCellData(paramTable.getVerRoot());
    List localList = paramTable.getRows();
    int j = localList.size();
    this.I = new ArrayList(j);
    int k = paramTable.getColCount();
    int n;
    for (int i = 0; i < j; i++)
    {
      ArrayList localArrayList = new ArrayList(k);
      for (n = 0; n < k; n++) {
        localArrayList.add(null);
      }
      this.I.add(localArrayList);
    }
    for (i = 0; i < j; i++)
    {
      n = k;
      for (int m = 0; m < n; m++)
      {
        CellData localCellData1 = A(i, m);
        if (localCellData1 != null)
        {
          CellData localCellData2 = localCellData1.getRealCell();
          CellData localCellData3 = A(localCellData2.getModel().getHorParent());
          CellData localCellData4 = A(localCellData2.getModel().getVerParent());
          localCellData3.addHorChild(localCellData2);
          localCellData4.addVerChild(localCellData2);
          if (localCellData2.isTopCell()) {
            this.D.add(localCellData2);
          }
        }
      }
    }
  }
  
  CellData A(Cell paramCell)
  {
    if (paramCell == this.E.getHorRoot()) {
      return this.J;
    }
    if (paramCell == this.E.getVerRoot()) {
      return this.F;
    }
    return A(paramCell.getRowIndex() - 1, paramCell.getIndex() - 1);
  }
  
  CellData A(int paramInt1, int paramInt2)
  {
    Cell localCell = this.E.getCell(paramInt1, paramInt2);
    if (localCell.isIgnored()) {
      return null;
    }
    List localList = (List)this.I.get(paramInt1);
    XptExpandCell localXptExpandCell = (XptExpandCell)localList.get(paramInt2);
    if (localXptExpandCell == null)
    {
      localXptExpandCell = new XptExpandCell(new CellData(localCell));
      localList.set(paramInt2, localXptExpandCell);
    }
    return localXptExpandCell.getInitCell();
  }
  
  public int calcMaxExpandColIndex(int paramInt)
  {
    int i = 0;
    int k = this.I.size();
    for (int j = 0; j < k; j++)
    {
      List localList = (List)this.I.get(j);
      if (paramInt < localList.size())
      {
        XptExpandCell localXptExpandCell = (XptExpandCell)localList.get(paramInt);
        if (localXptExpandCell == null)
        {
          Cell localCell = this.E.getCell(j, paramInt);
          if (!localCell.isAtMergeTopRight()) {
            continue;
          }
          localXptExpandCell = (XptExpandCell)localList.get(localCell.getRealCell().getColPos());
        }
        else
        {
          if ((localXptExpandCell.getInitCell() != null) && (!localXptExpandCell.getInitCell().getModel().isAtMergeTopRight())) {
            continue;
          }
        }
        if ((localXptExpandCell.getInitCell() == null) || (!localXptExpandCell.getInitCell().isHorRemoved()))
        {
          i = localXptExpandCell.calcMaxExpandColIndex();
          if (i != 0) {
            break;
          }
        }
      }
    }
    return i;
  }
  
  public int calcMaxExpandRowIndex(int paramInt)
  {
    if (this.I.size() <= paramInt) {
      return 0;
    }
    int i = 0;
    List localList = (List)this.I.get(paramInt);
    int k = localList.size();
    for (int j = 0; j < k; j++)
    {
      XptExpandCell localXptExpandCell = (XptExpandCell)localList.get(j);
      if (localXptExpandCell == null)
      {
        Cell localCell = this.E.getCell(paramInt, j);
        if (localCell.isAtMergeBottomLeft()) {
          localXptExpandCell = (XptExpandCell)((List)this.I.get(localCell.getRealCell().getRowPos())).get(j);
        }
      }
      else if ((localXptExpandCell.getInitCell() == null) || (!localXptExpandCell.getInitCell().isVerRemoved()))
      {
        i = localXptExpandCell.calcMaxExpandRowIndex();
        if (i != 0) {
          break;
        }
      }
    }
    return i;
  }
  
  public XptExpandCell getExpandCell(int paramInt1, int paramInt2)
  {
    if ((paramInt1 < 0) || (paramInt1 >= this.I.size())) {
      return null;
    }
    List localList = (List)this.I.get(paramInt1);
    if ((paramInt2 < 0) || (paramInt2 >= localList.size())) {
      return null;
    }
    return (XptExpandCell)localList.get(paramInt2);
  }
  
  public List<List<XptExpandCell>> getExpandRows()
  {
    return this.I;
  }
  
  public List<CellData> getRootExpandCells()
  {
    return this.D;
  }
  
  public void addExpandData(CellData paramCellData)
  {
    XptExpandCell localXptExpandCell = getExpandCell(paramCellData.getModelRowIdx(), paramCellData.getModelColIdx());
    localXptExpandCell.addData(paramCellData);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\xpt\XptExpandTable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */