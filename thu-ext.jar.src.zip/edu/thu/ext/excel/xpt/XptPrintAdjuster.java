package edu.thu.ext.excel.xpt;

import edu.thu.ext.excel.model.IRow;
import edu.thu.ext.excel.model.NamedRange;
import edu.thu.ext.excel.model.Names;
import edu.thu.ext.excel.model.Range;
import edu.thu.ext.excel.model.Row;
import edu.thu.ext.excel.model.Worksheet;
import edu.thu.ext.excel.model.data.RowData;
import edu.thu.ext.excel.model.data.TableData;
import edu.thu.ext.excel.model.data.WorksheetData;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class XptPrintAdjuster
{
  public void adjustForPrint(WorksheetData paramWorksheetData)
  {
    A(paramWorksheetData);
    B(paramWorksheetData);
  }
  
  void B(WorksheetData paramWorksheetData)
  {
    Names localNames = new Names();
    NamedRange localNamedRange = paramWorksheetData.getModel().getNamedRange("Print_Titles");
    if (localNamedRange != null) {
      localNames.addRange(localNamedRange);
    }
    paramWorksheetData.setNames(localNames);
  }
  
  void A(WorksheetData paramWorksheetData)
  {
    Worksheet localWorksheet = paramWorksheetData.getModel();
    NamedRange localNamedRange1 = localWorksheet.getNamedRange("Print_Area");
    NamedRange localNamedRange2 = localWorksheet.getNamedRange("Print_Titles");
    NamedRange localNamedRange3 = localWorksheet.getNamedRange("padding");
    if ((localNamedRange1 == null) || (localNamedRange3 == null)) {
      return;
    }
    double d1 = A(localWorksheet, localNamedRange1);
    double d2 = localNamedRange2 == null ? 0.0D : A(localWorksheet, localNamedRange2);
    double d3 = A(localWorksheet, localNamedRange3);
    ArrayList localArrayList = new ArrayList();
    for (int i = A(paramWorksheetData, 0, d1, localArrayList); paramWorksheetData.getRow(i) != null; i = A(paramWorksheetData, i, d1 - d2, localArrayList)) {}
    double d4 = ((Double)localArrayList.get(localArrayList.size() - 1)).doubleValue();
    if (d4 < d3) {
      B(paramWorksheetData, d4);
    } else {
      A(paramWorksheetData, d1 - d2 - d4);
    }
  }
  
  int A(WorksheetData paramWorksheetData, int paramInt, double paramDouble, List<Double> paramList)
  {
    int i = paramInt;
    double d = 0.0D;
    for (;;)
    {
      RowData localRowData = paramWorksheetData.getRow(i);
      if ((localRowData == null) || (d + localRowData.getHeight() > paramDouble + 5.0E-4D)) {
        break;
      }
      d += localRowData.getHeight();
      i++;
    }
    paramList.add(Double.valueOf(d));
    return i;
  }
  
  void B(WorksheetData paramWorksheetData, double paramDouble)
  {
    List localList = A(paramWorksheetData.getModel());
    int i = paramWorksheetData.getRowCount();
    double d = 0.0D;
    for (int j = i - 1; j >= 0; j--)
    {
      RowData localRowData = paramWorksheetData.getRow(j);
      if (A(localRowData.getModel(), localList))
      {
        if (d + localRowData.getHeight() > paramDouble + 5.0E-4D) {
          return;
        }
        d += localRowData.getHeight();
        paramWorksheetData.getTable().removeRow(j, true);
      }
    }
  }
  
  void A(WorksheetData paramWorksheetData, double paramDouble)
  {
    List localList = A(paramWorksheetData.getModel());
    int j = paramWorksheetData.getRowCount();
    for (int i = j - 1; i >= 0; i--)
    {
      localRowData = paramWorksheetData.getRow(i);
      if (A(localRowData.getModel(), localList)) {
        break;
      }
    }
    RowData localRowData = paramWorksheetData.getRow(i);
    for (double d = 0.0D;; d += localRowData.getHeight())
    {
      if (d + localRowData.getHeight() > paramDouble + 5.0E-4D) {
        return;
      }
      paramWorksheetData.getTable().extendRow(i);
    }
  }
  
  double A(Worksheet paramWorksheet, NamedRange paramNamedRange)
  {
    double d = 0.0D;
    Iterator localIterator = paramWorksheet.getRows().iterator();
    while (localIterator.hasNext())
    {
      Row localRow = (Row)localIterator.next();
      if (A(localRow, paramNamedRange.getRanges())) {
        d += localRow.getHeight();
      }
    }
    return d;
  }
  
  List<Range> A(Worksheet paramWorksheet)
  {
    List localList = paramWorksheet.getNamedRanges("padding");
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      NamedRange localNamedRange = (NamedRange)localIterator.next();
      localArrayList.addAll(localNamedRange.getRanges());
    }
    return localArrayList;
  }
  
  boolean A(IRow paramIRow, List<Range> paramList)
  {
    int i = paramIRow.getIndex() - 1;
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      Range localRange = (Range)localIterator.next();
      if (localRange.containsRow(i)) {
        return true;
      }
    }
    return false;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\xpt\XptPrintAdjuster.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */