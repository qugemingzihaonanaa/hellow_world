package edu.thu.ext.excel.xpt;

import edu.thu.config.AppConfig;
import edu.thu.ext.excel.WxReportRenderer;
import edu.thu.ext.excel.model.Cell;
import edu.thu.ext.excel.model.CellBandModel;
import edu.thu.ext.excel.model.CellExpandModel;
import edu.thu.ext.excel.model.ExcelModelConstants;
import edu.thu.ext.excel.model.SheetConfig;
import edu.thu.ext.excel.model.SheetConfig.Item;
import edu.thu.ext.excel.model.Table;
import edu.thu.ext.excel.model.Workbook;
import edu.thu.ext.excel.model.Worksheet;
import edu.thu.ext.excel.model.WorksheetOptions;
import edu.thu.ext.excel.model.WxReportConfig;
import edu.thu.ext.excel.model.data.CellData;
import edu.thu.ext.excel.model.data.ICellHandle;
import edu.thu.ext.excel.model.data.IgnoreCellHandle;
import edu.thu.ext.excel.model.data.RowData;
import edu.thu.ext.excel.model.data.TableData;
import edu.thu.ext.excel.model.data.WorkbookData;
import edu.thu.ext.excel.model.data.WorksheetData;
import edu.thu.ext.excel.model.formula.CellFormula;
import edu.thu.ext.excel.model.formula.ICellFormulaExpandSupport;
import edu.thu.java.util.Coercions;
import edu.thu.lang.IVariant;
import edu.thu.lang.util.ITplReference;
import edu.thu.lang.util.TplC;
import edu.thu.model.stg.view.PageMaker.PageIterator;
import edu.thu.service.IServiceContext;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class XptExpander
  implements ExcelModelConstants
{
  static final Logger A = LoggerFactory.getLogger(XptExpander.class);
  WxReportRenderer C;
  boolean B = AppConfig.var("xpt.evaluate_row_by_row").booleanValue(true);
  
  public WorkbookData expandWorkbook(Workbook paramWorkbook, Map<String, Object> paramMap, IServiceContext paramIServiceContext)
  {
    paramMap.put("workbookModel", paramWorkbook);
    WorkbookData localWorkbookData = new WorkbookData(paramWorkbook);
    paramMap.put("workbookData", localWorkbookData);
    WxReportConfig localWxReportConfig = paramWorkbook.getWxReportConfig();
    if ((localWxReportConfig != null) && (localWxReportConfig.getBeforeExpandTpl() != null)) {
      TplC.runTpl(localWxReportConfig.getBeforeExpandTpl(), paramMap, paramIServiceContext);
    }
    Object localObject1 = TplC.getToken(paramMap, "varsList");
    if (localObject1 != null)
    {
      Iterator localIterator = TplC.getCollectionIterator(localObject1);
      while (localIterator.hasNext())
      {
        Object localObject2 = localIterator.next();
        if ((localObject2 instanceof Map)) {
          paramMap.putAll((Map)localObject2);
        } else {
          paramMap.put("_varsListItem", localObject2);
        }
        A(paramWorkbook, "beforeSheetsTpl", paramMap, paramIServiceContext);
        A(paramWorkbook, localWorkbookData, paramMap, paramIServiceContext);
        A(paramWorkbook, "afterSheetsTpl", paramMap, paramIServiceContext);
      }
    }
    else
    {
      A(paramWorkbook, "beforeSheetsTpl", paramMap, paramIServiceContext);
      A(paramWorkbook, localWorkbookData, paramMap, paramIServiceContext);
      A(paramWorkbook, "afterSheetsTpl", paramMap, paramIServiceContext);
    }
    if ((localWxReportConfig != null) && (localWxReportConfig.getAfterExpandTpl() != null)) {
      TplC.runTpl(localWxReportConfig.getAfterExpandTpl(), paramMap, paramIServiceContext);
    }
    return localWorkbookData;
  }
  
  void A(Workbook paramWorkbook, WorkbookData paramWorkbookData, Map<String, Object> paramMap, IServiceContext paramIServiceContext)
  {
    WxReportConfig localWxReportConfig = paramWorkbook.getWxReportConfig();
    if ((localWxReportConfig != null) && (localWxReportConfig.getPageMaker() != null))
    {
      this.C = new WxReportRenderer(localWxReportConfig);
      this.C.initPageMakers(paramMap);
    }
    Iterator localIterator = paramWorkbook.getWorksheets().iterator();
    while (localIterator.hasNext())
    {
      Worksheet localWorksheet = (Worksheet)localIterator.next();
      B(localWorksheet, paramWorkbookData, paramMap, paramIServiceContext);
    }
  }
  
  void A(Workbook paramWorkbook, String paramString, Map<String, Object> paramMap, IServiceContext paramIServiceContext)
  {
    ITplReference localITplReference = paramWorkbook.getWxReportConfig().getTpl(paramString);
    if (localITplReference != null) {
      TplC.runTpl(localITplReference, paramMap, paramIServiceContext);
    }
  }
  
  SheetConfig.Item A(Worksheet paramWorksheet)
  {
    WxReportConfig localWxReportConfig = paramWorksheet.getWorkbook().getWxReportConfig();
    if (localWxReportConfig == null) {
      return null;
    }
    return localWxReportConfig.getSheetConfig().getItem(paramWorksheet.getNormalName());
  }
  
  ITplReference C(Worksheet paramWorksheet)
  {
    WxReportConfig localWxReportConfig = paramWorksheet.getWorkbook().getWxReportConfig();
    if (localWxReportConfig == null) {
      return null;
    }
    return localWxReportConfig.getSheetLoopVarTpl(paramWorksheet.getNormalName());
  }
  
  ITplReference B(Worksheet paramWorksheet)
  {
    WxReportConfig localWxReportConfig = paramWorksheet.getWorkbook().getWxReportConfig();
    if (localWxReportConfig == null) {
      return null;
    }
    return localWxReportConfig.getSheetNameTpl(paramWorksheet.getNormalName());
  }
  
  XptBuildRuntime A(Worksheet paramWorksheet, WorkbookData paramWorkbookData, Map<String, Object> paramMap, IServiceContext paramIServiceContext)
  {
    WorksheetData localWorksheetData = new WorksheetData(paramWorksheet, paramWorkbookData);
    paramMap.put("worksheetData", localWorksheetData);
    XptBuildRuntime localXptBuildRuntime = new XptBuildRuntime(paramWorksheet.getTable());
    localXptBuildRuntime.setWxReportConfig(paramWorksheet.getWxReportConfig());
    localXptBuildRuntime.setArgs(paramMap);
    localXptBuildRuntime.setContext(paramIServiceContext);
    return localXptBuildRuntime;
  }
  
  boolean A(XptBuildRuntime paramXptBuildRuntime)
  {
    SheetConfig.Item localItem = A(paramXptBuildRuntime.getWorksheet());
    if ((localItem != null) && (localItem.getTestTpl() != null))
    {
      Object localObject = TplC.runTpl(localItem.getTestTpl(), paramXptBuildRuntime.getArgs(), paramXptBuildRuntime.getContext());
      if (!Coercions.toBoolean(localObject, true))
      {
        A.info("xpt.CAN_sheet_test_fail::" + paramXptBuildRuntime.getWorksheet());
        return false;
      }
    }
    return true;
  }
  
  public WorksheetData expandWorksheet(Worksheet paramWorksheet, WorkbookData paramWorkbookData, Map<String, Object> paramMap, IServiceContext paramIServiceContext)
  {
    XptBuildRuntime localXptBuildRuntime = A(paramWorksheet, paramWorkbookData, paramMap, paramIServiceContext);
    if (!A(localXptBuildRuntime)) {
      return null;
    }
    SheetConfig.Item localItem = A(paramWorksheet);
    A(localItem, localXptBuildRuntime);
    return localXptBuildRuntime.getWorkSheetData();
  }
  
  void B(Worksheet paramWorksheet, WorkbookData paramWorkbookData, Map<String, Object> paramMap, IServiceContext paramIServiceContext)
  {
    XptBuildRuntime localXptBuildRuntime = A(paramWorksheet, paramWorkbookData, paramMap, paramIServiceContext);
    if (!A(localXptBuildRuntime)) {
      return;
    }
    SheetConfig.Item localItem = A(paramWorksheet);
    ITplReference localITplReference = C(paramWorksheet);
    if (localITplReference == null)
    {
      A(localItem, localXptBuildRuntime, paramWorkbookData);
    }
    else
    {
      Object localObject1 = TplC.runTpl(localITplReference, paramMap, paramIServiceContext);
      Iterator localIterator = TplC.getCollectionIterator(localObject1);
      if (localIterator != null)
      {
        int i = 0;
        while (localIterator.hasNext())
        {
          Object localObject2 = localIterator.next();
          paramMap.put("sheetLoopVar", localObject2);
          paramMap.put("sheetLoopIndex", Integer.valueOf(i));
          i++;
          localXptBuildRuntime = A(paramWorksheet, paramWorkbookData, paramMap, paramIServiceContext);
          A(localItem, localXptBuildRuntime, paramWorkbookData);
        }
      }
    }
  }
  
  void A(SheetConfig.Item paramItem, XptBuildRuntime paramXptBuildRuntime, WorkbookData paramWorkbookData)
  {
    if (this.C != null)
    {
      Map localMap = paramXptBuildRuntime.getArgs();
      IServiceContext localIServiceContext = paramXptBuildRuntime.getContext();
      if (this.C.enterSheet(paramXptBuildRuntime.getWorksheet().getNormalName(), localMap, localIServiceContext))
      {
        String str1 = (String)localMap.get("_pageType");
        String str2 = (String)localMap.get("_pageVarName");
        WorksheetData localWorksheetData = paramXptBuildRuntime.getWorkSheetData();
        PageMaker.PageIterator localPageIterator = null;
        if ("single".equals(str1)) {
          localPageIterator = (PageMaker.PageIterator)localMap.get("_pageSingleIt");
        } else if ("middle".equals(str1)) {
          localPageIterator = (PageMaker.PageIterator)localMap.get("_pageMiddleIt");
        }
        if (localPageIterator != null) {
          while (localPageIterator.hasNext())
          {
            Object localObject = localPageIterator.next();
            if (((List)localObject).size() < localPageIterator.getPageEndCount())
            {
              ArrayList localArrayList = new ArrayList((Collection)localObject);
              for (int i = ((List)localObject).size(); i < localPageIterator.getPageEndCount(); i++) {
                localArrayList.add(null);
              }
              localObject = localArrayList;
            }
            localMap.put(str2, localObject);
            localMap.put("_currentPage", Integer.valueOf(localPageIterator.getCurrentPage()));
            A(paramItem, paramXptBuildRuntime);
            if (paramXptBuildRuntime.getWorkSheetData() != localWorksheetData) {
              localWorksheetData.mergeWorksheetData(paramXptBuildRuntime.getWorkSheetData(), true);
            }
            if (localPageIterator.hasNext()) {
              paramXptBuildRuntime = A(paramXptBuildRuntime.getWorksheet(), paramWorkbookData, localMap, localIServiceContext);
            }
          }
        } else {
          A(paramItem, paramXptBuildRuntime);
        }
        paramWorkbookData.addSheetWithUniqueName(localWorksheetData);
      }
    }
    else
    {
      A(paramItem, paramXptBuildRuntime);
      paramWorkbookData.addSheetWithUniqueName(paramXptBuildRuntime.getWorkSheetData());
    }
  }
  
  void A(SheetConfig.Item paramItem, XptBuildRuntime paramXptBuildRuntime)
  {
    Map localMap = paramXptBuildRuntime.getArgs();
    IServiceContext localIServiceContext = paramXptBuildRuntime.getContext();
    WorksheetData localWorksheetData = paramXptBuildRuntime.getWorkSheetData();
    Worksheet localWorksheet = localWorksheetData.getModel();
    if ((paramItem != null) && (paramItem.getBeforeExpandTpl() != null)) {
      TplC.runTpl(paramItem.getBeforeExpandTpl(), localMap, localIServiceContext);
    }
    TableData localTableData = localWorksheetData.getTable();
    localTableData.setHorRoot(paramXptBuildRuntime.getExpandTable().getHorRoot());
    localTableData.setVerRoot(paramXptBuildRuntime.getExpandTable().getVerRoot());
    if (localWorksheet.getTable().getColCount() > 0)
    {
      B(paramXptBuildRuntime.getExpandTable().getVerRoot(), paramXptBuildRuntime);
      paramXptBuildRuntime.setVerOffset(0);
      D(localTableData.getVerRoot(), paramXptBuildRuntime);
      A(paramXptBuildRuntime.getExpandTable().getHorRoot(), paramXptBuildRuntime);
      paramXptBuildRuntime.setHorOffset(0);
      E(localTableData.getHorRoot(), paramXptBuildRuntime);
      if (this.B) {
        A(localTableData, paramXptBuildRuntime);
      } else {
        B(localTableData, paramXptBuildRuntime);
      }
    }
    XptExtProcessor.getInstance().process(paramXptBuildRuntime);
    new XptPrintAdjuster().adjustForPrint(localWorksheetData);
    A(localWorksheetData, paramXptBuildRuntime);
    if ((paramItem != null) && (paramItem.getAfterExpandTpl() != null)) {
      TplC.runTpl(paramItem.getAfterExpandTpl(), localMap, localIServiceContext);
    }
    ITplReference localITplReference = B(localWorksheet);
    if (localITplReference != null)
    {
      String str = Coercions.toString(TplC.runTpl(localITplReference, localMap, localIServiceContext), null);
      if (str != null) {
        localWorksheetData.setWorksheetName(str);
      }
    }
  }
  
  void A(WorksheetData paramWorksheetData, XptBuildRuntime paramXptBuildRuntime)
  {
    WorksheetOptions localWorksheetOptions1 = paramWorksheetData.getWorksheetOptions();
    if (localWorksheetOptions1 != null)
    {
      WorksheetOptions localWorksheetOptions2 = localWorksheetOptions1.copy();
      int i;
      if (localWorksheetOptions1.getSplitHorizontal() > 0)
      {
        i = paramXptBuildRuntime.getExpandTable().calcMaxExpandRowIndex(localWorksheetOptions1.getSplitHorizontal() - 1);
        localWorksheetOptions2.setSplitHorizontal(i);
      }
      if (localWorksheetOptions1.getSplitVertical() > 0)
      {
        i = paramXptBuildRuntime.getExpandTable().calcMaxExpandColIndex(localWorksheetOptions1.getSplitVertical() - 1);
        localWorksheetOptions2.setSplitVertical(i);
      }
      paramWorksheetData.setWorksheetOptions(localWorksheetOptions2);
    }
  }
  
  int E(CellData paramCellData, XptBuildRuntime paramXptBuildRuntime)
  {
    if (paramCellData.isHorRemoved()) {
      return 0;
    }
    List localList1 = paramCellData.getHorChildren();
    if ((localList1 == null) || (localList1.isEmpty()))
    {
      A(paramCellData, paramXptBuildRuntime.getHorOffset() + 1, paramXptBuildRuntime.getExpandTable());
      paramXptBuildRuntime.getExpandTable().addRow(paramCellData.getModel().getRowIndex(), paramCellData.getRowspan());
      return paramCellData.getRowspan();
    }
    List localList2 = paramCellData.getExpandModel().getHorBandModels();
    int i = paramXptBuildRuntime.getHorOffset();
    int k = localList2.size();
    int m = 0;
    int n = 0;
    int i1 = -1;
    for (int j = 0; j < k; j++)
    {
      int i2 = paramXptBuildRuntime.getHorOffset();
      CellBandModel localCellBandModel = (CellBandModel)localList2.get(j);
      int i3 = localCellBandModel.getBranchCellPos();
      int i4 = 0;
      Object localObject;
      if (i3 >= 0)
      {
        CellData localCellData1 = (CellData)localList1.get(i3);
        int i6;
        if (localCellData1.isHorRemoved())
        {
          i4 = 0;
        }
        else if ((localCellData1.getModel().isExpandVer()) && (localCellData1.getExpandedCells() != null))
        {
          Iterator localIterator2 = localCellData1.getExpandedCells().iterator();
          while (localIterator2.hasNext())
          {
            CellData localCellData2 = (CellData)localIterator2.next();
            int i8 = E(localCellData2, paramXptBuildRuntime);
            paramXptBuildRuntime.incHorOffset(i8);
            i4 += i8;
          }
        }
        else
        {
          i6 = E(localCellData1, paramXptBuildRuntime);
          i4 += i6;
        }
        if (localCellBandModel.getSiblingPosList() != null)
        {
          i6 = i4 - localCellBandModel.getWidth();
          Iterator localIterator3 = localCellBandModel.getSiblingPosList().iterator();
          while (localIterator3.hasNext())
          {
            int i7 = ((Integer)localIterator3.next()).intValue();
            CellData localCellData3 = (CellData)localList1.get(i7);
            B(localCellData3, i6);
          }
        }
        if ((i4 == 0) && (localCellBandModel.getSamePosList() != null))
        {
          localObject = localCellBandModel.getSamePosList().iterator();
          while (((Iterator)localObject).hasNext())
          {
            i6 = ((Integer)((Iterator)localObject).next()).intValue();
            ((CellData)localList1.get(i6)).setHorRemoved(true);
          }
        }
      }
      else
      {
        i4 = localCellBandModel.getWidth();
        paramXptBuildRuntime.getExpandTable().addRow(localCellBandModel.getIndex(), i4);
      }
      if (localCellBandModel.getPosList() != null)
      {
        Iterator localIterator1 = localCellBandModel.getPosList().iterator();
        while (localIterator1.hasNext())
        {
          int i5 = ((Integer)localIterator1.next()).intValue();
          paramXptBuildRuntime.setHorOffset(i2);
          localObject = (CellData)localList1.get(i5);
          A((CellData)localObject, i2 + 1, paramXptBuildRuntime.getExpandTable());
        }
      }
      paramXptBuildRuntime.setHorOffset(i2 + i4);
      if (localCellBandModel.isAlignWithParent())
      {
        n += i4;
        if (i1 < 0) {
          i1 = i2;
        }
      }
      m += i4;
    }
    paramCellData.setMergeDown(n - 1);
    paramCellData.setCalcRowIndex(i1 + 1);
    if (n == 0) {
      paramCellData.setHorRemoved(true);
    } else if (!paramCellData.isVirtualRoot()) {
      paramXptBuildRuntime.getExpandTable().addExpandData(paramCellData);
    }
    paramXptBuildRuntime.setHorOffset(i);
    return m;
  }
  
  void B(CellData paramCellData, int paramInt)
  {
    if (paramCellData.getVerCopyCells() != null)
    {
      paramCellData.incRowspan(paramInt);
      Iterator localIterator = paramCellData.getVerCopyCells().iterator();
      while (localIterator.hasNext())
      {
        CellData localCellData = (CellData)localIterator.next();
        localCellData.incRowspan(paramInt);
      }
    }
    else
    {
      paramCellData.incRowspan(paramInt);
    }
  }
  
  void A(CellData paramCellData, int paramInt)
  {
    if ((paramCellData.getModel().isExpandVer()) && (paramCellData.getExpandedCells() != null))
    {
      Iterator localIterator = paramCellData.getExpandedCells().iterator();
      while (localIterator.hasNext())
      {
        CellData localCellData = (CellData)localIterator.next();
        localCellData.incColspan(paramInt);
      }
    }
    else
    {
      paramCellData.incColspan(paramInt);
    }
  }
  
  void C(CellData paramCellData, int paramInt)
  {
    if ((paramCellData.getModel().isExpandVer()) && (paramCellData.getExpandedCells() != null))
    {
      Iterator localIterator = paramCellData.getExpandedCells().iterator();
      while (localIterator.hasNext())
      {
        CellData localCellData = (CellData)localIterator.next();
        localCellData.setIndex(paramInt);
      }
    }
    else
    {
      paramCellData.setIndex(paramInt);
    }
  }
  
  void A(CellData paramCellData, int paramInt, XptExpandTable paramXptExpandTable)
  {
    if (paramCellData.getVerCopyCells() != null)
    {
      Iterator localIterator = paramCellData.getVerCopyCells().iterator();
      while (localIterator.hasNext())
      {
        CellData localCellData = (CellData)localIterator.next();
        localCellData.setCalcRowIndex(paramInt);
        if (!localCellData.isRemoved()) {
          paramXptExpandTable.addExpandData(localCellData);
        }
      }
    }
    else
    {
      paramCellData.setCalcRowIndex(paramInt);
      if (!paramCellData.isRemoved()) {
        paramXptExpandTable.addExpandData(paramCellData);
      }
    }
  }
  
  int D(CellData paramCellData, XptBuildRuntime paramXptBuildRuntime)
  {
    if (paramCellData.isVerRemoved()) {
      return 0;
    }
    List localList1 = paramCellData.getVerChildren();
    if ((localList1 == null) || (localList1.isEmpty()))
    {
      C(paramCellData, paramXptBuildRuntime.getVerOffset() + 1);
      paramXptBuildRuntime.getExpandTable().addCol(paramCellData.getModel().getIndex(), paramCellData.getColspan());
      return paramCellData.getColspan();
    }
    List localList2 = paramCellData.getExpandModel().getVerBandModels();
    int i = paramXptBuildRuntime.getVerOffset();
    int k = localList2.size();
    int m = 0;
    int n = 0;
    int i1 = -1;
    for (int j = 0; j < k; j++)
    {
      int i2 = paramXptBuildRuntime.getVerOffset();
      CellBandModel localCellBandModel = (CellBandModel)localList2.get(j);
      int i3 = localCellBandModel.getBranchCellPos();
      int i4 = 0;
      Object localObject;
      if (i3 >= 0)
      {
        CellData localCellData1 = (CellData)localList1.get(i3);
        int i6;
        if (localCellData1.isVerRemoved())
        {
          i4 = 0;
        }
        else if ((localCellData1.getModel().isExpandHor()) && (localCellData1.getExpandedCells() != null))
        {
          Iterator localIterator2 = localCellData1.getExpandedCells().iterator();
          while (localIterator2.hasNext())
          {
            CellData localCellData2 = (CellData)localIterator2.next();
            int i8 = D(localCellData2, paramXptBuildRuntime);
            paramXptBuildRuntime.incVerOffset(i8);
            i4 += i8;
          }
        }
        else
        {
          i6 = D(localCellData1, paramXptBuildRuntime);
          i4 += i6;
        }
        if (localCellBandModel.getSiblingPosList() != null)
        {
          i6 = i4 - localCellBandModel.getWidth();
          Iterator localIterator3 = localCellBandModel.getSiblingPosList().iterator();
          while (localIterator3.hasNext())
          {
            int i7 = ((Integer)localIterator3.next()).intValue();
            CellData localCellData3 = (CellData)localList1.get(i7);
            A(localCellData3, i6);
          }
        }
        if ((i4 == 0) && (localCellBandModel.getSamePosList() != null))
        {
          localObject = localCellBandModel.getSamePosList().iterator();
          while (((Iterator)localObject).hasNext())
          {
            i6 = ((Integer)((Iterator)localObject).next()).intValue();
            ((CellData)localList1.get(i6)).setVerRemoved(true);
          }
        }
      }
      else
      {
        i4 = localCellBandModel.getWidth();
        paramXptBuildRuntime.getExpandTable().addCol(localCellBandModel.getIndex(), i4);
      }
      if (localCellBandModel.getPosList() != null)
      {
        Iterator localIterator1 = localCellBandModel.getPosList().iterator();
        while (localIterator1.hasNext())
        {
          int i5 = ((Integer)localIterator1.next()).intValue();
          paramXptBuildRuntime.setVerOffset(i2);
          localObject = (CellData)localList1.get(i5);
          C((CellData)localObject, i2 + 1);
        }
      }
      paramXptBuildRuntime.setVerOffset(i2 + i4);
      if (localCellBandModel.isAlignWithParent())
      {
        n += i4;
        if (i1 < 0) {
          i1 = i2;
        }
      }
      m += i4;
    }
    if (n == 0) {
      paramCellData.setVerRemoved(true);
    }
    paramCellData.setMergeAcross(n - 1);
    paramCellData.setIndex(i1 + 1);
    paramXptBuildRuntime.setVerOffset(i);
    return m;
  }
  
  void B(TableData paramTableData, XptBuildRuntime paramXptBuildRuntime)
  {
    paramTableData.setCols(paramXptBuildRuntime.getExpandTable().getCols());
    paramTableData.setRows(paramXptBuildRuntime.getExpandTable().getRows());
    int j = paramTableData.getRows().size();
    for (int i = 0; i < j; i++)
    {
      localObject = (RowData)paramTableData.getRows().get(i);
      ((RowData)localObject).setIndex(i + 1);
      ((RowData)localObject).setTable(paramTableData);
    }
    Object localObject = paramXptBuildRuntime.getExpandTable().getExpandRows();
    int m = ((List)localObject).size();
    for (int k = 0; k < m; k++)
    {
      List localList = (List)((List)localObject).get(k);
      int i1 = localList.size();
      for (int n = 0; n < i1; n++)
      {
        XptExpandCell localXptExpandCell = (XptExpandCell)localList.get(n);
        if (localXptExpandCell != null)
        {
          int i3 = localXptExpandCell.getExpandedCells().size();
          for (int i2 = 0; i2 < i3; i2++)
          {
            CellData localCellData = (CellData)localXptExpandCell.getExpandedCells().get(i2);
            A(paramTableData, localCellData);
            localCellData.evaluateCell(paramXptBuildRuntime);
            C(localCellData, paramXptBuildRuntime);
          }
        }
      }
    }
  }
  
  void C(CellData paramCellData, XptBuildRuntime paramXptBuildRuntime)
  {
    if ((paramCellData.getModel() != null) && (paramCellData.getModel().getCellFormula() != null))
    {
      CellFormula localCellFormula = paramCellData.getModel().getCellFormula();
      CellData localCellData = paramXptBuildRuntime.getCellData();
      paramXptBuildRuntime.setCellData(paramCellData);
      String str = localCellFormula.getExpandedFormula(paramXptBuildRuntime);
      if (str != null) {
        paramCellData.setFormula(str);
      }
      paramXptBuildRuntime.setCellData(localCellData);
    }
  }
  
  void A(TableData paramTableData, XptBuildRuntime paramXptBuildRuntime)
  {
    paramTableData.setCols(paramXptBuildRuntime.getExpandTable().getCols());
    paramTableData.setRows(paramXptBuildRuntime.getExpandTable().getRows());
    int j = paramTableData.getRows().size();
    for (int i = 0; i < j; i++)
    {
      localObject = (RowData)paramTableData.getRows().get(i);
      ((RowData)localObject).setIndex(i + 1);
      ((RowData)localObject).setTable(paramTableData);
    }
    Object localObject = paramXptBuildRuntime.getExpandTable().getExpandRows();
    int m = ((List)localObject).size();
    for (int k = 0; k < m; k++)
    {
      List localList = (List)((List)localObject).get(k);
      int i1 = localList.size();
      for (int n = 0; n < i1; n++)
      {
        XptExpandCell localXptExpandCell = (XptExpandCell)localList.get(n);
        if (localXptExpandCell != null)
        {
          int i3 = localXptExpandCell.getExpandedCells().size();
          for (int i2 = 0; i2 < i3; i2++)
          {
            CellData localCellData = (CellData)localXptExpandCell.getExpandedCells().get(i2);
            A(paramTableData, localCellData);
          }
        }
      }
    }
    C(paramTableData, paramXptBuildRuntime);
  }
  
  void C(TableData paramTableData, XptBuildRuntime paramXptBuildRuntime)
  {
    Map localMap = paramXptBuildRuntime.getArgs();
    Iterator localIterator = paramTableData.getRows().iterator();
    while (localIterator.hasNext())
    {
      RowData localRowData = (RowData)localIterator.next();
      localRowData.evaluatePrepareRow(localMap);
      int i = localRowData.getColCount();
      List localList = localRowData.getCells();
      int j = 0;
      int k = i;
      while (j < k)
      {
        ICellHandle localICellHandle = (ICellHandle)localList.get(j);
        if (!localICellHandle.isIgnored())
        {
          CellData localCellData = (CellData)localICellHandle;
          localCellData.evaluateCell(paramXptBuildRuntime);
          C(localCellData, paramXptBuildRuntime);
        }
        j++;
      }
    }
  }
  
  void A(TableData paramTableData, CellData paramCellData)
  {
    for (int i = 0; i <= paramCellData.getMergeDown(); i++)
    {
      RowData localRowData = (RowData)paramTableData.getRow(paramCellData.getCalcRowIndex() - 1 + i);
      for (int j = 0; j <= paramCellData.getMergeAcross(); j++) {
        if ((i == 0) && (j == 0))
        {
          localRowData.setCellAt(paramCellData);
        }
        else
        {
          IgnoreCellHandle localIgnoreCellHandle = new IgnoreCellHandle(paramCellData);
          localIgnoreCellHandle.setRow(localRowData);
          localIgnoreCellHandle.setIndex(paramCellData.getIndex() + j);
          localRowData.setCellAt(localIgnoreCellHandle);
        }
      }
    }
  }
  
  void A(TableData paramTableData, List<CellData> paramList, XptBuildRuntime paramXptBuildRuntime)
  {
    if (paramList != null)
    {
      Iterator localIterator1 = paramList.iterator();
      while (localIterator1.hasNext())
      {
        CellData localCellData1 = (CellData)localIterator1.next();
        if (localCellData1.isNeedExpand())
        {
          List localList = localCellData1.getExpandedCells();
          if (localList != null)
          {
            Iterator localIterator2 = localList.iterator();
            while (localIterator2.hasNext())
            {
              CellData localCellData2 = (CellData)localIterator2.next();
              A(paramTableData, localCellData2, paramXptBuildRuntime);
            }
          }
        }
        else
        {
          A(paramTableData, localCellData1, paramXptBuildRuntime);
        }
      }
    }
  }
  
  void A(TableData paramTableData, CellData paramCellData, XptBuildRuntime paramXptBuildRuntime)
  {
    if (!paramCellData.isRemoved())
    {
      paramCellData.evaluateCell(paramXptBuildRuntime);
      for (int i = 0; i <= paramCellData.getMergeDown(); i++)
      {
        RowData localRowData = paramTableData.makeRow(paramCellData.getCalcRowIndex() - 1 + i);
        for (int j = 0; j <= paramCellData.getMergeAcross(); j++) {
          if ((i == 0) && (j == 0))
          {
            localRowData.setCellAt(paramCellData);
            localRowData.setModel(paramCellData.getModel().getRow());
            paramTableData.fixCol(paramCellData);
          }
          else
          {
            IgnoreCellHandle localIgnoreCellHandle = new IgnoreCellHandle(paramCellData);
            localIgnoreCellHandle.setRow(localRowData);
            localIgnoreCellHandle.setIndex(paramCellData.getIndex() + i);
            localRowData.setCellAt(localIgnoreCellHandle);
          }
        }
      }
    }
    List localList = paramCellData.getHorChildren();
    if (localList != null) {
      A(paramTableData, localList, paramXptBuildRuntime);
    }
  }
  
  void B(CellData paramCellData, boolean paramBoolean, XptBuildRuntime paramXptBuildRuntime)
  {
    List localList = paramCellData.getChildren(paramBoolean);
    if (localList != null)
    {
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        CellData localCellData = (CellData)localIterator.next();
        A(localCellData, paramBoolean, paramXptBuildRuntime);
      }
    }
  }
  
  void A(CellData paramCellData, boolean paramBoolean, XptBuildRuntime paramXptBuildRuntime)
  {
    paramCellData.markRemoved(paramBoolean);
    paramXptBuildRuntime.setHasRemovedCell(true);
    B(paramCellData, paramBoolean, paramXptBuildRuntime);
  }
  
  void A(CellData paramCellData, XptBuildRuntime paramXptBuildRuntime)
  {
    if (!paramCellData.passTest(paramXptBuildRuntime.getArgs()))
    {
      A(paramCellData, true, paramXptBuildRuntime);
      return;
    }
    if (!paramCellData.getModel().isExpandVer())
    {
      A(paramCellData.getHorChildren(), true, paramXptBuildRuntime);
      return;
    }
    Collection localCollection = paramCellData.getExpandedSet(paramXptBuildRuntime);
    if ((localCollection == null) || (localCollection.isEmpty()))
    {
      paramCellData.setExpandObj(null);
      A(paramCellData, true, paramXptBuildRuntime);
      return;
    }
    ArrayList localArrayList = new ArrayList(localCollection.size());
    int i = 0;
    Iterator localIterator1 = localCollection.iterator();
    while (localIterator1.hasNext())
    {
      Object localObject = localIterator1.next();
      CellData localCellData1 = paramCellData.deepCopyHor();
      localCellData1.setUnexpandCell(paramCellData);
      localCellData1.setExpandObj(localObject);
      localCellData1.setExpandIndex(i);
      if (localCellData1.getVerCopyCells() != null)
      {
        Iterator localIterator2 = localCellData1.getVerCopyCells().iterator();
        while (localIterator2.hasNext())
        {
          CellData localCellData2 = (CellData)localIterator2.next();
          localCellData2.setExpandObj(localObject);
          localCellData2.setExpandIndex(i);
        }
      }
      localArrayList.add(localCellData1);
      i++;
      A(localCellData1.getHorChildren(), true, paramXptBuildRuntime);
    }
    paramCellData.setExpandedCells(localArrayList);
  }
  
  void B(CellData paramCellData, XptBuildRuntime paramXptBuildRuntime)
  {
    if (!paramCellData.passTest(paramXptBuildRuntime.getArgs()))
    {
      A(paramCellData, false, paramXptBuildRuntime);
      return;
    }
    if (!paramCellData.getModel().isExpandHor())
    {
      if (paramCellData.getVerChildren() == null)
      {
        if (paramCellData.getVerOrgCell() != null) {
          paramCellData.getVerOrgCell().addVerCopyCell(paramCellData);
        }
      }
      else {
        A(paramCellData.getVerChildren(), false, paramXptBuildRuntime);
      }
      return;
    }
    Collection localCollection = paramCellData.getExpandedSet(paramXptBuildRuntime);
    if ((localCollection == null) || (localCollection.isEmpty()))
    {
      A(paramCellData, false, paramXptBuildRuntime);
      return;
    }
    ArrayList localArrayList = new ArrayList(localCollection.size());
    int i = 0;
    Iterator localIterator = localCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      CellData localCellData = paramCellData.deepCopyVer();
      localCellData.setUnexpandCell(paramCellData);
      localCellData.getVerOrgCell().addVerCopyCell(localCellData);
      localCellData.setExpandObj(localObject);
      localCellData.setExpandIndex(i);
      localArrayList.add(localCellData);
      i++;
      A(localCellData.getVerChildren(), false, paramXptBuildRuntime);
    }
    paramCellData.setExpandedCells(localArrayList);
  }
  
  void A(List<CellData> paramList, boolean paramBoolean, XptBuildRuntime paramXptBuildRuntime)
  {
    if (paramList != null)
    {
      int j = paramList.size();
      for (int i = 0; i < j; i++)
      {
        CellData localCellData = (CellData)paramList.get(i);
        if (paramBoolean) {
          A(localCellData, paramXptBuildRuntime);
        } else {
          B(localCellData, paramXptBuildRuntime);
        }
      }
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\xpt\XptExpander.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */