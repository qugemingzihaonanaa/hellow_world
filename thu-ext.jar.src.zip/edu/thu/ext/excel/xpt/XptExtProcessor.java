package edu.thu.ext.excel.xpt;

public class XptExtProcessor
{
  static XptExtProcessor A = new XptExtProcessor();
  
  public static XptExtProcessor getInstance()
  {
    return A;
  }
  
  public void process(XptBuildRuntime paramXptBuildRuntime) {}
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\xpt\XptExtProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */