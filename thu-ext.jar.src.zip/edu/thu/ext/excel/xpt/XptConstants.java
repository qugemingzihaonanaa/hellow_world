package edu.thu.ext.excel.xpt;

public abstract interface XptConstants
{
  public static final String RENDER_TYPE_HTML = "html";
  public static final String DS_FUNC_FIELD = "F";
  public static final String DS_FUNC_GROUP = "G";
  public static final String DS_FUNC_NAME = "N";
  public static final String DS_FUNC_LIST = "L";
  public static final String DS_FUNC_OBJECT = "O";
  public static final String TPL_ID_EXPORT_FILE_NAME = "exportFileNameTpl";
  public static final String TPL_ID_BEFORE_SHEETS_TPL = "beforeSheetsTpl";
  public static final String TPL_ID_AFTER_SHEETS_TPL = "afterSheetsTpl";
  public static final String VAR_XPT_RT = "xptRt";
  public static final String VAR_WORKBOOK_MODEL = "workbookModel";
  public static final String VAR_WORKBOOK_DATA = "workbookData";
  public static final String VAR_WORKSHEET_DATA = "worksheetData";
  public static final String VAR_SHEET_LOOP_VAR = "sheetLoopVar";
  public static final String VAR_SHEET_LOOP_INDEX = "sheetLoopIndex";
  public static final String VAR_TD = "_td";
  public static final String VAR_VARS_LIST = "varsList";
  public static final String VAR_VARS_LIST_ITEM = "_varsListItem";
  public static final String VAR_DUMMY = "_";
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\excel\xpt\XptConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */