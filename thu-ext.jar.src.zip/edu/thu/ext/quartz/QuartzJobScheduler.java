package edu.thu.ext.quartz;

import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.exceptions.StdException;
import edu.thu.service.job.IJobScheduler;
import edu.thu.service.job.JobConstants;
import edu.thu.service.job.JobDescriptor;
import edu.thu.service.job.PeriodicConfig;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;

public class QuartzJobScheduler
  implements IJobScheduler, JobConstants
{
  static Log B = LogFactory.getLog(QuartzJobScheduler.class);
  String A;
  Scheduler C;
  boolean D;
  
  public String getName()
  {
    return this.A;
  }
  
  public void setName(String paramString)
  {
    this.A = paramString;
  }
  
  public void setQuartzScheduler(Scheduler paramScheduler)
  {
    this.C = paramScheduler;
    try
    {
      this.C.addJobListener(new MonitorJobListener());
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public Scheduler getQuartzScheduler()
  {
    return this.C;
  }
  
  public void clear()
  {
    QuartzUtils.clearJob(this.C);
  }
  
  public void validatePeriodicConfig(PeriodicConfig paramPeriodicConfig)
  {
    QuartzUtils.makeTrigger(paramPeriodicConfig);
  }
  
  public boolean existsJob(String paramString1, String paramString2)
  {
    try
    {
      JobDetail localJobDetail = this.C.getJobDetail(paramString2, paramString1);
      return localJobDetail != null;
    }
    catch (Exception localException)
    {
      B.trace("job.err_existsJob", localException);
    }
    return false;
  }
  
  public boolean isJobScheduled(String paramString1, String paramString2)
  {
    try
    {
      return this.C.getTrigger(paramString2, paramString1) != null;
    }
    catch (Exception localException)
    {
      B.debug(localException);
    }
    return false;
  }
  
  MonitorJobListener A()
  {
    try
    {
      return (MonitorJobListener)this.C.getJobListener(MonitorJobListener.class.getName());
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public boolean isJobRunning(String paramString1, String paramString2)
  {
    return A().isJobRunning(paramString1, paramString2);
  }
  
  public boolean isShutdown()
  {
    try
    {
      return this.C.isShutdown();
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public void removeGroup(String paramString)
  {
    if (this.D) {
      QuartzUtils.removeJobGroup(this.C, "manual." + paramString);
    }
    QuartzUtils.removeJobGroup(this.C, paramString);
  }
  
  public void removeJob(String paramString1, String paramString2)
  {
    Debug.check(paramString1);
    Debug.check(paramString2);
    try
    {
      if (this.D) {
        this.C.deleteJob(paramString2, "manual." + paramString1);
      }
      this.C.deleteJob(paramString2, paramString1);
    }
    catch (SchedulerException localSchedulerException)
    {
      throw Exceptions.source(localSchedulerException);
    }
  }
  
  public void resume()
  {
    try
    {
      this.C.resumeAll();
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public void shutdown()
  {
    try
    {
      this.C.shutdown();
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public void start()
  {
    try
    {
      this.C.start();
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public void suspend()
  {
    try
    {
      this.C.pauseAll();
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public PeriodicConfig getPeriodicConfig(String paramString1, String paramString2)
  {
    try
    {
      Trigger localTrigger = this.C.getTrigger(paramString2, paramString1);
      return QuartzUtils.getPeriodicConfigFromTrigger(localTrigger);
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  JobDescriptor A(String paramString1, String paramString2)
    throws Exception
  {
    JobDetail localJobDetail = this.C.getJobDetail(paramString2, paramString1);
    if (localJobDetail == null) {
      return null;
    }
    JobDescriptor localJobDescriptor = QuartzUtils.makeJobDescriptor(localJobDetail);
    localJobDescriptor.setSchedulerName(getName());
    return localJobDescriptor;
  }
  
  JobDescriptor A(JobDetail paramJobDetail)
  {
    JobDescriptor localJobDescriptor = QuartzUtils.makeJobDescriptor(paramJobDetail);
    localJobDescriptor.setSchedulerName(getName());
    return localJobDescriptor;
  }
  
  public JobDescriptor getJobDescriptor(String paramString1, String paramString2)
  {
    try
    {
      JobDescriptor localJobDescriptor = A(paramString1, paramString2);
      if (localJobDescriptor == null) {
        return null;
      }
      Trigger localTrigger = this.C.getTrigger(paramString2, paramString1);
      PeriodicConfig localPeriodicConfig = QuartzUtils.getPeriodicConfigFromTrigger(localTrigger);
      localJobDescriptor.setPeriodicConfig(localPeriodicConfig);
      if (localTrigger != null)
      {
        localJobDescriptor.setPrevFireTimeValue(localTrigger.getPreviousFireTime());
        localJobDescriptor.setNextFireTimeValue(localTrigger.getNextFireTime());
        int i = this.C.getTriggerState(localTrigger.getName(), localTrigger.getGroup());
        localJobDescriptor.setTriggerState(QuartzUtils.triggerStateToString(i));
      }
      return localJobDescriptor;
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public JobDescriptor triggerNow(String paramString1, String paramString2)
  {
    try
    {
      JobDetail localJobDetail = this.C.getJobDetail(paramString2, paramString1);
      if (localJobDetail == null) {
        throw Exceptions.code("job.CAN_err_missing_job").param(paramString1).param(paramString2);
      }
      if (isJobRunning(paramString1, paramString2)) {
        return A(localJobDetail);
      }
      this.C.triggerJobWithVolatileTrigger(localJobDetail.getName(), localJobDetail.getGroup(), localJobDetail.getJobDataMap());
      return A(localJobDetail);
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public void schedule(JobDescriptor paramJobDescriptor)
  {
    if (paramJobDescriptor.getJobGroup() == null) {
      paramJobDescriptor.setJobGroup("DEFAULT");
    }
    if (paramJobDescriptor.getPeriodicConfig() == null) {
      paramJobDescriptor.setPeriodicConfig(PeriodicConfig.once(null));
    }
    JobDetail localJobDetail = QuartzUtils.makeJobDetail(paramJobDescriptor);
    Trigger localTrigger = QuartzUtils.makeTrigger(paramJobDescriptor.getPeriodicConfig());
    localTrigger.setJobName(localJobDetail.getName());
    localTrigger.setJobGroup(localJobDetail.getGroup());
    localTrigger.setName(localJobDetail.getName());
    localTrigger.setGroup(localJobDetail.getGroup());
    if ((this.D) && (!paramJobDescriptor.getJobGroup().startsWith("manual."))) {
      removeJob("manual." + paramJobDescriptor.getJobGroup(), paramJobDescriptor.getJobName());
    }
    QuartzUtils.setJob(this.C, localTrigger, localJobDetail);
  }
  
  public void store(JobDescriptor paramJobDescriptor)
  {
    if (paramJobDescriptor.getJobGroup() == null) {
      paramJobDescriptor.setJobGroup("DEFAULT");
    }
    paramJobDescriptor.setDurable(true);
    if (paramJobDescriptor.getPeriodicConfig() != null)
    {
      schedule(paramJobDescriptor);
    }
    else
    {
      JobDetail localJobDetail = QuartzUtils.makeJobDetail(paramJobDescriptor);
      try
      {
        this.C.addJob(localJobDetail, true);
      }
      catch (Exception localException)
      {
        throw Exceptions.source(localException);
      }
    }
  }
  
  public void updatePeriodicConfig(String paramString1, String paramString2, PeriodicConfig paramPeriodicConfig)
  {
    if (paramString1 == null) {
      paramString1 = "DEFAULT";
    }
    Trigger localTrigger = QuartzUtils.makeTrigger(paramPeriodicConfig);
    localTrigger.setGroup(paramString1);
    localTrigger.setName(paramString2);
    localTrigger.setJobName(paramString2);
    localTrigger.setJobGroup(paramString1);
    try
    {
      if (this.C.rescheduleJob(paramString2, paramString1, localTrigger) == null) {
        this.C.scheduleJob(localTrigger);
      }
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public void resumeGroup(String paramString)
  {
    try
    {
      this.C.resumeJobGroup(paramString);
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public void resumeJob(String paramString1, String paramString2)
  {
    try
    {
      this.C.resumeJob(paramString2, paramString1);
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public void suspendGroup(String paramString)
  {
    try
    {
      this.C.pauseJobGroup(paramString);
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public void suspendJob(String paramString1, String paramString2)
  {
    try
    {
      this.C.pauseJob(paramString2, paramString1);
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public boolean interruptJob(String paramString1, String paramString2)
  {
    try
    {
      return this.C.interrupt(paramString2, paramString1);
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public Set<String> getRunningJobs()
  {
    return A().getRunningJobs();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\quartz\QuartzJobScheduler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */