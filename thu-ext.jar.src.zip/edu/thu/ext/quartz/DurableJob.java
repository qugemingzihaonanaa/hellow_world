package edu.thu.ext.quartz;

public class DurableJob
  extends Triggers
{
  String N;
  
  public String getJobClassName()
  {
    return this.N;
  }
  
  public void setJobClassName(String paramString)
  {
    this.N = paramString;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\quartz\DurableJob.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */