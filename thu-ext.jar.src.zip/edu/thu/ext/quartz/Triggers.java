package edu.thu.ext.quartz;

import java.sql.Timestamp;

public class Triggers
{
  private TriggersPK L;
  private String F;
  private String K;
  private String J;
  private String I;
  private Long G;
  private Long A;
  private String H;
  private String D;
  private Long C;
  private Long E;
  private String M;
  private Integer B;
  
  public Timestamp getPrevFireTimeValue()
  {
    if (this.A == null) {
      return null;
    }
    return new Timestamp(this.A.longValue());
  }
  
  public Timestamp getNextFireTimeValue()
  {
    if (this.G == null) {
      return null;
    }
    return new Timestamp(this.G.longValue());
  }
  
  public Timestamp getStartTimeValue()
  {
    if (this.C == null) {
      return null;
    }
    return new Timestamp(this.C.longValue());
  }
  
  public Timestamp getEndTimeValue()
  {
    if (this.E == null) {
      return null;
    }
    return new Timestamp(this.E.longValue());
  }
  
  public String getCalendarName()
  {
    return this.M;
  }
  
  public void setCalendarName(String paramString)
  {
    this.M = paramString;
  }
  
  public String getDescription()
  {
    return this.I;
  }
  
  public void setDescription(String paramString)
  {
    this.I = paramString;
  }
  
  public String getIsVolatile()
  {
    return this.J;
  }
  
  public void setIsVolatile(String paramString)
  {
    this.J = paramString;
  }
  
  public String getJobGroup()
  {
    return this.K;
  }
  
  public void setJobGroup(String paramString)
  {
    this.K = paramString;
  }
  
  public String getJobName()
  {
    return this.F;
  }
  
  public void setJobName(String paramString)
  {
    this.F = paramString;
  }
  
  public Integer getMisfireInstr()
  {
    return this.B;
  }
  
  public void setMisfireInstr(Integer paramInteger)
  {
    this.B = paramInteger;
  }
  
  public TriggersPK getTriggersPK()
  {
    return this.L;
  }
  
  public void setTriggersPK(TriggersPK paramTriggersPK)
  {
    this.L = paramTriggersPK;
  }
  
  public String getTriggerName()
  {
    if (this.L == null) {
      return null;
    }
    return this.L.getTriggerName();
  }
  
  public void setTriggerName(String paramString)
  {
    if (this.L == null) {
      this.L = new TriggersPK();
    }
    this.L.setTriggerName(paramString);
  }
  
  public String getTriggerGroup()
  {
    if (this.L == null) {
      return null;
    }
    return this.L.getTriggerGroup();
  }
  
  public void setTriggerGroup(String paramString)
  {
    if (this.L == null) {
      this.L = new TriggersPK();
    }
    this.L.setTriggerGroup(paramString);
  }
  
  public String getTriggerState()
  {
    return this.H;
  }
  
  public void setTriggerState(String paramString)
  {
    this.H = paramString;
  }
  
  public String getTriggerType()
  {
    return this.D;
  }
  
  public void setTriggerType(String paramString)
  {
    this.D = paramString;
  }
  
  public Long getEndTime()
  {
    return this.E;
  }
  
  public void setEndTime(Long paramLong)
  {
    this.E = paramLong;
  }
  
  public Long getNextFireTime()
  {
    return this.G;
  }
  
  public void setNextFireTime(Long paramLong)
  {
    this.G = paramLong;
  }
  
  public Long getPrevFireTime()
  {
    return this.A;
  }
  
  public void setPrevFireTime(Long paramLong)
  {
    this.A = paramLong;
  }
  
  public Long getStartTime()
  {
    return this.C;
  }
  
  public void setStartTime(Long paramLong)
  {
    this.C = paramLong;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\quartz\Triggers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */