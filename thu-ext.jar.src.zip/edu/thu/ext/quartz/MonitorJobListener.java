package edu.thu.ext.quartz;

import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobListener;

public class MonitorJobListener
  implements JobListener
{
  Map<String, Boolean> runningJobs = new ConcurrentHashMap();
  
  public String getName()
  {
    return MonitorJobListener.class.getName();
  }
  
  public Set<String> getRunningJobs()
  {
    return Collections.unmodifiableSet(this.runningJobs.keySet());
  }
  
  String getJobKey(JobExecutionContext paramJobExecutionContext)
  {
    return paramJobExecutionContext.getJobDetail().getGroup() + "|" + paramJobExecutionContext.getJobDetail().getName();
  }
  
  String getJobKey(String paramString1, String paramString2)
  {
    return paramString1 + "|" + paramString2;
  }
  
  public void jobExecutionVetoed(JobExecutionContext paramJobExecutionContext)
  {
    this.runningJobs.remove(getJobKey(paramJobExecutionContext));
  }
  
  public void jobToBeExecuted(JobExecutionContext paramJobExecutionContext)
  {
    this.runningJobs.put(getJobKey(paramJobExecutionContext), Boolean.TRUE);
  }
  
  public void jobWasExecuted(JobExecutionContext paramJobExecutionContext, JobExecutionException paramJobExecutionException)
  {
    this.runningJobs.remove(getJobKey(paramJobExecutionContext));
  }
  
  public boolean isJobRunning(String paramString1, String paramString2)
  {
    return this.runningJobs.containsKey(getJobKey(paramString1, paramString2));
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\quartz\MonitorJobListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */