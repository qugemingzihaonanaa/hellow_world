package edu.thu.ext.quartz;

import edu.thu.global.Debug;
import org.quartz.Calendar;
import org.quartz.JobDetail;
import org.quartz.JobPersistenceException;
import org.quartz.Trigger;
import org.quartz.core.SchedulingContext;
import org.quartz.spi.JobStore;

public class QuartzStore
{
  JobStore B;
  SchedulingContext A;
  boolean C = true;
  
  public QuartzStore(JobStore paramJobStore)
  {
    Debug.check(paramJobStore);
    this.B = paramJobStore;
    this.A = new SchedulingContext();
  }
  
  public void exportCalendarTo(JobStore paramJobStore, boolean paramBoolean)
    throws JobPersistenceException
  {
    String[] arrayOfString = this.B.getCalendarNames(this.A);
    if (arrayOfString != null)
    {
      int j = arrayOfString.length;
      for (int i = 0; i < j; i++)
      {
        String str = arrayOfString[i];
        exportCalendarTo(str, paramJobStore, paramBoolean);
      }
    }
  }
  
  public void exportCalendarTo(String paramString, JobStore paramJobStore, boolean paramBoolean)
    throws JobPersistenceException
  {
    Calendar localCalendar = this.B.retrieveCalendar(this.A, paramString);
    if (localCalendar != null) {
      paramJobStore.storeCalendar(this.A, paramString, localCalendar, paramBoolean, true);
    }
  }
  
  public void exportTriggerTo(JobStore paramJobStore, boolean paramBoolean)
    throws JobPersistenceException
  {
    String[] arrayOfString = this.B.getTriggerGroupNames(this.A);
    if (arrayOfString != null)
    {
      int j = arrayOfString.length;
      for (int i = 0; i < j; i++)
      {
        String str = arrayOfString[i];
        exportTriggerGroupTo(str, paramJobStore, paramBoolean);
      }
    }
  }
  
  public void exportTriggerGroupTo(String paramString, JobStore paramJobStore, boolean paramBoolean)
    throws JobPersistenceException
  {
    String[] arrayOfString = this.B.getTriggerNames(this.A, paramString);
    if (arrayOfString != null)
    {
      int j = arrayOfString.length;
      for (int i = 0; i < j; i++)
      {
        String str = arrayOfString[i];
        exportTriggerTo(paramString, str, paramJobStore, paramBoolean);
      }
    }
  }
  
  public void exportTriggerTo(String paramString1, String paramString2, JobStore paramJobStore, boolean paramBoolean)
    throws JobPersistenceException
  {
    Trigger localTrigger = this.B.retrieveTrigger(this.A, paramString2, paramString1);
    if (localTrigger != null) {
      paramJobStore.storeTrigger(this.A, localTrigger, paramBoolean);
    }
  }
  
  public void exportJobTo(JobStore paramJobStore, boolean paramBoolean)
    throws JobPersistenceException
  {
    String[] arrayOfString = this.B.getJobGroupNames(this.A);
    if (arrayOfString != null)
    {
      int j = arrayOfString.length;
      for (int i = 0; i < j; i++)
      {
        String str = arrayOfString[i];
        exportJobGroupTo(str, paramJobStore, paramBoolean);
      }
    }
  }
  
  public void exportJobGroupTo(String paramString, JobStore paramJobStore, boolean paramBoolean)
    throws JobPersistenceException
  {
    String[] arrayOfString = this.B.getJobNames(this.A, paramString);
    if (arrayOfString != null)
    {
      int j = arrayOfString.length;
      for (int i = 0; i < j; i++)
      {
        String str = arrayOfString[i];
        exportJobTo(paramString, str, paramJobStore, paramBoolean);
      }
    }
  }
  
  public void exportJobTo(String paramString1, String paramString2, JobStore paramJobStore, boolean paramBoolean)
    throws JobPersistenceException
  {
    try
    {
      JobDetail localJobDetail = this.B.retrieveJob(this.A, paramString2, paramString1);
      if (localJobDetail != null) {
        paramJobStore.storeJob(this.A, localJobDetail, paramBoolean);
      }
    }
    catch (JobPersistenceException localJobPersistenceException)
    {
      localJobPersistenceException.printStackTrace();
      if (!this.C) {
        throw localJobPersistenceException;
      }
    }
  }
  
  public void exportTo(JobStore paramJobStore, boolean paramBoolean)
    throws JobPersistenceException
  {
    exportCalendarTo(paramJobStore, paramBoolean);
    exportJobTo(paramJobStore, paramBoolean);
    exportTriggerTo(paramJobStore, paramBoolean);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\quartz\QuartzStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */