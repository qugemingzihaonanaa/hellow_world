package edu.thu.ext.quartz;

import edu.thu.orm.component.AbstractCompositePK;
import edu.thu.orm.util.ReflectHelper;
import java.lang.reflect.Field;

public class TriggersPK
  extends AbstractCompositePK
{
  private static final long serialVersionUID = 3007460248926065063L;
  private static final Field[] A = ReflectHelper.getPersistDeclaredFields(TriggersPK.class);
  private String B;
  private String C;
  
  protected Field[] getFields()
  {
    return A;
  }
  
  public String getTriggerGroup()
  {
    return this.C;
  }
  
  public void setTriggerGroup(String paramString)
  {
    this.C = paramString;
  }
  
  public String getTriggerName()
  {
    return this.B;
  }
  
  public void setTriggerName(String paramString)
  {
    this.B = paramString;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\quartz\TriggersPK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */