package edu.thu.ext.quartz;

import edu.thu.global.Debug;
import edu.thu.model.data.TableMatcher;
import edu.thu.service.job.JobDescriptor;
import java.io.Serializable;
import org.quartz.JobDetail;
import org.quartz.Trigger;

public class QuartzJobDescriptor
  implements Serializable
{
  private static final long serialVersionUID = -2904243490805975571L;
  String A = "default";
  JobDetail B;
  Trigger C;
  
  public QuartzJobDescriptor()
  {
    new TableMatcher().process(this);
  }
  
  public QuartzJobDescriptor(JobDescriptor paramJobDescriptor)
  {
    Debug.check(paramJobDescriptor);
    this.C = QuartzUtils.makeTrigger(paramJobDescriptor.getPeriodicConfig());
    this.B = QuartzUtils.makeJobDetail(paramJobDescriptor.getJobGroup(), paramJobDescriptor.getJobName(), paramJobDescriptor.getJobClass(), paramJobDescriptor.getArgs(), paramJobDescriptor.isDurable());
    this.C.setJobName(this.B.getName());
    this.C.setJobGroup(this.B.getGroup());
    this.C.setName(this.B.getName());
    this.C.setGroup(this.B.getGroup());
    if (paramJobDescriptor.getSchedulerName() != null) {
      this.A = paramJobDescriptor.getSchedulerName();
    }
  }
  
  public String getSchedulerName()
  {
    return this.A;
  }
  
  public void setSchedulerName(String paramString)
  {
    Debug.check(paramString);
    this.A = paramString;
  }
  
  public JobDetail getJobDetail()
  {
    return this.B;
  }
  
  public void setJobDetail(JobDetail paramJobDetail)
  {
    Debug.check(paramJobDetail);
    this.B = paramJobDetail;
  }
  
  public Trigger getTrigger()
  {
    return this.C;
  }
  
  public void setTrigger(Trigger paramTrigger)
  {
    Debug.check(paramTrigger);
    this.C = paramTrigger;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\quartz\QuartzJobDescriptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */