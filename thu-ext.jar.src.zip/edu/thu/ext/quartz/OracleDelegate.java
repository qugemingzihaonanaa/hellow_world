package edu.thu.ext.quartz;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import oracle.sql.BLOB;
import org.apache.commons.logging.Log;
import org.quartz.Calendar;
import org.quartz.CronTrigger;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.SimpleTrigger;
import org.quartz.Trigger;
import org.quartz.impl.jdbcjobstore.StdJDBCDelegate;

public class OracleDelegate
  extends StdJDBCDelegate
{
  public static final String UPDATE_ORACLE_JOB_DETAIL = "UPDATE {0}JOB_DETAILS SET DESCRIPTION = ?, JOB_CLASS_NAME = ?, IS_DURABLE = ?, IS_VOLATILE = ?, IS_STATEFUL = ?, REQUESTS_RECOVERY = ?  WHERE JOB_NAME = ? AND JOB_GROUP = ?";
  public static final String UPDATE_ORACLE_JOB_DETAIL_BLOB = "UPDATE {0}JOB_DETAILS SET JOB_DATA = ?  WHERE JOB_NAME = ? AND JOB_GROUP = ?";
  public static final String UPDATE_ORACLE_JOB_DETAIL_EMPTY_BLOB = "UPDATE {0}JOB_DETAILS SET JOB_DATA = EMPTY_BLOB()  WHERE JOB_NAME = ? AND JOB_GROUP = ?";
  public static final String SELECT_ORACLE_JOB_DETAIL_BLOB = "SELECT JOB_DATA FROM {0}JOB_DETAILS WHERE JOB_NAME = ? AND JOB_GROUP = ? FOR UPDATE";
  public static final String UPDATE_ORACLE_TRIGGER = "UPDATE {0}TRIGGERS SET JOB_NAME = ?, JOB_GROUP = ?, IS_VOLATILE = ?, DESCRIPTION = ?, NEXT_FIRE_TIME = ?, PREV_FIRE_TIME = ?, TRIGGER_STATE = ?, TRIGGER_TYPE = ?, START_TIME = ?, END_TIME = ?, CALENDAR_NAME = ?, MISFIRE_INSTR = ? WHERE TRIGGER_NAME = ? AND TRIGGER_GROUP = ?";
  public static final String SELECT_ORACLE_TRIGGER_JOB_DETAIL_BLOB = "SELECT JOB_DATA FROM {0}TRIGGERS WHERE TRIGGER_NAME = ? AND TRIGGER_GROUP = ? FOR UPDATE";
  public static final String UPDATE_ORACLE_TRIGGER_JOB_DETAIL_BLOB = "UPDATE {0}TRIGGERS SET JOB_DATA = ?  WHERE TRIGGER_NAME = ? AND TRIGGER_GROUP = ?";
  public static final String UPDATE_ORACLE_TRIGGER_JOB_DETAIL_EMPTY_BLOB = "UPDATE {0}TRIGGERS SET JOB_DATA = EMPTY_BLOB()  WHERE TRIGGER_NAME = ? AND TRIGGER_GROUP = ?";
  public static final String INSERT_ORACLE_CALENDAR = "INSERT INTO {0}CALENDARS (CALENDAR_NAME, CALENDAR)  VALUES(?, EMPTY_BLOB())";
  public static final String SELECT_ORACLE_CALENDAR_BLOB = "SELECT CALENDAR FROM {0}CALENDARS WHERE CALENDAR_NAME = ? FOR UPDATE";
  public static final String UPDATE_ORACLE_CALENDAR_BLOB = "UPDATE {0}CALENDARS SET CALENDAR = ?  WHERE CALENDAR_NAME = ?";
  
  public OracleDelegate(Log paramLog, String paramString1, String paramString2)
  {
    super(paramLog, paramString1, paramString2);
  }
  
  public OracleDelegate(Log paramLog, String paramString1, String paramString2, Boolean paramBoolean)
  {
    super(paramLog, paramString1, paramString2, paramBoolean);
  }
  
  protected Object getObjectFromBlob(ResultSet paramResultSet, String paramString)
    throws ClassNotFoundException, IOException, SQLException
  {
    Object localObject = null;
    InputStream localInputStream = paramResultSet.getBinaryStream(paramString);
    if (localInputStream != null)
    {
      ObjectInputStream localObjectInputStream = new ObjectInputStream(localInputStream);
      localObject = localObjectInputStream.readObject();
      localObjectInputStream.close();
    }
    return localObject;
  }
  
  public int insertJobDetail(Connection paramConnection, JobDetail paramJobDetail)
    throws IOException, SQLException
  {
    ByteArrayOutputStream localByteArrayOutputStream = serializeJobData(paramJobDetail.getJobDataMap());
    byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
    PreparedStatement localPreparedStatement = null;
    ResultSet localResultSet = null;
    try
    {
      localPreparedStatement = paramConnection.prepareStatement(rtp("INSERT INTO {0}JOB_DETAILS (JOB_NAME, JOB_GROUP, DESCRIPTION, JOB_CLASS_NAME, IS_DURABLE, IS_VOLATILE, IS_STATEFUL, REQUESTS_RECOVERY, JOB_DATA)  VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)"));
      localPreparedStatement.setString(1, paramJobDetail.getName());
      localPreparedStatement.setString(2, paramJobDetail.getGroup());
      localPreparedStatement.setString(3, paramJobDetail.getDescription());
      localPreparedStatement.setString(4, paramJobDetail.getJobClass().getName());
      localPreparedStatement.setBoolean(5, paramJobDetail.isDurable());
      localPreparedStatement.setBoolean(6, paramJobDetail.isVolatile());
      localPreparedStatement.setBoolean(7, paramJobDetail.isStateful());
      localPreparedStatement.setBoolean(8, paramJobDetail.requestsRecovery());
      localPreparedStatement.setBinaryStream(9, null, 0);
      localPreparedStatement.executeUpdate();
      localPreparedStatement.close();
      localPreparedStatement = paramConnection.prepareStatement(rtp("UPDATE {0}JOB_DETAILS SET JOB_DATA = EMPTY_BLOB()  WHERE JOB_NAME = ? AND JOB_GROUP = ?"));
      localPreparedStatement.setString(1, paramJobDetail.getName());
      localPreparedStatement.setString(2, paramJobDetail.getGroup());
      localPreparedStatement.executeUpdate();
      localPreparedStatement.close();
      localPreparedStatement = paramConnection.prepareStatement(rtp("SELECT JOB_DATA FROM {0}JOB_DETAILS WHERE JOB_NAME = ? AND JOB_GROUP = ? FOR UPDATE"));
      localPreparedStatement.setString(1, paramJobDetail.getName());
      localPreparedStatement.setString(2, paramJobDetail.getGroup());
      localResultSet = localPreparedStatement.executeQuery();
      int i = 0;
      Blob localBlob = null;
      if (localResultSet.next())
      {
        localBlob = writeDataToBlob(localResultSet, 1, arrayOfByte);
      }
      else
      {
        k = i;
        return k;
      }
      localResultSet.close();
      localPreparedStatement.close();
      localPreparedStatement = paramConnection.prepareStatement(rtp("UPDATE {0}JOB_DETAILS SET JOB_DATA = ?  WHERE JOB_NAME = ? AND JOB_GROUP = ?"));
      localPreparedStatement.setBlob(1, localBlob);
      localPreparedStatement.setString(2, paramJobDetail.getName());
      localPreparedStatement.setString(3, paramJobDetail.getGroup());
      i = localPreparedStatement.executeUpdate();
      if (i > 0)
      {
        String[] arrayOfString = paramJobDetail.getJobListenerNames();
        for (int j = 0; (arrayOfString != null) && (j < arrayOfString.length); j++) {
          insertJobListener(paramConnection, paramJobDetail, arrayOfString[j]);
        }
      }
      int k = i;
      return k;
    }
    finally
    {
      if (localResultSet != null) {
        try
        {
          localResultSet.close();
        }
        catch (SQLException localSQLException5) {}
      }
      if (localPreparedStatement != null) {
        try
        {
          localPreparedStatement.close();
        }
        catch (SQLException localSQLException6) {}
      }
    }
  }
  
  protected Object getJobDetailFromBlob(ResultSet paramResultSet, String paramString)
    throws ClassNotFoundException, IOException, SQLException
  {
    if (canUseProperties())
    {
      InputStream localInputStream = paramResultSet.getBinaryStream(paramString);
      return localInputStream;
    }
    return getObjectFromBlob(paramResultSet, paramString);
  }
  
  public int updateJobDetail(Connection paramConnection, JobDetail paramJobDetail)
    throws IOException, SQLException
  {
    ByteArrayOutputStream localByteArrayOutputStream = serializeJobData(paramJobDetail.getJobDataMap());
    byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
    PreparedStatement localPreparedStatement1 = null;
    PreparedStatement localPreparedStatement2 = null;
    ResultSet localResultSet = null;
    try
    {
      localPreparedStatement1 = paramConnection.prepareStatement(rtp("UPDATE {0}JOB_DETAILS SET DESCRIPTION = ?, JOB_CLASS_NAME = ?, IS_DURABLE = ?, IS_VOLATILE = ?, IS_STATEFUL = ?, REQUESTS_RECOVERY = ?  WHERE JOB_NAME = ? AND JOB_GROUP = ?"));
      localPreparedStatement1.setString(1, paramJobDetail.getDescription());
      localPreparedStatement1.setString(2, paramJobDetail.getJobClass().getName());
      localPreparedStatement1.setBoolean(3, paramJobDetail.isDurable());
      localPreparedStatement1.setBoolean(4, paramJobDetail.isVolatile());
      localPreparedStatement1.setBoolean(5, paramJobDetail.isStateful());
      localPreparedStatement1.setBoolean(6, paramJobDetail.requestsRecovery());
      localPreparedStatement1.setString(7, paramJobDetail.getName());
      localPreparedStatement1.setString(8, paramJobDetail.getGroup());
      localPreparedStatement1.executeUpdate();
      localPreparedStatement1.close();
      localPreparedStatement1 = paramConnection.prepareStatement(rtp("UPDATE {0}JOB_DETAILS SET JOB_DATA = EMPTY_BLOB()  WHERE JOB_NAME = ? AND JOB_GROUP = ?"));
      localPreparedStatement1.setString(1, paramJobDetail.getName());
      localPreparedStatement1.setString(2, paramJobDetail.getGroup());
      localPreparedStatement1.executeUpdate();
      localPreparedStatement1.close();
      localPreparedStatement1 = paramConnection.prepareStatement(rtp("SELECT JOB_DATA FROM {0}JOB_DETAILS WHERE JOB_NAME = ? AND JOB_GROUP = ? FOR UPDATE"));
      localPreparedStatement1.setString(1, paramJobDetail.getName());
      localPreparedStatement1.setString(2, paramJobDetail.getGroup());
      localResultSet = localPreparedStatement1.executeQuery();
      int i = 0;
      Object localObject1;
      if (localResultSet.next())
      {
        localObject1 = writeDataToBlob(localResultSet, 1, arrayOfByte);
        localPreparedStatement2 = paramConnection.prepareStatement(rtp("UPDATE {0}JOB_DETAILS SET JOB_DATA = ?  WHERE JOB_NAME = ? AND JOB_GROUP = ?"));
        localPreparedStatement2.setBlob(1, (Blob)localObject1);
        localPreparedStatement2.setString(2, paramJobDetail.getName());
        localPreparedStatement2.setString(3, paramJobDetail.getGroup());
        i = localPreparedStatement2.executeUpdate();
      }
      if (i > 0)
      {
        deleteJobListeners(paramConnection, paramJobDetail.getName(), paramJobDetail.getGroup());
        localObject1 = paramJobDetail.getJobListenerNames();
        for (int j = 0; (localObject1 != null) && (j < localObject1.length); j++) {
          insertJobListener(paramConnection, paramJobDetail, localObject1[j]);
        }
      }
      int k = i;
      return k;
    }
    finally
    {
      if (localResultSet != null) {
        try
        {
          localResultSet.close();
        }
        catch (SQLException localSQLException4) {}
      }
      if (localPreparedStatement1 != null) {
        try
        {
          localPreparedStatement1.close();
        }
        catch (SQLException localSQLException5) {}
      }
      if (localPreparedStatement2 != null) {
        try
        {
          localPreparedStatement2.close();
        }
        catch (SQLException localSQLException6) {}
      }
    }
  }
  
  public int insertTrigger(Connection paramConnection, Trigger paramTrigger, String paramString, JobDetail paramJobDetail)
    throws SQLException, IOException
  {
    byte[] arrayOfByte = null;
    if (paramTrigger.getJobDataMap().size() > 0) {
      arrayOfByte = serializeJobData(paramTrigger.getJobDataMap()).toByteArray();
    }
    PreparedStatement localPreparedStatement = null;
    ResultSet localResultSet = null;
    int i = 0;
    try
    {
      localPreparedStatement = paramConnection.prepareStatement(rtp("INSERT INTO {0}TRIGGERS (TRIGGER_NAME, TRIGGER_GROUP, JOB_NAME, JOB_GROUP, IS_VOLATILE, DESCRIPTION, NEXT_FIRE_TIME, PREV_FIRE_TIME, TRIGGER_STATE, TRIGGER_TYPE, START_TIME, END_TIME, CALENDAR_NAME, MISFIRE_INSTR, JOB_DATA, PRIORITY)  VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"));
      localPreparedStatement.setString(1, paramTrigger.getName());
      localPreparedStatement.setString(2, paramTrigger.getGroup());
      localPreparedStatement.setString(3, paramTrigger.getJobName());
      localPreparedStatement.setString(4, paramTrigger.getJobGroup());
      localPreparedStatement.setBoolean(5, paramTrigger.isVolatile());
      localPreparedStatement.setString(6, paramTrigger.getDescription());
      localPreparedStatement.setBigDecimal(7, new BigDecimal(String.valueOf(paramTrigger.getNextFireTime().getTime())));
      long l1 = -1L;
      if (paramTrigger.getPreviousFireTime() != null) {
        l1 = paramTrigger.getPreviousFireTime().getTime();
      }
      localPreparedStatement.setBigDecimal(8, new BigDecimal(String.valueOf(l1)));
      localPreparedStatement.setString(9, paramString);
      if ((paramTrigger instanceof SimpleTrigger)) {
        localPreparedStatement.setString(10, "SIMPLE");
      } else if ((paramTrigger instanceof CronTrigger)) {
        localPreparedStatement.setString(10, "CRON");
      } else {
        localPreparedStatement.setString(10, "BLOB");
      }
      localPreparedStatement.setBigDecimal(11, new BigDecimal(String.valueOf(paramTrigger.getStartTime().getTime())));
      long l2 = 0L;
      if (paramTrigger.getEndTime() != null) {
        l2 = paramTrigger.getEndTime().getTime();
      }
      localPreparedStatement.setBigDecimal(12, new BigDecimal(String.valueOf(l2)));
      localPreparedStatement.setString(13, paramTrigger.getCalendarName());
      localPreparedStatement.setInt(14, paramTrigger.getMisfireInstruction());
      localPreparedStatement.setBinaryStream(15, null, 0);
      i = localPreparedStatement.executeUpdate();
      if (arrayOfByte != null)
      {
        localPreparedStatement.close();
        localPreparedStatement = paramConnection.prepareStatement(rtp("UPDATE {0}TRIGGERS SET JOB_DATA = EMPTY_BLOB()  WHERE TRIGGER_NAME = ? AND TRIGGER_GROUP = ?"));
        localPreparedStatement.setString(1, paramTrigger.getName());
        localPreparedStatement.setString(2, paramTrigger.getGroup());
        localPreparedStatement.executeUpdate();
        localPreparedStatement.close();
        localPreparedStatement = paramConnection.prepareStatement(rtp("SELECT JOB_DATA FROM {0}TRIGGERS WHERE TRIGGER_NAME = ? AND TRIGGER_GROUP = ? FOR UPDATE"));
        localPreparedStatement.setString(1, paramTrigger.getName());
        localPreparedStatement.setString(2, paramTrigger.getGroup());
        localResultSet = localPreparedStatement.executeQuery();
        int k = 0;
        Blob localBlob = null;
        if (localResultSet.next())
        {
          localBlob = writeDataToBlob(localResultSet, 1, arrayOfByte);
        }
        else
        {
          int m = k;
          return m;
        }
        localResultSet.close();
        localPreparedStatement.close();
        localPreparedStatement = paramConnection.prepareStatement(rtp("UPDATE {0}TRIGGERS SET JOB_DATA = ?  WHERE TRIGGER_NAME = ? AND TRIGGER_GROUP = ?"));
        localPreparedStatement.setBlob(1, localBlob);
        localPreparedStatement.setString(2, paramTrigger.getName());
        localPreparedStatement.setString(3, paramTrigger.getGroup());
        k = localPreparedStatement.executeUpdate();
      }
    }
    finally
    {
      if (localResultSet != null) {
        try
        {
          localResultSet.close();
        }
        catch (SQLException localSQLException3) {}
      }
      if (localPreparedStatement != null) {
        try
        {
          localPreparedStatement.close();
        }
        catch (SQLException localSQLException4) {}
      }
    }
    if (localResultSet != null) {
      try
      {
        localResultSet.close();
      }
      catch (SQLException localSQLException5) {}
    }
    if (localPreparedStatement != null) {
      try
      {
        localPreparedStatement.close();
      }
      catch (SQLException localSQLException6) {}
    }
    if (i > 0)
    {
      String[] arrayOfString = paramTrigger.getTriggerListenerNames();
      for (int j = 0; (arrayOfString != null) && (j < arrayOfString.length); j++) {
        insertTriggerListener(paramConnection, paramTrigger, arrayOfString[j]);
      }
    }
    return i;
  }
  
  /* Error */
  public int updateTrigger(Connection paramConnection, Trigger paramTrigger, String paramString, JobDetail paramJobDetail)
    throws SQLException, IOException
  {
    // Byte code:
    //   0: aload_2
    //   1: invokevirtual 240	org/quartz/Trigger:getJobDataMap	()Lorg/quartz/JobDataMap;
    //   4: invokevirtual 333	org/quartz/JobDataMap:isDirty	()Z
    //   7: istore 5
    //   9: aconst_null
    //   10: astore 6
    //   12: iload 5
    //   14: ifeq +26 -> 40
    //   17: aload_2
    //   18: invokevirtual 240	org/quartz/Trigger:getJobDataMap	()Lorg/quartz/JobDataMap;
    //   21: invokevirtual 243	org/quartz/JobDataMap:size	()I
    //   24: ifle +16 -> 40
    //   27: aload_0
    //   28: aload_2
    //   29: invokevirtual 240	org/quartz/Trigger:getJobDataMap	()Lorg/quartz/JobDataMap;
    //   32: invokevirtual 108	edu/thu/ext/quartz/OracleDelegate:serializeJobData	(Lorg/quartz/JobDataMap;)Ljava/io/ByteArrayOutputStream;
    //   35: invokevirtual 112	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   38: astore 6
    //   40: aconst_null
    //   41: astore 7
    //   43: aconst_null
    //   44: astore 8
    //   46: aconst_null
    //   47: astore 9
    //   49: iconst_0
    //   50: istore 10
    //   52: aload_1
    //   53: aload_0
    //   54: ldc 20
    //   56: invokevirtual 120	edu/thu/ext/quartz/OracleDelegate:rtp	(Ljava/lang/String;)Ljava/lang/String;
    //   59: invokeinterface 124 2 0
    //   64: astore 7
    //   66: aload 7
    //   68: iconst_1
    //   69: aload_2
    //   70: invokevirtual 252	org/quartz/Trigger:getJobName	()Ljava/lang/String;
    //   73: invokeinterface 134 3 0
    //   78: aload 7
    //   80: iconst_2
    //   81: aload_2
    //   82: invokevirtual 255	org/quartz/Trigger:getJobGroup	()Ljava/lang/String;
    //   85: invokeinterface 134 3 0
    //   90: aload 7
    //   92: iconst_3
    //   93: aload_2
    //   94: invokevirtual 258	org/quartz/Trigger:isVolatile	()Z
    //   97: invokeinterface 157 3 0
    //   102: aload 7
    //   104: iconst_4
    //   105: aload_2
    //   106: invokevirtual 259	org/quartz/Trigger:getDescription	()Ljava/lang/String;
    //   109: invokeinterface 134 3 0
    //   114: ldc2_w 285
    //   117: lstore 11
    //   119: aload_2
    //   120: invokevirtual 262	org/quartz/Trigger:getNextFireTime	()Ljava/util/Date;
    //   123: ifnull +12 -> 135
    //   126: aload_2
    //   127: invokevirtual 262	org/quartz/Trigger:getNextFireTime	()Ljava/util/Date;
    //   130: invokevirtual 266	java/util/Date:getTime	()J
    //   133: lstore 11
    //   135: aload 7
    //   137: iconst_5
    //   138: new 260	java/math/BigDecimal
    //   141: dup
    //   142: lload 11
    //   144: invokestatic 272	java/lang/String:valueOf	(J)Ljava/lang/String;
    //   147: invokespecial 278	java/math/BigDecimal:<init>	(Ljava/lang/String;)V
    //   150: invokeinterface 281 3 0
    //   155: ldc2_w 285
    //   158: lstore 13
    //   160: aload_2
    //   161: invokevirtual 287	org/quartz/Trigger:getPreviousFireTime	()Ljava/util/Date;
    //   164: ifnull +12 -> 176
    //   167: aload_2
    //   168: invokevirtual 287	org/quartz/Trigger:getPreviousFireTime	()Ljava/util/Date;
    //   171: invokevirtual 266	java/util/Date:getTime	()J
    //   174: lstore 13
    //   176: aload 7
    //   178: bipush 6
    //   180: new 260	java/math/BigDecimal
    //   183: dup
    //   184: lload 13
    //   186: invokestatic 272	java/lang/String:valueOf	(J)Ljava/lang/String;
    //   189: invokespecial 278	java/math/BigDecimal:<init>	(Ljava/lang/String;)V
    //   192: invokeinterface 281 3 0
    //   197: aload 7
    //   199: bipush 7
    //   201: aload_3
    //   202: invokeinterface 134 3 0
    //   207: aload_2
    //   208: instanceof 290
    //   211: ifeq +18 -> 229
    //   214: aload 7
    //   216: bipush 8
    //   218: ldc_w 292
    //   221: invokeinterface 134 3 0
    //   226: goto +37 -> 263
    //   229: aload_2
    //   230: instanceof 294
    //   233: ifeq +18 -> 251
    //   236: aload 7
    //   238: bipush 8
    //   240: ldc_w 296
    //   243: invokeinterface 134 3 0
    //   248: goto +15 -> 263
    //   251: aload 7
    //   253: bipush 8
    //   255: ldc_w 298
    //   258: invokeinterface 134 3 0
    //   263: aload 7
    //   265: bipush 9
    //   267: new 260	java/math/BigDecimal
    //   270: dup
    //   271: aload_2
    //   272: invokevirtual 300	org/quartz/Trigger:getStartTime	()Ljava/util/Date;
    //   275: invokevirtual 266	java/util/Date:getTime	()J
    //   278: invokestatic 272	java/lang/String:valueOf	(J)Ljava/lang/String;
    //   281: invokespecial 278	java/math/BigDecimal:<init>	(Ljava/lang/String;)V
    //   284: invokeinterface 281 3 0
    //   289: lconst_0
    //   290: lstore 15
    //   292: aload_2
    //   293: invokevirtual 303	org/quartz/Trigger:getEndTime	()Ljava/util/Date;
    //   296: ifnull +12 -> 308
    //   299: aload_2
    //   300: invokevirtual 303	org/quartz/Trigger:getEndTime	()Ljava/util/Date;
    //   303: invokevirtual 266	java/util/Date:getTime	()J
    //   306: lstore 15
    //   308: aload 7
    //   310: bipush 10
    //   312: new 260	java/math/BigDecimal
    //   315: dup
    //   316: lload 15
    //   318: invokestatic 272	java/lang/String:valueOf	(J)Ljava/lang/String;
    //   321: invokespecial 278	java/math/BigDecimal:<init>	(Ljava/lang/String;)V
    //   324: invokeinterface 281 3 0
    //   329: aload 7
    //   331: bipush 11
    //   333: aload_2
    //   334: invokevirtual 306	org/quartz/Trigger:getCalendarName	()Ljava/lang/String;
    //   337: invokeinterface 134 3 0
    //   342: aload 7
    //   344: bipush 12
    //   346: aload_2
    //   347: invokevirtual 309	org/quartz/Trigger:getMisfireInstruction	()I
    //   350: invokeinterface 312 3 0
    //   355: aload 7
    //   357: bipush 13
    //   359: aload_2
    //   360: invokevirtual 250	org/quartz/Trigger:getName	()Ljava/lang/String;
    //   363: invokeinterface 134 3 0
    //   368: aload 7
    //   370: bipush 14
    //   372: aload_2
    //   373: invokevirtual 251	org/quartz/Trigger:getGroup	()Ljava/lang/String;
    //   376: invokeinterface 134 3 0
    //   381: aload 7
    //   383: invokeinterface 174 1 0
    //   388: istore 10
    //   390: iload 5
    //   392: ifeq +250 -> 642
    //   395: aload 7
    //   397: invokeinterface 178 1 0
    //   402: aload_1
    //   403: aload_0
    //   404: ldc 29
    //   406: invokevirtual 120	edu/thu/ext/quartz/OracleDelegate:rtp	(Ljava/lang/String;)Ljava/lang/String;
    //   409: invokeinterface 124 2 0
    //   414: astore 7
    //   416: aload 7
    //   418: iconst_1
    //   419: aload_2
    //   420: invokevirtual 250	org/quartz/Trigger:getName	()Ljava/lang/String;
    //   423: invokeinterface 134 3 0
    //   428: aload 7
    //   430: iconst_2
    //   431: aload_2
    //   432: invokevirtual 251	org/quartz/Trigger:getGroup	()Ljava/lang/String;
    //   435: invokeinterface 134 3 0
    //   440: aload 7
    //   442: invokeinterface 174 1 0
    //   447: pop
    //   448: aload 7
    //   450: invokeinterface 178 1 0
    //   455: aload_1
    //   456: aload_0
    //   457: ldc 23
    //   459: invokevirtual 120	edu/thu/ext/quartz/OracleDelegate:rtp	(Ljava/lang/String;)Ljava/lang/String;
    //   462: invokeinterface 124 2 0
    //   467: astore 7
    //   469: aload 7
    //   471: iconst_1
    //   472: aload_2
    //   473: invokevirtual 250	org/quartz/Trigger:getName	()Ljava/lang/String;
    //   476: invokeinterface 134 3 0
    //   481: aload 7
    //   483: iconst_2
    //   484: aload_2
    //   485: invokevirtual 251	org/quartz/Trigger:getGroup	()Ljava/lang/String;
    //   488: invokeinterface 134 3 0
    //   493: aload 7
    //   495: invokeinterface 179 1 0
    //   500: astore 9
    //   502: iconst_0
    //   503: istore 17
    //   505: aload 9
    //   507: invokeinterface 183 1 0
    //   512: ifeq +130 -> 642
    //   515: aload_0
    //   516: aload 9
    //   518: iconst_1
    //   519: aload 6
    //   521: invokevirtual 186	edu/thu/ext/quartz/OracleDelegate:writeDataToBlob	(Ljava/sql/ResultSet;I[B)Ljava/sql/Blob;
    //   524: astore 18
    //   526: aload_1
    //   527: aload_0
    //   528: ldc 26
    //   530: invokevirtual 120	edu/thu/ext/quartz/OracleDelegate:rtp	(Ljava/lang/String;)Ljava/lang/String;
    //   533: invokeinterface 124 2 0
    //   538: astore 8
    //   540: aload 8
    //   542: iconst_1
    //   543: aload 18
    //   545: invokeinterface 191 3 0
    //   550: aload 8
    //   552: iconst_2
    //   553: aload_2
    //   554: invokevirtual 250	org/quartz/Trigger:getName	()Ljava/lang/String;
    //   557: invokeinterface 134 3 0
    //   562: aload 8
    //   564: iconst_3
    //   565: aload_2
    //   566: invokevirtual 251	org/quartz/Trigger:getGroup	()Ljava/lang/String;
    //   569: invokeinterface 134 3 0
    //   574: aload 8
    //   576: invokeinterface 174 1 0
    //   581: istore 17
    //   583: goto +59 -> 642
    //   586: astore 19
    //   588: aload 9
    //   590: ifnull +15 -> 605
    //   593: aload 9
    //   595: invokeinterface 190 1 0
    //   600: goto +5 -> 605
    //   603: astore 20
    //   605: aload 7
    //   607: ifnull +15 -> 622
    //   610: aload 7
    //   612: invokeinterface 178 1 0
    //   617: goto +5 -> 622
    //   620: astore 20
    //   622: aload 8
    //   624: ifnull +15 -> 639
    //   627: aload 8
    //   629: invokeinterface 178 1 0
    //   634: goto +5 -> 639
    //   637: astore 20
    //   639: aload 19
    //   641: athrow
    //   642: aload 9
    //   644: ifnull +15 -> 659
    //   647: aload 9
    //   649: invokeinterface 190 1 0
    //   654: goto +5 -> 659
    //   657: astore 20
    //   659: aload 7
    //   661: ifnull +15 -> 676
    //   664: aload 7
    //   666: invokeinterface 178 1 0
    //   671: goto +5 -> 676
    //   674: astore 20
    //   676: aload 8
    //   678: ifnull +15 -> 693
    //   681: aload 8
    //   683: invokeinterface 178 1 0
    //   688: goto +5 -> 693
    //   691: astore 20
    //   693: iload 10
    //   695: ifle +57 -> 752
    //   698: aload_0
    //   699: aload_1
    //   700: aload_2
    //   701: invokevirtual 250	org/quartz/Trigger:getName	()Ljava/lang/String;
    //   704: aload_2
    //   705: invokevirtual 251	org/quartz/Trigger:getGroup	()Ljava/lang/String;
    //   708: invokevirtual 336	edu/thu/ext/quartz/OracleDelegate:deleteTriggerListeners	(Ljava/sql/Connection;Ljava/lang/String;Ljava/lang/String;)I
    //   711: pop
    //   712: aload_2
    //   713: invokevirtual 316	org/quartz/Trigger:getTriggerListenerNames	()[Ljava/lang/String;
    //   716: astore 11
    //   718: iconst_0
    //   719: istore 12
    //   721: goto +18 -> 739
    //   724: aload_0
    //   725: aload_1
    //   726: aload_2
    //   727: aload 11
    //   729: iload 12
    //   731: aaload
    //   732: invokevirtual 319	edu/thu/ext/quartz/OracleDelegate:insertTriggerListener	(Ljava/sql/Connection;Lorg/quartz/Trigger;Ljava/lang/String;)I
    //   735: pop
    //   736: iinc 12 1
    //   739: aload 11
    //   741: ifnull +11 -> 752
    //   744: iload 12
    //   746: aload 11
    //   748: arraylength
    //   749: if_icmplt -25 -> 724
    //   752: iload 10
    //   754: ireturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	755	0	this	OracleDelegate
    //   0	755	1	paramConnection	Connection
    //   0	755	2	paramTrigger	Trigger
    //   0	755	3	paramString	String
    //   0	755	4	paramJobDetail	JobDetail
    //   7	384	5	bool	boolean
    //   10	510	6	arrayOfByte	byte[]
    //   41	624	7	localPreparedStatement1	PreparedStatement
    //   44	638	8	localPreparedStatement2	PreparedStatement
    //   47	601	9	localResultSet	ResultSet
    //   50	703	10	i	int
    //   117	26	11	l1	long
    //   716	31	11	arrayOfString	String[]
    //   719	31	12	j	int
    //   158	27	13	l2	long
    //   290	27	15	l3	long
    //   503	79	17	k	int
    //   524	20	18	localBlob	Blob
    //   586	54	19	localObject	Object
    //   603	1	20	localSQLException1	SQLException
    //   620	1	20	localSQLException2	SQLException
    //   637	1	20	localSQLException3	SQLException
    //   657	1	20	localSQLException4	SQLException
    //   674	1	20	localSQLException5	SQLException
    //   691	1	20	localSQLException6	SQLException
    // Exception table:
    //   from	to	target	type
    //   52	586	586	finally
    //   593	600	603	java/sql/SQLException
    //   610	617	620	java/sql/SQLException
    //   627	634	637	java/sql/SQLException
    //   647	654	657	java/sql/SQLException
    //   664	671	674	java/sql/SQLException
    //   681	688	691	java/sql/SQLException
  }
  
  public int insertCalendar(Connection paramConnection, String paramString, Calendar paramCalendar)
    throws IOException, SQLException
  {
    ByteArrayOutputStream localByteArrayOutputStream = serializeObject(paramCalendar);
    PreparedStatement localPreparedStatement1 = null;
    PreparedStatement localPreparedStatement2 = null;
    ResultSet localResultSet = null;
    try
    {
      localPreparedStatement1 = paramConnection.prepareStatement(rtp("INSERT INTO {0}CALENDARS (CALENDAR_NAME, CALENDAR)  VALUES(?, EMPTY_BLOB())"));
      localPreparedStatement1.setString(1, paramString);
      localPreparedStatement1.executeUpdate();
      localPreparedStatement1.close();
      localPreparedStatement1 = paramConnection.prepareStatement(rtp("SELECT CALENDAR FROM {0}CALENDARS WHERE CALENDAR_NAME = ? FOR UPDATE"));
      localPreparedStatement1.setString(1, paramString);
      localResultSet = localPreparedStatement1.executeQuery();
      if (localResultSet.next())
      {
        Blob localBlob = writeDataToBlob(localResultSet, 1, localByteArrayOutputStream.toByteArray());
        localPreparedStatement2 = paramConnection.prepareStatement(rtp("UPDATE {0}CALENDARS SET CALENDAR = ?  WHERE CALENDAR_NAME = ?"));
        localPreparedStatement2.setBlob(1, localBlob);
        localPreparedStatement2.setString(2, paramString);
        int i = localPreparedStatement2.executeUpdate();
        return i;
      }
      return 0;
    }
    finally
    {
      if (localResultSet != null) {
        try
        {
          localResultSet.close();
        }
        catch (SQLException localSQLException7) {}
      }
      if (localPreparedStatement1 != null) {
        try
        {
          localPreparedStatement1.close();
        }
        catch (SQLException localSQLException8) {}
      }
      if (localPreparedStatement2 != null) {
        try
        {
          localPreparedStatement2.close();
        }
        catch (SQLException localSQLException9) {}
      }
    }
  }
  
  public int updateCalendar(Connection paramConnection, String paramString, Calendar paramCalendar)
    throws IOException, SQLException
  {
    ByteArrayOutputStream localByteArrayOutputStream = serializeObject(paramCalendar);
    PreparedStatement localPreparedStatement1 = null;
    PreparedStatement localPreparedStatement2 = null;
    ResultSet localResultSet = null;
    try
    {
      localPreparedStatement1 = paramConnection.prepareStatement(rtp("SELECT CALENDAR FROM {0}CALENDARS WHERE CALENDAR_NAME = ? FOR UPDATE"));
      localPreparedStatement1.setString(1, paramString);
      localResultSet = localPreparedStatement1.executeQuery();
      if (localResultSet.next())
      {
        Blob localBlob = writeDataToBlob(localResultSet, 1, localByteArrayOutputStream.toByteArray());
        localPreparedStatement2 = paramConnection.prepareStatement(rtp("UPDATE {0}CALENDARS SET CALENDAR = ?  WHERE CALENDAR_NAME = ?"));
        localPreparedStatement2.setBlob(1, localBlob);
        localPreparedStatement2.setString(2, paramString);
        int i = localPreparedStatement2.executeUpdate();
        return i;
      }
      return 0;
    }
    finally
    {
      if (localResultSet != null) {
        try
        {
          localResultSet.close();
        }
        catch (SQLException localSQLException7) {}
      }
      if (localPreparedStatement1 != null) {
        try
        {
          localPreparedStatement1.close();
        }
        catch (SQLException localSQLException8) {}
      }
      if (localPreparedStatement2 != null) {
        try
        {
          localPreparedStatement2.close();
        }
        catch (SQLException localSQLException9) {}
      }
    }
  }
  
  public int updateJobData(Connection paramConnection, JobDetail paramJobDetail)
    throws IOException, SQLException
  {
    ByteArrayOutputStream localByteArrayOutputStream = serializeJobData(paramJobDetail.getJobDataMap());
    byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
    PreparedStatement localPreparedStatement1 = null;
    PreparedStatement localPreparedStatement2 = null;
    ResultSet localResultSet = null;
    try
    {
      localPreparedStatement1 = paramConnection.prepareStatement(rtp("SELECT JOB_DATA FROM {0}JOB_DETAILS WHERE JOB_NAME = ? AND JOB_GROUP = ? FOR UPDATE"));
      localPreparedStatement1.setString(1, paramJobDetail.getName());
      localPreparedStatement1.setString(2, paramJobDetail.getGroup());
      localResultSet = localPreparedStatement1.executeQuery();
      int i = 0;
      if (localResultSet.next())
      {
        Blob localBlob = writeDataToBlob(localResultSet, 1, arrayOfByte);
        localPreparedStatement2 = paramConnection.prepareStatement(rtp("UPDATE {0}JOB_DETAILS SET JOB_DATA = ?  WHERE JOB_NAME = ? AND JOB_GROUP = ?"));
        localPreparedStatement2.setBlob(1, localBlob);
        localPreparedStatement2.setString(2, paramJobDetail.getName());
        localPreparedStatement2.setString(3, paramJobDetail.getGroup());
        i = localPreparedStatement2.executeUpdate();
      }
      int j = i;
      return j;
    }
    finally
    {
      if (localResultSet != null) {
        try
        {
          localResultSet.close();
        }
        catch (SQLException localSQLException4) {}
      }
      if (localPreparedStatement1 != null) {
        try
        {
          localPreparedStatement1.close();
        }
        catch (SQLException localSQLException5) {}
      }
      if (localPreparedStatement2 != null) {
        try
        {
          localPreparedStatement2.close();
        }
        catch (SQLException localSQLException6) {}
      }
    }
  }
  
  protected Blob writeDataToBlob(ResultSet paramResultSet, int paramInt, byte[] paramArrayOfByte)
    throws SQLException
  {
    Blob localBlob = paramResultSet.getBlob(paramInt);
    if (localBlob == null) {
      throw new SQLException("Driver's Blob representation is null!");
    }
    if ((localBlob instanceof BLOB))
    {
      ((BLOB)localBlob).putBytes(1L, paramArrayOfByte);
      return localBlob;
    }
    throw new SQLException("Driver's Blob representation is of an unsupported type: " + localBlob.getClass().getName());
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\quartz\OracleDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */