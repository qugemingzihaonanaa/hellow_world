package edu.thu.ext.quartz;

import edu.thu.global.Debug;
import edu.thu.global.exceptions.Exceptions;
import java.util.Set;
import org.quartz.Calendar;
import org.quartz.JobDetail;
import org.quartz.JobPersistenceException;
import org.quartz.ObjectAlreadyExistsException;
import org.quartz.SchedulerConfigException;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.core.SchedulingContext;
import org.quartz.impl.jdbcjobstore.JobStoreSupport;
import org.quartz.simpl.RAMJobStore;
import org.quartz.spi.ClassLoadHelper;
import org.quartz.spi.JobStore;
import org.quartz.spi.SchedulerSignaler;
import org.quartz.spi.TriggerFiredBundle;

public class CacheJobStore
  implements JobStore
{
  JobStore ramStore;
  JobStore persistStore;
  
  public CacheJobStore(JobStore paramJobStore1, JobStore paramJobStore2)
  {
    Debug.check(paramJobStore1);
    Debug.check(paramJobStore2);
    this.ramStore = paramJobStore1;
    this.persistStore = paramJobStore2;
  }
  
  public CacheJobStore(JobStoreSupport paramJobStoreSupport)
  {
    this(new RAMJobStore(), paramJobStoreSupport);
  }
  
  public void init()
    throws JobPersistenceException
  {
    new QuartzStore(this.persistStore).exportTo(this.ramStore, true);
  }
  
  public Trigger acquireNextTrigger(SchedulingContext paramSchedulingContext, long paramLong)
    throws JobPersistenceException
  {
    return this.ramStore.acquireNextTrigger(paramSchedulingContext, paramLong);
  }
  
  public String[] getCalendarNames(SchedulingContext paramSchedulingContext)
    throws JobPersistenceException
  {
    return this.ramStore.getCalendarNames(paramSchedulingContext);
  }
  
  public String[] getJobGroupNames(SchedulingContext paramSchedulingContext)
    throws JobPersistenceException
  {
    return this.ramStore.getJobGroupNames(paramSchedulingContext);
  }
  
  public String[] getJobNames(SchedulingContext paramSchedulingContext, String paramString)
    throws JobPersistenceException
  {
    return this.ramStore.getJobNames(paramSchedulingContext, paramString);
  }
  
  public int getNumberOfCalendars(SchedulingContext paramSchedulingContext)
    throws JobPersistenceException
  {
    return this.ramStore.getNumberOfCalendars(paramSchedulingContext);
  }
  
  public int getNumberOfJobs(SchedulingContext paramSchedulingContext)
    throws JobPersistenceException
  {
    return this.ramStore.getNumberOfJobs(paramSchedulingContext);
  }
  
  public int getNumberOfTriggers(SchedulingContext paramSchedulingContext)
    throws JobPersistenceException
  {
    return this.ramStore.getNumberOfTriggers(paramSchedulingContext);
  }
  
  public Set getPausedTriggerGroups(SchedulingContext paramSchedulingContext)
    throws JobPersistenceException
  {
    return this.ramStore.getPausedTriggerGroups(paramSchedulingContext);
  }
  
  public String[] getTriggerGroupNames(SchedulingContext paramSchedulingContext)
    throws JobPersistenceException
  {
    return this.ramStore.getTriggerGroupNames(paramSchedulingContext);
  }
  
  public String[] getTriggerNames(SchedulingContext paramSchedulingContext, String paramString)
    throws JobPersistenceException
  {
    return this.ramStore.getTriggerNames(paramSchedulingContext, paramString);
  }
  
  public Trigger[] getTriggersForJob(SchedulingContext paramSchedulingContext, String paramString1, String paramString2)
    throws JobPersistenceException
  {
    return this.ramStore.getTriggersForJob(paramSchedulingContext, paramString1, paramString2);
  }
  
  public int getTriggerState(SchedulingContext paramSchedulingContext, String paramString1, String paramString2)
    throws JobPersistenceException
  {
    return this.ramStore.getTriggerState(paramSchedulingContext, paramString1, paramString2);
  }
  
  public void initialize(ClassLoadHelper paramClassLoadHelper, SchedulerSignaler paramSchedulerSignaler)
    throws SchedulerConfigException
  {
    this.persistStore.initialize(paramClassLoadHelper, new SchedulerSignaler()
    {
      public void notifyTriggerListenersMisfired(Trigger paramAnonymousTrigger) {}
      
      public void signalSchedulingChange() {}
      
      public void notifySchedulerListenersFinalized(Trigger paramAnonymousTrigger) {}
      
      public void signalSchedulingChange(long paramAnonymousLong) {}
    });
    this.ramStore.initialize(paramClassLoadHelper, paramSchedulerSignaler);
    try
    {
      init();
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public void pauseAll(SchedulingContext paramSchedulingContext)
    throws JobPersistenceException
  {
    this.ramStore.pauseAll(paramSchedulingContext);
    this.persistStore.pauseAll(paramSchedulingContext);
  }
  
  public void pauseJob(SchedulingContext paramSchedulingContext, String paramString1, String paramString2)
    throws JobPersistenceException
  {
    this.ramStore.pauseJob(paramSchedulingContext, paramString1, paramString2);
    this.persistStore.pauseJob(paramSchedulingContext, paramString1, paramString2);
  }
  
  public void pauseJobGroup(SchedulingContext paramSchedulingContext, String paramString)
    throws JobPersistenceException
  {
    this.ramStore.pauseJobGroup(paramSchedulingContext, paramString);
    this.persistStore.pauseJobGroup(paramSchedulingContext, paramString);
  }
  
  public void pauseTrigger(SchedulingContext paramSchedulingContext, String paramString1, String paramString2)
    throws JobPersistenceException
  {
    this.ramStore.pauseTrigger(paramSchedulingContext, paramString1, paramString2);
    this.persistStore.pauseTrigger(paramSchedulingContext, paramString1, paramString2);
  }
  
  public void pauseTriggerGroup(SchedulingContext paramSchedulingContext, String paramString)
    throws JobPersistenceException
  {
    this.ramStore.pauseTriggerGroup(paramSchedulingContext, paramString);
    this.persistStore.pauseTriggerGroup(paramSchedulingContext, paramString);
  }
  
  public void releaseAcquiredTrigger(SchedulingContext paramSchedulingContext, Trigger paramTrigger)
    throws JobPersistenceException
  {
    this.ramStore.releaseAcquiredTrigger(paramSchedulingContext, paramTrigger);
  }
  
  public boolean removeCalendar(SchedulingContext paramSchedulingContext, String paramString)
    throws JobPersistenceException
  {
    this.ramStore.removeCalendar(paramSchedulingContext, paramString);
    return this.persistStore.removeCalendar(paramSchedulingContext, paramString);
  }
  
  public boolean removeJob(SchedulingContext paramSchedulingContext, String paramString1, String paramString2)
    throws JobPersistenceException
  {
    this.ramStore.removeJob(paramSchedulingContext, paramString1, paramString2);
    return this.persistStore.removeJob(paramSchedulingContext, paramString1, paramString2);
  }
  
  public boolean removeTrigger(SchedulingContext paramSchedulingContext, String paramString1, String paramString2)
    throws JobPersistenceException
  {
    this.ramStore.removeTrigger(paramSchedulingContext, paramString1, paramString2);
    return this.persistStore.removeTrigger(paramSchedulingContext, paramString1, paramString2);
  }
  
  public boolean replaceTrigger(SchedulingContext paramSchedulingContext, String paramString1, String paramString2, Trigger paramTrigger)
    throws JobPersistenceException
  {
    this.ramStore.replaceTrigger(paramSchedulingContext, paramString1, paramString2, paramTrigger);
    return this.persistStore.replaceTrigger(paramSchedulingContext, paramString1, paramString2, paramTrigger);
  }
  
  public void resumeAll(SchedulingContext paramSchedulingContext)
    throws JobPersistenceException
  {
    this.persistStore.resumeAll(paramSchedulingContext);
    this.ramStore.resumeAll(paramSchedulingContext);
  }
  
  public void resumeJob(SchedulingContext paramSchedulingContext, String paramString1, String paramString2)
    throws JobPersistenceException
  {
    this.persistStore.resumeJob(paramSchedulingContext, paramString1, paramString2);
    this.ramStore.resumeJob(paramSchedulingContext, paramString1, paramString2);
  }
  
  public void resumeJobGroup(SchedulingContext paramSchedulingContext, String paramString)
    throws JobPersistenceException
  {
    this.persistStore.resumeJobGroup(paramSchedulingContext, paramString);
    this.ramStore.resumeJobGroup(paramSchedulingContext, paramString);
  }
  
  public void resumeTrigger(SchedulingContext paramSchedulingContext, String paramString1, String paramString2)
    throws JobPersistenceException
  {
    this.persistStore.resumeTrigger(paramSchedulingContext, paramString1, paramString2);
    this.ramStore.resumeTrigger(paramSchedulingContext, paramString1, paramString2);
  }
  
  public void resumeTriggerGroup(SchedulingContext paramSchedulingContext, String paramString)
    throws JobPersistenceException
  {
    this.persistStore.resumeTriggerGroup(paramSchedulingContext, paramString);
    this.ramStore.resumeTriggerGroup(paramSchedulingContext, paramString);
  }
  
  public Calendar retrieveCalendar(SchedulingContext paramSchedulingContext, String paramString)
    throws JobPersistenceException
  {
    return this.ramStore.retrieveCalendar(paramSchedulingContext, paramString);
  }
  
  public JobDetail retrieveJob(SchedulingContext paramSchedulingContext, String paramString1, String paramString2)
    throws JobPersistenceException
  {
    return this.ramStore.retrieveJob(paramSchedulingContext, paramString1, paramString2);
  }
  
  public Trigger retrieveTrigger(SchedulingContext paramSchedulingContext, String paramString1, String paramString2)
    throws JobPersistenceException
  {
    return this.ramStore.retrieveTrigger(paramSchedulingContext, paramString1, paramString2);
  }
  
  public void schedulerStarted()
    throws SchedulerException
  {
    this.ramStore.schedulerStarted();
  }
  
  public void shutdown()
  {
    this.ramStore.shutdown();
  }
  
  public void storeCalendar(SchedulingContext paramSchedulingContext, String paramString, Calendar paramCalendar, boolean paramBoolean1, boolean paramBoolean2)
    throws ObjectAlreadyExistsException, JobPersistenceException
  {
    this.persistStore.storeCalendar(paramSchedulingContext, paramString, paramCalendar, paramBoolean1, paramBoolean2);
    this.ramStore.storeCalendar(paramSchedulingContext, paramString, paramCalendar, paramBoolean1, paramBoolean2);
  }
  
  public void storeJob(SchedulingContext paramSchedulingContext, JobDetail paramJobDetail, boolean paramBoolean)
    throws ObjectAlreadyExistsException, JobPersistenceException
  {
    this.persistStore.storeJob(paramSchedulingContext, paramJobDetail, paramBoolean);
    this.ramStore.storeJob(paramSchedulingContext, paramJobDetail, paramBoolean);
  }
  
  public void storeJobAndTrigger(SchedulingContext paramSchedulingContext, JobDetail paramJobDetail, Trigger paramTrigger)
    throws ObjectAlreadyExistsException, JobPersistenceException
  {
    this.persistStore.storeJobAndTrigger(paramSchedulingContext, paramJobDetail, paramTrigger);
    this.ramStore.storeJobAndTrigger(paramSchedulingContext, paramJobDetail, paramTrigger);
  }
  
  public void storeTrigger(SchedulingContext paramSchedulingContext, Trigger paramTrigger, boolean paramBoolean)
    throws ObjectAlreadyExistsException, JobPersistenceException
  {
    this.persistStore.storeTrigger(paramSchedulingContext, paramTrigger, paramBoolean);
    this.ramStore.storeTrigger(paramSchedulingContext, paramTrigger, paramBoolean);
  }
  
  public boolean supportsPersistence()
  {
    return true;
  }
  
  public void triggeredJobComplete(SchedulingContext paramSchedulingContext, Trigger paramTrigger, JobDetail paramJobDetail, int paramInt)
    throws JobPersistenceException
  {
    this.ramStore.triggeredJobComplete(paramSchedulingContext, paramTrigger, paramJobDetail, paramInt);
    this.persistStore.triggeredJobComplete(paramSchedulingContext, paramTrigger, paramJobDetail, paramInt);
  }
  
  public TriggerFiredBundle triggerFired(SchedulingContext paramSchedulingContext, Trigger paramTrigger)
    throws JobPersistenceException
  {
    return this.ramStore.triggerFired(paramSchedulingContext, paramTrigger);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\quartz\CacheJobStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */