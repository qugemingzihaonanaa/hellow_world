package edu.thu.ext.quartz;

import java.lang.reflect.Method;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.commons.logging.Log;

public class WebLogicOracleDelegate
  extends OracleDelegate
{
  public WebLogicOracleDelegate(Log paramLog, String paramString1, String paramString2)
  {
    super(paramLog, paramString1, paramString2);
  }
  
  public WebLogicOracleDelegate(Log paramLog, String paramString1, String paramString2, Boolean paramBoolean)
  {
    super(paramLog, paramString1, paramString2, paramBoolean);
  }
  
  protected Blob writeDataToBlob(ResultSet paramResultSet, int paramInt, byte[] paramArrayOfByte)
    throws SQLException
  {
    Blob localBlob = paramResultSet.getBlob(paramInt);
    if (localBlob == null) {
      throw new SQLException("Driver's Blob representation is null!");
    }
    if (localBlob.getClass().getPackage().getName().startsWith("weblogic."))
    {
      try
      {
        Method localMethod = localBlob.getClass().getMethod("putBytes", new Class[] { Long.TYPE, byte[].class });
        localMethod.invoke(localBlob, new Object[] { new Long(1L), paramArrayOfByte });
      }
      catch (Exception localException)
      {
        throw new SQLException("Unable to find putBytes(long,byte[]) method on blob: " + localException);
      }
      return localBlob;
    }
    return super.writeDataToBlob(paramResultSet, paramInt, paramArrayOfByte);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\quartz\WebLogicOracleDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */