package edu.thu.ext.quartz;

import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.service.IContinuation;
import edu.thu.service.job.JobConstants;
import edu.thu.service.job.JobDescriptor;
import edu.thu.service.job.JobHolder;
import edu.thu.service.job.PeriodicConfig;
import edu.thu.service.job.PeriodicConstants;
import java.util.Date;
import java.util.Map;
import org.quartz.CronTrigger;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleTrigger;
import org.quartz.Trigger;

public class QuartzUtils
  implements PeriodicConstants, JobConstants
{
  public static void removeJobGroup(Scheduler paramScheduler, String paramString)
  {
    Debug.check(paramString);
    try
    {
      String[] arrayOfString = paramScheduler.getJobNames(paramString);
      if (arrayOfString != null)
      {
        int j = arrayOfString.length;
        for (int i = 0; i < j; i++)
        {
          String str = arrayOfString[i];
          paramScheduler.deleteJob(str, paramString);
        }
      }
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public static void clearJob(Scheduler paramScheduler)
  {
    try
    {
      String[] arrayOfString = paramScheduler.getJobGroupNames();
      int j = arrayOfString.length;
      for (int i = 0; i < j; i++) {
        removeJobGroup(paramScheduler, arrayOfString[i]);
      }
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public static Trigger makeTrigger(PeriodicConfig paramPeriodicConfig)
  {
    Object localObject;
    if (isCronTrigger(paramPeriodicConfig)) {
      localObject = A(paramPeriodicConfig);
    } else {
      localObject = B(paramPeriodicConfig);
    }
    if (paramPeriodicConfig.getMisfireInstruction() == 0) {
      ((Trigger)localObject).setMisfireInstruction(0);
    } else {
      ((Trigger)localObject).setMisfireInstruction(paramPeriodicConfig.getMisfireInstruction());
    }
    return (Trigger)localObject;
  }
  
  public static JobDescriptor makeJobDescriptor(JobDetail paramJobDetail)
  {
    JobDescriptor localJobDescriptor = new JobDescriptor();
    localJobDescriptor.setJobGroup(paramJobDetail.getGroup());
    localJobDescriptor.setJobName(paramJobDetail.getName());
    localJobDescriptor.setContinuation((IContinuation)paramJobDetail.getJobDataMap().get("continuation"));
    if (paramJobDetail.getJobClass() == JobHolder.class) {
      localJobDescriptor.setJobClass((Class)paramJobDetail.getJobDataMap().get("jobClass"));
    } else {
      localJobDescriptor.setJobClass(paramJobDetail.getJobClass());
    }
    localJobDescriptor.setArgs(paramJobDetail.getJobDataMap());
    localJobDescriptor.setDescription(paramJobDetail.getDescription());
    localJobDescriptor.setVolatile(paramJobDetail.isVolatile());
    localJobDescriptor.setShouldRecover(paramJobDetail.requestsRecovery());
    localJobDescriptor.setDurable(paramJobDetail.isDurable());
    return localJobDescriptor;
  }
  
  public static JobDetail makeJobDetail(JobDescriptor paramJobDescriptor)
  {
    JobDetail localJobDetail = makeJobDetail(paramJobDescriptor.getJobGroup(), paramJobDescriptor.getJobName(), paramJobDescriptor.getJobClass(), paramJobDescriptor.getArgs(), paramJobDescriptor.isDurable());
    localJobDetail.setVolatility(paramJobDescriptor.isVolatile());
    localJobDetail.setRequestsRecovery(paramJobDescriptor.isShouldRecover());
    localJobDetail.setDescription(paramJobDescriptor.getDescription());
    if (paramJobDescriptor.getContinuation() != null) {
      localJobDetail.getJobDataMap().put("continuation", paramJobDescriptor.getContinuation());
    }
    return localJobDetail;
  }
  
  public static JobDetail makeJobDetail(String paramString1, String paramString2, Class paramClass, Map paramMap, boolean paramBoolean)
  {
    Debug.check(paramString1);
    Debug.check(paramString2);
    Debug.check(paramClass);
    JobDetail localJobDetail = new JobDetail();
    localJobDetail.setGroup(paramString1);
    localJobDetail.setName(paramString2);
    JobDataMap localJobDataMap;
    if (Job.class.isAssignableFrom(paramClass))
    {
      localJobDetail.setJobClass(paramClass);
      if (paramMap != null)
      {
        localJobDataMap = new JobDataMap();
        localJobDataMap.putAll(paramMap);
        localJobDetail.setJobDataMap(localJobDataMap);
      }
    }
    else
    {
      Debug.check(Runnable.class.isAssignableFrom(paramClass));
      localJobDataMap = new JobDataMap();
      localJobDataMap.put("jobClass", paramClass.getName());
      if (paramMap != null) {
        localJobDataMap.putAll(paramMap);
      }
      localJobDetail.setJobDataMap(localJobDataMap);
      localJobDetail.setJobClass(JobHolder.class);
    }
    localJobDetail.setDurability(paramBoolean);
    return localJobDetail;
  }
  
  public static boolean isCronTrigger(PeriodicConfig paramPeriodicConfig)
  {
    if (("periodic".equals(paramPeriodicConfig.getMode())) && ((!"byDay".equals(paramPeriodicConfig.getPeriodicMode())) || (!"interval".equals(paramPeriodicConfig.getDayMode())))) {
      return true;
    }
    return "cron".equals(paramPeriodicConfig.getMode());
  }
  
  static CronTrigger A(PeriodicConfig paramPeriodicConfig)
  {
    CronTrigger localCronTrigger = new CronTrigger();
    Date localDate = paramPeriodicConfig.getStartTime();
    if (localDate != null) {
      localCronTrigger.setStartTime(localDate);
    }
    localCronTrigger.setEndTime(paramPeriodicConfig.getEndTime());
    try
    {
      localCronTrigger.setCronExpression(paramPeriodicConfig.toCronExpression());
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
    return localCronTrigger;
  }
  
  static SimpleTrigger B(PeriodicConfig paramPeriodicConfig)
  {
    SimpleTrigger localSimpleTrigger = new SimpleTrigger();
    Date localDate = paramPeriodicConfig.getStartTime();
    if (localDate != null) {
      localSimpleTrigger.setStartTime(localDate);
    } else {
      localSimpleTrigger.setStartTime(new Date());
    }
    localSimpleTrigger.setRepeatCount(paramPeriodicConfig.getRepeatCount());
    localSimpleTrigger.setEndTime(paramPeriodicConfig.getEndTime());
    localSimpleTrigger.setRepeatInterval(paramPeriodicConfig.getInterval());
    if (("periodic".equals(paramPeriodicConfig.getMode())) && ("byDay".equals(paramPeriodicConfig.getPeriodicMode())) && ("interval".equals(paramPeriodicConfig.getDayMode())))
    {
      localSimpleTrigger.setRepeatInterval(paramPeriodicConfig.getIntervalDay() * 24L * 60L * 60L * 1000L);
      localSimpleTrigger.setRepeatCount(-1);
    }
    return localSimpleTrigger;
  }
  
  public static PeriodicConfig getPeriodicConfigFromTrigger(Trigger paramTrigger)
  {
    if (paramTrigger == null) {
      return null;
    }
    PeriodicConfig localPeriodicConfig = new PeriodicConfig();
    localPeriodicConfig.setStartTime(paramTrigger.getStartTime());
    localPeriodicConfig.setEndTime(paramTrigger.getEndTime());
    Object localObject;
    if ((paramTrigger instanceof SimpleTrigger))
    {
      localObject = (SimpleTrigger)paramTrigger;
      int i = ((SimpleTrigger)localObject).getRepeatCount();
      if (i == -1)
      {
        localPeriodicConfig.setMode("periodic");
        localPeriodicConfig.setPeriodicMode("byDay");
        localPeriodicConfig.setDayMode("interval");
        localPeriodicConfig.setIntervalDay((int)(((SimpleTrigger)localObject).getRepeatInterval() / 86400000L));
      }
      else
      {
        localPeriodicConfig.setMode("repeat");
        localPeriodicConfig.setRepeatCount(((SimpleTrigger)localObject).getRepeatCount());
        localPeriodicConfig.setInterval(((SimpleTrigger)localObject).getRepeatInterval());
      }
    }
    else
    {
      localObject = (CronTrigger)paramTrigger;
      String str = ((CronTrigger)localObject).getCronExpression();
      localPeriodicConfig.fromCronExpression(str);
    }
    return localPeriodicConfig;
  }
  
  public static void setJob(Scheduler paramScheduler, Trigger paramTrigger, JobDetail paramJobDetail)
  {
    try
    {
      if (paramTrigger.getStartTime() == null) {
        paramTrigger.setStartTime(new Date());
      }
      paramScheduler.deleteJob(paramJobDetail.getName(), paramJobDetail.getGroup());
      paramScheduler.scheduleJob(paramJobDetail, paramTrigger);
    }
    catch (SchedulerException localSchedulerException)
    {
      if (localSchedulerException.getErrorCode() == 100) {
        throw Exceptions.code("job.CAN_err_invalid_trigger").cause(localSchedulerException);
      }
      throw Exceptions.source(localSchedulerException);
    }
  }
  
  public static String triggerStateToString(int paramInt)
  {
    if (paramInt == -1) {
      return "DELETED";
    }
    if (paramInt == 2) {
      return "COMPLETE";
    }
    if (paramInt == 1) {
      return "PAUSED";
    }
    if (paramInt == 3) {
      return "ERROR";
    }
    if (paramInt == 4) {
      return "BLOCKED";
    }
    return "WAITING";
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\ext\quartz\QuartzUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */