package edu.thu.app.oa.msg;

import edu.thu.model.stg.view.IPageViewer;
import edu.thu.search.IQuery;
import java.util.Collection;

public abstract interface IMessageStore
{
  public abstract String addSendMessage(IBasicMessage paramIBasicMessage);
  
  public abstract String addRecvMessage(IBasicMessage paramIBasicMessage);
  
  public abstract void addSendMessageMany(IMessage paramIMessage);
  
  public abstract int getUnReadCount(String paramString);
  
  public abstract IPageViewer listUnRead(IQuery paramIQuery, String paramString);
  
  public abstract IPageViewer listAll(IQuery paramIQuery, String paramString);
  
  public abstract IPageViewer listReceived(IQuery paramIQuery, String paramString);
  
  public abstract IPageViewer listSent(IQuery paramIQuery, String paramString);
  
  public abstract void markAsRead(String paramString);
  
  public abstract void markAsReceived(IBasicMessage paramIBasicMessage);
  
  public abstract void remove(String paramString);
  
  public abstract void removeMany(Collection paramCollection);
  
  public abstract IBasicMessage getMessage(String paramString);
  
  public abstract boolean exists(String paramString);
  
  public abstract void clear();
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\oa\msg\IMessageStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */