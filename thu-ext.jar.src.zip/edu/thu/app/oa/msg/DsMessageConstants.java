package edu.thu.app.oa.msg;

import java.util.Arrays;
import java.util.List;

public abstract interface DsMessageConstants
{
  public static final String DS_NAME = "oa/OA_消息.xml";
  public static final String MESSAGE_ID = "消息ID";
  public static final String FIELD_PK = "ID";
  public static final String FIELD_MESSAGE_ID = "消息ID";
  public static final String FIELD_OWNER_ID = "持有人ID";
  public static final String FIELD_INTERLOCUTOR_ID = "对话人ID";
  public static final String FIELD_OWNER = "持有人";
  public static final String FIELD_INTERLOCUTOR = "对话人";
  public static final String FIELD_DIRECTION = "方向";
  public static final String FIELD_STATUS = "状态";
  public static final String FIELD_SEND_TIME = "发送时间";
  public static final String FIELD_RECEIVE_TIME = "接收时间";
  public static final String FIELD_TITLE = "标题";
  public static final String FIELD_CONTENT = "内容";
  public static final String FIELD_TYPE = "类型";
  public static final String FIELD_PRIORITY = "优先级";
  public static final String DIRECTION_OUT = "发";
  public static final String DIRECTION_IN = "收";
  public static final String STATUS_NEW = "未阅读";
  public static final String STATUS_READ = "已阅读";
  public static final String STATUS_KEEP = "已保留";
  public static final String STATUS_SENT = "已发出";
  public static final String STATUS_RECEIVED = "已收到";
  public static final String TYPE_SINGLE = "单发";
  public static final String TYPE_MULTI = "群发";
  public static final String TYPE_SYSTEM = "系统";
  public static final String CONTENT_USER_ACKNOWLEDGED = "用户已阅读";
  public static final String TITLE_DEFAULT = "一般消息";
  public static final int PRIORITY_DEFAULT = 0;
  public static final List FIELDS = Arrays.asList(new String[] { "ID", "消息ID", "标题", "内容", "持有人ID", "对话人ID", "持有人", "对话人", "方向", "状态", "类型", "发送时间", "接收时间", "优先级" });
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\oa\msg\DsMessageConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */