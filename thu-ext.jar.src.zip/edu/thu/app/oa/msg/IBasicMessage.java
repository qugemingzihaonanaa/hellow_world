package edu.thu.app.oa.msg;

import java.util.Date;

public abstract interface IBasicMessage
{
  public abstract String getId();
  
  public abstract String getMessageType();
  
  public abstract String getTitle();
  
  public abstract String getReceiverId();
  
  public abstract String getReceiver();
  
  public abstract String getSenderId();
  
  public abstract String getSender();
  
  public abstract int getPriority();
  
  public abstract String getContent();
  
  public abstract Date getSendTime();
  
  public abstract Date getReceiveTime();
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\oa\msg\IBasicMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */