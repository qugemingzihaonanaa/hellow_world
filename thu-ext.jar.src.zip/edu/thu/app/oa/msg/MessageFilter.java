package edu.thu.app.oa.msg;

import edu.thu.search.IQuery;

public class MessageFilter
{
  public static IQuery unviewed()
  {
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\oa\msg\MessageFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */