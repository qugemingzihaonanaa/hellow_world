package edu.thu.app.oa.msg;

import java.util.List;

public class Message
  extends BasicMessage
  implements IMessage
{
  List L;
  
  public List getReceiverList()
  {
    return this.L;
  }
  
  public void setReceiverList(List paramList)
  {
    this.L = paramList;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\oa\msg\Message.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */