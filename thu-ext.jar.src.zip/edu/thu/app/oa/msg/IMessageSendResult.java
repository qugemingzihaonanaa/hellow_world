package edu.thu.app.oa.msg;

public abstract interface IMessageSendResult {}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\oa\msg\IMessageSendResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */