package edu.thu.app.oa.msg;

import java.util.Date;

public class BasicMessage
  implements IBasicMessage
{
  String B;
  String F;
  String I;
  int J;
  String C;
  String A;
  String K;
  String D;
  String G;
  Date H;
  Date E;
  
  public BasicMessage() {}
  
  public BasicMessage(IBasicMessage paramIBasicMessage)
  {
    this.B = paramIBasicMessage.getId();
    this.G = paramIBasicMessage.getContent();
    this.F = paramIBasicMessage.getMessageType();
    this.J = paramIBasicMessage.getPriority();
    this.A = paramIBasicMessage.getReceiver();
    this.C = paramIBasicMessage.getReceiverId();
    this.E = paramIBasicMessage.getReceiveTime();
    this.D = paramIBasicMessage.getSender();
    this.K = paramIBasicMessage.getSenderId();
    this.H = paramIBasicMessage.getSendTime();
    this.I = paramIBasicMessage.getTitle();
  }
  
  public String getReceiver()
  {
    return this.A;
  }
  
  public void setReceiver(String paramString)
  {
    this.A = paramString;
  }
  
  public String getMessageType()
  {
    return this.F;
  }
  
  public void setMessageType(String paramString)
  {
    this.F = paramString;
  }
  
  public String getContent()
  {
    return this.G;
  }
  
  public void setContent(String paramString)
  {
    this.G = paramString;
  }
  
  public String getId()
  {
    return this.B;
  }
  
  public void setId(String paramString)
  {
    this.B = paramString;
  }
  
  public int getPriority()
  {
    return this.J;
  }
  
  public void setPriority(int paramInt)
  {
    this.J = paramInt;
  }
  
  public Date getReceiveTime()
  {
    return this.E;
  }
  
  public void setReceiveTime(Date paramDate)
  {
    this.E = paramDate;
  }
  
  public String getSender()
  {
    return this.D;
  }
  
  public void setSender(String paramString)
  {
    this.D = paramString;
  }
  
  public Date getSendTime()
  {
    return this.H;
  }
  
  public void setSendTime(Date paramDate)
  {
    this.H = paramDate;
  }
  
  public String getTitle()
  {
    return this.I;
  }
  
  public void setTitle(String paramString)
  {
    this.I = paramString;
  }
  
  public String getReceiverId()
  {
    return this.C;
  }
  
  public void setReceiverId(String paramString)
  {
    this.C = paramString;
  }
  
  public String getSenderId()
  {
    return this.K;
  }
  
  public void setSenderId(String paramString)
  {
    this.K = paramString;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\oa\msg\BasicMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */