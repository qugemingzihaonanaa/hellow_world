package edu.thu.app.oa.msg;

import java.util.List;

public abstract interface IMessage
  extends IBasicMessage
{
  public abstract List getReceiverList();
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\oa\msg\IMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */