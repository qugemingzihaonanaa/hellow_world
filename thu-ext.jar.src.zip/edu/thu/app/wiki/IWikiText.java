package edu.thu.app.wiki;

import edu.thu.model.entity.Tags;
import java.sql.Timestamp;

public abstract interface IWikiText
{
  public abstract String getId();
  
  public abstract void setId(String paramString);
  
  public abstract String getPageName();
  
  public abstract String getWikiType();
  
  public abstract String getTitle();
  
  public abstract void setTitle(String paramString);
  
  public abstract long getVersion();
  
  public abstract void setVersion(long paramLong);
  
  public abstract String getContentType();
  
  public abstract void setContentType(String paramString);
  
  public abstract String getContent();
  
  public abstract void setContent(String paramString);
  
  public abstract int getContentLength();
  
  public abstract void setContentLength(int paramInt);
  
  public abstract Tags getTagsObj();
  
  public abstract IWikiUser getWikiCreater();
  
  public abstract void setWikiCreater(IWikiUser paramIWikiUser);
  
  public abstract Timestamp getCreateTime();
  
  public abstract void setCreateTime(Timestamp paramTimestamp);
  
  public abstract IWikiUser getWikiUpdater();
  
  public abstract void setWikiUpdater(IWikiUser paramIWikiUser);
  
  public abstract Timestamp getUpdateTime();
  
  public abstract void setUpdateTime(Timestamp paramTimestamp);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\IWikiText.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */