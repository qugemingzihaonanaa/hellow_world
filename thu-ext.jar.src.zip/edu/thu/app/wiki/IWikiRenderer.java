package edu.thu.app.wiki;

import java.io.Writer;

public abstract interface IWikiRenderer
{
  public abstract void renderTo(String paramString, Writer paramWriter);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\IWikiRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */