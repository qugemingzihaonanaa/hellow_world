package edu.thu.app.wiki;

import edu.thu.model.stg.view.IPageViewer;
import edu.thu.search.IQuery;
import edu.thu.service.IServiceContext;
import java.io.Writer;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.Set;

public abstract interface IWikiEngine
{
  public static final String CAP_LOCK = "lock";
  public static final String CAP_AUTH = "auth";
  public static final String CAP_COMMENT = "comment";
  public static final String CAP_VERSION = "version";
  public static final String CAP_SERACH = "search";
  public static final String CAP_REFERENCE = "reference";
  
  public abstract Set<String> getCapabilities();
  
  public abstract IWikiUser newUser();
  
  public abstract IWikiUser resolveUser(IWikiUser paramIWikiUser);
  
  public abstract boolean existsPage(String paramString, IServiceContext paramIServiceContext);
  
  public abstract IWikiPage getWikiPage(String paramString, IServiceContext paramIServiceContext);
  
  public abstract void renderTo(IWikiText paramIWikiText, Map paramMap, Writer paramWriter, IServiceContext paramIServiceContext);
  
  public abstract void validateWikiText(IWikiText paramIWikiText);
  
  public abstract IPageViewer findMany(IQuery paramIQuery, IServiceContext paramIServiceContext);
  
  public abstract IPageViewer listChildPages(String paramString, IServiceContext paramIServiceContext);
  
  public abstract IPageViewer listSubPagesForPageName(String paramString, IServiceContext paramIServiceContext);
  
  public abstract List<String> getToPageNames(String paramString);
  
  public abstract List<String> getFromPageNames(String paramString, IServiceContext paramIServiceContext);
  
  public abstract List<IWikiPage> getRecentChangePages(Timestamp paramTimestamp, IServiceContext paramIServiceContext);
  
  public abstract IPageViewer listChangePage(IServiceContext paramIServiceContext);
  
  public abstract IWikiPageLock lockPage(String paramString, IWikiUser paramIWikiUser);
  
  public abstract boolean unlockPage(String paramString, IWikiUser paramIWikiUser);
  
  public abstract IWikiPageLock getCurrentLock(String paramString);
  
  public abstract void onPageTextChange(IWikiPage paramIWikiPage);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\IWikiEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */