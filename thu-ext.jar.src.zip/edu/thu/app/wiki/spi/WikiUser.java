package edu.thu.app.wiki.spi;

import edu.thu.app.wiki.IWikiUser;

public class WikiUser
  implements IWikiUser
{
  String D;
  String B;
  String A;
  String C;
  
  public String getId()
  {
    return this.D;
  }
  
  public void setId(String paramString)
  {
    this.D = paramString;
  }
  
  public String getName()
  {
    return this.B;
  }
  
  public void setName(String paramString)
  {
    this.B = paramString;
  }
  
  public String getEmail()
  {
    return this.A;
  }
  
  public void setEmail(String paramString)
  {
    this.A = paramString;
  }
  
  public String getRemoteAddr()
  {
    return this.C;
  }
  
  public void setRemoteAddr(String paramString)
  {
    this.C = paramString;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof IWikiUser)) {
      return false;
    }
    IWikiUser localIWikiUser = (IWikiUser)paramObject;
    if (this.D != null) {
      return this.D.equals(localIWikiUser.getId());
    }
    return true;
  }
  
  public int hashCode()
  {
    return this.D == null ? 0 : this.D.hashCode();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\spi\WikiUser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */