package edu.thu.app.wiki.spi;

import edu.thu.app.wiki.IWikiComment;
import edu.thu.app.wiki.IWikiEngine;
import edu.thu.app.wiki.IWikiPage;
import edu.thu.app.wiki.IWikiStore;
import edu.thu.app.wiki.IWikiText;
import edu.thu.app.wiki.IWikiUser;
import edu.thu.app.wiki.entity.WikiCommentEntity;
import edu.thu.app.wiki.entity.WikiPageEntity;
import edu.thu.app.wiki.entity.WikiTextEntity;
import edu.thu.core.AppEnv;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.exceptions.StdException;
import edu.thu.model.entity.Tags;
import edu.thu.model.stg.IBinaryStreamMoniker;
import edu.thu.model.tree.LayerCode;
import edu.thu.orm.component.IFileListComponent;
import edu.thu.service.IServiceContext;
import java.io.Writer;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

public class WikiPage
  implements IWikiPage
{
  boolean A;
  WikiPageEntity B;
  IWikiEngine D;
  IWikiStore C;
  
  public WikiPage(WikiPageEntity paramWikiPageEntity, IWikiEngine paramIWikiEngine, IWikiStore paramIWikiStore)
  {
    this.B = paramWikiPageEntity;
    this.D = paramIWikiEngine;
    this.C = paramIWikiStore;
    this.A = (paramWikiPageEntity.getSid() != null);
  }
  
  public IWikiEngine getWikiEngine()
  {
    return this.D;
  }
  
  public void passivate()
  {
    this.B = null;
  }
  
  WikiPageEntity A()
  {
    return this.B;
  }
  
  public boolean isExisting()
  {
    return this.A;
  }
  
  public LayerCode getPageLc()
  {
    return A().getPageLc();
  }
  
  public LayerCode getLc()
  {
    return A().getLc();
  }
  
  public String getPageName()
  {
    return A().getPageName();
  }
  
  public String getTitle()
  {
    return A().getTitle();
  }
  
  public Tags getTagsObj()
  {
    return A().getTagsObj();
  }
  
  public Map<String, Object> getAttributes()
  {
    return A().getAttributes();
  }
  
  public Object getAttribute(String paramString)
  {
    return getAttributes().get(paramString);
  }
  
  public void setAttribute(String paramString, Object paramObject)
  {
    getAttributes().put(paramString, paramObject);
  }
  
  public void removeAttribute(String paramString)
  {
    getAttributes().remove(paramString);
  }
  
  public IWikiText getWikiText()
  {
    return A().getWikiText();
  }
  
  public List<? extends IWikiText> getHistoryVersions()
  {
    return this.C.getHistoryVersions(this.B);
  }
  
  public IWikiText getVersion(long paramLong)
  {
    return this.C.getVersion(this.B, paramLong);
  }
  
  public List<? extends IWikiComment> getComments()
  {
    return this.C.getComments(this.B);
  }
  
  public IWikiComment getComment(String paramString)
  {
    return this.C.getComment(this.B, paramString);
  }
  
  public IWikiComment newComment(IWikiUser paramIWikiUser)
  {
    WikiCommentEntity localWikiCommentEntity = new WikiCommentEntity();
    localWikiCommentEntity.setWikiPageEntity(this.B);
    Timestamp localTimestamp = new Timestamp(AppEnv.currentTimeMillis());
    localWikiCommentEntity.setWikiCreater(paramIWikiUser);
    localWikiCommentEntity.setCreateTime(localTimestamp);
    localWikiCommentEntity.setWikiUpdater(paramIWikiUser);
    localWikiCommentEntity.setUpdateTime(localTimestamp);
    return localWikiCommentEntity;
  }
  
  public IWikiText newWikiText(IWikiUser paramIWikiUser)
  {
    WikiTextEntity localWikiTextEntity = new WikiTextEntity();
    localWikiTextEntity.setWikiPageEntity(this.B);
    Timestamp localTimestamp = new Timestamp(AppEnv.currentTimeMillis());
    localWikiTextEntity.setWikiCreater(paramIWikiUser);
    localWikiTextEntity.setCreateTime(localTimestamp);
    localWikiTextEntity.setWikiUpdater(paramIWikiUser);
    localWikiTextEntity.setUpdateTime(localTimestamp);
    return localWikiTextEntity;
  }
  
  public IFileListComponent getAttachments()
  {
    return this.C.getAttatchments(this.B);
  }
  
  public void removeAttachment(String paramString)
  {
    this.C.removeAttachment(this.B, paramString);
  }
  
  public void saveAttachment(String paramString, IBinaryStreamMoniker paramIBinaryStreamMoniker)
  {
    this.C.saveAttachment(this.B, paramString, paramIBinaryStreamMoniker);
  }
  
  public void remove()
  {
    this.C.remove(this.B);
    this.B.setWikiText(null);
    this.A = false;
    this.D.onPageTextChange(this);
  }
  
  public void saveWikiText(IWikiText paramIWikiText)
  {
    this.C.saveWikiText((WikiTextEntity)paramIWikiText);
    if (A().getWikiText() == paramIWikiText) {
      this.D.onPageTextChange(this);
    }
  }
  
  public void saveComment(IWikiComment paramIWikiComment)
  {
    if (this.B != ((WikiCommentEntity)paramIWikiComment).getWikiPageEntity()) {
      throw Exceptions.code("wiki.CAN_err_invalid_comment").param(paramIWikiComment.getId()).param(paramIWikiComment.getPageName());
    }
    this.C.saveComment((WikiCommentEntity)paramIWikiComment);
  }
  
  public void removeComment(IWikiComment paramIWikiComment)
  {
    if (this.B != ((WikiCommentEntity)paramIWikiComment).getWikiPageEntity()) {
      throw Exceptions.code("wiki.CAN_err_invalid_comment").param(paramIWikiComment.getId()).param(paramIWikiComment.getPageName());
    }
    this.C.removeComment((WikiCommentEntity)paramIWikiComment);
  }
  
  public void removeVersion(IWikiText paramIWikiText)
  {
    this.C.removeVersion((WikiTextEntity)paramIWikiText);
  }
  
  public void save()
  {
    this.C.save(this.B);
    this.A = true;
  }
  
  public Timestamp getUpdateTime()
  {
    return A().getUpdateTime();
  }
  
  public IWikiUser getWikiUpdater()
  {
    return A().getWikiUpdater();
  }
  
  public void setUpdateTime(Timestamp paramTimestamp)
  {
    A().setUpdateTime(paramTimestamp);
  }
  
  public void setWikiUpdater(IWikiUser paramIWikiUser)
  {
    A().setWikiUpdater(paramIWikiUser);
  }
  
  public void renderTo(IWikiText paramIWikiText, Map paramMap, Writer paramWriter, IServiceContext paramIServiceContext)
  {
    this.D.renderTo(paramIWikiText, paramMap, paramWriter, paramIServiceContext);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\spi\WikiPage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */