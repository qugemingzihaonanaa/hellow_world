package edu.thu.app.wiki.spi;

import edu.thu.app.wiki.IWikiPageLock;
import edu.thu.app.wiki.IWikiUser;
import java.sql.Timestamp;

public class WikiPageLock
  implements IWikiPageLock
{
  String B;
  Timestamp A;
  Timestamp C;
  IWikiUser D;
  
  public Timestamp getAcquireTime()
  {
    return this.A;
  }
  
  public void setAcquireTime(Timestamp paramTimestamp)
  {
    this.A = paramTimestamp;
  }
  
  public Timestamp getExpireTime()
  {
    return this.C;
  }
  
  public void setExpireTime(Timestamp paramTimestamp)
  {
    this.C = paramTimestamp;
  }
  
  public IWikiUser getLocker()
  {
    return this.D;
  }
  
  public void setLocker(IWikiUser paramIWikiUser)
  {
    this.D = paramIWikiUser;
  }
  
  public String getPageName()
  {
    return this.B;
  }
  
  public void setPageName(String paramString)
  {
    this.B = paramString;
  }
  
  public boolean isLockByUser(String paramString)
  {
    return this.D.getId().equals(paramString);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\spi\WikiPageLock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */