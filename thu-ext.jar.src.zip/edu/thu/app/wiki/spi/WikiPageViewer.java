package edu.thu.app.wiki.spi;

import edu.thu.app.wiki.entity.WikiPageEntity;
import edu.thu.model.stg.view.IPageViewer;
import java.util.List;

public class WikiPageViewer
  implements IPageViewer
{
  WikiEngine wikiEngine;
  IPageViewer viewer;
  
  public WikiPageViewer(WikiEngine paramWikiEngine, IPageViewer paramIPageViewer)
  {
    this.wikiEngine = paramWikiEngine;
    this.viewer = paramIPageViewer;
  }
  
  public List getAll()
  {
    return this.wikiEngine.wrapPageList(this.viewer.getAll());
  }
  
  public Object getOne(long paramLong)
  {
    return this.wikiEngine.wrapPage((WikiPageEntity)this.viewer.getOne(paramLong));
  }
  
  public long getTotalCount()
  {
    return this.viewer.getTotalCount();
  }
  
  public List listPage(long paramLong, int paramInt)
  {
    return this.wikiEngine.wrapPageList(this.viewer.listPage(paramLong, paramInt));
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\spi\WikiPageViewer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */