package edu.thu.app.wiki.spi;

import edu.thu.app.wiki.IWikiEngine;
import edu.thu.app.wiki.IWikiPage;
import edu.thu.app.wiki.model.WikiLink;
import edu.thu.model.tree.LayerCode;
import edu.thu.search.Query;
import edu.thu.search.Query.ConditionSpec;
import edu.thu.search.Query.OrderBySpec;
import edu.thu.service.IServiceContext;
import java.sql.Timestamp;

public class WikiQuery
{
  public static Query buildQuery(Query paramQuery, String paramString1, Timestamp paramTimestamp, String paramString2, IWikiEngine paramIWikiEngine, IServiceContext paramIServiceContext)
  {
    if (paramString1 == null) {
      paramString1 = "subPagesForPageName";
    }
    String str;
    IWikiPage localIWikiPage;
    if (paramString1.equals("childPages"))
    {
      str = WikiLink.getPageDirName(paramString2);
      if ((str == null) || (str.length() <= 0)) {
        return condAll(paramQuery);
      }
      localIWikiPage = paramIWikiEngine.getWikiPage(str, paramIServiceContext);
      return condChildPages(paramQuery, localIWikiPage.getLc());
    }
    if (paramString1.equals("subPagesForPageName"))
    {
      str = WikiLink.getPageDirName(paramString2);
      if ((str == null) || (str.length() <= 0)) {
        return condAll(paramQuery);
      }
      localIWikiPage = paramIWikiEngine.getWikiPage(str, paramIServiceContext);
      return condSubPagesForPageName(paramQuery, localIWikiPage.getPageLc());
    }
    if (paramString1.equals("topPages")) {
      return condTopPages(paramQuery);
    }
    if (paramString1.equals("recentChange")) {
      return condRecentChange(paramQuery, paramTimestamp);
    }
    if (paramString1.equals("changePage")) {
      return condChangePage(paramQuery);
    }
    if (paramString1.equals("all")) {
      return condAll(paramQuery);
    }
    return paramQuery;
  }
  
  public static Query condChildPages(Query paramQuery, LayerCode paramLayerCode)
  {
    if (paramLayerCode == null) {
      return paramQuery;
    }
    paramQuery.condition().include_direct_sub("layerCode", paramLayerCode, "layerLeve").orderby().field("layerCode", true).end();
    return paramQuery;
  }
  
  public static Query condSubPagesForPageName(Query paramQuery, LayerCode paramLayerCode)
  {
    paramQuery.condition().include_direct_sub("lcPageName", paramLayerCode.toLowerCase(), "pageLevel").orderby().field("lcPageName", true).end();
    return paramQuery;
  }
  
  public static Query condTopPages(Query paramQuery)
  {
    paramQuery.condition().eq("pageLevel", Integer.valueOf(1)).orderby().field("lcPageName", true).end();
    return paramQuery;
  }
  
  public static Query condRecentChange(Query paramQuery, Timestamp paramTimestamp)
  {
    paramQuery.condition().ge("updateTime", paramTimestamp).orderby().field("updateTime", false).end();
    return paramQuery;
  }
  
  public static Query condChangePage(Query paramQuery)
  {
    paramQuery.condition().orderby().field("updateTime", false).end();
    return paramQuery;
  }
  
  public static Query condAll(Query paramQuery)
  {
    paramQuery.orderby().field("lcPageName", true).end();
    return paramQuery;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\spi\WikiQuery.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */