package edu.thu.app.wiki.spi;

import edu.thu.app.wiki.IWikiEngine;
import edu.thu.app.wiki.IWikiLockManager;
import edu.thu.app.wiki.IWikiPage;
import edu.thu.app.wiki.IWikiPageLock;
import edu.thu.app.wiki.IWikiRelationManager;
import edu.thu.app.wiki.IWikiStore;
import edu.thu.app.wiki.IWikiText;
import edu.thu.app.wiki.IWikiUser;
import edu.thu.app.wiki.entity.WikiPageEntity;
import edu.thu.app.wiki.entity.WikiPageEntityPK;
import edu.thu.app.wiki.entity.WikiTextEntity;
import edu.thu.app.wiki.model.WikiLink;
import edu.thu.app.wiki.model.WikiModel;
import edu.thu.app.wiki.model.parse.WikiParser;
import edu.thu.config.AppConfig;
import edu.thu.global.Debug;
import edu.thu.java.util.Coercions;
import edu.thu.lang.util.TplC;
import edu.thu.model.stg.view.IPageViewer;
import edu.thu.search.IQuery;
import edu.thu.service.IServiceContext;
import java.io.Writer;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class WikiEngine
  implements IWikiEngine
{
  Set<String> A = new HashSet();
  String E = "default";
  IWikiStore D;
  IWikiLockManager F;
  IWikiRelationManager B;
  Map<String, WikiModel> C = new HashMap();
  
  public String normalizePageName(String paramString)
  {
    return WikiLink.normalizePageName(paramString);
  }
  
  public boolean existsPage(String paramString, IServiceContext paramIServiceContext)
  {
    paramString = normalizePageName(paramString);
    WikiPageEntityPK localWikiPageEntityPK = new WikiPageEntityPK();
    localWikiPageEntityPK.setWikiType(getWikiType());
    localWikiPageEntityPK.setPageName(paramString);
    return this.D.existsPage(localWikiPageEntityPK);
  }
  
  public boolean isUseWikiCache()
  {
    return Coercions.toBoolean(AppConfig.getVar("wiki.page_cache." + getWikiType()), false);
  }
  
  public void onPageTextChange(IWikiPage paramIWikiPage)
  {
    if (paramIWikiPage.getWikiText() == null)
    {
      if (isUseWikiCache()) {
        synchronized (this.C)
        {
          this.C.remove(paramIWikiPage.getPageName());
        }
      }
      if (this.B != null) {
        this.B.updatePageRelations(paramIWikiPage.getPageName(), null);
      }
      return;
    }
    ??? = A(paramIWikiPage.getWikiText());
    if ((isUseWikiCache()) && (((WikiModel)???).getWikiTextId() != null)) {
      synchronized (this.C)
      {
        this.C.put(paramIWikiPage.getPageName(), ???);
      }
    }
    if (this.B != null) {
      this.B.updatePageRelations(paramIWikiPage.getPageName(), ((WikiModel)???).getToPageNames());
    }
  }
  
  WikiParser A()
  {
    WikiParser localWikiParser = new WikiParser();
    localWikiParser.setOnlyWikiTag(true);
    return localWikiParser;
  }
  
  WikiModel A(IWikiText paramIWikiText)
  {
    WikiModel localWikiModel = this.D.loadWikiModel((WikiTextEntity)paramIWikiText);
    if (localWikiModel == null) {
      localWikiModel = A().parseText(paramIWikiText.getContent());
    }
    localWikiModel.setWikiTextId(paramIWikiText.getId());
    return localWikiModel;
  }
  
  public String getWikiType()
  {
    return this.E;
  }
  
  public void setWikiType(String paramString)
  {
    this.E = paramString;
  }
  
  public void setWikiCache(Map<String, WikiModel> paramMap)
  {
    this.C = paramMap;
  }
  
  public void setWikiStore(IWikiStore paramIWikiStore)
  {
    this.D = paramIWikiStore;
  }
  
  public void setWikiLockManager(IWikiLockManager paramIWikiLockManager)
  {
    this.F = paramIWikiLockManager;
  }
  
  public void setWikiRelationManager(IWikiRelationManager paramIWikiRelationManager)
  {
    this.B = paramIWikiRelationManager;
  }
  
  public IPageViewer findMany(IQuery paramIQuery, IServiceContext paramIServiceContext)
  {
    return new WikiPageViewer(this, this.D.findMany(getWikiType(), paramIQuery, paramIServiceContext));
  }
  
  public Set<String> getCapabilities()
  {
    return this.A;
  }
  
  public IWikiPageLock getCurrentLock(String paramString)
  {
    if (this.F == null) {
      return null;
    }
    paramString = normalizePageName(paramString);
    return this.F.getCurrentLock(paramString);
  }
  
  public List<String> getFromPageNames(String paramString, IServiceContext paramIServiceContext)
  {
    if (this.B == null) {
      return null;
    }
    paramString = normalizePageName(paramString);
    return this.B.getFromPages(paramString, paramIServiceContext);
  }
  
  public List<IWikiPage> getRecentChangePages(Timestamp paramTimestamp, IServiceContext paramIServiceContext)
  {
    return wrapPageList(this.D.getRecentChangePages(getWikiType(), paramTimestamp, paramIServiceContext));
  }
  
  public IPageViewer listChildPages(String paramString, IServiceContext paramIServiceContext)
  {
    paramString = normalizePageName(paramString);
    if (paramString.length() <= 0) {
      return new WikiPageViewer(this, this.D.listTopPages(this.E, paramIServiceContext));
    }
    WikiPageEntityPK localWikiPageEntityPK = new WikiPageEntityPK();
    localWikiPageEntityPK.setWikiType(getWikiType());
    localWikiPageEntityPK.setPageName(paramString);
    WikiPageEntity localWikiPageEntity = this.D.getPage(localWikiPageEntityPK);
    if (localWikiPageEntity == null) {
      return null;
    }
    return new WikiPageViewer(this, this.D.listChildPages(localWikiPageEntity, paramIServiceContext));
  }
  
  public IPageViewer listSubPagesForPageName(String paramString, IServiceContext paramIServiceContext)
  {
    paramString = normalizePageName(paramString);
    if (paramString.length() <= 0) {
      return new WikiPageViewer(this, this.D.listTopPages(this.E, paramIServiceContext));
    }
    WikiPageEntityPK localWikiPageEntityPK = new WikiPageEntityPK();
    localWikiPageEntityPK.setWikiType(getWikiType());
    localWikiPageEntityPK.setPageName(paramString);
    WikiPageEntity localWikiPageEntity = this.D.getPage(localWikiPageEntityPK);
    if (localWikiPageEntity == null) {
      return null;
    }
    return new WikiPageViewer(this, this.D.listSubPagesForPageName(localWikiPageEntity, paramIServiceContext));
  }
  
  public List<String> getToPageNames(String paramString)
  {
    if (this.B == null) {
      return null;
    }
    paramString = normalizePageName(paramString);
    return this.B.getToPages(paramString);
  }
  
  public IWikiPage getWikiPage(String paramString, IServiceContext paramIServiceContext)
  {
    paramString = normalizePageName(paramString);
    WikiPageEntityPK localWikiPageEntityPK = new WikiPageEntityPK();
    localWikiPageEntityPK.setWikiType(getWikiType());
    localWikiPageEntityPK.setPageName(paramString);
    WikiPageEntity localWikiPageEntity = this.D.getPage(localWikiPageEntityPK);
    Debug.check(localWikiPageEntity);
    return wrapPage(localWikiPageEntity);
  }
  
  protected WikiPage wrapPage(WikiPageEntity paramWikiPageEntity)
  {
    if (paramWikiPageEntity == null) {
      return null;
    }
    return new WikiPage(paramWikiPageEntity, this, this.D);
  }
  
  protected List<IWikiPage> wrapPageList(List paramList)
  {
    if (paramList == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(paramList.size());
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      WikiPageEntity localWikiPageEntity = (WikiPageEntity)paramList.get(i);
      localArrayList.add(wrapPage(localWikiPageEntity));
    }
    return localArrayList;
  }
  
  public IPageViewer listChangePage(IServiceContext paramIServiceContext)
  {
    return new WikiPageViewer(this, this.D.listChangePage(getWikiType(), paramIServiceContext));
  }
  
  public IWikiPageLock lockPage(String paramString, IWikiUser paramIWikiUser)
  {
    if (this.F == null) {
      return null;
    }
    paramString = normalizePageName(paramString);
    return this.F.lockPage(paramString, paramIWikiUser);
  }
  
  public void renderTo(IWikiText paramIWikiText, Map paramMap, Writer paramWriter, IServiceContext paramIServiceContext)
  {
    if (paramIWikiText == null) {
      return;
    }
    WikiModel localWikiModel = null;
    if (isUseWikiCache()) {
      synchronized (this.C)
      {
        localWikiModel = (WikiModel)this.C.get(paramIWikiText.getPageName());
        if ((localWikiModel != null) && (!localWikiModel.getWikiTextId().equals(paramIWikiText.getId()))) {
          localWikiModel = null;
        }
      }
    }
    if (localWikiModel == null)
    {
      localWikiModel = A(paramIWikiText);
      if (isUseWikiCache())
      {
        ??? = (WikiTextEntity)paramIWikiText;
        if (((WikiTextEntity)???).getWikiPageEntity().getWikiText() == paramIWikiText) {
          this.C.put(paramIWikiText.getPageName(), localWikiModel);
        }
      }
    }
    if (paramMap == null) {
      paramMap = new HashMap();
    }
    paramMap.put("wikiModel", localWikiModel);
    TplC.render(localWikiModel.getTpl(), paramMap, paramWriter, paramIServiceContext);
    paramMap.remove("wikiModel");
  }
  
  public IWikiUser newUser()
  {
    return new WikiUser();
  }
  
  public IWikiUser resolveUser(IWikiUser paramIWikiUser)
  {
    return paramIWikiUser;
  }
  
  public boolean unlockPage(String paramString, IWikiUser paramIWikiUser)
  {
    if (this.F == null) {
      return false;
    }
    paramString = normalizePageName(paramString);
    return this.F.unlockPage(paramString, paramIWikiUser);
  }
  
  public void validateWikiText(IWikiText paramIWikiText)
  {
    A(paramIWikiText);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\spi\WikiEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */