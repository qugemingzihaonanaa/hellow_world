package edu.thu.app.wiki.spi;

import edu.thu.app.wiki.IWikiRelationManager;
import edu.thu.service.IServiceContext;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class WikiRelationManager
  implements IWikiRelationManager, Serializable
{
  private static final long serialVersionUID = 5992437203780759532L;
  Map<String, Set<String>> A = new HashMap();
  Map<String, Set<String>> B = new HashMap();
  
  public void clear()
  {
    synchronized (this.A)
    {
      this.A.clear();
    }
    synchronized (this.B)
    {
      this.B.clear();
    }
  }
  
  public List<String> getFromPages(String paramString, IServiceContext paramIServiceContext)
  {
    synchronized (this.A)
    {
      Set localSet = (Set)this.A.get(paramString);
      if (localSet == null) {
        return null;
      }
      return new ArrayList(localSet);
    }
  }
  
  public List<String> getToPages(String paramString)
  {
    synchronized (this.B)
    {
      Set localSet = (Set)this.B.get(paramString);
      if (localSet == null) {
        return null;
      }
      return new ArrayList(localSet);
    }
  }
  
  public void updatePageRelations(String paramString, List<String> paramList)
  {
    synchronized (this.B)
    {
      if ((paramList == null) || (paramList.isEmpty())) {
        this.B.remove(paramString);
      } else {
        this.B.put(paramString, new TreeSet(paramList));
      }
    }
    if ((paramList != null) && (!paramList.isEmpty())) {
      synchronized (this.A)
      {
        int j = paramList.size();
        for (int i = 0; i < j; i++)
        {
          Object localObject1 = (Set)this.A.get(paramList.get(i));
          if (localObject1 == null)
          {
            localObject1 = new TreeSet();
            this.A.put((String)paramList.get(i), localObject1);
          }
          ((Set)localObject1).add(paramString);
        }
      }
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\spi\WikiRelationManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */