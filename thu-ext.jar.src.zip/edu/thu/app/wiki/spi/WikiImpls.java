package edu.thu.app.wiki.spi;

import edu.thu.app.wiki.IWikiPage;
import edu.thu.ext.hibernate.FileListItem;

public class WikiImpls
{
  public static void updateAttachments(IWikiPage paramIWikiPage, FileListItem paramFileListItem) {}
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\spi\WikiImpls.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */