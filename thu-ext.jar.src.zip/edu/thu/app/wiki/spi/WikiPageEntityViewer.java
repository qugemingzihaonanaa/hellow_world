package edu.thu.app.wiki.spi;

import edu.thu.app.wiki.entity.WikiPageEntity;
import edu.thu.model.stg.view.IPageViewer;
import java.util.List;

public class WikiPageEntityViewer
  implements IPageViewer
{
  DaoWikiStore wikiStore;
  IPageViewer viewer;
  
  public WikiPageEntityViewer(DaoWikiStore paramDaoWikiStore, IPageViewer paramIPageViewer)
  {
    this.wikiStore = paramDaoWikiStore;
    this.viewer = paramIPageViewer;
  }
  
  public List getAll()
  {
    return this.wikiStore.initPageEntityList(this.viewer.getAll());
  }
  
  public Object getOne(long paramLong)
  {
    return this.wikiStore.initPageEntity((WikiPageEntity)this.viewer.getOne(paramLong));
  }
  
  public long getTotalCount()
  {
    return this.viewer.getTotalCount();
  }
  
  public List listPage(long paramLong, int paramInt)
  {
    return this.wikiStore.initPageEntityList(this.viewer.listPage(paramLong, paramInt));
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\spi\WikiPageEntityViewer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */