package edu.thu.app.wiki.spi;

import edu.thu.app.wiki.IWikiLockManager;
import edu.thu.app.wiki.IWikiPageLock;
import edu.thu.app.wiki.IWikiUser;
import edu.thu.core.AppEnv;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

public class WikiLockManager
  implements IWikiLockManager
{
  long A = 1800000L;
  Map<String, WikiPageLock> B = new HashMap();
  
  public long getExpireInterval()
  {
    return this.A;
  }
  
  public void setExpireInterval(long paramLong)
  {
    this.A = paramLong;
  }
  
  public synchronized IWikiPageLock lockPage(String paramString, IWikiUser paramIWikiUser)
  {
    Object localObject = (WikiPageLock)this.B.get(paramString);
    if (localObject == null)
    {
      WikiPageLock localWikiPageLock = new WikiPageLock();
      Timestamp localTimestamp1 = new Timestamp(AppEnv.currentTimeMillis());
      Timestamp localTimestamp2 = new Timestamp(AppEnv.currentTimeMillis() + this.A);
      localWikiPageLock.setAcquireTime(localTimestamp1);
      localWikiPageLock.setExpireTime(localTimestamp2);
      localWikiPageLock.setLocker(paramIWikiUser);
      localWikiPageLock.setPageName(paramString);
      this.B.put(paramString, localWikiPageLock);
      localObject = localWikiPageLock;
    }
    else if (((WikiPageLock)localObject).getLocker().equals(paramIWikiUser))
    {
      ((WikiPageLock)localObject).setExpireTime(new Timestamp(AppEnv.currentTimeMillis() + this.A));
    }
    return (IWikiPageLock)localObject;
  }
  
  public synchronized boolean unlockPage(String paramString, IWikiUser paramIWikiUser)
  {
    WikiPageLock localWikiPageLock = (WikiPageLock)this.B.get(paramString);
    if (localWikiPageLock == null) {
      return false;
    }
    if (localWikiPageLock.getLocker().equals(paramIWikiUser))
    {
      this.B.remove(paramString);
      return true;
    }
    return false;
  }
  
  public synchronized IWikiPageLock getCurrentLock(String paramString)
  {
    return (IWikiPageLock)this.B.get(paramString);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\spi\WikiLockManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */