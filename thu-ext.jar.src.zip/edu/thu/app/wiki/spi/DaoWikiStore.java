package edu.thu.app.wiki.spi;

import edu.thu.app.wiki.IWikiComment;
import edu.thu.app.wiki.IWikiStore;
import edu.thu.app.wiki.IWikiText;
import edu.thu.app.wiki.entity.WikiCommentEntity;
import edu.thu.app.wiki.entity.WikiPageEntity;
import edu.thu.app.wiki.entity.WikiPageEntityPK;
import edu.thu.app.wiki.entity.WikiTextEntity;
import edu.thu.app.wiki.model.WikiModel;
import edu.thu.core.AppEnv;
import edu.thu.db.SQL;
import edu.thu.db.SqlBuilder;
import edu.thu.ext.hibernate.AbstractHibernateDao;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.exceptions.NotSupportedException;
import edu.thu.lang.exceptions.StdException;
import edu.thu.model.entity.seq.ISequenceGenerator;
import edu.thu.model.entity.seq.SequenceGenerator;
import edu.thu.model.stg.IBinaryStreamMoniker;
import edu.thu.model.stg.view.IPageViewer;
import edu.thu.model.tree.LayerCode;
import edu.thu.model.tree.TreeNode;
import edu.thu.orm.component.IFileListComponent;
import edu.thu.orm.component.impl.FileListComponent;
import edu.thu.orm.dao.IEntityDao;
import edu.thu.orm.dao.IOrmTemplate;
import edu.thu.search.IQuery;
import edu.thu.search.Query;
import edu.thu.search.Query.ConditionSpec;
import edu.thu.search.Query.FieldSpec;
import edu.thu.service.IServiceContext;
import edu.thu.xml.dom.DomToTree;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

public class DaoWikiStore
  extends AbstractHibernateDao
  implements IWikiStore
{
  public static final String EMPTY_ID = "";
  Map<WikiPageEntityPK, String> pageNameToId = Collections.synchronizedMap(new WeakHashMap());
  boolean useCache;
  
  public void setUseCache(boolean paramBoolean)
  {
    this.useCache = paramBoolean;
  }
  
  public boolean isUseCache()
  {
    return this.useCache;
  }
  
  public boolean existsPage(WikiPageEntityPK paramWikiPageEntityPK)
  {
    String str = (String)this.pageNameToId.get(paramWikiPageEntityPK);
    if ("".equals(str)) {
      return false;
    }
    WikiPageEntity localWikiPageEntity = loadPageEntity(paramWikiPageEntityPK);
    if (localWikiPageEntity == null)
    {
      if (isUseCache()) {
        this.pageNameToId.put(paramWikiPageEntityPK, "");
      }
      return false;
    }
    this.pageNameToId.put(paramWikiPageEntityPK, localWikiPageEntity.getSid());
    return true;
  }
  
  public IPageViewer listChildPages(WikiPageEntity paramWikiPageEntity, IServiceContext paramIServiceContext)
  {
    LayerCode localLayerCode = paramWikiPageEntity.getPageLc();
    if (localLayerCode == null) {
      return null;
    }
    Query localQuery = WikiQuery.condChildPages(Query.begin().end(), localLayerCode);
    return findMany(paramWikiPageEntity.getWikiType(), localQuery, paramIServiceContext);
  }
  
  public IPageViewer listSubPagesForPageName(WikiPageEntity paramWikiPageEntity, IServiceContext paramIServiceContext)
  {
    LayerCode localLayerCode = paramWikiPageEntity.getPageLc();
    if (localLayerCode == null) {
      return null;
    }
    Query localQuery = WikiQuery.condSubPagesForPageName(Query.begin().end(), localLayerCode);
    return findMany(paramWikiPageEntity.getWikiType(), localQuery, paramIServiceContext);
  }
  
  public IPageViewer listTopPages(String paramString, IServiceContext paramIServiceContext)
  {
    return findMany(paramString, WikiQuery.condTopPages(Query.begin().end()), paramIServiceContext);
  }
  
  public IWikiComment getComment(WikiPageEntity paramWikiPageEntity, String paramString)
  {
    WikiCommentEntity localWikiCommentEntity = (WikiCommentEntity)orm().get(WikiCommentEntity.class.getName(), paramString);
    if (localWikiCommentEntity == null) {
      return null;
    }
    if (localWikiCommentEntity.getWikiPageEntity() != paramWikiPageEntity) {
      throw Exceptions.code("wf.CAN_err_invalid_comment").param(paramString).param(paramWikiPageEntity);
    }
    return localWikiCommentEntity;
  }
  
  public List<WikiCommentEntity> getComments(WikiPageEntity paramWikiPageEntity)
  {
    return new ArrayList(paramWikiPageEntity.getWikiCommentEntitys());
  }
  
  public List<WikiTextEntity> getHistoryVersions(WikiPageEntity paramWikiPageEntity)
  {
    ArrayList localArrayList = new ArrayList(paramWikiPageEntity.getWikiTextEntitys());
    int j = localArrayList.size();
    for (int i = 0; i < j; i++)
    {
      IWikiText localIWikiText = (IWikiText)localArrayList.get(i);
      if (localIWikiText.getId().equals(paramWikiPageEntity.getCurTextId()))
      {
        localArrayList.remove(i);
        break;
      }
    }
    return localArrayList;
  }
  
  WikiPageEntity loadPageEntity(WikiPageEntityPK paramWikiPageEntityPK)
  {
    SQL localSQL = SQL.begin().eq("o", "lcPageName", paramWikiPageEntityPK.getLcPageName()).and().eq("o", "wikiType", paramWikiPageEntityPK.getWikiType()).end();
    return (WikiPageEntity)dao(WikiPageEntity.class.getName()).findFirst(localSQL);
  }
  
  public WikiPageEntity getPage(WikiPageEntityPK paramWikiPageEntityPK)
  {
    WikiPageEntity localWikiPageEntity = null;
    if (isUseCache())
    {
      String str = (String)this.pageNameToId.get(paramWikiPageEntityPK);
      if (str != null) {
        localWikiPageEntity = (WikiPageEntity)orm().get(WikiPageEntity.class.getName(), str);
      } else {
        localWikiPageEntity = loadPageEntity(paramWikiPageEntityPK);
      }
    }
    else
    {
      localWikiPageEntity = loadPageEntity(paramWikiPageEntityPK);
    }
    if (localWikiPageEntity == null)
    {
      localWikiPageEntity = new WikiPageEntity();
      localWikiPageEntity.setWikiType(paramWikiPageEntityPK.getWikiType());
      localWikiPageEntity.setPageName(paramWikiPageEntityPK.getPageName());
      if (isUseCache()) {
        this.pageNameToId.put(paramWikiPageEntityPK, "");
      }
      return localWikiPageEntity;
    }
    initPageEntity(localWikiPageEntity);
    if (isUseCache()) {
      this.pageNameToId.put(paramWikiPageEntityPK, localWikiPageEntity.getSid());
    }
    return localWikiPageEntity;
  }
  
  public WikiPageEntity initPageEntity(WikiPageEntity paramWikiPageEntity)
  {
    if (paramWikiPageEntity == null) {
      return null;
    }
    if (!paramWikiPageEntity.isInited())
    {
      if (paramWikiPageEntity.getCurTextId() != null) {
        paramWikiPageEntity.setWikiText((WikiTextEntity)orm().load(WikiTextEntity.class.getName(), paramWikiPageEntity.getCurTextId()));
      } else {
        paramWikiPageEntity.setWikiText(null);
      }
      try
      {
        if (paramWikiPageEntity.getAttributesXml() != null)
        {
          TreeNode localTreeNode = DomToTree.getInstance().allowText(false).transform(paramWikiPageEntity.getAttributesXml());
          paramWikiPageEntity.getAttributes().putAll(localTreeNode.getAttributes());
        }
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
      paramWikiPageEntity.setInited(true);
    }
    return paramWikiPageEntity;
  }
  
  public List initPageEntityList(List paramList)
  {
    if (paramList == null) {
      return null;
    }
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      WikiPageEntity localWikiPageEntity = (WikiPageEntity)paramList.get(i);
      initPageEntity(localWikiPageEntity);
    }
    return paramList;
  }
  
  public WikiTextEntity getVersion(WikiPageEntity paramWikiPageEntity, long paramLong)
  {
    Iterator localIterator = paramWikiPageEntity.getWikiTextEntitys().iterator();
    while (localIterator.hasNext())
    {
      WikiTextEntity localWikiTextEntity = (WikiTextEntity)localIterator.next();
      if (localWikiTextEntity.getVersion() == paramLong) {
        return localWikiTextEntity;
      }
    }
    return null;
  }
  
  public void save(WikiPageEntity paramWikiPageEntity)
  {
    if (paramWikiPageEntity.getAttributes().isEmpty())
    {
      paramWikiPageEntity.setAttributesXml(null);
    }
    else
    {
      localObject = TreeNode.make("_");
      ((TreeNode)localObject).setAttributes(paramWikiPageEntity.getAttributes());
      paramWikiPageEntity.setAttributesXml(((TreeNode)localObject).toXml());
    }
    Object localObject = new Timestamp(AppEnv.currentTimeMillis());
    if (paramWikiPageEntity.getCreateTime() == null) {
      paramWikiPageEntity.setCreateTime((Timestamp)localObject);
    }
    paramWikiPageEntity.setUpdateTime((Timestamp)localObject);
    if (paramWikiPageEntity.getWikiText() != null)
    {
      if (paramWikiPageEntity.getCreateTime() == null) {
        paramWikiPageEntity.setWikiCreater(paramWikiPageEntity.getWikiText().getWikiCreater());
      }
      paramWikiPageEntity.setWikiUpdater(paramWikiPageEntity.getWikiText().getWikiUpdater());
      if (paramWikiPageEntity.getWikiText().getVersion() == 0L) {
        paramWikiPageEntity.getWikiText().setVersion(getNextTextVersion(paramWikiPageEntity.getWikiType()));
      }
    }
    int i = paramWikiPageEntity.getSid() == null ? 1 : 0;
    IEntityDao localIEntityDao = dao(WikiPageEntity.class.getName());
    localIEntityDao.saveOrUpdateEntity(paramWikiPageEntity);
    if ((i != 0) && (isUseCache())) {
      this.pageNameToId.put(paramWikiPageEntity.getPagePk(), paramWikiPageEntity.getSid());
    }
    if (paramWikiPageEntity.getWikiText() != null)
    {
      localIEntityDao.saveOrUpdateEntity(paramWikiPageEntity.getWikiText());
      paramWikiPageEntity.setCurTextId(paramWikiPageEntity.getWikiText().getId());
      if (orm().isInitialized(paramWikiPageEntity.getWikiTextEntitys())) {
        paramWikiPageEntity.getWikiTextEntitys().add(paramWikiPageEntity.getWikiText());
      }
    }
  }
  
  public void remove(WikiPageEntity paramWikiPageEntity)
  {
    orm().delete(paramWikiPageEntity);
    if (isUseCache()) {
      this.pageNameToId.remove(paramWikiPageEntity.getPagePk());
    }
  }
  
  public void removeVersion(WikiTextEntity paramWikiTextEntity)
  {
    paramWikiTextEntity.getWikiPageEntity().getWikiTextEntitys().remove(paramWikiTextEntity);
  }
  
  public void removeComment(WikiCommentEntity paramWikiCommentEntity)
  {
    paramWikiCommentEntity.getWikiPageEntity().getWikiCommentEntitys().remove(paramWikiCommentEntity);
  }
  
  public void saveComment(WikiCommentEntity paramWikiCommentEntity)
  {
    orm().saveOrUpdate(paramWikiCommentEntity);
    paramWikiCommentEntity.getWikiPageEntity().getWikiCommentEntitys().add(paramWikiCommentEntity);
  }
  
  public void saveWikiText(WikiTextEntity paramWikiTextEntity)
  {
    if (paramWikiTextEntity.getVersion() == 0L) {
      paramWikiTextEntity.setVersion(getNextTextVersion(paramWikiTextEntity.getWikiType()));
    }
    WikiPageEntity localWikiPageEntity = paramWikiTextEntity.getWikiPageEntity();
    save(localWikiPageEntity);
    if (paramWikiTextEntity.getId() == null)
    {
      orm().save(paramWikiTextEntity);
      if (orm().isInitialized(localWikiPageEntity.getWikiTextEntitys())) {
        localWikiPageEntity.getWikiCommentEntitys().add(paramWikiTextEntity);
      }
      localWikiPageEntity.setCurTextId(paramWikiTextEntity.getId());
      localWikiPageEntity.setWikiText(paramWikiTextEntity);
    }
  }
  
  public IFileListComponent getAttatchments(WikiPageEntity paramWikiPageEntity)
  {
    return paramWikiPageEntity.getWikiAttachments();
  }
  
  public void removeAttachment(WikiPageEntity paramWikiPageEntity, String paramString)
  {
    FileListComponent localFileListComponent = paramWikiPageEntity.getWikiAttachments();
    if (localFileListComponent == null) {
      return;
    }
    throw new NotSupportedException();
  }
  
  public void saveAttachment(WikiPageEntity paramWikiPageEntity, String paramString, IBinaryStreamMoniker paramIBinaryStreamMoniker)
  {
    throw new NotSupportedException();
  }
  
  public long getNextTextVersion(String paramString)
  {
    return Long.valueOf(SequenceGenerator.getInstance().getNextValue("wiki_seq_" + paramString, false)).longValue();
  }
  
  public WikiModel loadWikiModel(WikiTextEntity paramWikiTextEntity)
  {
    return null;
  }
  
  public IPageViewer listPage(String paramString, IServiceContext paramIServiceContext)
  {
    Query localQuery = WikiQuery.condAll(Query.begin().end());
    return findMany(paramString, localQuery, paramIServiceContext);
  }
  
  public IPageViewer findMany(String paramString, IQuery paramIQuery, IServiceContext paramIServiceContext)
  {
    if ((paramIQuery instanceof Query))
    {
      Query localQuery = (Query)paramIQuery;
      localQuery.condition().eq("wikiType", paramString);
      IEntityDao localIEntityDao = dao(WikiPageEntity.class.getName());
      localIEntityDao.transformCondition(localQuery.getCondition());
      SQL localSQL = localIEntityDao.buildConditionSql(localQuery.getCondition());
      return new WikiPageEntityViewer(this, localIEntityDao.list(localSQL));
    }
    throw Exceptions.notAllowed();
  }
  
  public List<WikiPageEntity> getRecentChangePages(String paramString, Timestamp paramTimestamp, IServiceContext paramIServiceContext)
  {
    Query localQuery = WikiQuery.condRecentChange(Query.begin().end(), paramTimestamp);
    return findMany(paramString, localQuery, paramIServiceContext).getAll();
  }
  
  public IPageViewer listChangePage(String paramString, IServiceContext paramIServiceContext)
  {
    Query localQuery = WikiQuery.condChangePage(Query.begin().end());
    return findMany(paramString, localQuery, paramIServiceContext);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\spi\DaoWikiStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */