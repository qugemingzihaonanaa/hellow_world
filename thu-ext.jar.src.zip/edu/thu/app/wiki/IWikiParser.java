package edu.thu.app.wiki;

import edu.thu.app.wiki.model.WikiModel;

public abstract interface IWikiParser
{
  public abstract WikiModel parseText(String paramString);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\IWikiParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */