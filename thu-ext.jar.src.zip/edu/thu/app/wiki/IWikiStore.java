package edu.thu.app.wiki;

import edu.thu.app.wiki.entity.WikiCommentEntity;
import edu.thu.app.wiki.entity.WikiPageEntity;
import edu.thu.app.wiki.entity.WikiPageEntityPK;
import edu.thu.app.wiki.entity.WikiTextEntity;
import edu.thu.app.wiki.model.WikiModel;
import edu.thu.model.stg.IBinaryStreamMoniker;
import edu.thu.model.stg.view.IPageViewer;
import edu.thu.orm.component.IFileListComponent;
import edu.thu.search.IQuery;
import edu.thu.service.IServiceContext;
import java.sql.Timestamp;
import java.util.List;

public abstract interface IWikiStore
{
  public abstract boolean existsPage(WikiPageEntityPK paramWikiPageEntityPK);
  
  public abstract IPageViewer listPage(String paramString, IServiceContext paramIServiceContext);
  
  public abstract WikiPageEntity getPage(WikiPageEntityPK paramWikiPageEntityPK);
  
  public abstract IPageViewer listChildPages(WikiPageEntity paramWikiPageEntity, IServiceContext paramIServiceContext);
  
  public abstract IPageViewer listSubPagesForPageName(WikiPageEntity paramWikiPageEntity, IServiceContext paramIServiceContext);
  
  public abstract IPageViewer listTopPages(String paramString, IServiceContext paramIServiceContext);
  
  public abstract List<WikiCommentEntity> getComments(WikiPageEntity paramWikiPageEntity);
  
  public abstract List<WikiTextEntity> getHistoryVersions(WikiPageEntity paramWikiPageEntity);
  
  public abstract long getNextTextVersion(String paramString);
  
  public abstract IWikiText getVersion(WikiPageEntity paramWikiPageEntity, long paramLong);
  
  public abstract IWikiComment getComment(WikiPageEntity paramWikiPageEntity, String paramString);
  
  public abstract void save(WikiPageEntity paramWikiPageEntity);
  
  public abstract void remove(WikiPageEntity paramWikiPageEntity);
  
  public abstract void removeVersion(WikiTextEntity paramWikiTextEntity);
  
  public abstract void saveWikiText(WikiTextEntity paramWikiTextEntity);
  
  public abstract void removeComment(WikiCommentEntity paramWikiCommentEntity);
  
  public abstract void saveComment(WikiCommentEntity paramWikiCommentEntity);
  
  public abstract IFileListComponent getAttatchments(WikiPageEntity paramWikiPageEntity);
  
  public abstract void removeAttachment(WikiPageEntity paramWikiPageEntity, String paramString);
  
  public abstract void saveAttachment(WikiPageEntity paramWikiPageEntity, String paramString, IBinaryStreamMoniker paramIBinaryStreamMoniker);
  
  public abstract WikiModel loadWikiModel(WikiTextEntity paramWikiTextEntity);
  
  public abstract IPageViewer findMany(String paramString, IQuery paramIQuery, IServiceContext paramIServiceContext);
  
  public abstract List<WikiPageEntity> getRecentChangePages(String paramString, Timestamp paramTimestamp, IServiceContext paramIServiceContext);
  
  public abstract IPageViewer listChangePage(String paramString, IServiceContext paramIServiceContext);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\IWikiStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */