package edu.thu.app.wiki;

import java.sql.Timestamp;

public abstract interface IWikiPageLock
{
  public abstract String getPageName();
  
  public abstract Timestamp getAcquireTime();
  
  public abstract Timestamp getExpireTime();
  
  public abstract IWikiUser getLocker();
  
  public abstract boolean isLockByUser(String paramString);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\IWikiPageLock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */