package edu.thu.app.wiki;

public abstract interface IWikiUser
{
  public abstract String getId();
  
  public abstract void setId(String paramString);
  
  public abstract String getName();
  
  public abstract void setName(String paramString);
  
  public abstract String getEmail();
  
  public abstract void setEmail(String paramString);
  
  public abstract String getRemoteAddr();
  
  public abstract void setRemoteAddr(String paramString);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\IWikiUser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */