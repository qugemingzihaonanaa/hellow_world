package edu.thu.app.wiki;

public abstract interface WikiConstants
{
  public static final String DEFAULT_WIKI_TYPE = "default";
  public static final String WIKI_SEQ_PREFIX = "wiki_seq";
  public static final String CONFIG_WIKI_PAGE_CACHE = "wiki.page_cache";
  public static final String PROP_PAGE_ID = "pageId";
  public static final String PROP_VERSION = "version";
  public static final String PROP_PAGE_NAME = "pageName";
  public static final String PROP_LC_PAGE_NAME = "lcPageName";
  public static final String PROP_PAGE_LEVEL = "pageLevel";
  public static final String PROP_WIKI_TYPE = "wikiType";
  public static final String PROP_UPDATE_TIME = "updateTime";
  public static final String PROP_SID = "sid";
  public static final String PROP_LAYER_CODE = "layerCode";
  public static final String PROP_LAYER_LEVEL = "layerLeve";
  public static final String PROTOCOL_WIKI = "wiki";
  public static final String WIKI_MODEL_NAME = "wikiModel";
  public static final String WIKI_PAGE_NAME = "wikiPage";
  public static final String WIKI_PAGE_LOCK_NAME = "wikiPageLock";
  public static final String WIKI_TRAIL_NAME = "wikiTrail";
  public static final String WIKI_ENGINE_NAME = "wikiEngine";
  public static final String PAGE_NAME_NAME = "pageName";
  public static final String CONTENT_NAME = "content";
  public static final String UNLOCK_NAME = "unlock";
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\WikiConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */