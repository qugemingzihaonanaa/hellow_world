package edu.thu.app.wiki;

import edu.thu.model.entity.Tags;
import edu.thu.model.stg.IBinaryStreamMoniker;
import edu.thu.model.tree.LayerCode;
import edu.thu.orm.component.IFileListComponent;
import edu.thu.service.IServiceContext;
import java.io.Writer;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

public abstract interface IWikiPage
{
  public abstract IWikiEngine getWikiEngine();
  
  public abstract boolean isExisting();
  
  public abstract String getPageName();
  
  public abstract LayerCode getPageLc();
  
  public abstract LayerCode getLc();
  
  public abstract String getTitle();
  
  public abstract Tags getTagsObj();
  
  public abstract Map<String, Object> getAttributes();
  
  public abstract Object getAttribute(String paramString);
  
  public abstract void setAttribute(String paramString, Object paramObject);
  
  public abstract void removeAttribute(String paramString);
  
  public abstract IWikiText getWikiText();
  
  public abstract List<? extends IWikiText> getHistoryVersions();
  
  public abstract IWikiText getVersion(long paramLong);
  
  public abstract IWikiComment newComment(IWikiUser paramIWikiUser);
  
  public abstract IWikiText newWikiText(IWikiUser paramIWikiUser);
  
  public abstract List<? extends IWikiComment> getComments();
  
  public abstract IWikiComment getComment(String paramString);
  
  public abstract IFileListComponent getAttachments();
  
  public abstract void removeAttachment(String paramString);
  
  public abstract void saveAttachment(String paramString, IBinaryStreamMoniker paramIBinaryStreamMoniker);
  
  public abstract void remove();
  
  public abstract void save();
  
  public abstract void saveWikiText(IWikiText paramIWikiText);
  
  public abstract void saveComment(IWikiComment paramIWikiComment);
  
  public abstract void removeComment(IWikiComment paramIWikiComment);
  
  public abstract void removeVersion(IWikiText paramIWikiText);
  
  public abstract IWikiUser getWikiUpdater();
  
  public abstract Timestamp getUpdateTime();
  
  public abstract void setWikiUpdater(IWikiUser paramIWikiUser);
  
  public abstract void setUpdateTime(Timestamp paramTimestamp);
  
  public abstract void renderTo(IWikiText paramIWikiText, Map paramMap, Writer paramWriter, IServiceContext paramIServiceContext);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\IWikiPage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */