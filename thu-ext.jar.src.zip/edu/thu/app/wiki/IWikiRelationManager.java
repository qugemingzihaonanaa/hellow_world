package edu.thu.app.wiki;

import edu.thu.service.IServiceContext;
import java.util.List;

public abstract interface IWikiRelationManager
{
  public abstract void clear();
  
  public abstract List<String> getFromPages(String paramString, IServiceContext paramIServiceContext);
  
  public abstract List<String> getToPages(String paramString);
  
  public abstract void updatePageRelations(String paramString, List<String> paramList);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\IWikiRelationManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */