package edu.thu.app.wiki;

public abstract interface IWikiComment
  extends IWikiText
{
  public abstract boolean isPublic();
  
  public abstract void setPublic(boolean paramBoolean);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\IWikiComment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */