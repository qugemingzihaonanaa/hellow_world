package edu.thu.app.wiki.entity;

import edu.thu.app.wiki.IWikiComment;
import edu.thu.app.wiki.IWikiUser;
import edu.thu.app.wiki.entity._entity._WikiCommentEntity;
import edu.thu.app.wiki.spi.WikiUser;

public class WikiCommentEntity
  extends _WikiCommentEntity
  implements IWikiComment
{
  private static final long serialVersionUID = 1L;
  
  public boolean isPublic()
  {
    return "Y".equals(getIsPublic());
  }
  
  public void setPublic(boolean paramBoolean)
  {
    setIsPublic(paramBoolean ? "Y" : "N");
  }
  
  public long getVersion()
  {
    return 0L;
  }
  
  public void setVersion(long paramLong) {}
  
  public String getPageName()
  {
    return getWikiPageEntity().getPageName();
  }
  
  public String getWikiType()
  {
    return getWikiPageEntity().getWikiType();
  }
  
  public String getId()
  {
    return getSid();
  }
  
  public void setId(String paramString)
  {
    setSid(paramString);
  }
  
  public IWikiUser getWikiCreater()
  {
    WikiUser localWikiUser = new WikiUser();
    localWikiUser.setId(getCreaterId());
    localWikiUser.setName(getCreaterName());
    localWikiUser.setEmail(getCreaterEmail());
    localWikiUser.setRemoteAddr(getCreaterAddr());
    return localWikiUser;
  }
  
  public void setWikiCreater(IWikiUser paramIWikiUser)
  {
    if (paramIWikiUser == null)
    {
      setCreaterId(null);
      setCreaterAddr(null);
      setCreaterEmail(null);
      setCreaterName(null);
    }
    else
    {
      setCreaterId(paramIWikiUser.getId());
      setCreaterAddr(paramIWikiUser.getRemoteAddr());
      setCreaterEmail(paramIWikiUser.getEmail());
      setCreaterName(paramIWikiUser.getName());
    }
  }
  
  public IWikiUser getWikiUpdater()
  {
    WikiUser localWikiUser = new WikiUser();
    localWikiUser.setId(getUpdaterId());
    localWikiUser.setName(getUpdaterName());
    localWikiUser.setEmail(getUpdaterEmail());
    localWikiUser.setRemoteAddr(getUpdaterAddr());
    return localWikiUser;
  }
  
  public void setWikiUpdater(IWikiUser paramIWikiUser)
  {
    if (paramIWikiUser == null)
    {
      setUpdaterId(null);
      setUpdaterAddr(null);
      setUpdaterEmail(null);
      setUpdaterName(null);
    }
    else
    {
      setUpdaterId(paramIWikiUser.getId());
      setUpdaterAddr(paramIWikiUser.getRemoteAddr());
      setUpdaterEmail(paramIWikiUser.getEmail());
      setUpdaterName(paramIWikiUser.getName());
    }
  }
  
  public void setContent(String paramString)
  {
    if (paramString == null) {
      setContentLength(0);
    } else {
      setContentLength(paramString.length());
    }
    super.setContent(paramString);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\entity\WikiCommentEntity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */