package edu.thu.app.wiki.entity;

import edu.thu.app.wiki.IWikiUser;
import edu.thu.app.wiki.entity._entity._WikiPageEntity;
import edu.thu.app.wiki.spi.WikiUser;
import edu.thu.core.AppEnv;
import edu.thu.model.tree.LayerCode;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

public class WikiPageEntity
  extends _WikiPageEntity
{
  private static final long serialVersionUID = 1L;
  WikiTextEntity wikiText;
  Map<String, Object> attributes = new HashMap(0);
  boolean inited;
  
  public WikiPageEntity()
  {
    setWikiType("default");
  }
  
  public void setPageName(String paramString)
  {
    setLcPageName(paramString == null ? null : paramString.toLowerCase());
    super.setPageName(paramString);
  }
  
  public WikiPageEntityPK getPagePk()
  {
    WikiPageEntityPK localWikiPageEntityPK = new WikiPageEntityPK();
    localWikiPageEntityPK.setPageName(getPageName());
    localWikiPageEntityPK.setWikiType(getWikiType());
    return localWikiPageEntityPK;
  }
  
  public boolean isExisting()
  {
    return getSid() != null;
  }
  
  public String getWikiTextContent()
  {
    if (this.wikiText == null) {
      return null;
    }
    return this.wikiText.getContent();
  }
  
  public void setWikiTextContent(String paramString)
  {
    if (this.wikiText == null)
    {
      this.wikiText = new WikiTextEntity();
      Timestamp localTimestamp = new Timestamp(AppEnv.currentTimeMillis());
      this.wikiText.setWikiPageEntity(this);
      this.wikiText.setWikiCreater(getWikiUpdater());
      this.wikiText.setCreateTime(localTimestamp);
      this.wikiText.setWikiUpdater(getWikiUpdater());
      this.wikiText.setUpdateTime(localTimestamp);
      this.wikiText.setContent(paramString);
      return;
    }
    this.wikiText.setContent(paramString);
  }
  
  public IWikiUser getWikiCreater()
  {
    WikiUser localWikiUser = new WikiUser();
    localWikiUser.setId(getCreaterId());
    localWikiUser.setName(getCreaterName());
    localWikiUser.setEmail(getCreaterEmail());
    localWikiUser.setRemoteAddr(getCreaterAddr());
    return localWikiUser;
  }
  
  public void setWikiCreater(IWikiUser paramIWikiUser)
  {
    if (paramIWikiUser == null)
    {
      setCreaterId(null);
      setCreaterAddr(null);
      setCreaterEmail(null);
      setCreaterName(null);
    }
    else
    {
      setCreaterId(paramIWikiUser.getId());
      setCreaterAddr(paramIWikiUser.getRemoteAddr());
      setCreaterEmail(paramIWikiUser.getEmail());
      setCreaterName(paramIWikiUser.getName());
    }
  }
  
  public IWikiUser getWikiUpdater()
  {
    WikiUser localWikiUser = new WikiUser();
    localWikiUser.setId(getUpdaterId());
    localWikiUser.setName(getUpdaterName());
    localWikiUser.setEmail(getUpdaterEmail());
    localWikiUser.setRemoteAddr(getUpdaterAddr());
    return localWikiUser;
  }
  
  public void setWikiUpdater(IWikiUser paramIWikiUser)
  {
    if (paramIWikiUser == null)
    {
      setUpdaterId(null);
      setUpdaterAddr(null);
      setUpdaterEmail(null);
      setUpdaterName(null);
    }
    else
    {
      setUpdaterId(paramIWikiUser.getId());
      setUpdaterAddr(paramIWikiUser.getRemoteAddr());
      setUpdaterEmail(paramIWikiUser.getEmail());
      setUpdaterName(paramIWikiUser.getName());
    }
  }
  
  public boolean isInited()
  {
    return this.inited;
  }
  
  public void setInited(boolean paramBoolean)
  {
    this.inited = paramBoolean;
  }
  
  public WikiTextEntity getWikiText()
  {
    return this.wikiText;
  }
  
  public void setWikiText(WikiTextEntity paramWikiTextEntity)
  {
    this.wikiText = paramWikiTextEntity;
  }
  
  public Map<String, Object> getAttributes()
  {
    return this.attributes;
  }
  
  public void setAttributes(Map<String, Object> paramMap)
  {
    this.attributes = paramMap;
  }
  
  public LayerCode getLc()
  {
    if (this.layerCode == null) {
      return null;
    }
    return LayerCode.valueOf(this.layerCode);
  }
  
  public LayerCode getPageLc()
  {
    if ((this.pageName == null) || (this.pageName.length() <= 0)) {
      return null;
    }
    return LayerCode.valueOf(this.pageName);
  }
  
  public void syncLc()
  {
    if (this.layerCode == null)
    {
      this.layerLevel = null;
    }
    else
    {
      LayerCode localLayerCode = LayerCode.valueOf(this.layerCode);
      this.layerLevel = Integer.valueOf(localLayerCode.getLevel());
    }
    this.pageLevel = Integer.valueOf(LayerCode.valueOf(this.pageName).getLevel());
  }
  
  public void entityBeforeSave()
  {
    syncLc();
  }
  
  public void entityBeforeUpdate()
  {
    syncLc();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\entity\WikiPageEntity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */