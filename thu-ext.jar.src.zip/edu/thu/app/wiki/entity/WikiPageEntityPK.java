package edu.thu.app.wiki.entity;

import edu.thu.app.wiki.entity._entity._WikiPageEntityPK;

public class WikiPageEntityPK
  extends _WikiPageEntityPK
{
  private static final long serialVersionUID = 1L;
  
  public WikiPageEntityPK()
  {
    setWikiType("default");
  }
  
  public String getLcPageName()
  {
    return this.pageName.toLowerCase();
  }
  
  public int hashCode()
  {
    return getWikiType().hashCode() + getLcPageName().hashCode();
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof WikiPageEntityPK)) {
      return false;
    }
    WikiPageEntityPK localWikiPageEntityPK = (WikiPageEntityPK)paramObject;
    return (localWikiPageEntityPK.getWikiType().equals(getWikiType())) && (localWikiPageEntityPK.getLcPageName().equals(getLcPageName()));
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\entity\WikiPageEntityPK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */