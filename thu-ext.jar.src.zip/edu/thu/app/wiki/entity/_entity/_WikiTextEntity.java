package edu.thu.app.wiki.entity._entity;

import edu.thu.app.sys.UserResolver;
import edu.thu.app.sys.user.UserInfo;
import edu.thu.app.wiki.entity.WikiPageEntity;
import edu.thu.ext.hibernate.AbstractEntity;
import java.sql.Timestamp;

public abstract class _WikiTextEntity
  extends AbstractEntity
{
  private static final long serialVersionUID = 1L;
  protected String sid;
  protected long version;
  protected String title;
  protected String contentType;
  protected String content;
  protected int contentLength;
  protected String createrId;
  protected String createrName;
  protected String createrEmail;
  protected String createrAddr;
  protected Timestamp createTime;
  protected String updaterId;
  protected String updaterName;
  protected String updaterEmail;
  protected String updaterAddr;
  protected Timestamp updateTime;
  protected WikiPageEntity wikiPageEntity;
  
  public String getSid()
  {
    return this.sid;
  }
  
  public void setSid(String paramString)
  {
    this.sid = paramString;
  }
  
  public long getVersion()
  {
    return this.version;
  }
  
  public void setVersion(long paramLong)
  {
    this.version = paramLong;
  }
  
  public String getTitle()
  {
    return this.title;
  }
  
  public void setTitle(String paramString)
  {
    this.title = paramString;
  }
  
  public String getContentType()
  {
    return this.contentType;
  }
  
  public void setContentType(String paramString)
  {
    this.contentType = paramString;
  }
  
  public String getContent()
  {
    return this.content;
  }
  
  public void setContent(String paramString)
  {
    this.content = paramString;
  }
  
  public int getContentLength()
  {
    return this.contentLength;
  }
  
  public void setContentLength(int paramInt)
  {
    this.contentLength = paramInt;
  }
  
  public String getCreaterId()
  {
    return this.createrId;
  }
  
  public void setCreaterId(String paramString)
  {
    this.createrId = paramString;
  }
  
  public String getCreaterName()
  {
    return this.createrName;
  }
  
  public void setCreaterName(String paramString)
  {
    this.createrName = paramString;
  }
  
  public String getCreaterEmail()
  {
    return this.createrEmail;
  }
  
  public void setCreaterEmail(String paramString)
  {
    this.createrEmail = paramString;
  }
  
  public String getCreaterAddr()
  {
    return this.createrAddr;
  }
  
  public void setCreaterAddr(String paramString)
  {
    this.createrAddr = paramString;
  }
  
  public Timestamp getCreateTime()
  {
    return this.createTime;
  }
  
  public void setCreateTime(Timestamp paramTimestamp)
  {
    this.createTime = paramTimestamp;
  }
  
  public String getUpdaterId()
  {
    return this.updaterId;
  }
  
  public void setUpdaterId(String paramString)
  {
    this.updaterId = paramString;
  }
  
  public String getUpdaterName()
  {
    return this.updaterName;
  }
  
  public void setUpdaterName(String paramString)
  {
    this.updaterName = paramString;
  }
  
  public String getUpdaterEmail()
  {
    return this.updaterEmail;
  }
  
  public void setUpdaterEmail(String paramString)
  {
    this.updaterEmail = paramString;
  }
  
  public String getUpdaterAddr()
  {
    return this.updaterAddr;
  }
  
  public void setUpdaterAddr(String paramString)
  {
    this.updaterAddr = paramString;
  }
  
  public Timestamp getUpdateTime()
  {
    return this.updateTime;
  }
  
  public void setUpdateTime(Timestamp paramTimestamp)
  {
    this.updateTime = paramTimestamp;
  }
  
  public WikiPageEntity getWikiPageEntity()
  {
    return this.wikiPageEntity;
  }
  
  public void setWikiPageEntity(WikiPageEntity paramWikiPageEntity)
  {
    this.wikiPageEntity = paramWikiPageEntity;
  }
  
  public Object toDbType()
  {
    return _toObject(this.sid);
  }
  
  public UserInfo getCreater()
  {
    return UserResolver.resolve(getCreaterId());
  }
  
  public void setCreater(UserInfo paramUserInfo)
  {
    if (paramUserInfo == null) {
      return;
    }
    setCreaterId(paramUserInfo.getId());
  }
  
  public UserInfo getUpdater()
  {
    return UserResolver.resolve(getUpdaterId());
  }
  
  public void setUpdater(UserInfo paramUserInfo)
  {
    if (paramUserInfo == null) {
      return;
    }
    setUpdaterId(paramUserInfo.getId());
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\entity\_entity\_WikiTextEntity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */