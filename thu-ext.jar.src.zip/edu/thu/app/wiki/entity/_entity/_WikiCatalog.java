package edu.thu.app.wiki.entity._entity;

import edu.thu.app.wiki.entity.WikiCatalog;
import edu.thu.ext.hibernate.AbstractEntity;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

public abstract class _WikiCatalog
  extends AbstractEntity
{
  private static final long serialVersionUID = 1L;
  protected String sid;
  protected String wikiType;
  protected String name;
  protected String layerCode;
  protected Integer layerLevel;
  protected String isPublic;
  protected Integer createrId;
  protected Timestamp createTime;
  protected Integer updaterId;
  protected Timestamp updateTime;
  protected Set wikiPageEntitys = new HashSet(0);
  protected WikiCatalog parent;
  protected Set children = new HashSet(0);
  
  public String getSid()
  {
    return this.sid;
  }
  
  public void setSid(String paramString)
  {
    this.sid = paramString;
  }
  
  public String getWikiType()
  {
    return this.wikiType;
  }
  
  public void setWikiType(String paramString)
  {
    this.wikiType = paramString;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public void setName(String paramString)
  {
    this.name = paramString;
  }
  
  public String getLayerCode()
  {
    return this.layerCode;
  }
  
  public void setLayerCode(String paramString)
  {
    this.layerCode = paramString;
  }
  
  public Integer getLayerLevel()
  {
    return this.layerLevel;
  }
  
  public void setLayerLevel(Integer paramInteger)
  {
    this.layerLevel = paramInteger;
  }
  
  public String getIsPublic()
  {
    return this.isPublic;
  }
  
  public void setIsPublic(String paramString)
  {
    this.isPublic = paramString;
  }
  
  public Integer getCreaterId()
  {
    return this.createrId;
  }
  
  public void setCreaterId(Integer paramInteger)
  {
    this.createrId = paramInteger;
  }
  
  public Timestamp getCreateTime()
  {
    return this.createTime;
  }
  
  public void setCreateTime(Timestamp paramTimestamp)
  {
    this.createTime = paramTimestamp;
  }
  
  public Integer getUpdaterId()
  {
    return this.updaterId;
  }
  
  public void setUpdaterId(Integer paramInteger)
  {
    this.updaterId = paramInteger;
  }
  
  public Timestamp getUpdateTime()
  {
    return this.updateTime;
  }
  
  public void setUpdateTime(Timestamp paramTimestamp)
  {
    this.updateTime = paramTimestamp;
  }
  
  public Set getWikiPageEntitys()
  {
    return this.wikiPageEntitys;
  }
  
  public void setWikiPageEntitys(Set paramSet)
  {
    this.wikiPageEntitys = paramSet;
  }
  
  public WikiCatalog getParent()
  {
    return this.parent;
  }
  
  public void setParent(WikiCatalog paramWikiCatalog)
  {
    this.parent = paramWikiCatalog;
  }
  
  public Set getChildren()
  {
    return this.children;
  }
  
  public void setChildren(Set paramSet)
  {
    this.children = paramSet;
  }
  
  public Object toDbType()
  {
    return _toObject(this.sid);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\entity\_entity\_WikiCatalog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */