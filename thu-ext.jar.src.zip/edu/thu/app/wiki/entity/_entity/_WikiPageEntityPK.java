package edu.thu.app.wiki.entity._entity;

import edu.thu.orm.component.AbstractCompositePK;
import java.lang.reflect.Field;

public class _WikiPageEntityPK
  extends AbstractCompositePK
{
  private static final long serialVersionUID = 1L;
  protected String wikiType;
  protected String pageName;
  
  protected Field[] getFields()
  {
    return null;
  }
  
  public String getWikiType()
  {
    return this.wikiType;
  }
  
  public void setWikiType(String paramString)
  {
    this.wikiType = paramString;
  }
  
  public String getPageName()
  {
    return this.pageName;
  }
  
  public void setPageName(String paramString)
  {
    this.pageName = paramString;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\entity\_entity\_WikiPageEntityPK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */