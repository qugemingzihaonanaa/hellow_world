package edu.thu.app.wiki.entity._entity;

import edu.thu.app.sys.UserResolver;
import edu.thu.app.sys.user.UserInfo;
import edu.thu.app.wiki.entity.WikiCatalog;
import edu.thu.ext.hibernate.AbstractEntity;
import edu.thu.orm.component.impl.FileListComponent;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

public abstract class _WikiPageEntity
  extends AbstractEntity
{
  private static final long serialVersionUID = 1L;
  protected String sid;
  protected String wikiType;
  protected String pageName;
  protected String lcPageName;
  protected Integer pageLevel;
  protected String layerCode;
  protected Integer layerLevel;
  protected String title;
  protected String keywords;
  protected String curTextId;
  protected String attributesXml;
  protected int status;
  protected Timestamp lastAccessTime;
  protected int accessCount;
  protected Integer modifyCount;
  protected Integer commentCount;
  protected String isPublic;
  protected String isAllowComment;
  protected String readRoles;
  protected String writeRoles;
  protected String createrId;
  protected String createrName;
  protected String createrEmail;
  protected String createrAddr;
  protected Timestamp createTime;
  protected String updaterId;
  protected String updaterName;
  protected String updaterEmail;
  protected String updaterAddr;
  protected Timestamp updateTime;
  protected Set wikiTextEntitys = new HashSet(0);
  protected Set wikiCommentEntitys = new HashSet(0);
  protected WikiCatalog wikiCatalog;
  protected FileListComponent wikiAttachments;
  
  public String getSid()
  {
    return this.sid;
  }
  
  public void setSid(String paramString)
  {
    this.sid = paramString;
  }
  
  public String getWikiType()
  {
    return this.wikiType;
  }
  
  public void setWikiType(String paramString)
  {
    this.wikiType = paramString;
  }
  
  public String getPageName()
  {
    return this.pageName;
  }
  
  public void setPageName(String paramString)
  {
    this.pageName = paramString;
  }
  
  public String getLcPageName()
  {
    return this.lcPageName;
  }
  
  public void setLcPageName(String paramString)
  {
    this.lcPageName = paramString;
  }
  
  public Integer getPageLevel()
  {
    return this.pageLevel;
  }
  
  public void setPageLevel(Integer paramInteger)
  {
    this.pageLevel = paramInteger;
  }
  
  public String getLayerCode()
  {
    return this.layerCode;
  }
  
  public void setLayerCode(String paramString)
  {
    this.layerCode = paramString;
  }
  
  public Integer getLayerLevel()
  {
    return this.layerLevel;
  }
  
  public void setLayerLevel(Integer paramInteger)
  {
    this.layerLevel = paramInteger;
  }
  
  public String getTitle()
  {
    return this.title;
  }
  
  public void setTitle(String paramString)
  {
    this.title = paramString;
  }
  
  public String getKeywords()
  {
    return this.keywords;
  }
  
  public void setKeywords(String paramString)
  {
    this.keywords = paramString;
  }
  
  public String getCurTextId()
  {
    return this.curTextId;
  }
  
  public void setCurTextId(String paramString)
  {
    this.curTextId = paramString;
  }
  
  public String getAttributesXml()
  {
    return this.attributesXml;
  }
  
  public void setAttributesXml(String paramString)
  {
    this.attributesXml = paramString;
  }
  
  public int getStatus()
  {
    return this.status;
  }
  
  public void setStatus(int paramInt)
  {
    this.status = paramInt;
  }
  
  public Timestamp getLastAccessTime()
  {
    return this.lastAccessTime;
  }
  
  public void setLastAccessTime(Timestamp paramTimestamp)
  {
    this.lastAccessTime = paramTimestamp;
  }
  
  public int getAccessCount()
  {
    return this.accessCount;
  }
  
  public void setAccessCount(int paramInt)
  {
    this.accessCount = paramInt;
  }
  
  public Integer getModifyCount()
  {
    return this.modifyCount;
  }
  
  public void setModifyCount(Integer paramInteger)
  {
    this.modifyCount = paramInteger;
  }
  
  public Integer getCommentCount()
  {
    return this.commentCount;
  }
  
  public void setCommentCount(Integer paramInteger)
  {
    this.commentCount = paramInteger;
  }
  
  public String getIsPublic()
  {
    return this.isPublic;
  }
  
  public void setIsPublic(String paramString)
  {
    this.isPublic = paramString;
  }
  
  public String getIsAllowComment()
  {
    return this.isAllowComment;
  }
  
  public void setIsAllowComment(String paramString)
  {
    this.isAllowComment = paramString;
  }
  
  public String getReadRoles()
  {
    return this.readRoles;
  }
  
  public void setReadRoles(String paramString)
  {
    this.readRoles = paramString;
  }
  
  public String getWriteRoles()
  {
    return this.writeRoles;
  }
  
  public void setWriteRoles(String paramString)
  {
    this.writeRoles = paramString;
  }
  
  public String getCreaterId()
  {
    return this.createrId;
  }
  
  public void setCreaterId(String paramString)
  {
    this.createrId = paramString;
  }
  
  public String getCreaterName()
  {
    return this.createrName;
  }
  
  public void setCreaterName(String paramString)
  {
    this.createrName = paramString;
  }
  
  public String getCreaterEmail()
  {
    return this.createrEmail;
  }
  
  public void setCreaterEmail(String paramString)
  {
    this.createrEmail = paramString;
  }
  
  public String getCreaterAddr()
  {
    return this.createrAddr;
  }
  
  public void setCreaterAddr(String paramString)
  {
    this.createrAddr = paramString;
  }
  
  public Timestamp getCreateTime()
  {
    return this.createTime;
  }
  
  public void setCreateTime(Timestamp paramTimestamp)
  {
    this.createTime = paramTimestamp;
  }
  
  public String getUpdaterId()
  {
    return this.updaterId;
  }
  
  public void setUpdaterId(String paramString)
  {
    this.updaterId = paramString;
  }
  
  public String getUpdaterName()
  {
    return this.updaterName;
  }
  
  public void setUpdaterName(String paramString)
  {
    this.updaterName = paramString;
  }
  
  public String getUpdaterEmail()
  {
    return this.updaterEmail;
  }
  
  public void setUpdaterEmail(String paramString)
  {
    this.updaterEmail = paramString;
  }
  
  public String getUpdaterAddr()
  {
    return this.updaterAddr;
  }
  
  public void setUpdaterAddr(String paramString)
  {
    this.updaterAddr = paramString;
  }
  
  public Timestamp getUpdateTime()
  {
    return this.updateTime;
  }
  
  public void setUpdateTime(Timestamp paramTimestamp)
  {
    this.updateTime = paramTimestamp;
  }
  
  public Set getWikiTextEntitys()
  {
    return this.wikiTextEntitys;
  }
  
  public void setWikiTextEntitys(Set paramSet)
  {
    this.wikiTextEntitys = paramSet;
  }
  
  public Set getWikiCommentEntitys()
  {
    return this.wikiCommentEntitys;
  }
  
  public void setWikiCommentEntitys(Set paramSet)
  {
    this.wikiCommentEntitys = paramSet;
  }
  
  public WikiCatalog getWikiCatalog()
  {
    return this.wikiCatalog;
  }
  
  public void setWikiCatalog(WikiCatalog paramWikiCatalog)
  {
    this.wikiCatalog = paramWikiCatalog;
  }
  
  public Object toDbType()
  {
    return _toObject(this.sid);
  }
  
  public FileListComponent makeWikiAttachments()
  {
    if (this.wikiAttachments == null)
    {
      setWikiAttachments(new FileListComponent());
      this.wikiAttachments.setParentEntity(this);
    }
    return this.wikiAttachments;
  }
  
  public FileListComponent getWikiAttachments()
  {
    return this.wikiAttachments;
  }
  
  public void setWikiAttachments(FileListComponent paramFileListComponent)
  {
    this.wikiAttachments = paramFileListComponent;
    if (paramFileListComponent != null) {
      paramFileListComponent.setFieldName("wikiAttachments");
    }
  }
  
  public UserInfo getCreater()
  {
    return UserResolver.resolve(getCreaterId());
  }
  
  public void setCreater(UserInfo paramUserInfo)
  {
    if (paramUserInfo == null) {
      return;
    }
    setCreaterId(paramUserInfo.getId());
  }
  
  public UserInfo getUpdater()
  {
    return UserResolver.resolve(getUpdaterId());
  }
  
  public void setUpdater(UserInfo paramUserInfo)
  {
    if (paramUserInfo == null) {
      return;
    }
    setUpdaterId(paramUserInfo.getId());
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\entity\_entity\_WikiPageEntity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */