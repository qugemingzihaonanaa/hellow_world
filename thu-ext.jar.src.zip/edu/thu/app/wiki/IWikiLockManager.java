package edu.thu.app.wiki;

public abstract interface IWikiLockManager
{
  public abstract IWikiPageLock lockPage(String paramString, IWikiUser paramIWikiUser);
  
  public abstract boolean unlockPage(String paramString, IWikiUser paramIWikiUser);
  
  public abstract IWikiPageLock getCurrentLock(String paramString);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\IWikiLockManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */