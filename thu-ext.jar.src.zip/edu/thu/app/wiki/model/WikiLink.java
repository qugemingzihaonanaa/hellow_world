package edu.thu.app.wiki.model;

import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.util.Coercions;
import edu.thu.lang.exceptions.StdException;
import edu.thu.util.StringUtils;
import edu.thu.xml.XmlUtils;
import java.io.PrintStream;
import java.io.Serializable;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class WikiLink
  implements Serializable
{
  private static final long serialVersionUID = -5259677281698201396L;
  String D;
  String F;
  String E;
  Map<String, String> C;
  String G;
  int H;
  boolean A;
  boolean B;
  
  public static String normalizePageName(String paramString)
  {
    if (paramString == null) {
      paramString = "";
    }
    paramString = paramString.trim();
    StringBuffer localStringBuffer = new StringBuffer(paramString.length());
    int j = paramString.length();
    for (int i = 0; i < j; i++)
    {
      char c = paramString.charAt(i);
      if (c == '*')
      {
        if ((i != 0) && (paramString.charAt(i - 1) != '.')) {
          c = '_';
        }
        if (i != j - 1) {
          c = '_';
        }
      }
      else if ((c != '.') && (!Character.isJavaIdentifierPart(c)))
      {
        c = '_';
      }
      localStringBuffer.append(c);
    }
    for (String str = localStringBuffer.toString(); str.indexOf("..") >= 0; str = StringUtils.replace(str, "..", "_.")) {}
    if (str.startsWith(".")) {
      str = "_" + str.substring(1);
    }
    if (str.endsWith(".")) {
      str = str.substring(0, str.length() - 1) + "_";
    }
    return str;
  }
  
  public static String toLowerCasePageName(String paramString)
  {
    return normalizePageName(paramString).toLowerCase();
  }
  
  public static String getPageDirName(String paramString)
  {
    if (paramString.equals("*")) {
      return "";
    }
    int i = paramString.lastIndexOf('.');
    if (i < 0) {
      return "";
    }
    return paramString.substring(0, i);
  }
  
  public boolean isPageLink()
  {
    return (getProtocol().equals("wiki")) && (!isLocalRef());
  }
  
  public boolean isDirLink()
  {
    return (isPageLink()) && (this.E != null) && ((this.E.equals("*")) || (this.E.endsWith(".*")));
  }
  
  public String getPageDirName()
  {
    if (!isPageLink()) {
      return "";
    }
    if (this.E.equals("*")) {
      return "";
    }
    return this.E.substring(0, this.E.lastIndexOf('.'));
  }
  
  public boolean isLocalRef()
  {
    return this.B;
  }
  
  public void setLocalRef(boolean paramBoolean)
  {
    this.B = paramBoolean;
  }
  
  public String getFullLink()
  {
    return this.G;
  }
  
  public Map<String, String> getArgs()
  {
    return this.C;
  }
  
  public void setArgs(Map<String, String> paramMap)
  {
    this.C = paramMap;
  }
  
  public int getFootNo()
  {
    return this.H;
  }
  
  public void setFootNo(int paramInt)
  {
    this.H = paramInt;
  }
  
  public boolean isFootDef()
  {
    return this.A;
  }
  
  public void setFootDef(boolean paramBoolean)
  {
    this.A = paramBoolean;
  }
  
  public String getPageName()
  {
    return this.E;
  }
  
  public void setPageName(String paramString)
  {
    this.E = paramString;
  }
  
  public String getProtocol()
  {
    if ((this.F == null) || (this.F.length() <= 0)) {
      return "wiki";
    }
    return this.F;
  }
  
  public void setProtocol(String paramString)
  {
    this.F = paramString;
  }
  
  public String getTitle()
  {
    if ((this.D == null) || (this.D.length() <= 0))
    {
      if (this.A) {
        return "#" + this.H;
      }
      if (this.B) {
        return String.valueOf(this.H);
      }
      return this.E;
    }
    return this.D;
  }
  
  public void setTitle(String paramString)
  {
    this.D = paramString;
  }
  
  public String toString()
  {
    if (isLocalRef())
    {
      if (isFootDef()) {
        return this.D + "|#" + this.H;
      }
      return this.D + "|#" + this.H;
    }
    return this.D + "|" + this.G;
  }
  
  public void render(StringBuffer paramStringBuffer)
  {
    if (isLocalRef())
    {
      if (isFootDef()) {
        paramStringBuffer.append("<wiki:footdef footNo='").append(this.H).append("' title='").append(getTitle()).append("' />");
      } else {
        paramStringBuffer.append("<wiki:footnote footNo='").append(this.H).append("' title='").append(getTitle()).append("' />");
      }
    }
    else
    {
      paramStringBuffer.append("<wiki:link protocol='");
      paramStringBuffer.append(XmlUtils.encodeXml(getProtocol()));
      paramStringBuffer.append("' title='").append(XmlUtils.encodeXml(getTitle()));
      paramStringBuffer.append("' fullLink='").append(XmlUtils.encodeXml(getFullLink()));
      paramStringBuffer.append("' pageName='").append(XmlUtils.encodeXml(getPageName()));
      paramStringBuffer.append("' ");
      A(paramStringBuffer);
      if (this.H != 0) {
        paramStringBuffer.append("footNo='").append(this.H).append("' ");
      }
      paramStringBuffer.append("/>");
    }
  }
  
  void A(StringBuffer paramStringBuffer)
  {
    if ((this.C != null) && (!this.C.isEmpty()))
    {
      paramStringBuffer.append("args='${toMap(");
      Iterator localIterator = this.C.keySet().iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        paramStringBuffer.append("'").append(XmlUtils.encodeXml(str)).append("',");
        paramStringBuffer.append("'").append(XmlUtils.encodeXml((String)this.C.get(str))).append("',");
      }
      paramStringBuffer.append(")}' ");
    }
  }
  
  public void changePageName(String paramString)
  {
    if (!"wiki".equals(getProtocol())) {
      throw Exceptions.code("wiki.CAN_err_protocol_not_allow_change_pageName").param(paramString).param(this);
    }
    paramString = normalizePageName(paramString);
    this.E = paramString;
    this.G = paramString;
    if (this.H != 0) {
      this.G = (this.G + "#" + this.H);
    }
    if ((this.C != null) && (!this.C.isEmpty()))
    {
      this.G += "?";
      Iterator localIterator = this.C.keySet().iterator();
      while (localIterator.hasNext())
      {
        String str1 = (String)localIterator.next();
        String str2 = (String)this.C.get(str1);
        if (!this.G.endsWith("?")) {
          this.G += "&";
        }
        this.G = (this.G + A(str1) + "=" + A(str2));
      }
    }
  }
  
  String A(String paramString)
  {
    if (paramString == null) {
      return "";
    }
    paramString = StringUtils.replace(paramString, " ", "+");
    paramString = StringUtils.replace(paramString, "%", "%25");
    paramString = StringUtils.replace(paramString, "=", "%3D");
    paramString = StringUtils.replace(paramString, "&", "%26");
    paramString = StringUtils.replace(paramString, "\r", "%0D");
    paramString = StringUtils.replace(paramString, "\n", "%0A");
    paramString = StringUtils.replace(paramString, "[", "%5B");
    paramString = StringUtils.replace(paramString, "]", "%5D");
    paramString = StringUtils.replace(paramString, "|", "%7C");
    return paramString;
  }
  
  public void parseFrom(String paramString)
  {
    int i = paramString.indexOf('|');
    if (i >= 0)
    {
      this.D = paramString.substring(0, i);
      paramString = paramString.substring(i + 1);
    }
    paramString = StringUtils.strip(paramString);
    if (paramString == null) {
      return;
    }
    this.G = paramString;
    i = paramString.indexOf(':');
    if (i >= 0)
    {
      this.F = paramString.substring(0, i);
      paramString = paramString.substring(i + 1);
    }
    if (paramString.startsWith("//")) {
      return;
    }
    i = paramString.indexOf('?');
    if (i >= 0)
    {
      this.E = paramString.substring(0, i);
      paramString = paramString.substring(i + 1);
    }
    else
    {
      this.E = paramString;
      paramString = "";
    }
    this.E = StringUtils.strip(this.E);
    if (this.E == null) {
      this.E = "";
    }
    i = this.E.indexOf('#');
    if (i >= 0)
    {
      localObject = this.E.substring(i + 1);
      this.E = this.E.substring(0, i);
      if (StringUtils.isDigits((String)localObject))
      {
        this.H = Coercions.toInt(localObject, 0);
        if (this.E.length() <= 0)
        {
          this.A = true;
          this.B = true;
        }
      }
    }
    else if (StringUtils.isDigits(this.E))
    {
      this.H = Coercions.toInt(this.E, 0);
      this.A = false;
      this.B = true;
      this.E = "";
    }
    Object localObject = StringUtils.stripedSplit(paramString, '&');
    if (localObject != null)
    {
      int k = ((List)localObject).size();
      HashMap localHashMap = new HashMap(k);
      try
      {
        for (int j = 0; j < k; j++)
        {
          String[] arrayOfString = StringUtils.split((String)((List)localObject).get(j), '=');
          if ((arrayOfString != null) && (arrayOfString.length > 1))
          {
            String str1 = URLDecoder.decode(arrayOfString[0], "utf8");
            String str2 = URLDecoder.decode(arrayOfString[1], "utf8");
            localHashMap.put(str1, str2);
          }
        }
      }
      catch (Exception localException)
      {
        throw Exceptions.code("wiki.CAN_err_invalid_link").param(this.G).cause(localException);
      }
      this.C = localHashMap;
    }
    if (isPageLink()) {
      this.E = normalizePageName(this.E);
    }
  }
  
  public static void main(String[] paramArrayOfString)
    throws Exception
  {
    System.out.println(URLEncoder.encode("[]|%=&\r\n\t", "utf8"));
    String str = URLDecoder.decode("中+中\t@#'", "utf8");
    System.out.println(str);
    WikiLink localWikiLink = new WikiLink();
    localWikiLink.parseFrom("x|my#3?v=3");
    StringBuffer localStringBuffer = new StringBuffer();
    localWikiLink.render(localStringBuffer);
    Debug.trace(localStringBuffer);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\model\WikiLink.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */