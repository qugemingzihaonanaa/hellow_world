package edu.thu.app.wiki.model;

public class WikiContent {}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\model\WikiContent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */