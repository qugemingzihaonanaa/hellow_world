package edu.thu.app.wiki.model;

import edu.thu.lang.util.ITplReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WikiModel
{
  String D;
  List<WikiLink> B = new ArrayList();
  List<WikiHeader> E = new ArrayList();
  ITplReference C;
  Map<String, String> A = new HashMap();
  
  public List<String> getToPageNames()
  {
    ArrayList localArrayList = new ArrayList(this.B.size());
    int j = this.B.size();
    for (int i = 0; i < j; i++)
    {
      WikiLink localWikiLink = (WikiLink)this.B.get(i);
      if ((localWikiLink.getProtocol().equals("wiki")) && (localWikiLink.getPageName() != null) && (localWikiLink.getPageName().length() > 0)) {
        localArrayList.add(localWikiLink.getPageName());
      }
    }
    return localArrayList;
  }
  
  public String getWikiTextId()
  {
    return this.D;
  }
  
  public void setWikiTextId(String paramString)
  {
    this.D = paramString;
  }
  
  public Map<String, String> getAttributes()
  {
    return this.A;
  }
  
  public String getAttribute(String paramString)
  {
    return (String)this.A.get(paramString);
  }
  
  public void setAttribute(String paramString1, String paramString2)
  {
    this.A.put(paramString1, paramString2);
  }
  
  public List<WikiLink> getLinks()
  {
    return this.B;
  }
  
  public List<WikiHeader> getHeaders()
  {
    return this.E;
  }
  
  public ITplReference getTpl()
  {
    return this.C;
  }
  
  public void setTpl(ITplReference paramITplReference)
  {
    this.C = paramITplReference;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\model\WikiModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */