package edu.thu.app.wiki.model;

public class WikiHeader
{
  int B;
  String A;
  
  public WikiHeader(int paramInt, String paramString)
  {
    this.B = paramInt;
    this.A = paramString;
  }
  
  public int getLevel()
  {
    return this.B;
  }
  
  public void setLevel(int paramInt)
  {
    this.B = paramInt;
  }
  
  public String getTitle()
  {
    return this.A;
  }
  
  public void setTitle(String paramString)
  {
    this.A = paramString;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\model\WikiHeader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */