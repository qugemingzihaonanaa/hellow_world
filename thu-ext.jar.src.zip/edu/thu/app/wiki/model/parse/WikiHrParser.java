package edu.thu.app.wiki.model.parse;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import java.io.IOException;

public class WikiHrParser
  extends WikiSubParser
{
  public static WikiHrParser getInstance()
  {
    return new WikiHrParser();
  }
  
  public boolean isTopBlock()
  {
    return true;
  }
  
  public String getPrefix()
  {
    return "---";
  }
  
  public void parse(String paramString, WikiParser paramWikiParser)
    throws IOException
  {
    if (!paramString.startsWith("---")) {
      throw Exceptions.code("wiki.CAN_err_invalid_hr_start").param(paramString);
    }
    paramWikiParser.append("<wiki:hr />\n");
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\model\parse\WikiHrParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */