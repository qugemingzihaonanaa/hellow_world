package edu.thu.app.wiki.model.parse;

import java.io.IOException;

public class WikiSubParser
{
  public boolean isTopBlock()
  {
    return false;
  }
  
  public String getPrefix()
  {
    return "";
  }
  
  public void parse(String paramString, WikiParser paramWikiParser)
    throws IOException
  {}
  
  public int countStartChar(String paramString, char paramChar)
  {
    int j = paramString.length();
    for (int i = 0; i < j; i++) {
      if (paramString.charAt(i) != paramChar) {
        return i;
      }
    }
    return j;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\model\parse\WikiSubParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */