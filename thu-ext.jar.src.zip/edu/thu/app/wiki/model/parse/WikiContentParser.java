package edu.thu.app.wiki.model.parse;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.util.StringUtils;
import java.io.IOException;

public class WikiContentParser
  extends WikiSubParser
{
  public static WikiContentParser getInstance()
  {
    return new WikiContentParser();
  }
  
  public boolean isTopBlock()
  {
    return false;
  }
  
  public String getPrefix()
  {
    return "{{{";
  }
  
  public void parse(String paramString, WikiParser paramWikiParser)
    throws IOException
  {
    if (!paramString.startsWith("{{{")) {
      throw Exceptions.code("wiki.CAN_err_invalid_content_start").param(paramString);
    }
    paramString = paramString.substring(3);
    paramString = StringUtils.replace(paramString, "<![CDATA[", "< ![CDATA[");
    paramWikiParser.append("<wiki:content>").append(paramString).append("\n");
    paramWikiParser.readTill("}}}", true);
    paramWikiParser.append("</wiki:content>\n");
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\model\parse\WikiContentParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */