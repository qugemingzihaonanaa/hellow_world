package edu.thu.app.wiki.model.parse;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import java.io.IOException;

public class WikiUlParser
  extends WikiSubParser
{
  public static WikiUlParser getInstance()
  {
    return new WikiUlParser();
  }
  
  public String getPrefix()
  {
    return "*";
  }
  
  public boolean isTopBlock()
  {
    return true;
  }
  
  public void parse(String paramString, WikiParser paramWikiParser)
    throws IOException
  {
    if (!paramString.startsWith("*")) {
      throw Exceptions.code("wiki.CAN_err_not_ul").param(paramString);
    }
    paramWikiParser.pushbackLine(paramString);
    paramWikiParser.append("<wiki:ul level='1'>");
    B(paramWikiParser, 1, true);
    paramWikiParser.append("</wiki:ul>");
  }
  
  void B(WikiParser paramWikiParser, int paramInt, boolean paramBoolean)
    throws IOException
  {
    String str = paramWikiParser.readLine();
    if (str == null) {
      return;
    }
    if (!str.startsWith("*"))
    {
      paramWikiParser.pushbackLine(str);
      return;
    }
    int i = countStartChar(str, '*');
    if (i > paramInt)
    {
      paramWikiParser.append("<wiki:ul level='").append(String.valueOf(i)).append("' >");
      paramWikiParser.append("<wiki:li level='").append(String.valueOf(i)).append("' >");
      paramWikiParser.A(str.substring(i), true);
      paramWikiParser.process(true);
      B(paramWikiParser, i, false);
      paramWikiParser.append("</wiki:li>");
      B(paramWikiParser, i, true);
      paramWikiParser.append("</wiki:ul>");
    }
    else if ((i == paramInt) && (paramBoolean))
    {
      paramWikiParser.append("<wiki:li level='").append(String.valueOf(i)).append("' >");
      paramWikiParser.A(str.substring(i), true);
      paramWikiParser.process(true);
      B(paramWikiParser, i, false);
      paramWikiParser.append("</wiki:li>");
      B(paramWikiParser, i, true);
    }
    else
    {
      paramWikiParser.pushbackLine(str);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\model\parse\WikiUlParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */