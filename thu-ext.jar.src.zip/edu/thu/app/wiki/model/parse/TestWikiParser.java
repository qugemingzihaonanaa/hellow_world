package edu.thu.app.wiki.model.parse;

import edu.thu.app.wiki.model.WikiModel;
import edu.thu.global.Debug;
import edu.thu.lang.util.TplC;
import edu.thu.service.SystemServiceContext;
import edu.thu.util.FileUtils;
import java.io.File;
import test.UnitTest;

public class TestWikiParser
  extends UnitTest
{
  public void setUp() {}
  
  public void testParse()
  {
    File localFile = new File(getPath(), "test_wiki.txt");
    WikiParser localWikiParser = new WikiParser();
    localWikiParser.setOnlyWikiTag(true);
    WikiModel localWikiModel = localWikiParser.parseFile(localFile);
    Debug.trace(localWikiModel.getLinks());
    Debug.trace(localWikiModel.getHeaders());
    String str = TplC.getTplOut(localWikiModel.getTpl(), null, SystemServiceContext.getInstance());
    Debug.trace(str);
    FileUtils.save(new File("d:/test_wiki.html"), str);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\model\parse\TestWikiParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */