package edu.thu.app.wiki.model.parse;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.util.StringUtils;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class WikiTableParser
  extends WikiSubParser
{
  public static WikiTableParser getInstance()
  {
    return new WikiTableParser();
  }
  
  public String getPrefix()
  {
    return "|";
  }
  
  public boolean isTopBlock()
  {
    return false;
  }
  
  public void parse(String paramString, WikiParser paramWikiParser)
    throws IOException
  {
    if (!paramString.startsWith(getPrefix())) {
      throw Exceptions.code("wiki.CAN_err_not_table").param(paramString);
    }
    int i = countStartChar(paramString, '|');
    if (i > 2)
    {
      paramWikiParser.append(StringUtils.repeat("|", i));
      paramWikiParser.A(paramString.substring(i), true);
      return;
    }
    paramWikiParser.append("<wiki:table>");
    if (paramString.startsWith("||"))
    {
      paramWikiParser.append("<wiki:thead>");
      paramString = paramString.substring(1);
      A(paramString, paramWikiParser, 0);
      paramWikiParser.append("</wiki:thead>");
    }
    paramWikiParser.append("<wiki:tbody>");
    A(paramWikiParser);
    paramWikiParser.append("</wiki:tbody>");
    paramWikiParser.append("</wiki:table>");
  }
  
  void A(String paramString, WikiParser paramWikiParser, int paramInt)
    throws IOException
  {
    paramString = paramString.trim();
    paramWikiParser.append("<wiki:tr index='" + paramInt + "'>");
    List localList = Arrays.asList(StringUtils.split(paramString, '|'));
    int j = localList.size();
    if (paramString.endsWith("|")) {
      j--;
    }
    for (int i = 1; i < j; i++)
    {
      paramWikiParser.append("<wiki:td>");
      String str = (String)localList.get(i);
      str = StringUtils.strip(str);
      if (str == null) {
        str = " ";
      }
      paramWikiParser.processContent(str);
      paramWikiParser.append("</wiki:td>");
    }
    paramWikiParser.append("\n</wiki:tr>");
  }
  
  void A(WikiParser paramWikiParser)
    throws IOException
  {
    int i = 0;
    for (;;)
    {
      i++;
      String str = paramWikiParser.readLine();
      if (str == null) {
        return;
      }
      if (!str.startsWith(getPrefix()))
      {
        paramWikiParser.pushbackLine(str);
        return;
      }
      A(str, paramWikiParser, i);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\model\parse\WikiTableParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */