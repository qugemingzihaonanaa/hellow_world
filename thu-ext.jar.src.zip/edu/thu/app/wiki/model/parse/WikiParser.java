package edu.thu.app.wiki.model.parse;

import edu.thu.app.wiki.IWikiParser;
import edu.thu.app.wiki.model.WikiHeader;
import edu.thu.app.wiki.model.WikiLink;
import edu.thu.app.wiki.model.WikiModel;
import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.util.Coercions;
import edu.thu.lang.exceptions.StdException;
import edu.thu.lang.util.ITplReference;
import edu.thu.lang.util.TplC;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.SystemServiceContext;
import edu.thu.util.FileUtils;
import edu.thu.util.StringUtils;
import edu.thu.xml.dom.DomToTree;
import java.io.File;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class WikiParser
  implements IWikiParser
{
  static String[] C = { "&lt;", "&gt;", "&amp;", "&#34;", "&#39;", "&#034;", "&#039;", "&#160" };
  static Set<String> H = new HashSet(Arrays.asList(new String[] { "wiki:ul", "wiki:ol", "wiki:table", "wiki:h", "wiki:content", "wiki:hr" }));
  public static final Log logger = LogFactory.getLog(WikiParser.class);
  StringBuffer B = new StringBuffer();
  LineNumberReader I;
  List<WikiSubParser> J = new ArrayList();
  WikiModel A;
  String N;
  boolean E = true;
  boolean L = true;
  boolean O;
  boolean G = true;
  boolean M = true;
  String D;
  Map<String, Object> F = new HashMap();
  String K;
  
  public WikiParser()
  {
    this.J.add(WikiContentParser.getInstance());
    this.J.add(WikiHeaderParser.getInstance());
    this.J.add(WikiHrParser.getInstance());
    this.J.add(WikiUlParser.getInstance());
    this.J.add(WikiOlParser.getInstance());
    this.J.add(WikiTableParser.getInstance());
  }
  
  public String getTheme()
  {
    return this.D;
  }
  
  public void setTheme(String paramString)
  {
    this.D = paramString;
  }
  
  public void setOnlyWikiTag(boolean paramBoolean)
  {
    this.M = paramBoolean;
  }
  
  public void checkOnlyWikiTag(TreeNode paramTreeNode)
  {
    String str1 = paramTreeNode.getName();
    int i = str1.indexOf(':');
    if (i > 0)
    {
      String str2 = str1.substring(0, i);
      if ((!str2.equals("wiki")) && (!str1.equals("c:div"))) {
        throw Exceptions.code("wiki.CAN_err_invalid_tag").param(paramTreeNode);
      }
    }
    int k = paramTreeNode.getChildCount();
    for (int j = 0; j < k; j++) {
      checkOnlyWikiTag(paramTreeNode.getChild(j));
    }
  }
  
  public void setDump(boolean paramBoolean)
  {
    this.G = paramBoolean;
  }
  
  public void setOnlyAnalyze(boolean paramBoolean)
  {
    this.O = paramBoolean;
  }
  
  public void setNoTag(boolean paramBoolean)
  {
    this.E = paramBoolean;
  }
  
  public void setNoEl(boolean paramBoolean)
  {
    this.L = paramBoolean;
  }
  
  public LineNumberReader getIn()
  {
    return this.I;
  }
  
  public WikiParser append(String paramString)
  {
    if (this.O) {
      return this;
    }
    this.B.append(paramString);
    return this;
  }
  
  public void readTill(String paramString, boolean paramBoolean)
    throws IOException
  {
    for (;;)
    {
      String str = readLine();
      if (str == null)
      {
        if (!logger.isDebugEnabled()) {
          break;
        }
        logger.debug("wiki.CAN_err_unexpected_end::" + paramString);
        break;
      }
      if (str.startsWith(paramString)) {
        break;
      }
      if (paramBoolean)
      {
        str = StringUtils.replace(str, "<![CDATA[", "<! [CDATA[");
        str = StringUtils.replace(str, "]]>", "] ]>");
      }
      processContent(str);
      append("\n");
    }
  }
  
  protected TplC newTplC()
  {
    TplC localTplC = TplC.newWebTplC();
    TreeNode localTreeNode = TreeNode.make("c:lib");
    localTreeNode.setAttribute("src", "/_tpl/wiki.lib.xml");
    localTreeNode.setAttribute("namespace", "wiki");
    localTplC.run(localTreeNode, SystemServiceContext.getInstance());
    return localTplC;
  }
  
  public WikiModel parse(LineNumberReader paramLineNumberReader)
    throws IOException
  {
    this.I = paramLineNumberReader;
    this.A = new WikiModel();
    process(false);
    if (!this.O)
    {
      String str = "<c:div>" + this.B.toString() + "</c:div>";
      if (this.G) {
        Debug.trace(str);
      }
      TreeNode localTreeNode = DomToTree.getInstance().allowText(true).transform(str);
      A(localTreeNode);
      if (this.G) {
        localTreeNode.dump();
      }
      if (this.M) {
        checkOnlyWikiTag(localTreeNode);
      }
      ITplReference localITplReference = newTplC().compileBody(localTreeNode, null, SystemServiceContext.getInstance());
      this.A.setTpl(localITplReference);
    }
    return this.A;
  }
  
  void A(TreeNode paramTreeNode)
  {
    int j = paramTreeNode.getChildCount();
    for (int i = 0; i < j; i++) {
      A(paramTreeNode.getChild(i));
    }
    String str = paramTreeNode.stringValue();
    if (str != null)
    {
      if (str.indexOf(" ") >= 0)
      {
        str = StringUtils.replace(str, " ", String.valueOf(' '));
        paramTreeNode.setValue(str);
      }
      if ((!paramTreeNode.getName().equalsIgnoreCase("script")) && (str.indexOf("\n") >= 0))
      {
        str = StringUtils.replace(str, "\r", "");
        A(paramTreeNode, str);
      }
    }
  }
  
  void A(TreeNode paramTreeNode, String paramString)
  {
    int i;
    TreeNode localTreeNode1;
    if (paramString.startsWith("\n"))
    {
      localObject = paramTreeNode.getParent();
      if (localObject != null)
      {
        i = ((TreeNode)localObject).indexOfChild(paramTreeNode);
        if (i > 0)
        {
          localTreeNode1 = ((TreeNode)localObject).getChild(i - 1);
          if (H.contains(localTreeNode1.getName())) {
            paramString = paramString.substring(1);
          }
        }
      }
    }
    if (paramString.endsWith("\n"))
    {
      localObject = paramTreeNode.getParent();
      if (localObject != null)
      {
        i = ((TreeNode)localObject).indexOfChild(paramTreeNode);
        if (i != ((TreeNode)localObject).getChildCount() - 1)
        {
          localTreeNode1 = ((TreeNode)localObject).getChild(i + 1);
          if (H.contains(localTreeNode1.getName())) {
            paramString = paramString.substring(0, paramString.length() - 1);
          }
        }
      }
    }
    Object localObject = StringUtils.split(paramString, '\n');
    paramTreeNode.setValue(null);
    if (localObject != null)
    {
      if (paramTreeNode.getName().equals("#text")) {
        paramTreeNode.setName("c:div");
      }
      int j = localObject.length;
      for (i = 0; i < j; i++)
      {
        TreeNode localTreeNode2 = TreeNode.make("#text");
        localTreeNode2.setValue(localObject[i]);
        paramTreeNode.appendChild(localTreeNode2);
        if (i != j - 1) {
          paramTreeNode.appendChild(TreeNode.make("br"));
        }
      }
    }
  }
  
  public WikiModel parseText(String paramString)
  {
    try
    {
      return parse(new LineNumberReader(new StringReader(paramString)));
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public WikiModel parseFile(File paramFile)
  {
    return parseText(FileUtils.loadText(paramFile));
  }
  
  public int getLineNumber()
  {
    if (this.N != null) {
      return this.I.getLineNumber() - 1;
    }
    return this.I.getLineNumber();
  }
  
  public String readLine()
    throws IOException
  {
    if (this.N != null)
    {
      String str = this.N;
      this.N = null;
      return str;
    }
    return this.I.readLine();
  }
  
  public String peekLine()
    throws IOException
  {
    if (this.N == null) {
      this.N = this.I.readLine();
    }
    return this.N;
  }
  
  public void pushbackLine(String paramString)
  {
    this.N = paramString;
  }
  
  public void process(boolean paramBoolean)
    throws IOException
  {
    for (;;)
    {
      String str = readLine();
      if (str == null) {
        return;
      }
      if (StringUtils.strip(str) == null)
      {
        if (paramBoolean)
        {
          pushbackLine(str);
          return;
        }
        append(str).append("\n");
      }
      else if (str.startsWith(">>>"))
      {
        C(str.substring(3));
      }
      else
      {
        if (str.endsWith("\\")) {
          str = str.substring(0, str.length() - 2);
        }
        if (str.contains("\\")) {
          str = StringUtils.replace(str, "\\", "\n");
        }
        int j = this.J.size();
        for (int i = 0; i < j; i++)
        {
          WikiSubParser localWikiSubParser = (WikiSubParser)this.J.get(i);
          if (str.startsWith(localWikiSubParser.getPrefix()))
          {
            if ((paramBoolean) && (localWikiSubParser.isTopBlock()))
            {
              pushbackLine(str);
              return;
            }
            localWikiSubParser.parse(str, this);
            break;
          }
        }
        if (i == j) {
          A(str, true);
        }
      }
    }
  }
  
  public void addHeader(WikiHeader paramWikiHeader)
  {
    this.A.getHeaders().add(paramWikiHeader);
  }
  
  public void processContent(String paramString)
  {
    if (this.O) {
      return;
    }
    int i = 0;
    for (;;)
    {
      int j = paramString.indexOf('&', i);
      if (j < 0) {
        break;
      }
      String str = paramString.substring(j);
      int m = C.length;
      for (int k = 0; k < m; k++) {
        if (str.startsWith(C[k]))
        {
          i = j + C[k].length();
          break;
        }
      }
      if (k == m)
      {
        paramString = paramString.substring(0, j) + "&amp;" + paramString.substring(j + 1);
        i = j + "amp;".length();
      }
    }
    if (this.E)
    {
      paramString = StringUtils.replace(paramString, "<", "&lt;");
      paramString = StringUtils.replace(paramString, ">", "&gt;");
    }
    if (this.L) {
      paramString = StringUtils.replace(paramString, "$", "${'$'}");
    }
    if ((paramString.startsWith("__")) && (paramString.endsWith("__")))
    {
      paramString = paramString.substring(2, paramString.length() - 2);
      append("<b>");
      append(paramString);
      append("</b>");
      return;
    }
    append(paramString);
  }
  
  void A(String paramString, boolean paramBoolean)
  {
    int i = 0;
    for (;;)
    {
      int j = paramString.indexOf('[', i);
      if (j < 0)
      {
        processContent(paramString.substring(i));
        break;
      }
      if ((j + 1 <= paramString.length()) && (paramString.charAt(j + 1) == '['))
      {
        processContent(paramString.substring(i, j + 1));
        i = j + 2;
      }
      else
      {
        int k = paramString.indexOf(']', j);
        if (k < 0)
        {
          processContent(paramString.substring(i));
          break;
        }
        processContent(paramString.substring(i, j));
        String str = paramString.substring(j + 1, k);
        B(str);
        i = k + 1;
      }
    }
    if (paramBoolean) {
      append("\n");
    }
  }
  
  void B(String paramString)
  {
    WikiLink localWikiLink = new WikiLink();
    localWikiLink.parseFrom(paramString);
    if (!localWikiLink.isLocalRef()) {
      this.A.getLinks().add(localWikiLink);
    }
    localWikiLink.render(this.B);
  }
  
  void C(String paramString)
  {
    while (paramString.startsWith(">")) {
      paramString = paramString.substring(1);
    }
    paramString = StringUtils.strip(paramString);
    if (paramString == null) {
      return;
    }
    Map localMap = A(paramString);
    if (localMap == null) {
      return;
    }
    Iterator localIterator = localMap.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      if (str.equals("no_tag")) {
        setNoTag(Coercions.toBoolean(localMap.get("no_tag"), false));
      } else if (str.equals("no_el")) {
        setNoEl(Coercions.toBoolean(localMap.get("no_el"), false));
      } else if (str.equals("dump")) {
        setDump(Coercions.toBoolean(localMap.get("dump"), false));
      } else if (str.equals("theme")) {
        setTheme((String)localMap.get("theme"));
      } else if (str.startsWith("attr_")) {
        this.A.setAttribute(str, (String)localMap.get(str));
      } else {
        throw Exceptions.code("wiki.CAN_err_unknown_attribute").param(str).param(getLineNumber()).param(paramString);
      }
    }
  }
  
  Map<String, String> A(String paramString)
  {
    List localList = StringUtils.stripedSplit(paramString, ',');
    if (localList == null) {
      return null;
    }
    LinkedHashMap localLinkedHashMap = new LinkedHashMap();
    int j = localList.size();
    for (int i = 0; i < j; i++)
    {
      String str = (String)localList.get(i);
      String[] arrayOfString = StringUtils.split(str, '=');
      if (StringUtils.strip(arrayOfString[0]) != null) {
        localLinkedHashMap.put(StringUtils.strip(arrayOfString[0]), StringUtils.strip(arrayOfString[1]));
      }
    }
    return localLinkedHashMap;
  }
  
  void A(String paramString, WikiLinkVisitor paramWikiLinkVisitor)
  {
    int i = 0;
    for (;;)
    {
      int j = paramString.indexOf('[', i);
      if (j < 0)
      {
        append(paramString.substring(i));
        break;
      }
      if ((j + 1 <= paramString.length()) && (paramString.charAt(j + 1) == '['))
      {
        append(paramString.substring(i, j + 1));
        i = j + 2;
      }
      else
      {
        int k = paramString.indexOf(']', j);
        if (k < 0)
        {
          append(paramString.substring(i));
          break;
        }
        append(paramString.substring(i, j + 1));
        String str = paramString.substring(j + 1, k);
        WikiLink localWikiLink = new WikiLink();
        try
        {
          localWikiLink.parseFrom(str);
          paramWikiLinkVisitor.visit(localWikiLink);
          str = localWikiLink.toString();
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
        }
        append(str).append("]");
        i = k + 1;
      }
    }
    append("\n");
  }
  
  public void setInText(String paramString)
  {
    this.I = new LineNumberReader(new StringReader(paramString));
  }
  
  public void setIn(Reader paramReader)
  {
    this.I = new LineNumberReader(paramReader);
  }
  
  public void accept(WikiLinkVisitor paramWikiLinkVisitor)
  {
    try
    {
      for (;;)
      {
        String str = readLine();
        if (str == null) {
          break;
        }
        if (str.startsWith("{{{"))
        {
          readTill("}}}", false);
          append("}}}\n");
        }
        else if (str.startsWith("!"))
        {
          append(str).append("\n");
        }
        else
        {
          A(str, paramWikiLinkVisitor);
        }
      }
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  public String getResult()
  {
    return this.B.toString();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\model\parse\WikiParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */