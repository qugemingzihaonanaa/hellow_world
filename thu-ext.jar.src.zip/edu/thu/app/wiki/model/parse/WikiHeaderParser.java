package edu.thu.app.wiki.model.parse;

import edu.thu.app.wiki.model.WikiHeader;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import java.io.IOException;

public class WikiHeaderParser
  extends WikiSubParser
{
  public static WikiHeaderParser getInstance()
  {
    return new WikiHeaderParser();
  }
  
  public boolean isTopBlock()
  {
    return true;
  }
  
  public String getPrefix()
  {
    return "!";
  }
  
  public void parse(String paramString, WikiParser paramWikiParser)
    throws IOException
  {
    if (!paramString.startsWith("!")) {
      throw Exceptions.code("wiki.CAN_err_invalid_header_start").param(paramString);
    }
    int i = countStartChar(paramString, '!');
    paramWikiParser.append("<wiki:h ").append("level='").append(String.valueOf(i)).append("' >");
    String str = paramString.substring(i);
    paramWikiParser.processContent(str);
    paramWikiParser.append("</wiki:h>\n");
    paramWikiParser.addHeader(new WikiHeader(i, str));
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\model\parse\WikiHeaderParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */