package edu.thu.app.wiki.model.parse;

import edu.thu.app.wiki.model.WikiLink;

public abstract class WikiLinkVisitor
{
  protected boolean processed;
  
  public boolean isProcessed()
  {
    return this.processed;
  }
  
  public abstract void visit(WikiLink paramWikiLink);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\wiki\model\parse\WikiLinkVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */