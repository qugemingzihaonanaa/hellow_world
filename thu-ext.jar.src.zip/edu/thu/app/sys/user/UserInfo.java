package edu.thu.app.sys.user;

import edu.thu.orm.component.impl.FileComponent;

public class UserInfo
{
  String A;
  String B;
  
  public String getHmName()
  {
    return this.A;
  }
  
  public String getId()
  {
    return this.B;
  }
  
  public void setId(String paramString)
  {
    this.B = paramString;
  }
  
  public String getDeptId()
  {
    return null;
  }
  
  public void setHmName(String paramString)
  {
    this.A = paramString;
  }
  
  public FileComponent getNamePic()
  {
    return null;
  }
  
  public Integer getSecretLevel()
  {
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\user\UserInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */