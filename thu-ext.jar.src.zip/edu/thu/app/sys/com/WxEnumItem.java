package edu.thu.app.sys.com;

public class WxEnumItem
{
  protected String itemName;
  protected String itemValue;
  
  public String getItemName()
  {
    return this.itemName;
  }
  
  public void setItemName(String paramString)
  {
    this.itemName = paramString;
  }
  
  public String getItemValue()
  {
    return this.itemValue;
  }
  
  public void setItemValue(String paramString)
  {
    this.itemValue = paramString;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\com\WxEnumItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */