package edu.thu.app.sys.com;

import edu.thu.app.sys.com._entity._PartitionInfo;

public class PartitionInfo
  extends _PartitionInfo
{
  private static final long serialVersionUID = 1L;
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\com\PartitionInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */