package edu.thu.app.sys.com;

import edu.thu.model.stg.ds.EnumItem;
import java.util.List;
import java.util.Set;

public class WxEnum
{
  public Set getWxEnumItems()
  {
    return null;
  }
  
  public List<EnumItem> getEnumItems()
  {
    return null;
  }
  
  public boolean isUseCodeField()
  {
    return false;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\com\WxEnum.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */