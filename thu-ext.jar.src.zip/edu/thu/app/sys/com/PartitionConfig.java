package edu.thu.app.sys.com;

public class PartitionConfig
{
  String A;
  
  public String getCurrentPartition()
  {
    return this.A;
  }
  
  public void setCurrentPartition(String paramString)
  {
    this.A = paramString;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\com\PartitionConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */