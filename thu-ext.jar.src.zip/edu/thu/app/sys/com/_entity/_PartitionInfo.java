package edu.thu.app.sys.com._entity;

import edu.thu.ext.hibernate.AbstractEntity;
import java.sql.Timestamp;

public class _PartitionInfo
  extends AbstractEntity
{
  private static final long serialVersionUID = 1L;
  protected String partitionId;
  protected Timestamp startTime;
  protected String isActive;
  protected String description;
  
  public String getPartitionId()
  {
    return this.partitionId;
  }
  
  public void setPartitionId(String paramString)
  {
    this.partitionId = paramString;
  }
  
  public Timestamp getStartTime()
  {
    return this.startTime;
  }
  
  public void setStartTime(Timestamp paramTimestamp)
  {
    this.startTime = paramTimestamp;
  }
  
  public String getIsActive()
  {
    return this.isActive;
  }
  
  public void setIsActive(String paramString)
  {
    this.isActive = paramString;
  }
  
  public String getDescription()
  {
    return this.description;
  }
  
  public void setDescription(String paramString)
  {
    this.description = paramString;
  }
  
  public Object toDbType()
  {
    return _toObject(this.partitionId);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\com\_entity\_PartitionInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */