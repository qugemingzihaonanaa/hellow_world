package edu.thu.app.sys;

import edu.thu.ext.hibernate.AbstractEntity;
import edu.thu.model.entity.Tags;
import edu.thu.model.tree.LayerCode;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

public class Department
  extends AbstractEntity
{
  private static final long serialVersionUID = -6264767015199960331L;
  public static final String TAG_SPECIAL = "s";
  private String B;
  private String A;
  private String H;
  private Integer C;
  private String G;
  private Timestamp J;
  private String E;
  private Timestamp F;
  Tags tags;
  private Department I;
  private Set D = new HashSet(0);
  transient LayerCode lc;
  
  public Department() {}
  
  public Department(String paramString1, String paramString2)
  {
    this.A = paramString1;
    this.H = paramString2;
  }
  
  public Object toDbType()
  {
    return getId();
  }
  
  public String getId()
  {
    return this.B;
  }
  
  public void setId(String paramString)
  {
    this.B = paramString;
  }
  
  public String getName()
  {
    return this.A;
  }
  
  public void setName(String paramString)
  {
    this.A = paramString;
  }
  
  public String getLayerCode()
  {
    return this.H;
  }
  
  public void setLayerCode(String paramString)
  {
    this.lc = null;
    this.H = paramString;
    LayerCode localLayerCode = getLc();
    if (localLayerCode == null) {
      this.C = new Integer(0);
    } else {
      this.C = new Integer(localLayerCode.getLevel());
    }
  }
  
  public Integer getLayerLevel()
  {
    return this.C;
  }
  
  public void setLayerLevel(Integer paramInteger)
  {
    this.C = paramInteger;
  }
  
  public String getCreaterId()
  {
    return this.G;
  }
  
  public void setCreaterId(String paramString)
  {
    this.G = paramString;
  }
  
  public Timestamp getCreateTime()
  {
    return this.J;
  }
  
  public void setCreateTime(Timestamp paramTimestamp)
  {
    this.J = paramTimestamp;
  }
  
  public String getUpdaterId()
  {
    return this.E;
  }
  
  public void setUpdaterId(String paramString)
  {
    this.E = paramString;
  }
  
  public Timestamp getUpdateTime()
  {
    return this.F;
  }
  
  public void setUpdateTime(Timestamp paramTimestamp)
  {
    this.F = paramTimestamp;
  }
  
  public Department getParent()
  {
    return this.I;
  }
  
  public void setParent(Department paramDepartment)
  {
    this.I = paramDepartment;
  }
  
  public Set getChildren()
  {
    return this.D;
  }
  
  public void setChildren(Set paramSet)
  {
    this.D = paramSet;
  }
  
  public void addChild(Department paramDepartment)
  {
    if (this.D == null) {
      this.D = new HashSet();
    }
    this.D.add(paramDepartment);
    paramDepartment.setParent(this);
  }
  
  public void removeChild(Department paramDepartment)
  {
    if (this.D == null) {
      return;
    }
    this.D.remove(paramDepartment);
  }
  
  public LayerCode getLc()
  {
    if (this.lc != null) {
      return this.lc;
    }
    if ((this.H == null) || (this.H.length() <= 0)) {
      this.lc = null;
    } else {
      this.lc = LayerCode.valueOf(this.H);
    }
    return this.lc;
  }
  
  public void setLc(LayerCode paramLayerCode)
  {
    this.lc = paramLayerCode;
    this.H = (this.lc == null ? null : this.lc.toString());
    this.C = (this.lc == null ? new Integer(0) : new Integer(this.lc.getLevel()));
  }
  
  public void setDistSystemId(String paramString) {}
  
  public void setDistStatus(int paramInt) {}
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\Department.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */