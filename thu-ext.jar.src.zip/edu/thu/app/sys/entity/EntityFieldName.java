package edu.thu.app.sys.entity;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.model.tree.TreeNode;

public class EntityFieldName
{
  public static final String TYPE_SEPARATOR = "__";
  EntityDataType A;
  String B;
  
  public EntityDataType getDataType()
  {
    return this.A;
  }
  
  public String getName()
  {
    return this.B;
  }
  
  public TreeNode toFieldNode()
  {
    TreeNode localTreeNode = TreeNode.make("field");
    localTreeNode.setAttribute("name", this.B);
    localTreeNode.setAttribute("syncWithModel", "true");
    localTreeNode.makeChild("type").setValue(this.A.getName());
    localTreeNode.makeChild("storeType").setValue(this.A.getStoreType());
    localTreeNode.makeChild("storeSize").setValue(String.valueOf(this.A.getStoreSize()));
    localTreeNode.makeChild("maxLength").setValue(String.valueOf(this.A.getMaxLength()));
    localTreeNode.makeChild("precision").setValue(String.valueOf(this.A.getPrecision()));
    return localTreeNode;
  }
  
  public static String getStdName(String paramString)
  {
    if ((paramString == null) || (paramString.length() <= 0)) {
      return null;
    }
    int i = paramString.indexOf("__");
    if (i < 0) {
      return paramString;
    }
    return paramString.substring(0, i);
  }
  
  public void parse(String paramString, EntityDataTypeSet paramEntityDataTypeSet)
  {
    if ((paramString == null) || (paramString.length() <= 0)) {
      throw Exceptions.code("entity.CAN_err_invalid_field_name").param(this.B);
    }
    int i = paramString.indexOf("__");
    if (i < 0)
    {
      this.B = paramString;
      this.A = paramEntityDataTypeSet.getDataType("string");
    }
    else
    {
      this.B = paramString.substring(0, i);
      if (this.B.length() <= 0) {
        throw Exceptions.code("entity.CAN_err_invalid_field_name").param(paramString);
      }
      String str = paramString.substring(i + "__".length() + 1);
      while (str.length() > 0) {
        if (str.charAt(0) == '_') {
          str = str.substring(1);
        }
      }
      while (str.length() > 0) {
        if (str.charAt(str.length() - 1) == '_') {
          str = str.substring(0, str.length() - 1);
        }
      }
      if (str.length() <= 0) {
        throw Exceptions.code("entity.CAN_err_invalid_field_type").param(paramString);
      }
      this.A = new EntityDataType();
      this.A.parse(str, paramEntityDataTypeSet.getDataType(str));
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\EntityFieldName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */