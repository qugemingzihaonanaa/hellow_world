package edu.thu.app.sys.entity;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.util.Coercions;
import edu.thu.lang.IVariant;
import edu.thu.model.tree.TreeNode;
import edu.thu.util.StringUtils;
import java.util.List;

public class EntityDataType
{
  String C;
  String E;
  int D;
  int B = -1;
  int A = -1;
  
  public EntityDataType() {}
  
  public EntityDataType(EntityDataType paramEntityDataType)
  {
    this.C = paramEntityDataType.C;
    this.E = paramEntityDataType.E;
    this.D = paramEntityDataType.D;
    this.B = paramEntityDataType.B;
    this.A = paramEntityDataType.A;
  }
  
  public int getMaxLength()
  {
    return this.B;
  }
  
  public void setMaxLength(int paramInt)
  {
    this.B = paramInt;
  }
  
  public int getStoreSize()
  {
    return this.D;
  }
  
  public void setStoreSize(int paramInt)
  {
    this.D = paramInt;
  }
  
  public String getName()
  {
    return this.C;
  }
  
  public void setName(String paramString)
  {
    this.C = paramString;
  }
  
  public int getPrecision()
  {
    return this.A;
  }
  
  public void setPrecision(int paramInt)
  {
    this.A = paramInt;
  }
  
  public String getStoreType()
  {
    return this.E;
  }
  
  public void setStoreType(String paramString)
  {
    this.E = paramString;
  }
  
  public void fromNode(TreeNode paramTreeNode)
  {
    this.C = paramTreeNode.attribute("name").stripedStringValue();
    this.E = paramTreeNode.attribute("storeType").stripedStringValue();
    this.D = paramTreeNode.attribute("storeSize").intValue(-1);
    this.B = paramTreeNode.attribute("maxLength").intValue(-1);
    if ((this.C == null) || (this.E == null)) {
      throw Exceptions.code("entity.CAN_err_invalid_datatype_node").param(paramTreeNode);
    }
  }
  
  public void parse(String paramString, EntityDataType paramEntityDataType)
  {
    List localList = StringUtils.stripedSplit(paramString, '_');
    if ((localList == null) || (localList.size() <= 1)) {
      throw Exceptions.code("entity.CAN_err_invalid_datatype").param(paramString);
    }
    this.C = ((String)localList.get(0));
    if (localList.size() >= 2) {
      this.D = Coercions.toInt(localList.get(1), -1);
    }
    if (localList.size() >= 3) {
      this.A = Coercions.toInt(localList.get(2), -1);
    }
    this.E = paramEntityDataType.getStoreType();
    if (this.D < 0) {
      this.D = paramEntityDataType.getStoreSize();
    }
    if (this.B < 0) {
      this.B = paramEntityDataType.getMaxLength();
    }
  }
  
  public void validate()
  {
    if (this.E == null) {
      throw Exceptions.code("entity.CAN_err_invalid_datatype");
    }
    if (this.D < 0) {
      throw Exceptions.code("entity.CAN_err_invalid_storeSize").param(this.D);
    }
    if ((this.D > 0) && (this.B < 0))
    {
      this.B = (this.D / 2);
      if (this.B <= 0) {
        this.B = 1;
      }
    }
    if (this.D > 4000) {
      throw Exceptions.code("entity.CAN_err_data_too_large").param(this.D);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\EntityDataType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */