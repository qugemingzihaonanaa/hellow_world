package edu.thu.app.sys.entity;

import edu.thu.ext.hibernate.AbstractHibernateDao;
import edu.thu.model.stg.ds.DataSourceMeta;
import edu.thu.orm.dao.IOrmTemplate;
import edu.thu.service.BeanLoader;
import java.util.Hashtable;
import java.util.Map;

public class EntityDsMetaManager
  extends AbstractHibernateDao
{
  private static final long serialVersionUID = 443612403728719650L;
  Map<String, DataSourceMeta> cache = new Hashtable();
  
  public static EntityDsMetaManager getInstance()
  {
    return (EntityDsMetaManager)BeanLoader.getBean(EntityDsMetaManager.class);
  }
  
  public void clearCache()
  {
    this.cache.clear();
  }
  
  public void clearCache(String paramString)
  {
    this.cache.remove(paramString);
  }
  
  EntityDsMeta getEntityDsMeta(String paramString)
  {
    return null;
  }
  
  public DataSourceMeta getDsMeta(String paramString)
  {
    return null;
  }
  
  public void updateDsMeta(String paramString1, String paramString2, String paramString3) {}
  
  public void removeDsMeta(String paramString)
  {
    clearCache(paramString);
    EntityDsMeta localEntityDsMeta = getEntityDsMeta(paramString);
    if (localEntityDsMeta != null) {
      orm().delete(localEntityDsMeta);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\EntityDsMetaManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */