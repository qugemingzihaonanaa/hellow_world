package edu.thu.app.sys.entity;

import edu.thu.core.AppResourceLoader;
import edu.thu.core.IResource;
import edu.thu.core.IResourceLoader;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.BeanLoader;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.PostConstruct;

public class EntityDataTypeSet
{
  Map<String, EntityDataType> B = new HashMap();
  String A;
  
  public static EntityDataTypeSet getInstance()
  {
    return (EntityDataTypeSet)BeanLoader.getBean(EntityDataTypeSet.class);
  }
  
  public void setDefinition(String paramString)
  {
    this.A = paramString;
  }
  
  @PostConstruct
  public void afterPropertiesSet()
  {
    IResource localIResource = AppResourceLoader.getInstance().getResource("classpath:entity_data_type.xml");
    if (localIResource.exists()) {
      A(localIResource);
    }
    if (this.A == null) {
      return;
    }
    A(AppResourceLoader.getInstance().getCustomizableResource(this.A));
  }
  
  /* Error */
  void A(IResource paramIResource)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_1
    //   3: invokeinterface 69 1 0
    //   8: astore_2
    //   9: invokestatic 73	edu/thu/xml/dom/DomToTree:getInstance	()Ledu/thu/xml/dom/DomToTree;
    //   12: iconst_1
    //   13: invokevirtual 78	edu/thu/xml/dom/DomToTree:allowText	(Z)Ledu/thu/xml/dom/DomToTree;
    //   16: aload_2
    //   17: invokevirtual 82	edu/thu/xml/dom/DomToTree:transform	(Ljava/io/InputStream;)Ledu/thu/model/tree/TreeNode;
    //   20: astore_3
    //   21: aload_0
    //   22: aload_3
    //   23: invokevirtual 86	edu/thu/app/sys/entity/EntityDataTypeSet:load	(Ledu/thu/model/tree/TreeNode;)V
    //   26: goto +18 -> 44
    //   29: astore_3
    //   30: aload_3
    //   31: invokestatic 90	edu/thu/global/exceptions/Exceptions:source	(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;
    //   34: athrow
    //   35: astore 4
    //   37: aload_2
    //   38: invokestatic 96	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/InputStream;)V
    //   41: aload 4
    //   43: athrow
    //   44: aload_2
    //   45: invokestatic 96	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/InputStream;)V
    //   48: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	49	0	this	EntityDataTypeSet
    //   0	49	1	paramIResource	IResource
    //   1	44	2	localInputStream	java.io.InputStream
    //   20	3	3	localTreeNode	TreeNode
    //   29	2	3	localException	Exception
    //   35	7	4	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   2	26	29	java/lang/Exception
    //   2	35	35	finally
  }
  
  public void load(TreeNode paramTreeNode)
  {
    int j = paramTreeNode.getChildCount();
    for (int i = 0; i < j; i++)
    {
      EntityDataType localEntityDataType = new EntityDataType();
      localEntityDataType.fromNode(paramTreeNode.getChild(i));
      localEntityDataType.validate();
      this.B.put(localEntityDataType.getName(), localEntityDataType);
    }
  }
  
  public EntityDataType getDataType(String paramString)
  {
    EntityDataType localEntityDataType = (EntityDataType)this.B.get(paramString);
    if (localEntityDataType == null) {
      throw Exceptions.code("entity.CAN_err_unknown_datatype").param(paramString);
    }
    return localEntityDataType;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\EntityDataTypeSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */