package edu.thu.app.sys.entity;

import edu.thu.db.SQL;
import edu.thu.db.SqlBuilder;
import edu.thu.ext.hibernate.AbstractHibernateDao;
import edu.thu.service.EntityManager;
import edu.thu.service.IEntityManager;
import java.util.ArrayList;
import java.util.List;

public abstract class AbstractEntityHandler
  extends AbstractHibernateDao
{
  public EntityPk makeEntityPk(String paramString1, String paramString2)
  {
    EntityPk localEntityPk = new EntityPk();
    localEntityPk.setEntityType(paramString1);
    localEntityPk.setEntityId(paramString2);
    return localEntityPk;
  }
  
  public Object getEntity(EntityPk paramEntityPk)
  {
    return EntityManager.getInstance().get(paramEntityPk.getEntityType(), paramEntityPk.getEntityId());
  }
  
  public List getEntityList(List paramList)
  {
    if ((paramList == null) || (paramList.isEmpty())) {
      return paramList;
    }
    int j = paramList.size();
    ArrayList localArrayList = new ArrayList(j);
    for (int i = 0; i < j; i++)
    {
      EntityPk localEntityPk = (EntityPk)paramList.get(i);
      Object localObject = getEntity(localEntityPk);
      localArrayList.add(localObject);
    }
    return localArrayList;
  }
  
  protected SQL getEntityCond(EntityPk paramEntityPk)
  {
    return SQL.begin().sql("o.entityType = ?  and o.entityId = ? ", paramEntityPk.getEntityType(), paramEntityPk.getEntityId()).end();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\AbstractEntityHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */