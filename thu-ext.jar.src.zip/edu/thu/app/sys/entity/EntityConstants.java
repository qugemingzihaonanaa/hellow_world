package edu.thu.app.sys.entity;

public abstract interface EntityConstants
{
  public static final int STATUS_PROCESSING = 1;
  public static final int STATUS_FINISHED = 10;
  public static final int STATUS_STOPED = 11;
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\EntityConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */