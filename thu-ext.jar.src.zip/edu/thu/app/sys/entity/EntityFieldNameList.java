package edu.thu.app.sys.entity;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.model.tree.TreeNode;
import java.util.ArrayList;
import java.util.List;

public class EntityFieldNameList
{
  EntityDataTypeSet A;
  List B;
  
  public EntityFieldNameList()
  {
    this.A = EntityDataTypeSet.getInstance();
    this.B = new ArrayList();
  }
  
  public EntityFieldNameList(EntityDataTypeSet paramEntityDataTypeSet, List paramList)
  {
    this.A = paramEntityDataTypeSet;
    this.B = paramList;
  }
  
  public void addNames(List paramList)
  {
    if ((paramList == null) || (paramList.isEmpty())) {
      return;
    }
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      String str = (String)paramList.get(i);
      addName(str);
    }
  }
  
  public void addName(String paramString)
  {
    EntityFieldName localEntityFieldName = new EntityFieldName();
    localEntityFieldName.parse(paramString, this.A);
    if (!existsName(localEntityFieldName.getName())) {
      this.B.add(localEntityFieldName);
    }
  }
  
  public boolean existsName(String paramString)
  {
    return getName(paramString) != null;
  }
  
  public EntityFieldName getName(String paramString)
  {
    paramString = EntityFieldName.getStdName(paramString);
    int j = this.B.size();
    for (int i = 0; i < j; i++)
    {
      EntityFieldName localEntityFieldName = (EntityFieldName)this.B.get(i);
      if (localEntityFieldName.getName().equals(paramString)) {
        return localEntityFieldName;
      }
    }
    return null;
  }
  
  public List getUnknownFields(TreeNode paramTreeNode, boolean paramBoolean)
  {
    ArrayList localArrayList = new ArrayList();
    int j = this.B.size();
    for (int i = 0; i < j; i++)
    {
      EntityFieldName localEntityFieldName = (EntityFieldName)this.B.get(i);
      if (((paramBoolean) || (!localEntityFieldName.getName().startsWith("ext_"))) && (paramTreeNode.childWithAttr("name", localEntityFieldName.getName()) == null)) {
        localArrayList.add(localEntityFieldName.getName());
      }
    }
    return localArrayList;
  }
  
  public TreeNode buildExtMeta(TreeNode paramTreeNode)
  {
    TreeNode localTreeNode = paramTreeNode.makeChild("fields");
    List localList = getUnknownFields(localTreeNode, false);
    if ((localList != null) && (!localList.isEmpty())) {
      throw Exceptions.code("entity.CAN_err_unknown_fields").param(localList);
    }
    appendToFields(localTreeNode);
    A(localTreeNode);
    return paramTreeNode;
  }
  
  void A(TreeNode paramTreeNode)
  {
    int j = paramTreeNode.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(i);
      if (!existsName((String)localTreeNode.getAttribute("name")))
      {
        paramTreeNode.removeChildByIndex(i);
        i--;
        j--;
      }
    }
  }
  
  public EntityFieldNameList getNamesWithPrefix(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    int j = this.B.size();
    for (int i = 0; i < j; i++)
    {
      EntityFieldName localEntityFieldName = (EntityFieldName)this.B.get(i);
      if (localEntityFieldName.getName().startsWith(paramString)) {
        localArrayList.add(localEntityFieldName);
      }
    }
    return new EntityFieldNameList(this.A, localArrayList);
  }
  
  public TreeNode toFieldsNode()
  {
    TreeNode localTreeNode = TreeNode.make("fields");
    appendToFields(localTreeNode);
    return localTreeNode;
  }
  
  public TreeNode toMetaNode()
  {
    TreeNode localTreeNode = TreeNode.make("meta");
    appendToFields(localTreeNode.makeChild("fields"));
    return localTreeNode;
  }
  
  public void appendToFields(TreeNode paramTreeNode)
  {
    int j = this.B.size();
    for (int i = 0; i < j; i++)
    {
      EntityFieldName localEntityFieldName = (EntityFieldName)this.B.get(i);
      if (paramTreeNode.childWithAttr("name", localEntityFieldName.getName()) == null)
      {
        TreeNode localTreeNode = localEntityFieldName.toFieldNode();
        paramTreeNode.appendChild(localTreeNode);
      }
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\EntityFieldNameList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */