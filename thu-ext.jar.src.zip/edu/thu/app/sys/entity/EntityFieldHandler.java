package edu.thu.app.sys.entity;

import edu.thu.db.SQL;
import edu.thu.db.SqlBuilder;
import edu.thu.model.stg.ds.DataSourceMeta;
import edu.thu.orm.dao.IEntityDao;
import edu.thu.orm.dao.IOrmTemplate;
import edu.thu.service.BeanLoader;
import java.util.List;

public class EntityFieldHandler
  extends AbstractEntityHandler
{
  private static final long serialVersionUID = -715506025328019762L;
  
  public static EntityFieldHandler getInstance()
  {
    return (EntityFieldHandler)BeanLoader.getBean(EntityFieldHandler.class);
  }
  
  SQL sqlByPk(EntityPk paramEntityPk)
  {
    SQL localSQL = SQL.begin().sql(" o.entityType = ? and o.entityId = ? ", paramEntityPk.getEntityType(), paramEntityPk.getEntityId()).end();
    return localSQL;
  }
  
  public EntityFieldList getFields(EntityPk paramEntityPk)
  {
    if (paramEntityPk.getEntityId() == null) {
      return new EntityFieldList(paramEntityPk, null);
    }
    SQL localSQL = SQL.begin().from().table(EntityDynamicField.class.getName(), "o").where().sql(" o.entityType = ? and o.entityId = ? ", paramEntityPk.getEntityType(), paramEntityPk.getEntityId()).end();
    List localList = orm().findAll(localSQL);
    return new EntityFieldList(paramEntityPk, localList);
  }
  
  public void saveOrUpdate(EntityFieldList paramEntityFieldList)
  {
    List localList = paramEntityFieldList.getFields();
    if ((localList != null) && (!localList.isEmpty())) {
      dao(EntityDynamicField.class.getName()).saveOrUpdateAllEntity(localList);
    }
  }
  
  public void removeFields(EntityPk paramEntityPk)
  {
    EntityFieldList localEntityFieldList = getFields(paramEntityPk);
    List localList = localEntityFieldList.getFields();
    DataSourceMeta localDataSourceMeta = localEntityFieldList.getDsMeta();
    int j = localList.size();
    for (int i = 0; i < j; i++)
    {
      EntityDynamicField localEntityDynamicField = (EntityDynamicField)localList.get(i);
      if (localEntityDynamicField.isObjectField(localDataSourceMeta)) {
        orm().delete(localEntityDynamicField);
      }
    }
    dao(EntityDynamicField.class.getName()).deleteEntityByCond(sqlByPk(paramEntityPk));
  }
  
  public void removeFieldList(EntityFieldList paramEntityFieldList)
  {
    List localList = paramEntityFieldList.getFields();
    int j = localList.size();
    for (int i = 0; i < j; i++)
    {
      EntityDynamicField localEntityDynamicField = (EntityDynamicField)localList.get(i);
      orm().delete(localEntityDynamicField);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\EntityFieldHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */