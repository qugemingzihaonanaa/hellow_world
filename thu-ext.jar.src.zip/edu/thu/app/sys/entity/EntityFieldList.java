package edu.thu.app.sys.entity;

import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IGetter;
import edu.thu.lang.ISetter;
import edu.thu.model.entity.EntityInfo;
import edu.thu.model.stg.ds.DataSourceMeta;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class EntityFieldList
  implements IGetter, ISetter
{
  public static final String TYPE_SEPARATOR = "__";
  EntityPk pk;
  List fields;
  
  public EntityFieldList(EntityPk paramEntityPk, List paramList)
  {
    this.pk = paramEntityPk;
    this.fields = (paramList == null ? new ArrayList(0) : paramList);
  }
  
  public boolean isEmpty()
  {
    return (this.fields == null) || (this.fields.isEmpty());
  }
  
  public List getFields()
  {
    return this.fields;
  }
  
  String getNormalName(String paramString)
  {
    int i = paramString.indexOf("__");
    if (i < 0) {
      return paramString;
    }
    return paramString.substring(0, i);
  }
  
  public Object get(Object paramObject)
  {
    if (paramObject == null) {
      return null;
    }
    return getProperty(paramObject.toString());
  }
  
  public void set(Object paramObject1, Object paramObject2)
  {
    if (paramObject1 == null) {
      return;
    }
    setProperty(paramObject1.toString(), paramObject2);
  }
  
  public Object getProperty(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    EntityDynamicField localEntityDynamicField = getField(getNormalName(paramString));
    if (localEntityDynamicField == null) {
      return null;
    }
    return localEntityDynamicField.getValue(getDsMeta());
  }
  
  public void setProperty(String paramString, Object paramObject)
  {
    if (paramString == null) {
      return;
    }
    paramString = getNormalName(paramString);
    DataSourceMeta localDataSourceMeta = getDsMeta();
    EntityDynamicField localEntityDynamicField = getField(paramString);
    if (localEntityDynamicField == null)
    {
      if ((localDataSourceMeta != null) && (!localDataSourceMeta.getFieldsMap().containsKey(paramString))) {
        throw Exceptions.code("entity.CAN_err_unknown_field").param(paramString);
      }
      localEntityDynamicField = new EntityDynamicField();
      localEntityDynamicField.setEntityId(this.pk.getEntityId());
      localEntityDynamicField.setEntityType(this.pk.getEntityType());
      localEntityDynamicField.setPartitionId(this.pk.getPartitionId());
      localEntityDynamicField.setFieldName(paramString);
      localEntityDynamicField.setValue(localDataSourceMeta, paramObject);
      this.fields.add(localEntityDynamicField);
    }
    else
    {
      localEntityDynamicField.setValue(localDataSourceMeta, paramObject);
    }
  }
  
  public void setEntityPk(EntityPk paramEntityPk)
  {
    Debug.check(paramEntityPk);
    this.pk = paramEntityPk;
    int j = this.fields.size();
    for (int i = 0; i < j; i++)
    {
      EntityDynamicField localEntityDynamicField = (EntityDynamicField)this.fields.get(i);
      localEntityDynamicField.setEntityPk(paramEntityPk);
    }
  }
  
  public void entityBeforeSave()
  {
    int j = this.fields.size();
    for (int i = 0; i < j; i++)
    {
      EntityDynamicField localEntityDynamicField = (EntityDynamicField)this.fields.get(i);
      localEntityDynamicField.entityBeforeSave();
    }
  }
  
  public void entityBeforeUpdate()
  {
    int j = this.fields.size();
    for (int i = 0; i < j; i++)
    {
      EntityDynamicField localEntityDynamicField = (EntityDynamicField)this.fields.get(i);
      localEntityDynamicField.entityBeforeUpdate();
    }
  }
  
  DataSourceMeta getDsMeta()
  {
    return this.pk.getEntityInfo().getDsMeta();
  }
  
  EntityDynamicField getField(String paramString)
  {
    if (this.fields == null) {
      return null;
    }
    int j = this.fields.size();
    for (int i = 0; i < j; i++)
    {
      EntityDynamicField localEntityDynamicField = (EntityDynamicField)this.fields.get(i);
      if (localEntityDynamicField.getFieldName().equals(paramString)) {
        return localEntityDynamicField;
      }
    }
    return null;
  }
  
  public Map getValuesWithPrefix(String paramString)
  {
    if (this.fields == null) {
      return null;
    }
    DataSourceMeta localDataSourceMeta = getDsMeta();
    int j = this.fields.size();
    TreeMap localTreeMap = new TreeMap();
    for (int i = 0; i < j; i++)
    {
      EntityDynamicField localEntityDynamicField = (EntityDynamicField)this.fields.get(i);
      if (localEntityDynamicField.getFieldName().startsWith(paramString)) {
        localTreeMap.put(localEntityDynamicField.getFieldName(), localEntityDynamicField.getValue(localDataSourceMeta));
      }
    }
    return localTreeMap;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\EntityFieldList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */