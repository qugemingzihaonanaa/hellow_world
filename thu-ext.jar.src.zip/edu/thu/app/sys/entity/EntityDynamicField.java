package edu.thu.app.sys.entity;

import edu.thu.app.sys.entity._entity._EntityDynamicField;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.util.Coercions;
import edu.thu.lang.exceptions.StdException;
import edu.thu.model.stg.ds.DataSourceMeta;
import edu.thu.model.stg.ds.spi.FieldMeta;
import edu.thu.orm.component.impl.FileComponent;
import edu.thu.orm.component.impl.FileListComponent;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Map;

public class EntityDynamicField
  extends _EntityDynamicField
{
  private static final long serialVersionUID = 1L;
  static final int STORE_TYPE_INT = 1;
  static final int STORE_TYPE_NUMBER = 2;
  static final int STORE_TYPE_DATE = 3;
  static final int STORE_TYPE_STRING = 4;
  FileComponent fc;
  FileListComponent flc;
  
  FieldMeta getFieldMeta(DataSourceMeta paramDataSourceMeta)
  {
    if (paramDataSourceMeta == null) {
      return null;
    }
    FieldMeta localFieldMeta = (FieldMeta)paramDataSourceMeta.getFieldsMap().get(getFieldName());
    if (localFieldMeta == null) {
      throw Exceptions.code("entity.CAN_err_unknown_field").param(getEntityType()).param(getFieldName());
    }
    return localFieldMeta;
  }
  
  public boolean isObjectField(DataSourceMeta paramDataSourceMeta)
  {
    FieldMeta localFieldMeta = getFieldMeta(paramDataSourceMeta);
    if (localFieldMeta == null) {
      return false;
    }
    String str = localFieldMeta.getType();
    return ("file".equals(str)) || ("fileList".equals(str));
  }
  
  Object _getStoreValue()
  {
    int i = getStoreType();
    switch (i)
    {
    case 1: 
      return getIntValue();
    case 2: 
      return getNumberValue();
    case 3: 
      return getDateValue();
    }
    return getStringValue();
  }
  
  public void setEntityPk(EntityPk paramEntityPk)
  {
    setEntityId(paramEntityPk.getEntityId());
    setEntityType(paramEntityPk.getEntityType());
    setPartitionId(paramEntityPk.getPartitionId());
  }
  
  FileComponent getFileComponent()
  {
    if (this.fc == null)
    {
      this.fc = new FileComponent()
      {
        public void setFileName(String paramAnonymousString)
        {
          EntityDynamicField.this.setValue(null, paramAnonymousString);
          super.setFileName(paramAnonymousString);
        }
      };
      this.fc.setFieldName(this.fieldName);
      this.fc.setEntityName(getEntityType());
      this.fc.setEntityId(getEntityId());
      this.fc.setFileName(getStringValue());
    }
    return this.fc;
  }
  
  FileListComponent getFileListComponent()
  {
    if (this.flc == null)
    {
      this.flc = new FileListComponent()
      {
        public void setFileCount(Integer paramAnonymousInteger)
        {
          EntityDynamicField.this.setValue(null, paramAnonymousInteger);
          super.setFileCount(paramAnonymousInteger);
        }
      };
      this.flc.setFieldName(this.fieldName);
      this.flc.setEntityName(getEntityType());
      this.flc.setEntityId(getEntityId());
      Long localLong = getIntValue();
      this.flc.setFileCount(localLong == null ? null : new Integer(localLong.intValue()));
    }
    return this.flc;
  }
  
  public Object getValue(DataSourceMeta paramDataSourceMeta)
  {
    FieldMeta localFieldMeta = getFieldMeta(paramDataSourceMeta);
    if (localFieldMeta == null) {
      return _getStoreValue();
    }
    String str = localFieldMeta.getType();
    if ("file".equals(str)) {
      return getFileComponent();
    }
    if ("fileList".equals(str)) {
      return getFileListComponent();
    }
    return _getStoreValue();
  }
  
  int guessStoreType(Object paramObject)
  {
    if (paramObject == null) {
      return 4;
    }
    if (((paramObject instanceof Integer)) || ((paramObject instanceof Long)) || ((paramObject instanceof BigInteger))) {
      return 1;
    }
    if ((paramObject instanceof Double)) {
      return 2;
    }
    if (((paramObject instanceof Date)) || ((paramObject instanceof Timestamp))) {
      return 3;
    }
    return 4;
  }
  
  void clear()
  {
    setIntValue(null);
    setDateValue(null);
    setNumberValue(null);
    setStringValue(null);
  }
  
  public void setValue(DataSourceMeta paramDataSourceMeta, Object paramObject)
  {
    FieldMeta localFieldMeta = getFieldMeta(paramDataSourceMeta);
    if (localFieldMeta == null)
    {
      _setValue(guessStoreType(paramObject), paramObject);
      return;
    }
    String str1 = localFieldMeta.getType();
    if ("file".equals(str1))
    {
      getFileComponent().updateValue(paramObject);
      setStoreType(4);
      setStringValue(getFileComponent().getFileName());
    }
    else if ("fileList".equals(str1))
    {
      getFileListComponent().updateValue(paramObject);
      setStoreType(1);
      setIntValue(Coercions.toJavaLong(getFileListComponent().getFileCount(), 0L));
    }
    else
    {
      int i = 4;
      String str2 = localFieldMeta.getStoreType();
      if (str2 == null) {
        str2 = "string";
      }
      str2 = str2.toLowerCase();
      if (("int".equals(str2)) || ("integer".equals(str2)) || ("long".equals(str2))) {
        i = 1;
      } else if (("double".equals(str2)) || ("number".equals(str2))) {
        i = 2;
      } else if (("date".equals(str2)) || ("datetime".equals(str2))) {
        i = 3;
      }
      _setValue(i, paramObject);
    }
  }
  
  void _setValue(int paramInt, Object paramObject)
  {
    setStoreType(paramInt);
    clear();
    if (paramObject != null) {
      switch (paramInt)
      {
      case 1: 
        setIntValue(Coercions.toJavaLong(paramObject, 0L));
        setNumberValue(Coercions.toJavaDouble(paramObject, 0.0D));
        long l1 = Coercions.toLong(paramObject, 0L);
        setDateValue(new Timestamp(l1));
        break;
      case 2: 
        setNumberValue(Coercions.toJavaDouble(paramObject, 0.0D));
        setIntValue(Coercions.toJavaLong(paramObject, 0L));
        long l2 = Coercions.toLong(paramObject, 0L);
        setDateValue(new Timestamp(l2));
        break;
      case 3: 
        setDateValue(Coercions.toTimestamp(paramObject));
        setNumberValue(Coercions.toJavaDouble(paramObject, 0.0D));
        setIntValue(Coercions.toJavaLong(paramObject, 0L));
        break;
      default: 
        setStringValue(paramObject.toString());
      }
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\EntityDynamicField.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */