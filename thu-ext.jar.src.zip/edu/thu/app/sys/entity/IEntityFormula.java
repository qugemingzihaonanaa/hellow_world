package edu.thu.app.sys.entity;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public abstract interface IEntityFormula
{
  public static final String ACTION_ADD = "add";
  public static final String ACTION_REMOVE = "remove";
  public static final String ACTION_UPDATE = "update";
  public static final String ACTION_SYNC = "sync";
  public static final String VAR_EF_ACTION = "efAction";
  public static final String VAR_ENTITY_FORMULAS = "entityFormulas";
  public static final String VAR_NEXT_ACTIONS = "nextActions";
  
  public abstract String getSrcEntityType();
  
  public abstract String getFormulaKey(Object paramObject);
  
  public abstract List<String> getActions();
  
  public abstract List<FormulaAction> execute(Object paramObject, String paramString, Map<String, Object> paramMap);
  
  public static class FormulaAction
    implements Serializable
  {
    private static final long serialVersionUID = -1714353298980732565L;
    Object A;
    String B;
    Map<String, Object> C;
    
    public FormulaAction(Object paramObject, String paramString, Map<String, Object> paramMap)
    {
      this.A = paramObject;
      this.B = paramString;
      this.C = paramMap;
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\IEntityFormula.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */