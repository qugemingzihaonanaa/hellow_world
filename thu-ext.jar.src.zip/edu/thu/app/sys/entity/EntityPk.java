package edu.thu.app.sys.entity;

import edu.thu.model.entity.EntityInfo;
import edu.thu.service.EntityManager;
import edu.thu.service.IEntityManager;
import java.io.Serializable;

public class EntityPk
  implements Serializable
{
  private static final long serialVersionUID = 204495948992213802L;
  String B;
  String A;
  String C;
  
  public String toString()
  {
    return this.B + "#" + this.A;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject.getClass() != getClass()) {
      return false;
    }
    EntityPk localEntityPk = (EntityPk)paramObject;
    if (this.B == null)
    {
      if (localEntityPk.B != null) {
        return false;
      }
    }
    else if (!this.B.equals(localEntityPk.B)) {
      return false;
    }
    if (this.A == null)
    {
      if (localEntityPk.A != null) {
        return false;
      }
    }
    else if (!this.B.equals(localEntityPk.A)) {
      return false;
    }
    return true;
  }
  
  public int hashCode()
  {
    return (this.B == null ? 0 : this.B.hashCode()) ^ (this.A == null ? 0 : this.A.hashCode());
  }
  
  public String getEntityId()
  {
    return this.A;
  }
  
  public void setEntityId(String paramString)
  {
    this.A = paramString;
  }
  
  public String getEntityType()
  {
    return this.B;
  }
  
  public void setEntityType(String paramString)
  {
    this.B = paramString;
  }
  
  public String getPartitionId()
  {
    return this.C;
  }
  
  public void setPartitionId(String paramString)
  {
    this.C = paramString;
  }
  
  public Object getEntity()
  {
    return EntityManager.getInstance().get(getEntityType(), getEntityId());
  }
  
  public EntityInfo getEntityInfo()
  {
    return EntityManager.getInstance().getEntityInfo(getEntityType());
  }
  
  public static EntityPk makeFromEntity(Object paramObject)
  {
    if (paramObject == null) {
      return null;
    }
    IEntityManager localIEntityManager = EntityManager.getInstance();
    Object localObject = localIEntityManager.getEntityId(paramObject);
    String str = localIEntityManager.getFullEntityName(localIEntityManager.getEntityName(paramObject));
    EntityPk localEntityPk = new EntityPk();
    localEntityPk.setEntityId(localObject.toString());
    localEntityPk.setEntityType(str);
    return localEntityPk;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\EntityPk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */