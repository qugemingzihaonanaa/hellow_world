package edu.thu.app.sys.entity;

import edu.thu.db.SQL;
import edu.thu.db.SqlBuilder;
import edu.thu.orm.dao.IOrmTemplate;
import edu.thu.service.BeanLoader;
import java.util.ArrayList;
import java.util.List;

public class EntityRelationHandler
  extends AbstractEntityHandler
{
  private static final long serialVersionUID = -8711501760391469417L;
  
  public static EntityRelationHandler getInstance()
  {
    return (EntityRelationHandler)BeanLoader.getBean(EntityRelationHandler.class);
  }
  
  SQL _sqlRelationListBySrc(EntityPk paramEntityPk, String paramString)
  {
    SQL localSQL = SQL.begin().from().table(EntityRelation.class.getName(), "o").where().sql(" o.srcEntityType = ? and o.srcEntityId = ? ", paramEntityPk.getEntityType(), paramEntityPk.getEntityId()).sql(" and o.relReason=? ", paramString).sql(" order by o.seq asc ").end();
    return localSQL;
  }
  
  SQL _getRelationListByDst(EntityPk paramEntityPk, String paramString)
  {
    SQL localSQL = SQL.begin().from().table(EntityRelation.class.getName(), "o").where().sql(" o.dstEntityType = ? and o.dstEntityId = ? ", paramEntityPk.getEntityType(), paramEntityPk.getEntityId()).sql(" and o.relReason = ? ", paramString).sql(" order by o.seq asc ").end();
    return localSQL;
  }
  
  SQL _getRelationList(EntityPk paramEntityPk, String paramString)
  {
    SQL localSQL = SQL.begin().from().table(EntityRelation.class.getName(), "o").where().sql(" o.srcEntityType = ? and o.srcEntityId= ? or o.dstEntityType = ? and o.dstEntityId  = ? ", paramEntityPk.getEntityType(), paramEntityPk.getEntityId(), paramEntityPk.getEntityType(), paramEntityPk.getEntityId()).sql(" and o.relReason = ? ", paramString).end();
    return localSQL;
  }
  
  EntityRelation _getRelationBySrc(EntityPk paramEntityPk, String paramString)
  {
    return (EntityRelation)orm().findFirst(_sqlRelationListBySrc(paramEntityPk, paramString));
  }
  
  EntityRelation _getRelationByDst(EntityPk paramEntityPk, String paramString)
  {
    return (EntityRelation)orm().findFirst(_getRelationListByDst(paramEntityPk, paramString));
  }
  
  EntityRelation _getRelation(EntityPk paramEntityPk, String paramString)
  {
    return (EntityRelation)orm().findFirst(_getRelationList(paramEntityPk, paramString));
  }
  
  public List getRelatedPkListBySrc(EntityPk paramEntityPk, String paramString)
  {
    List localList = orm().findAll(_sqlRelationListBySrc(paramEntityPk, paramString));
    if ((localList == null) || (localList.isEmpty())) {
      return null;
    }
    ArrayList localArrayList = new ArrayList();
    int j = localList.size();
    for (int i = 0; i < j; i++)
    {
      EntityRelation localEntityRelation = (EntityRelation)localList.get(i);
      EntityPk localEntityPk = localEntityRelation.getDstPk();
      if (!localArrayList.contains(localEntityPk)) {
        localArrayList.add(localEntityPk);
      }
    }
    return localArrayList;
  }
  
  public List getRelatedPkListByDst(EntityPk paramEntityPk, String paramString)
  {
    List localList = orm().findAll(_getRelationListByDst(paramEntityPk, paramString));
    if ((localList == null) || (localList.isEmpty())) {
      return null;
    }
    ArrayList localArrayList = new ArrayList();
    int j = localList.size();
    for (int i = 0; i < j; i++)
    {
      EntityRelation localEntityRelation = (EntityRelation)localList.get(i);
      EntityPk localEntityPk = localEntityRelation.getDstPk();
      if (!localArrayList.contains(localEntityPk)) {
        localArrayList.add(localEntityPk);
      }
    }
    return localArrayList;
  }
  
  public List getRelatedPkList(EntityPk paramEntityPk, String paramString)
  {
    List localList = orm().findAll(_getRelationList(paramEntityPk, paramString));
    if ((localList == null) || (localList.isEmpty())) {
      return null;
    }
    ArrayList localArrayList = new ArrayList();
    int j = localList.size();
    for (int i = 0; i < j; i++)
    {
      EntityRelation localEntityRelation = (EntityRelation)localList.get(i);
      EntityPk localEntityPk = localEntityRelation.getDstPk();
      if (!localArrayList.contains(localEntityPk)) {
        localArrayList.add(localEntityPk);
      }
    }
    return null;
  }
  
  public EntityPk getRelatedPkBySrc(EntityPk paramEntityPk, String paramString)
  {
    EntityRelation localEntityRelation = _getRelationBySrc(paramEntityPk, paramString);
    if (localEntityRelation == null) {
      return null;
    }
    return localEntityRelation.getDstPk();
  }
  
  public EntityPk getRelatedPkByDst(EntityPk paramEntityPk, String paramString)
  {
    EntityRelation localEntityRelation = _getRelationByDst(paramEntityPk, paramString);
    if (localEntityRelation == null) {
      return null;
    }
    return localEntityRelation.getDstPk();
  }
  
  public EntityPk getRelatedPk(EntityPk paramEntityPk, String paramString)
  {
    EntityRelation localEntityRelation = _getRelation(paramEntityPk, paramString);
    if (localEntityRelation == null) {
      return null;
    }
    EntityPk localEntityPk = localEntityRelation.getSrcPk();
    if (localEntityPk.equals(paramEntityPk)) {
      return localEntityRelation.getDstPk();
    }
    return localEntityPk;
  }
  
  EntityRelation _load(EntityRelation paramEntityRelation)
  {
    SQL localSQL = SQL.begin().from().table(EntityRelation.class.getName(), "o").sql(" where o.srcEntityType = ? and o.srcEntityId = ? ", paramEntityRelation.getSrcEntityType(), paramEntityRelation.getSrcEntityId()).sql(" and o.dstEntityType = ? and o.dstEntityId = ? ", paramEntityRelation.getDstEntityType(), paramEntityRelation.getDstEntityId()).sql(" and o.relReason=? ", paramEntityRelation.getRelReason()).end();
    return (EntityRelation)orm().findFirst(localSQL);
  }
  
  public void setRelation(EntityRelation paramEntityRelation)
  {
    EntityRelation localEntityRelation = _load(paramEntityRelation);
    if (localEntityRelation == null)
    {
      orm().save(localEntityRelation);
    }
    else
    {
      if (paramEntityRelation.getPartitionId() != null) {
        localEntityRelation.setPartitionId(paramEntityRelation.getPartitionId());
      }
      localEntityRelation.setSeq(paramEntityRelation.getSeq());
      orm().update(localEntityRelation);
    }
  }
  
  public void removeRelationBySrc(EntityPk paramEntityPk)
  {
    if (paramEntityPk == null) {
      return;
    }
    SQL localSQL = SQL.begin().sql("delete EntityRelation o where o.srcEntityId = ? and o.srcEntityType = ? ", paramEntityPk.getEntityId(), paramEntityPk.getEntityType()).end();
    orm().executeUpdate(localSQL);
  }
  
  public void removeRelationByDst(EntityPk paramEntityPk)
  {
    if (paramEntityPk == null) {
      return;
    }
    SQL localSQL = SQL.begin().sql("delete EntityRelation o where o.dstEntityId = ? and o.dstEntityType = ? ", paramEntityPk.getEntityId(), paramEntityPk.getEntityType()).end();
    orm().executeUpdate(localSQL);
  }
  
  public void removeRelation(EntityPk paramEntityPk)
  {
    if (paramEntityPk == null) {
      return;
    }
    SQL localSQL = SQL.begin().sql("delete EntityRelation o where o.srcEntityId = ? and o.srcEntityType = ? or o.dstEntityId = ? and o.dstEntityType = ? ", paramEntityPk.getEntityId(), paramEntityPk.getEntityType(), paramEntityPk.getEntityId(), paramEntityPk.getEntityType()).end();
    orm().executeUpdate(localSQL);
  }
  
  public void setRelationListForSrc(EntityPk paramEntityPk, List paramList, String paramString)
  {
    removeRelationBySrc(paramEntityPk);
    flushSession();
    if (paramList == null) {
      return;
    }
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      EntityPk localEntityPk = (EntityPk)paramList.get(i);
      EntityRelation localEntityRelation = new EntityRelation();
      localEntityRelation.setPartitionId(paramEntityPk.getPartitionId());
      localEntityRelation.setSrcEntityType(paramEntityPk.getEntityType());
      localEntityRelation.setSrcEntityId(paramEntityPk.getEntityId());
      localEntityRelation.setDstEntityType(localEntityPk.getEntityType());
      localEntityRelation.setDstEntityId(localEntityPk.getEntityId());
      localEntityRelation.setRelReason(paramString);
      localEntityRelation.setSeq(new Integer(i));
      orm().save(localEntityRelation);
    }
  }
  
  public void setRelationListForDst(List paramList, EntityPk paramEntityPk, String paramString)
  {
    removeRelationBySrc(paramEntityPk);
    flushSession();
    if (paramList == null) {
      return;
    }
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      EntityPk localEntityPk = (EntityPk)paramList.get(i);
      EntityRelation localEntityRelation = new EntityRelation();
      localEntityRelation.setPartitionId(paramEntityPk.getPartitionId());
      localEntityRelation.setDstEntityId(paramEntityPk.getEntityId());
      localEntityRelation.setDstEntityType(paramEntityPk.getEntityType());
      localEntityRelation.setSrcEntityId(localEntityPk.getEntityId());
      localEntityRelation.setSrcEntityType(localEntityPk.getEntityType());
      localEntityRelation.setRelReason(paramString);
      localEntityRelation.setSeq(new Integer(i));
      orm().save(localEntityRelation);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\EntityRelationHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */