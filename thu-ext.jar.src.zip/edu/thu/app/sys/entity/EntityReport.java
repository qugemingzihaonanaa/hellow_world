package edu.thu.app.sys.entity;

import edu.thu.app.sys.entity._entity._EntityReport;

public class EntityReport
  extends _EntityReport
{
  private static final long serialVersionUID = 1L;
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\EntityReport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */