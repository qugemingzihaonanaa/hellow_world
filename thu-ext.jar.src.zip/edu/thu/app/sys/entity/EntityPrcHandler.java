package edu.thu.app.sys.entity;

import edu.thu.orm.dao.IEntityDao;
import edu.thu.service.BeanLoader;

public class EntityPrcHandler
  extends AbstractEntityHandler
{
  private static final long serialVersionUID = -3777750364448849604L;
  
  public static EntityPrcHandler getInstance()
  {
    return (EntityPrcHandler)BeanLoader.getBean(EntityPrcHandler.class);
  }
  
  public EntityPrcRecord getPrcRecord(EntityPk paramEntityPk)
  {
    return (EntityPrcRecord)dao(EntityPrcRecord.class.getName()).findFirst(getEntityCond(paramEntityPk));
  }
  
  public EntityPrcRecord makePrcRecord(EntityPk paramEntityPk)
  {
    EntityPrcRecord localEntityPrcRecord = getPrcRecord(paramEntityPk);
    if (localEntityPrcRecord == null)
    {
      localEntityPrcRecord = new EntityPrcRecord();
      dao(EntityPrcRecord.class.getName()).saveEntity(localEntityPrcRecord);
    }
    return localEntityPrcRecord;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\EntityPrcHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */