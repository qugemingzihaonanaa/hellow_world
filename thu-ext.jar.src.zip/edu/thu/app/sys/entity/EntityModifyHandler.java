package edu.thu.app.sys.entity;

import edu.thu.core.AppEnv;
import edu.thu.db.SQL;
import edu.thu.db.SqlBuilder;
import edu.thu.ext.hibernate.AbstractEntity;
import edu.thu.ext.hibernate.AbstractHibernateDao;
import edu.thu.orm.dao.IOrmTemplate;
import edu.thu.service.BeanLoader;
import java.sql.Timestamp;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class EntityModifyHandler
  extends AbstractHibernateDao
{
  private static final long serialVersionUID = 6686072602339938266L;
  
  public static EntityModifyHandler getInstance()
  {
    return (EntityModifyHandler)BeanLoader.getBean(EntityModifyHandler.class);
  }
  
  public void logModification(Object paramObject, Map paramMap, String paramString1, String paramString2, String paramString3)
  {
    AbstractEntity localAbstractEntity = (AbstractEntity)paramObject;
    if ((paramMap == null) || (paramMap.isEmpty())) {
      return;
    }
    Timestamp localTimestamp = new Timestamp(AppEnv.currentTimeMillis());
    EntityPk localEntityPk = localAbstractEntity.getEntityPk();
    EntityModifyReason localEntityModifyReason = null;
    if ((paramString2 != null) || (paramString3 != null))
    {
      localEntityModifyReason = new EntityModifyReason();
      localEntityModifyReason.setEntityId(localEntityPk.getEntityId());
      localEntityModifyReason.setEntityType(localEntityPk.getEntityType());
      localEntityModifyReason.setDescription(paramString3);
      localEntityModifyReason.setModifyReason(paramString2);
      localEntityModifyReason.setModifierId(paramString1);
      localEntityModifyReason.setModifyTime(localTimestamp);
      orm().save(localEntityModifyReason);
    }
    Iterator localIterator = paramMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      String str = (String)localEntry.getKey();
      Object localObject1 = localAbstractEntity.get(str);
      Object localObject2 = localEntry.getValue();
      if (!isEq(localObject1, localObject2)) {
        logModification(localEntityPk, str, localObject2, localObject1, localEntityModifyReason);
      }
    }
  }
  
  void logModification(EntityPk paramEntityPk, String paramString, Object paramObject1, Object paramObject2, EntityModifyReason paramEntityModifyReason)
  {
    EntityModifyLog localEntityModifyLog = new EntityModifyLog();
    localEntityModifyLog.setEntityType(paramEntityPk.getEntityType());
    localEntityModifyLog.setEntityId(paramEntityPk.getEntityId());
    localEntityModifyLog.setModifierId(paramEntityModifyReason.getModifierId());
    localEntityModifyLog.setModifyTime(paramEntityModifyReason.getModifyTime());
    localEntityModifyLog.setModifyField(paramString);
    if (paramObject1 != null) {
      localEntityModifyLog.setOldValue(paramObject1.toString());
    }
    if (paramObject2 != null) {
      localEntityModifyLog.setModifyValue(paramObject2.toString());
    }
    orm().save(localEntityModifyLog);
  }
  
  boolean isEq(Object paramObject1, Object paramObject2)
  {
    if (paramObject1 == null) {
      return paramObject2 == null;
    }
    return paramObject1.equals(paramObject2);
  }
  
  public List getModifications(Object paramObject)
  {
    AbstractEntity localAbstractEntity = (AbstractEntity)paramObject;
    if (localAbstractEntity == null) {
      return null;
    }
    EntityPk localEntityPk = localAbstractEntity.getEntityPk();
    SqlBuilder localSqlBuilder = SQL.begin();
    localSqlBuilder.sql(" from EntityModifyLog o where o.entityId = ?  and o.entityType = ?", localEntityPk.getEntityId(), localEntityPk.getEntityType());
    localSqlBuilder.sql(" order by o.modifyTime desc ");
    return orm().findAll(localSqlBuilder.end());
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\EntityModifyHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */