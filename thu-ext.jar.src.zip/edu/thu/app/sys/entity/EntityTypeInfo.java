package edu.thu.app.sys.entity;

import edu.thu.app.sys.entity._entity._EntityTypeInfo;
import edu.thu.ext.hibernate.FileItem;
import edu.thu.orm.component.impl.FileComponent;

public class EntityTypeInfo
  extends _EntityTypeInfo
{
  private static final long serialVersionUID = 1L;
  
  public FileItem getExportFileItem()
  {
    if (getExportTpl() == null) {
      return null;
    }
    return getExportTpl().getFileItem();
  }
  
  public FileItem getImportFileItem()
  {
    if (getImportTpl() == null) {
      return null;
    }
    return getImportTpl().getFileItem();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\EntityTypeInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */