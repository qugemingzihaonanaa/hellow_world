package edu.thu.app.sys.entity._entity;

import edu.thu.app.sys.UserResolver;
import edu.thu.app.sys.user.UserInfo;
import edu.thu.ext.hibernate.AbstractEntity;
import edu.thu.orm.component.impl.FileComponent;
import java.sql.Timestamp;

public abstract class _EntityTypeInfo
  extends AbstractEntity
{
  private static final long serialVersionUID = 1L;
  protected String entityType;
  protected String description;
  protected String createrId;
  protected Timestamp createTime;
  protected String updaterId;
  protected Timestamp updateTime;
  protected FileComponent exportTpl;
  protected FileComponent importTpl;
  
  public String getEntityType()
  {
    return this.entityType;
  }
  
  public void setEntityType(String paramString)
  {
    this.entityType = paramString;
  }
  
  public String getDescription()
  {
    return this.description;
  }
  
  public void setDescription(String paramString)
  {
    this.description = paramString;
  }
  
  public String getCreaterId()
  {
    return this.createrId;
  }
  
  public void setCreaterId(String paramString)
  {
    this.createrId = paramString;
  }
  
  public Timestamp getCreateTime()
  {
    return this.createTime;
  }
  
  public void setCreateTime(Timestamp paramTimestamp)
  {
    this.createTime = paramTimestamp;
  }
  
  public String getUpdaterId()
  {
    return this.updaterId;
  }
  
  public void setUpdaterId(String paramString)
  {
    this.updaterId = paramString;
  }
  
  public Timestamp getUpdateTime()
  {
    return this.updateTime;
  }
  
  public void setUpdateTime(Timestamp paramTimestamp)
  {
    this.updateTime = paramTimestamp;
  }
  
  public Object toDbType()
  {
    return _toObject(this.entityType);
  }
  
  public UserInfo getCreater()
  {
    return UserResolver.resolve(getCreaterId());
  }
  
  public void setCreater(UserInfo paramUserInfo)
  {
    if (paramUserInfo == null) {
      return;
    }
    setCreaterId(paramUserInfo.getId());
  }
  
  public UserInfo getUpdater()
  {
    return UserResolver.resolve(getUpdaterId());
  }
  
  public void setUpdater(UserInfo paramUserInfo)
  {
    if (paramUserInfo == null) {
      return;
    }
    setUpdaterId(paramUserInfo.getId());
  }
  
  public FileComponent makeExportTpl()
  {
    if (this.exportTpl == null)
    {
      setExportTpl(new FileComponent());
      this.exportTpl.setParentEntity(this);
    }
    return this.exportTpl;
  }
  
  public FileComponent getExportTpl()
  {
    return this.exportTpl;
  }
  
  public void setExportTpl(FileComponent paramFileComponent)
  {
    this.exportTpl = paramFileComponent;
    if (paramFileComponent != null) {
      paramFileComponent.setFieldName("exportTpl");
    }
  }
  
  public FileComponent makeImportTpl()
  {
    if (this.importTpl == null)
    {
      setImportTpl(new FileComponent());
      this.importTpl.setParentEntity(this);
    }
    return this.importTpl;
  }
  
  public FileComponent getImportTpl()
  {
    return this.importTpl;
  }
  
  public void setImportTpl(FileComponent paramFileComponent)
  {
    this.importTpl = paramFileComponent;
    if (paramFileComponent != null) {
      paramFileComponent.setFieldName("importTpl");
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\_entity\_EntityTypeInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */