package edu.thu.app.sys.entity._entity;

import edu.thu.ext.hibernate.AbstractEntity;
import java.sql.Timestamp;

public abstract class _EntityDynamicField
  extends AbstractEntity
{
  private static final long serialVersionUID = 1L;
  protected String sid;
  protected String partitionId;
  protected String entityType;
  protected String entityId;
  protected String fieldName;
  protected int storeType;
  protected Long intValue;
  protected Double numberValue;
  protected Timestamp dateValue;
  protected String stringValue;
  
  public String getSid()
  {
    return this.sid;
  }
  
  public void setSid(String paramString)
  {
    this.sid = paramString;
  }
  
  public String getPartitionId()
  {
    return this.partitionId;
  }
  
  public void setPartitionId(String paramString)
  {
    this.partitionId = paramString;
  }
  
  public String getEntityType()
  {
    return this.entityType;
  }
  
  public void setEntityType(String paramString)
  {
    this.entityType = paramString;
  }
  
  public String getEntityId()
  {
    return this.entityId;
  }
  
  public void setEntityId(String paramString)
  {
    this.entityId = paramString;
  }
  
  public String getFieldName()
  {
    return this.fieldName;
  }
  
  public void setFieldName(String paramString)
  {
    this.fieldName = paramString;
  }
  
  public int getStoreType()
  {
    return this.storeType;
  }
  
  public void setStoreType(int paramInt)
  {
    this.storeType = paramInt;
  }
  
  public Long getIntValue()
  {
    return this.intValue;
  }
  
  public void setIntValue(Long paramLong)
  {
    this.intValue = paramLong;
  }
  
  public Double getNumberValue()
  {
    return this.numberValue;
  }
  
  public void setNumberValue(Double paramDouble)
  {
    this.numberValue = paramDouble;
  }
  
  public Timestamp getDateValue()
  {
    return this.dateValue;
  }
  
  public void setDateValue(Timestamp paramTimestamp)
  {
    this.dateValue = paramTimestamp;
  }
  
  public String getStringValue()
  {
    return this.stringValue;
  }
  
  public void setStringValue(String paramString)
  {
    this.stringValue = paramString;
  }
  
  public Object toDbType()
  {
    return _toObject(this.sid);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\_entity\_EntityDynamicField.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */