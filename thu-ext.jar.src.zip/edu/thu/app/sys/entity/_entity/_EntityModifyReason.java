package edu.thu.app.sys.entity._entity;

import edu.thu.app.sys.UserResolver;
import edu.thu.app.sys.user.UserInfo;
import edu.thu.ext.hibernate.AbstractEntity;
import java.sql.Timestamp;

public abstract class _EntityModifyReason
  extends AbstractEntity
{
  private static final long serialVersionUID = 1L;
  protected String sid;
  protected String partitionId;
  protected String entityType;
  protected String entityId;
  protected String modifierId;
  protected Timestamp modifyTime;
  protected String modifyReason;
  protected String description;
  
  public String getSid()
  {
    return this.sid;
  }
  
  public void setSid(String paramString)
  {
    this.sid = paramString;
  }
  
  public String getPartitionId()
  {
    return this.partitionId;
  }
  
  public void setPartitionId(String paramString)
  {
    this.partitionId = paramString;
  }
  
  public String getEntityType()
  {
    return this.entityType;
  }
  
  public void setEntityType(String paramString)
  {
    this.entityType = paramString;
  }
  
  public String getEntityId()
  {
    return this.entityId;
  }
  
  public void setEntityId(String paramString)
  {
    this.entityId = paramString;
  }
  
  public String getModifierId()
  {
    return this.modifierId;
  }
  
  public void setModifierId(String paramString)
  {
    this.modifierId = paramString;
  }
  
  public Timestamp getModifyTime()
  {
    return this.modifyTime;
  }
  
  public void setModifyTime(Timestamp paramTimestamp)
  {
    this.modifyTime = paramTimestamp;
  }
  
  public String getModifyReason()
  {
    return this.modifyReason;
  }
  
  public void setModifyReason(String paramString)
  {
    this.modifyReason = paramString;
  }
  
  public String getDescription()
  {
    return this.description;
  }
  
  public void setDescription(String paramString)
  {
    this.description = paramString;
  }
  
  public Object toDbType()
  {
    return _toObject(this.sid);
  }
  
  public UserInfo getModifier()
  {
    return UserResolver.resolve(getModifierId());
  }
  
  public void setModifier(UserInfo paramUserInfo)
  {
    if (paramUserInfo == null) {
      return;
    }
    setModifierId(paramUserInfo.getId());
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\_entity\_EntityModifyReason.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */