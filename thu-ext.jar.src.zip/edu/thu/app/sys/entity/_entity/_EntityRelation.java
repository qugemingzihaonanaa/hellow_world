package edu.thu.app.sys.entity._entity;

import edu.thu.ext.hibernate.AbstractEntity;

public abstract class _EntityRelation
  extends AbstractEntity
{
  private static final long serialVersionUID = 1L;
  protected String sid;
  protected String partitionId;
  protected String srcEntityType;
  protected String srcEntityId;
  protected String dstEntityType;
  protected String dstEntityId;
  protected String relReason;
  protected Integer seq;
  
  public String getSid()
  {
    return this.sid;
  }
  
  public void setSid(String paramString)
  {
    this.sid = paramString;
  }
  
  public String getPartitionId()
  {
    return this.partitionId;
  }
  
  public void setPartitionId(String paramString)
  {
    this.partitionId = paramString;
  }
  
  public String getSrcEntityType()
  {
    return this.srcEntityType;
  }
  
  public void setSrcEntityType(String paramString)
  {
    this.srcEntityType = paramString;
  }
  
  public String getSrcEntityId()
  {
    return this.srcEntityId;
  }
  
  public void setSrcEntityId(String paramString)
  {
    this.srcEntityId = paramString;
  }
  
  public String getDstEntityType()
  {
    return this.dstEntityType;
  }
  
  public void setDstEntityType(String paramString)
  {
    this.dstEntityType = paramString;
  }
  
  public String getDstEntityId()
  {
    return this.dstEntityId;
  }
  
  public void setDstEntityId(String paramString)
  {
    this.dstEntityId = paramString;
  }
  
  public String getRelReason()
  {
    return this.relReason;
  }
  
  public void setRelReason(String paramString)
  {
    this.relReason = paramString;
  }
  
  public Integer getSeq()
  {
    return this.seq;
  }
  
  public void setSeq(Integer paramInteger)
  {
    this.seq = paramInteger;
  }
  
  public Object toDbType()
  {
    return _toObject(this.sid);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\_entity\_EntityRelation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */