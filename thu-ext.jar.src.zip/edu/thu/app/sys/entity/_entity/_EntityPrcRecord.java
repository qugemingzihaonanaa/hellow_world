package edu.thu.app.sys.entity._entity;

import edu.thu.ext.hibernate.AbstractEntity;
import java.sql.Timestamp;

public abstract class _EntityPrcRecord
  extends AbstractEntity
{
  private static final long serialVersionUID = 1L;
  protected String sid;
  protected String entityType;
  protected String entityId;
  protected Long totalCount;
  protected Long finishCount;
  protected Long errorCount;
  protected Timestamp startTime;
  protected Timestamp finishTime;
  protected int statusId;
  protected Timestamp updateTime;
  protected String prcResult;
  protected int tryNum;
  protected int maxTryNum;
  protected long tryDelay;
  protected Timestamp lastTryTime;
  
  public String getSid()
  {
    return this.sid;
  }
  
  public void setSid(String paramString)
  {
    this.sid = paramString;
  }
  
  public String getEntityType()
  {
    return this.entityType;
  }
  
  public void setEntityType(String paramString)
  {
    this.entityType = paramString;
  }
  
  public String getEntityId()
  {
    return this.entityId;
  }
  
  public void setEntityId(String paramString)
  {
    this.entityId = paramString;
  }
  
  public Long getTotalCount()
  {
    return this.totalCount;
  }
  
  public void setTotalCount(Long paramLong)
  {
    this.totalCount = paramLong;
  }
  
  public Long getFinishCount()
  {
    return this.finishCount;
  }
  
  public void setFinishCount(Long paramLong)
  {
    this.finishCount = paramLong;
  }
  
  public Long getErrorCount()
  {
    return this.errorCount;
  }
  
  public void setErrorCount(Long paramLong)
  {
    this.errorCount = paramLong;
  }
  
  public Timestamp getStartTime()
  {
    return this.startTime;
  }
  
  public void setStartTime(Timestamp paramTimestamp)
  {
    this.startTime = paramTimestamp;
  }
  
  public Timestamp getFinishTime()
  {
    return this.finishTime;
  }
  
  public void setFinishTime(Timestamp paramTimestamp)
  {
    this.finishTime = paramTimestamp;
  }
  
  public int getStatusId()
  {
    return this.statusId;
  }
  
  public void setStatusId(int paramInt)
  {
    this.statusId = paramInt;
  }
  
  public Timestamp getUpdateTime()
  {
    return this.updateTime;
  }
  
  public void setUpdateTime(Timestamp paramTimestamp)
  {
    this.updateTime = paramTimestamp;
  }
  
  public String getPrcResult()
  {
    return this.prcResult;
  }
  
  public void setPrcResult(String paramString)
  {
    this.prcResult = paramString;
  }
  
  public int getTryNum()
  {
    return this.tryNum;
  }
  
  public void setTryNum(int paramInt)
  {
    this.tryNum = paramInt;
  }
  
  public int getMaxTryNum()
  {
    return this.maxTryNum;
  }
  
  public void setMaxTryNum(int paramInt)
  {
    this.maxTryNum = paramInt;
  }
  
  public long getTryDelay()
  {
    return this.tryDelay;
  }
  
  public void setTryDelay(long paramLong)
  {
    this.tryDelay = paramLong;
  }
  
  public Timestamp getLastTryTime()
  {
    return this.lastTryTime;
  }
  
  public void setLastTryTime(Timestamp paramTimestamp)
  {
    this.lastTryTime = paramTimestamp;
  }
  
  public Object toDbType()
  {
    return _toObject(this.sid);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\_entity\_EntityPrcRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */