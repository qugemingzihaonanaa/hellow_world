package edu.thu.app.sys.entity._entity;

import edu.thu.ext.hibernate.AbstractEntity;

public abstract class _EntityReport
  extends AbstractEntity
{
  private static final long serialVersionUID = 1L;
  protected int id;
  protected String entityType;
  protected String reportType;
  protected String reportNo;
  protected String title;
  protected String description;
  protected String url;
  protected String reportDefinition;
  protected String isDefault;
  
  public int getId()
  {
    return this.id;
  }
  
  public void setId(int paramInt)
  {
    this.id = paramInt;
  }
  
  public String getEntityType()
  {
    return this.entityType;
  }
  
  public void setEntityType(String paramString)
  {
    this.entityType = paramString;
  }
  
  public String getReportType()
  {
    return this.reportType;
  }
  
  public void setReportType(String paramString)
  {
    this.reportType = paramString;
  }
  
  public String getReportNo()
  {
    return this.reportNo;
  }
  
  public void setReportNo(String paramString)
  {
    this.reportNo = paramString;
  }
  
  public String getTitle()
  {
    return this.title;
  }
  
  public void setTitle(String paramString)
  {
    this.title = paramString;
  }
  
  public String getDescription()
  {
    return this.description;
  }
  
  public void setDescription(String paramString)
  {
    this.description = paramString;
  }
  
  public String getUrl()
  {
    return this.url;
  }
  
  public void setUrl(String paramString)
  {
    this.url = paramString;
  }
  
  public String getReportDefinition()
  {
    return this.reportDefinition;
  }
  
  public void setReportDefinition(String paramString)
  {
    this.reportDefinition = paramString;
  }
  
  public String getIsDefault()
  {
    return this.isDefault;
  }
  
  public void setIsDefault(String paramString)
  {
    this.isDefault = paramString;
  }
  
  public Object toDbType()
  {
    return _toObject(this.id);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\_entity\_EntityReport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */