package edu.thu.app.sys.entity._entity;

import edu.thu.app.sys.UserResolver;
import edu.thu.app.sys.entity.EntityModifyReason;
import edu.thu.app.sys.user.UserInfo;
import edu.thu.ext.hibernate.AbstractEntity;
import java.sql.Timestamp;

public abstract class _EntityModifyLog
  extends AbstractEntity
{
  private static final long serialVersionUID = 1L;
  protected String sid;
  protected String partitionId;
  protected String entityType;
  protected String entityId;
  protected String modifierId;
  protected Timestamp modifyTime;
  protected String modifyField;
  protected String oldValue;
  protected String modifyValue;
  protected EntityModifyReason entityModifyReason;
  
  public EntityModifyReason getEntityModifyReason()
  {
    return this.entityModifyReason;
  }
  
  public void setEntityModifyReason(EntityModifyReason paramEntityModifyReason)
  {
    this.entityModifyReason = paramEntityModifyReason;
  }
  
  public String getSid()
  {
    return this.sid;
  }
  
  public void setSid(String paramString)
  {
    this.sid = paramString;
  }
  
  public String getPartitionId()
  {
    return this.partitionId;
  }
  
  public void setPartitionId(String paramString)
  {
    this.partitionId = paramString;
  }
  
  public String getEntityType()
  {
    return this.entityType;
  }
  
  public void setEntityType(String paramString)
  {
    this.entityType = paramString;
  }
  
  public String getEntityId()
  {
    return this.entityId;
  }
  
  public void setEntityId(String paramString)
  {
    this.entityId = paramString;
  }
  
  public String getModifierId()
  {
    return this.modifierId;
  }
  
  public void setModifierId(String paramString)
  {
    this.modifierId = paramString;
  }
  
  public Timestamp getModifyTime()
  {
    return this.modifyTime;
  }
  
  public void setModifyTime(Timestamp paramTimestamp)
  {
    this.modifyTime = paramTimestamp;
  }
  
  public String getModifyField()
  {
    return this.modifyField;
  }
  
  public void setModifyField(String paramString)
  {
    this.modifyField = paramString;
  }
  
  public String getOldValue()
  {
    return this.oldValue;
  }
  
  public void setOldValue(String paramString)
  {
    this.oldValue = paramString;
  }
  
  public String getModifyValue()
  {
    return this.modifyValue;
  }
  
  public void setModifyValue(String paramString)
  {
    this.modifyValue = paramString;
  }
  
  public Object toDbType()
  {
    return _toObject(this.sid);
  }
  
  public UserInfo getModifier()
  {
    return UserResolver.resolve(getModifierId());
  }
  
  public void setModifier(UserInfo paramUserInfo)
  {
    if (paramUserInfo == null) {
      return;
    }
    setModifierId(paramUserInfo.getId());
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\_entity\_EntityModifyLog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */