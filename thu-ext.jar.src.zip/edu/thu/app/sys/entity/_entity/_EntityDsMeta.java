package edu.thu.app.sys.entity._entity;

import edu.thu.app.sys.UserResolver;
import edu.thu.app.sys.user.UserInfo;
import edu.thu.ext.hibernate.AbstractEntity;
import java.sql.Timestamp;

public abstract class _EntityDsMeta
  extends AbstractEntity
{
  private static final long serialVersionUID = 1L;
  protected String sid;
  protected String entityType;
  protected String metaText;
  protected String createrId;
  protected Timestamp createTime;
  protected Integer updaterId;
  protected Timestamp updateTime;
  
  public String getSid()
  {
    return this.sid;
  }
  
  public void setSid(String paramString)
  {
    this.sid = paramString;
  }
  
  public String getEntityType()
  {
    return this.entityType;
  }
  
  public void setEntityType(String paramString)
  {
    this.entityType = paramString;
  }
  
  public String getMetaText()
  {
    return this.metaText;
  }
  
  public void setMetaText(String paramString)
  {
    this.metaText = paramString;
  }
  
  public String getCreaterId()
  {
    return this.createrId;
  }
  
  public void setCreaterId(String paramString)
  {
    this.createrId = paramString;
  }
  
  public Timestamp getCreateTime()
  {
    return this.createTime;
  }
  
  public void setCreateTime(Timestamp paramTimestamp)
  {
    this.createTime = paramTimestamp;
  }
  
  public Integer getUpdaterId()
  {
    return this.updaterId;
  }
  
  public void setUpdaterId(Integer paramInteger)
  {
    this.updaterId = paramInteger;
  }
  
  public Timestamp getUpdateTime()
  {
    return this.updateTime;
  }
  
  public void setUpdateTime(Timestamp paramTimestamp)
  {
    this.updateTime = paramTimestamp;
  }
  
  public Object toDbType()
  {
    return _toObject(this.sid);
  }
  
  public UserInfo getCreater()
  {
    return UserResolver.resolve(getCreaterId());
  }
  
  public void setCreater(UserInfo paramUserInfo)
  {
    if (paramUserInfo == null) {
      return;
    }
    setCreaterId(paramUserInfo.getId());
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\_entity\_EntityDsMeta.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */