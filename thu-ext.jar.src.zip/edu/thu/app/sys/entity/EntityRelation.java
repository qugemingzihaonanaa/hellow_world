package edu.thu.app.sys.entity;

import edu.thu.app.sys.entity._entity._EntityRelation;

public class EntityRelation
  extends _EntityRelation
{
  private static final long serialVersionUID = 1L;
  
  public EntityPk getSrcPk()
  {
    EntityPk localEntityPk = new EntityPk();
    localEntityPk.setEntityId(getSrcEntityId());
    localEntityPk.setEntityType(getSrcEntityType());
    return localEntityPk;
  }
  
  public EntityPk getDstPk()
  {
    EntityPk localEntityPk = new EntityPk();
    localEntityPk.setEntityId(getDstEntityId());
    localEntityPk.setEntityType(getDstEntityType());
    return localEntityPk;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\entity\EntityRelation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */