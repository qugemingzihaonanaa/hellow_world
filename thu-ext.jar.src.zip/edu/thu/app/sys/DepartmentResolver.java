package edu.thu.app.sys;

import edu.thu.java.FunctionResolver;
import edu.thu.java.util.Coercions;
import edu.thu.model.data.StaticFunction;
import edu.thu.orm.dao.IEntityDao;

public class DepartmentResolver
{
  static final String A = "$department";
  static DepartmentResolver C;
  IEntityDao B;
  static Class D = Department.class;
  
  public static void setEntityClass(Class paramClass)
  {
    D = paramClass;
  }
  
  public static void registerForExpr()
  {
    FunctionResolver.register("$department", new StaticFunction()
    {
      private static final long serialVersionUID = 8997912729371673848L;
      
      public Object invoke(Object[] paramAnonymousArrayOfObject)
      {
        if ((paramAnonymousArrayOfObject == null) || (paramAnonymousArrayOfObject.length <= 0)) {
          return null;
        }
        DepartmentResolver.getInstance();
        return DepartmentResolver.resolve(Coercions.toString(paramAnonymousArrayOfObject[0], null));
      }
    });
  }
  
  public static synchronized DepartmentResolver getInstance()
  {
    return C;
  }
  
  public Department getById(String paramString)
  {
    return (Department)this.B.getEntity(paramString);
  }
  
  public static Department resolve(String paramString)
  {
    return getInstance().getById(paramString);
  }
  
  public void clearCache() {}
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\DepartmentResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */