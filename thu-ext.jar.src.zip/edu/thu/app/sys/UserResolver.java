package edu.thu.app.sys;

import edu.thu.app.sys.user.UserInfo;
import edu.thu.java.FunctionResolver;
import edu.thu.java.util.Coercions;
import edu.thu.model.data.StaticFunction;
import edu.thu.orm.dao.IEntityDao;

public class UserResolver
{
  static final String C = "$user";
  static UserResolver B;
  IEntityDao A;
  static Class D = UserInfo.class;
  
  public static void setEntityClass(Class paramClass)
  {
    D = paramClass;
  }
  
  public static void registerForExpr()
  {
    FunctionResolver.register("$user", new StaticFunction()
    {
      private static final long serialVersionUID = 8997912729371673848L;
      
      public Object invoke(Object[] paramAnonymousArrayOfObject)
      {
        if ((paramAnonymousArrayOfObject == null) || (paramAnonymousArrayOfObject.length <= 0)) {
          return null;
        }
        return UserResolver.resolve(Coercions.toString(paramAnonymousArrayOfObject[0], null));
      }
    });
  }
  
  public static synchronized UserResolver getInstance()
  {
    return B;
  }
  
  public UserInfo getById(String paramString)
  {
    return (UserInfo)this.A.getEntity(paramString);
  }
  
  public static UserInfo resolve(String paramString)
  {
    return getInstance().getById(paramString);
  }
  
  public static UserInfo fullResolve(String paramString)
  {
    return getInstance().getById(paramString);
  }
  
  public void clearCache() {}
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\UserResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */