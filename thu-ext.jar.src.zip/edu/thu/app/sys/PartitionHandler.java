package edu.thu.app.sys;

import edu.thu.app.sys.com.PartitionConfig;
import edu.thu.app.sys.com.PartitionInfo;
import edu.thu.config.AppConfig;
import edu.thu.db.SQL;
import edu.thu.db.SqlBuilder;
import edu.thu.ext.hibernate.AbstractHibernateDao;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.FunctionResolver;
import edu.thu.lang.IVariant;
import edu.thu.model.data.StaticFunction;
import edu.thu.model.tree.TreeNode;
import edu.thu.orm.dao.IEntityDao;
import edu.thu.orm.dao.IOrmTemplate;
import edu.thu.orm.partition.IPartitionState;
import edu.thu.search.Query;
import edu.thu.search.Query.ConditionSpec;
import edu.thu.service.BeanLoader;
import java.util.List;

public class PartitionHandler
  extends AbstractHibernateDao
  implements IPartitionState
{
  static ThreadLocal<PartitionConfig> threadPartition = new ThreadLocal();
  List<PartitionInfo> partitionInfoList;
  boolean inited;
  
  public boolean isUsePartition()
  {
    return AppConfig.var("sys.use_partition").booleanValue(false);
  }
  
  public static void registerForExpr()
  {
    FunctionResolver.register("partition_id", new StaticFunction()
    {
      private static final long serialVersionUID = 1L;
      
      public Object invoke(Object[] paramAnonymousArrayOfObject)
      {
        return PartitionHandler.getInstance().getCurrentPartition();
      }
    });
  }
  
  public static PartitionHandler getInstance()
  {
    return (PartitionHandler)BeanLoader.getBean(PartitionHandler.class);
  }
  
  public boolean isInited()
  {
    return this.inited;
  }
  
  public void refresh()
  {
    this.partitionInfoList = loadAllPartitionInfo();
    this.inited = true;
  }
  
  public List<PartitionInfo> loadAllPartitionInfo()
  {
    SQL localSQL = SQL.begin().sql("from PartitionInfo o order by o.partitionId desc").end();
    return orm().findAll(localSQL);
  }
  
  public String getLatestPartition()
  {
    if ((this.partitionInfoList == null) || (this.partitionInfoList.isEmpty())) {
      return null;
    }
    return ((PartitionInfo)this.partitionInfoList.get(0)).getPartitionId();
  }
  
  public String getLatestActivePartition()
  {
    if ((this.partitionInfoList == null) || (this.partitionInfoList.isEmpty())) {
      return null;
    }
    int j = this.partitionInfoList.size();
    for (int i = 0; i < j; i++)
    {
      PartitionInfo localPartitionInfo = (PartitionInfo)this.partitionInfoList.get(i);
      if ("Y".equals(localPartitionInfo.getIsActive())) {
        return localPartitionInfo.getPartitionId();
      }
    }
    return null;
  }
  
  public String getTempPartition()
  {
    return "0";
  }
  
  public List<PartitionInfo> getPartitionInfoList()
  {
    return this.partitionInfoList;
  }
  
  public void setThreadPartition(PartitionConfig paramPartitionConfig)
  {
    threadPartition.set(paramPartitionConfig);
  }
  
  public String getCurrentPartition()
  {
    PartitionConfig localPartitionConfig = (PartitionConfig)threadPartition.get();
    if (localPartitionConfig == null) {
      return getLatestActivePartition();
    }
    return localPartitionConfig.getCurrentPartition();
  }
  
  public void setCurrentPartition(String paramString)
  {
    PartitionConfig localPartitionConfig = (PartitionConfig)threadPartition.get();
    if (localPartitionConfig == null) {
      throw Exceptions.code("partition.CAN_err_null_partition_config");
    }
    localPartitionConfig.setCurrentPartition(paramString);
  }
  
  public SqlBuilder appendPartition(SqlBuilder paramSqlBuilder, String paramString1, String paramString2)
  {
    if (!orm().hasPartitionId(paramString1)) {
      return paramSqlBuilder;
    }
    String str = paramSqlBuilder.toString();
    int i = 0;
    if (str.trim().length() > 0)
    {
      int j = str.lastIndexOf("from ");
      int k;
      if (j >= 0) {
        k = str.indexOf("where ", j);
      } else {
        k = str.indexOf("where ");
      }
      if ((k > 0) || (j < 0)) {
        i = 1;
      }
    }
    if (i != 0) {
      paramSqlBuilder.and();
    }
    IEntityDao localIEntityDao = dao(paramString1);
    paramSqlBuilder.eq(paramString2, "partitionId", localIEntityDao.castProperty("partitionId", getCurrentPartition()));
    return paramSqlBuilder;
  }
  
  public SqlBuilder appendPartition(SqlBuilder paramSqlBuilder, String paramString)
  {
    return appendPartition(paramSqlBuilder, paramString, "o");
  }
  
  public SQL appendPartition(SQL paramSQL, String paramString)
  {
    return appendPartition(paramSQL.extend(), paramString).end();
  }
  
  public SQL appendPartition(SQL paramSQL, String paramString1, String paramString2)
  {
    return appendPartition(paramSQL.extend(), paramString1, paramString2).end();
  }
  
  public void appendPartition(Query paramQuery, String paramString)
  {
    if ((paramQuery.getWhere() != null) && (paramQuery.getWhere().childWithAttr("name", "partitionId") != null)) {
      return;
    }
    if (!orm().hasPartitionId(paramString)) {
      return;
    }
    String str = getCurrentPartition();
    IEntityDao localIEntityDao = dao(paramString);
    paramQuery.condition().eq("partitionId", localIEntityDao.castProperty("partitionId", str));
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\PartitionHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */