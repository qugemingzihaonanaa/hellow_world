package edu.thu.app.sys;

import edu.thu.app.sys.com.WxEnum;
import edu.thu.service.BeanLoader;

public class WxEnumHandler
{
  public static WxEnumHandler getInstance()
  {
    return (WxEnumHandler)BeanLoader.getBean(WxEnumHandler.class);
  }
  
  public WxEnum getEnumByName(String paramString)
  {
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\sys\WxEnumHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */