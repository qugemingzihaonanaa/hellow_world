package edu.thu.app.portal.config;

import edu.thu.app.portal.PortalConstants;
import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.model.tree.TreeNode;
import edu.thu.model.tree.entry.IXEntryList;
import edu.thu.model.tree.entry.XEntry;
import edu.thu.util.StampUtils;
import java.io.Serializable;

public class PortalPageDescriptor
  extends XEntry
  implements PortalConstants, Serializable
{
  private static final long serialVersionUID = -8609602840417263324L;
  
  public PortalPageDescriptor(TreeNode paramTreeNode)
  {
    super(paramTreeNode);
    if (!paramTreeNode.getName().equals("page")) {
      throw Exceptions.code("portal.CAN_err_not_page_node").param(paramTreeNode);
    }
  }
  
  public static PortalPageDescriptor makeDescriptor(Object paramObject)
  {
    if (paramObject == null) {
      return null;
    }
    if ((paramObject instanceof PortalPageDescriptor)) {
      return (PortalPageDescriptor)paramObject;
    }
    TreeNode localTreeNode = TreeNode.toNode(paramObject);
    synchronized (localTreeNode)
    {
      PortalPageDescriptor localPortalPageDescriptor = (PortalPageDescriptor)localTreeNode._getHiddenVar("@object");
      if (localPortalPageDescriptor == null) {
        localPortalPageDescriptor = new PortalPageDescriptor(localTreeNode);
      }
      return localPortalPageDescriptor;
    }
  }
  
  public IXEntryList getColumns()
  {
    return XEntry.makeChildEntries(this.node.makeChild("columns"), PortalColumnDescriptor.class);
  }
  
  public PortalColumnDescriptor newColumn()
  {
    TreeNode localTreeNode = TreeNode.make("column");
    localTreeNode.setAttribute("width", new Integer(200));
    this.node.makeChild("columns").appendChild(localTreeNode);
    localTreeNode.dump();
    return PortalColumnDescriptor.makeDescriptor(localTreeNode);
  }
  
  public PortalModuleDescriptor getModule(String paramString)
  {
    IXEntryList localIXEntryList = getColumns();
    int j = localIXEntryList.size();
    for (int i = 0; i < j; i++)
    {
      PortalColumnDescriptor localPortalColumnDescriptor = (PortalColumnDescriptor)localIXEntryList.get(i);
      PortalModuleDescriptor localPortalModuleDescriptor = localPortalColumnDescriptor.getModule(paramString);
      if (localPortalModuleDescriptor != null) {
        return localPortalModuleDescriptor;
      }
    }
    return null;
  }
  
  public PortalColumnDescriptor getColumn(int paramInt)
  {
    if (paramInt < 0) {
      return null;
    }
    IXEntryList localIXEntryList = getColumns();
    if (paramInt >= localIXEntryList.size())
    {
      int j = paramInt - localIXEntryList.size() + 1;
      for (int i = 0; i < j; i++) {
        newColumn();
      }
    }
    return (PortalColumnDescriptor)localIXEntryList.get(paramInt);
  }
  
  public boolean resizeModule(String paramString, int paramInt1, int paramInt2)
  {
    PortalModuleDescriptor localPortalModuleDescriptor = getModule(paramString);
    if (localPortalModuleDescriptor == null)
    {
      Debug.traceErr("portal.CAN_err_unknown_module::" + paramString);
      return false;
    }
    PortalColumnDescriptor localPortalColumnDescriptor = localPortalModuleDescriptor.getColumn();
    if (localPortalColumnDescriptor != null) {
      localPortalColumnDescriptor.setWidth(paramInt1);
    }
    localPortalModuleDescriptor.setHeight(paramInt2);
    return true;
  }
  
  public boolean moveModule(String paramString, int paramInt1, int paramInt2)
  {
    PortalModuleDescriptor localPortalModuleDescriptor = getModule(paramString);
    if (localPortalModuleDescriptor == null)
    {
      Debug.traceErr("portal.CAN_err_unknown_module::" + paramString);
      return false;
    }
    localPortalModuleDescriptor.getColumn().removeModule(paramString);
    PortalColumnDescriptor localPortalColumnDescriptor = getColumn(paramInt1);
    Debug.check(localPortalColumnDescriptor);
    localPortalModuleDescriptor.toNode().setParent(null);
    localPortalColumnDescriptor.insertModule(paramInt2, localPortalModuleDescriptor);
    return false;
  }
  
  public boolean minimizeModule(String paramString)
  {
    PortalModuleDescriptor localPortalModuleDescriptor = getModule(paramString);
    if (localPortalModuleDescriptor == null)
    {
      Debug.traceErr("portal.CAN_err_unknown_module::" + paramString);
      return false;
    }
    localPortalModuleDescriptor.minimize();
    return true;
  }
  
  public boolean restoreModule(String paramString)
  {
    PortalModuleDescriptor localPortalModuleDescriptor = getModule(paramString);
    if (localPortalModuleDescriptor == null)
    {
      Debug.traceErr("portal.CAN_err_unknown_module::" + paramString);
      return false;
    }
    localPortalModuleDescriptor.restore();
    return true;
  }
  
  public boolean removeModule(String paramString)
  {
    IXEntryList localIXEntryList = getColumns();
    int j = localIXEntryList.size();
    for (int i = 0; i < j; i++)
    {
      PortalColumnDescriptor localPortalColumnDescriptor = (PortalColumnDescriptor)localIXEntryList.get(i);
      if (localPortalColumnDescriptor.removeModule(paramString) != null) {
        return true;
      }
    }
    return false;
  }
  
  public String generateModuleId()
  {
    for (String str = StampUtils.getUniqueString(); getModule(str) != null; str = StampUtils.getUniqueString()) {}
    return str;
  }
  
  public void addModule(int paramInt1, int paramInt2, PortalModuleDescriptor paramPortalModuleDescriptor)
  {
    if (paramInt1 < 0) {
      paramInt1 = 0;
    }
    String str = paramPortalModuleDescriptor.getId();
    if (str == null) {
      str = generateModuleId();
    } else {
      removeModule(str);
    }
    PortalColumnDescriptor localPortalColumnDescriptor = getColumn(paramInt1);
    paramPortalModuleDescriptor.setId(str);
    localPortalColumnDescriptor.getModules().add(paramInt2, paramPortalModuleDescriptor);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\portal\config\PortalPageDescriptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */