package edu.thu.app.portal.config;

import edu.thu.app.portal.PortalConstants;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.io.util.IoUtils;
import edu.thu.model.tree.TreeNode;
import edu.thu.model.tree.entry.IXEntryList;
import edu.thu.model.tree.entry.XEntry;
import edu.thu.xml.dom.DomToTree;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.Serializable;

public class PortalDescriptor
  extends XEntry
  implements PortalConstants, Serializable
{
  private static final long serialVersionUID = 6437853633953407781L;
  public static String EXT_CONFIG_TPL = "/_config/portal/portal_config.tpl";
  
  public PortalDescriptor(TreeNode paramTreeNode)
  {
    super(paramTreeNode);
    if (!paramTreeNode.getName().equals("portal")) {
      throw Exceptions.code("portal.CAN_err_not_portal_node").param(paramTreeNode);
    }
  }
  
  public PortalDescriptor() {}
  
  public static PortalDescriptor loadFromFile(File paramFile)
  {
    FileInputStream localFileInputStream = null;
    try
    {
      localFileInputStream = new FileInputStream(paramFile);
      PortalDescriptor localPortalDescriptor = loadFrom(localFileInputStream);
      return localPortalDescriptor;
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
    finally
    {
      IoUtils.safeClose(localFileInputStream);
    }
  }
  
  public static PortalDescriptor loadFrom(InputStream paramInputStream)
  {
    TreeNode localTreeNode = DomToTree.getInstance().transform(paramInputStream);
    if (localTreeNode == null) {
      throw Exceptions.code("portal.CAN_err_null_portal_descriptor");
    }
    return makeDescriptor(localTreeNode);
  }
  
  public static PortalDescriptor makeDescriptor(Object paramObject)
  {
    if (paramObject == null) {
      return null;
    }
    if ((paramObject instanceof PortalDescriptor)) {
      return (PortalDescriptor)paramObject;
    }
    TreeNode localTreeNode = TreeNode.toNode(paramObject);
    synchronized (localTreeNode)
    {
      PortalDescriptor localPortalDescriptor = (PortalDescriptor)localTreeNode._getHiddenVar("@object");
      if (localPortalDescriptor == null) {
        localPortalDescriptor = new PortalDescriptor(localTreeNode);
      }
      return localPortalDescriptor;
    }
  }
  
  public IXEntryList getPages()
  {
    return XEntry.makeChildEntries(this.node.makeChild("pages"), PortalPageDescriptor.class);
  }
  
  public PortalPageDescriptor getDefaultPage()
  {
    IXEntryList localIXEntryList = getPages();
    if (localIXEntryList.size() <= 0) {
      return null;
    }
    PortalPageDescriptor localPortalPageDescriptor = (PortalPageDescriptor)localIXEntryList.getById("default");
    if (localPortalPageDescriptor == null) {
      localPortalPageDescriptor = (PortalPageDescriptor)localIXEntryList.get(0);
    }
    return localPortalPageDescriptor;
  }
  
  public String getCurrentPageId()
  {
    return this.node.makeChild("currentPage").stripedStringValue("default");
  }
  
  public PortalPageDescriptor getPage(String paramString)
  {
    return (PortalPageDescriptor)getPages().getById(paramString);
  }
  
  public PortalPageDescriptor getCurrentPage()
  {
    return getPage(getCurrentPageId());
  }
  
  public PortalModuleDescriptor getModule(String paramString1, String paramString2)
  {
    PortalPageDescriptor localPortalPageDescriptor = getPage(paramString1);
    if (localPortalPageDescriptor == null) {
      return null;
    }
    return localPortalPageDescriptor.getModule(paramString2);
  }
  
  public boolean resizeModule(String paramString1, String paramString2, int paramInt1, int paramInt2)
  {
    PortalPageDescriptor localPortalPageDescriptor = getPage(paramString1);
    if (localPortalPageDescriptor == null) {
      return false;
    }
    return localPortalPageDescriptor.resizeModule(paramString2, paramInt1, paramInt2);
  }
  
  public boolean moveModule(String paramString1, String paramString2, int paramInt1, int paramInt2)
  {
    PortalPageDescriptor localPortalPageDescriptor = getPage(paramString1);
    if (localPortalPageDescriptor == null) {
      return false;
    }
    return localPortalPageDescriptor.moveModule(paramString2, paramInt1, paramInt2);
  }
  
  public boolean minimizeModule(String paramString1, String paramString2)
  {
    PortalPageDescriptor localPortalPageDescriptor = getPage(paramString1);
    if (localPortalPageDescriptor == null) {
      return false;
    }
    return localPortalPageDescriptor.minimizeModule(paramString2);
  }
  
  public boolean restoreModule(String paramString1, String paramString2)
  {
    PortalPageDescriptor localPortalPageDescriptor = getPage(paramString1);
    if (localPortalPageDescriptor == null) {
      return false;
    }
    return localPortalPageDescriptor.restoreModule(paramString2);
  }
  
  public boolean removeModule(String paramString1, String paramString2)
  {
    PortalPageDescriptor localPortalPageDescriptor = getPage(paramString1);
    if (localPortalPageDescriptor == null) {
      return false;
    }
    return localPortalPageDescriptor.removeModule(paramString2);
  }
  
  public PortalModuleDescriptor newModule()
  {
    return new PortalModuleDescriptor();
  }
  
  public boolean addModule(String paramString, int paramInt1, int paramInt2, PortalModuleDescriptor paramPortalModuleDescriptor)
  {
    PortalPageDescriptor localPortalPageDescriptor = getPage(paramString);
    if (localPortalPageDescriptor == null) {
      return false;
    }
    localPortalPageDescriptor.addModule(paramInt1, paramInt2, paramPortalModuleDescriptor);
    return true;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\portal\config\PortalDescriptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */