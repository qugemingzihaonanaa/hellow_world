package edu.thu.app.portal.config;

import edu.thu.app.portal.PortalConstants;
import java.io.Serializable;
import java.util.Map;

public class PortletDescriptor
  implements PortalConstants, Serializable
{
  private static final long serialVersionUID = 4805855208823336923L;
  String C;
  String B;
  String G;
  String H;
  String F;
  String A;
  int E;
  boolean D;
  Map I;
  
  public void setViews(Map paramMap)
  {
    this.I = paramMap;
  }
  
  public Map getViews()
  {
    return this.I;
  }
  
  public String getDescription()
  {
    return this.H;
  }
  
  public void setDescription(String paramString)
  {
    this.H = paramString;
  }
  
  public String getId()
  {
    return this.C;
  }
  
  public void setId(String paramString)
  {
    this.C = paramString;
  }
  
  public String getLargeIcon()
  {
    return this.A;
  }
  
  public void setLargeIcon(String paramString)
  {
    this.A = paramString;
  }
  
  public int getLayoutNo()
  {
    return this.E;
  }
  
  public void setLayoutNo(int paramInt)
  {
    this.E = paramInt;
  }
  
  public String getName()
  {
    return this.B;
  }
  
  public void setName(String paramString)
  {
    this.B = paramString;
  }
  
  public boolean isSingleton()
  {
    return this.D;
  }
  
  public void setSingleton(boolean paramBoolean)
  {
    this.D = paramBoolean;
  }
  
  public String getSmallIcon()
  {
    return this.F;
  }
  
  public void setSmallIcon(String paramString)
  {
    this.F = paramString;
  }
  
  public String getTitle()
  {
    return this.G;
  }
  
  public void setTitle(String paramString)
  {
    this.G = paramString;
  }
  
  public PortletViewDescriptor getView(String paramString)
  {
    return (PortletViewDescriptor)getViews().get(paramString);
  }
  
  public PortletViewDescriptor getDefaultView()
  {
    PortletViewDescriptor localPortletViewDescriptor = getView("default");
    if (localPortletViewDescriptor == null) {
      localPortletViewDescriptor = getView("normal");
    }
    return localPortletViewDescriptor;
  }
  
  public Object getDefaultViewContent()
  {
    PortletViewDescriptor localPortletViewDescriptor = getDefaultView();
    if (localPortletViewDescriptor == null) {
      return null;
    }
    return localPortletViewDescriptor.getContent();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\portal\config\PortletDescriptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */