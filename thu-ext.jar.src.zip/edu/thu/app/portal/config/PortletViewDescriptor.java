package edu.thu.app.portal.config;

import edu.thu.app.portal.PortalConstants;
import java.io.Serializable;

public class PortletViewDescriptor
  implements PortalConstants, Serializable
{
  private static final long serialVersionUID = 6230515870637221897L;
  String L;
  String J;
  Object K;
  
  public String getId()
  {
    return this.L;
  }
  
  public void setId(String paramString)
  {
    this.L = paramString;
  }
  
  public String getName()
  {
    return this.J;
  }
  
  public void setName(String paramString)
  {
    this.J = paramString;
  }
  
  public Object getContent()
  {
    return this.K;
  }
  
  public void setContent(Object paramObject)
  {
    this.K = paramObject;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\portal\config\PortletViewDescriptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */