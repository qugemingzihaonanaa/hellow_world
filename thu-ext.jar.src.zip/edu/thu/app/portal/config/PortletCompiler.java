package edu.thu.app.portal.config;

import edu.thu.app.portal.PortalConstants;
import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IVariant;
import edu.thu.lang.util.ITplReference;
import edu.thu.lang.util.TplC;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceContext;
import edu.thu.service.util.ContextHelper;
import edu.thu.xml.dom.DomToTree;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class PortletCompiler
  implements PortalConstants
{
  public static PortletCompiler getInstance()
  {
    return new PortletCompiler();
  }
  
  public TplC newTplC(IServiceContext paramIServiceContext)
  {
    TplC localTplC = TplC.newWebTplC();
    String str = PortalDescriptor.EXT_CONFIG_TPL;
    try
    {
      str = ContextHelper.getCustomizablePath(str);
      if (!localTplC.tryRun(str, null, paramIServiceContext)) {
        Debug.traceErr("portal.CAN_err_not_loading_portal_ext_config::" + str);
      }
    }
    catch (Exception localException)
    {
      Debug.trace(localException);
    }
    return localTplC;
  }
  
  public Map compilePortletsFile(File paramFile, IServiceContext paramIServiceContext)
  {
    TreeNode localTreeNode = DomToTree.getInstance().allowText(true).transform(paramFile);
    if (localTreeNode == null)
    {
      Debug.trace("portal.CAN_err_null_definition::" + paramFile);
      return null;
    }
    return compilePortlets(localTreeNode, paramIServiceContext);
  }
  
  public Map compilePortlets(TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    TplC localTplC = newTplC(paramIServiceContext);
    HashMap localHashMap = new HashMap();
    int j = paramTreeNode.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(i);
      if (localTreeNode.getName().equals("config"))
      {
        localTplC.run(localTreeNode, paramIServiceContext);
      }
      else if (localTreeNode.getName().equals("portlet"))
      {
        PortletDescriptor localPortletDescriptor = A(localTplC, localTreeNode, paramIServiceContext);
        if (localHashMap.containsKey(localPortletDescriptor.getId())) {
          throw Exceptions.code("portal.CAN_err_duplicate_portlet").param(localTreeNode);
        }
        localHashMap.put(localPortletDescriptor.getId(), localPortletDescriptor);
      }
      else
      {
        throw Exceptions.code("portal.CAN_err_unknown_portlet_tag").param(localTreeNode);
      }
    }
    return localHashMap;
  }
  
  public PortletDescriptor compilePortlet(TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    TplC localTplC = newTplC(paramIServiceContext);
    PortletDescriptor localPortletDescriptor = A(localTplC, paramTreeNode, paramIServiceContext);
    return localPortletDescriptor;
  }
  
  PortletDescriptor A(TplC paramTplC, TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    if (!paramTreeNode.getName().equals("portlet")) {
      throw Exceptions.code("portal.CAN_err_invalid_portlet").param(paramTreeNode);
    }
    PortletDescriptor localPortletDescriptor = new PortletDescriptor();
    String str1 = paramTreeNode.attribute("id").stripedStringValue();
    String str2 = paramTreeNode.attribute("name").stripedStringValue();
    String str3 = paramTreeNode.attribute("title").stripedStringValue();
    boolean bool = paramTreeNode.attribute("singleton").booleanValue(false);
    String str4 = paramTreeNode.makeChild("smallIcon").stripedStringValue();
    String str5 = paramTreeNode.makeChild("largeIcon").stripedStringValue();
    String str6 = paramTreeNode.makeChild("description").stripedStringValue();
    int i = paramTreeNode.attribute("layoutNo").intValue(0);
    if (str1 == null) {
      throw Exceptions.code("portal.CAN_err_null_portlet_id").param(paramTreeNode);
    }
    localPortletDescriptor.setId(str1);
    localPortletDescriptor.setName(str2);
    localPortletDescriptor.setTitle(str3);
    localPortletDescriptor.setDescription(str6);
    localPortletDescriptor.setSmallIcon(str4);
    localPortletDescriptor.setLargeIcon(str5);
    localPortletDescriptor.setLayoutNo(i);
    localPortletDescriptor.setSingleton(bool);
    Map localMap = C(paramTplC, paramTreeNode, paramIServiceContext);
    localPortletDescriptor.setViews(localMap);
    return localPortletDescriptor;
  }
  
  Map C(TplC paramTplC, TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    HashMap localHashMap = new HashMap();
    TreeNode localTreeNode1 = paramTreeNode.existingChild("view");
    if (localTreeNode1 != null) {
      A(paramTplC, localHashMap, localTreeNode1, paramIServiceContext);
    }
    TreeNode localTreeNode2 = paramTreeNode.existingChild("views");
    if (localTreeNode2 != null)
    {
      int j = localTreeNode2.getChildCount();
      for (int i = 0; i < j; i++) {
        A(paramTplC, localHashMap, localTreeNode2.getChild(i), paramIServiceContext);
      }
    }
    if (localHashMap.isEmpty()) {
      throw Exceptions.code("portal.CAN_err_portlet_no_view").param(paramTreeNode);
    }
    return localHashMap;
  }
  
  void A(TplC paramTplC, Map paramMap, TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    PortletViewDescriptor localPortletViewDescriptor = new PortletViewDescriptor();
    if (!paramTreeNode.getName().equals("view")) {
      throw Exceptions.code("portal.CAN_err_invalid_portlet_view_node").param(paramTreeNode);
    }
    String str = paramTreeNode.attribute("id").stripedStringValue("default");
    Object localObject = B(paramTplC, paramTreeNode, paramIServiceContext);
    localPortletViewDescriptor.setId(str);
    localPortletViewDescriptor.setContent(localObject);
    if (paramMap.containsKey(localPortletViewDescriptor.getId())) {
      throw Exceptions.code("portal.CAN_err_portlet_duplicate_view").param(paramTreeNode);
    }
    paramMap.put(localPortletViewDescriptor.getId(), localPortletViewDescriptor);
  }
  
  Object B(TplC paramTplC, TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    TreeNode localTreeNode = paramTreeNode.existingChild("content");
    if (localTreeNode == null) {
      localTreeNode = paramTreeNode;
    }
    ITplReference localITplReference = paramTplC.compileBody(localTreeNode, null, paramIServiceContext);
    if (localITplReference == null) {
      throw Exceptions.code("portal.CAN_err_portal_module_null_content").param(localTreeNode);
    }
    return localITplReference;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\portal\config\PortletCompiler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */