package edu.thu.app.portal.config;

import edu.thu.app.portal.PortalConstants;
import edu.thu.app.portal.PortletManager;
import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IVariant;
import edu.thu.model.tree.TreeNode;
import edu.thu.model.tree.entry.XEntry;
import java.io.Serializable;

public class PortalModuleDescriptor
  extends XEntry
  implements PortalConstants, Serializable
{
  private static final long serialVersionUID = -7696938329725022860L;
  
  public PortalModuleDescriptor(TreeNode paramTreeNode)
  {
    super(paramTreeNode);
    if (!paramTreeNode.getName().equals("module")) {
      throw Exceptions.code("portal.CAN_err_not_module_node").param(paramTreeNode);
    }
  }
  
  public PortalModuleDescriptor()
  {
    this(TreeNode.make("module"));
  }
  
  public static PortalModuleDescriptor makeDescriptor(Object paramObject)
  {
    if (paramObject == null) {
      return null;
    }
    if ((paramObject instanceof PortalModuleDescriptor)) {
      return (PortalModuleDescriptor)paramObject;
    }
    TreeNode localTreeNode = TreeNode.toNode(paramObject);
    synchronized (localTreeNode)
    {
      PortalModuleDescriptor localPortalModuleDescriptor = (PortalModuleDescriptor)localTreeNode._getHiddenVar("@object");
      if (localPortalModuleDescriptor == null) {
        localPortalModuleDescriptor = new PortalModuleDescriptor(localTreeNode);
      }
      return localPortalModuleDescriptor;
    }
  }
  
  public PortalColumnDescriptor getColumn()
  {
    TreeNode localTreeNode = this.node.getParent();
    if (localTreeNode == null) {
      return null;
    }
    return PortalColumnDescriptor.makeDescriptor(localTreeNode);
  }
  
  public PortalPageDescriptor getPage()
  {
    PortalColumnDescriptor localPortalColumnDescriptor = getColumn();
    if (localPortalColumnDescriptor == null) {
      return null;
    }
    return localPortalColumnDescriptor.getPage();
  }
  
  public String getPageId()
  {
    PortalPageDescriptor localPortalPageDescriptor = getPage();
    if (localPortalPageDescriptor == null) {
      return null;
    }
    return localPortalPageDescriptor.getId();
  }
  
  public int getColIdx()
  {
    PortalColumnDescriptor localPortalColumnDescriptor = getColumn();
    if (localPortalColumnDescriptor == null) {
      return -1;
    }
    return localPortalColumnDescriptor.getColIdx();
  }
  
  public int getModIdx()
  {
    PortalColumnDescriptor localPortalColumnDescriptor = getColumn();
    if (localPortalColumnDescriptor == null) {
      return -1;
    }
    return localPortalColumnDescriptor.getModuleIndex(getId());
  }
  
  public int getHeight()
  {
    return this.node.attribute("height").intValue(200);
  }
  
  public void setHeight(int paramInt)
  {
    if (paramInt <= 0) {
      paramInt = getMinHeight();
    }
    this.node.setAttribute("height", new Integer(paramInt));
  }
  
  public int getWidth()
  {
    return getColumnWidth();
  }
  
  public String getTitle()
  {
    return this.node.attribute("title").stripedStringValue();
  }
  
  public void setTitle(String paramString)
  {
    this.node.setAttribute("title", paramString);
  }
  
  public PortletDescriptor getPortlet()
  {
    String str = getPortletId();
    if (str == null) {
      throw Exceptions.code("portal.CAN_err_no_portlet_id").param(this.node);
    }
    PortletDescriptor localPortletDescriptor = PortletManager.getInstance().getPortlet(str);
    if (localPortletDescriptor == null) {
      throw Exceptions.code("portal.CAN_err_portlet_not_found").param(str);
    }
    return localPortletDescriptor;
  }
  
  public String getPortletId()
  {
    return this.node.attribute("portletId").stripedStringValue();
  }
  
  public void setPortletId(String paramString)
  {
    Debug.check(paramString);
    this.node.setAttribute("portletId", paramString);
  }
  
  public int getMinWidth()
  {
    return this.node.attribute("minWidth").intValue(50);
  }
  
  public void setMinWidth(int paramInt)
  {
    if (paramInt <= 0) {
      paramInt = 50;
    }
    this.node.setAttribute("minWidth", new Integer(paramInt));
  }
  
  public int getMinHeight()
  {
    return this.node.attribute("minHeight").intValue(50);
  }
  
  public void setMinHeight(int paramInt)
  {
    if (paramInt <= 0) {
      paramInt = 50;
    }
    this.node.setAttribute("minHeight", new Integer(paramInt));
  }
  
  public int getMaxWidth()
  {
    int i = this.node.attribute("maxWidth").intValue(800);
    int j = getMinWidth();
    if (i < j) {
      i = j;
    }
    return i;
  }
  
  public void setMaxWidth(int paramInt)
  {
    if (paramInt <= 0) {
      paramInt = 800;
    }
    this.node.setAttribute("maxWidth", new Integer(paramInt));
  }
  
  public int getMaxHeight()
  {
    int i = this.node.attribute("maxHeight").intValue(800);
    int j = getMinHeight();
    if (i < j) {
      i = j;
    }
    return i;
  }
  
  public void setMaxHeight(int paramInt)
  {
    if (paramInt <= 0) {
      paramInt = 800;
    }
    this.node.setAttribute("maxHeight", new Integer(paramInt));
  }
  
  public int getColumnWidth()
  {
    return getColumn().getWidth();
  }
  
  public String getState()
  {
    return this.node.attribute("state").stripedStringValue("normal");
  }
  
  public boolean isMinimized()
  {
    return getState().equals("minimized");
  }
  
  public void setState(String paramString)
  {
    this.node.setAttribute("state", paramString);
  }
  
  public void minimize()
  {
    setState("minimized");
  }
  
  public void restore()
  {
    setState("normal");
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\portal\config\PortalModuleDescriptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */