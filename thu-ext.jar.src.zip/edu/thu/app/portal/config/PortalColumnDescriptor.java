package edu.thu.app.portal.config;

import edu.thu.app.portal.PortalConstants;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IVariant;
import edu.thu.model.tree.TreeNode;
import edu.thu.model.tree.entry.IXEntryList;
import edu.thu.model.tree.entry.XEntry;
import java.io.Serializable;
import java.util.List;

public class PortalColumnDescriptor
  extends XEntry
  implements PortalConstants, Serializable
{
  private static final long serialVersionUID = -316082866120627879L;
  
  public PortalColumnDescriptor(TreeNode paramTreeNode)
  {
    super(paramTreeNode);
    if (!paramTreeNode.getName().equals("column")) {
      throw Exceptions.code("portal.CAN_err_not_column_node").param(paramTreeNode);
    }
    this.childClass = PortalModuleDescriptor.class;
    paramTreeNode.setValue(null);
  }
  
  public static PortalColumnDescriptor makeDescriptor(Object paramObject)
  {
    if (paramObject == null) {
      return null;
    }
    if ((paramObject instanceof PortalColumnDescriptor)) {
      return (PortalColumnDescriptor)paramObject;
    }
    TreeNode localTreeNode = TreeNode.toNode(paramObject);
    synchronized (localTreeNode)
    {
      PortalColumnDescriptor localPortalColumnDescriptor = (PortalColumnDescriptor)localTreeNode._getHiddenVar("@object");
      if (localPortalColumnDescriptor == null) {
        localPortalColumnDescriptor = new PortalColumnDescriptor(localTreeNode);
      }
      return localPortalColumnDescriptor;
    }
  }
  
  public int getWidth()
  {
    return this.node.attribute("width").intValue(200);
  }
  
  public void setWidth(int paramInt)
  {
    this.node.setAttribute("width", new Integer(paramInt));
  }
  
  public IXEntryList getModules()
  {
    return getChildEntries();
  }
  
  public int getModuleIndex(String paramString)
  {
    if (paramString == null) {
      return -1;
    }
    IXEntryList localIXEntryList = getModules();
    int j = localIXEntryList.size();
    for (int i = 0; i < j; i++)
    {
      PortalModuleDescriptor localPortalModuleDescriptor = (PortalModuleDescriptor)localIXEntryList.get(i);
      if (paramString.equals(localPortalModuleDescriptor.getId())) {
        return i;
      }
    }
    return -1;
  }
  
  public int getColIdx()
  {
    PortalPageDescriptor localPortalPageDescriptor = getPage();
    if (localPortalPageDescriptor == null) {
      return -1;
    }
    IXEntryList localIXEntryList = localPortalPageDescriptor.getColumns();
    return localIXEntryList.indexOf(this);
  }
  
  public PortalPageDescriptor getPage()
  {
    TreeNode localTreeNode = this.node.getParent();
    if (localTreeNode == null) {
      return null;
    }
    return PortalPageDescriptor.makeDescriptor(localTreeNode.getParent());
  }
  
  public PortalModuleDescriptor getModule(String paramString)
  {
    return (PortalModuleDescriptor)getModules().getById(paramString);
  }
  
  public PortalModuleDescriptor removeModule(String paramString)
  {
    return (PortalModuleDescriptor)getModules().removeById(paramString);
  }
  
  public int getMinWidth()
  {
    IXEntryList localIXEntryList = getModules();
    int i = -1;
    int k = localIXEntryList.size();
    for (int j = 0; j < k; j++)
    {
      PortalModuleDescriptor localPortalModuleDescriptor = (PortalModuleDescriptor)localIXEntryList.get(j);
      if (localPortalModuleDescriptor.getMinWidth() > i) {
        i = localPortalModuleDescriptor.getMinWidth();
      }
    }
    if (i < 0) {
      i = 50;
    }
    return i;
  }
  
  public int getMaxWidth()
  {
    IXEntryList localIXEntryList = getModules();
    int i = Integer.MAX_VALUE;
    int k = localIXEntryList.size();
    for (int j = 0; j < k; j++)
    {
      PortalModuleDescriptor localPortalModuleDescriptor = (PortalModuleDescriptor)localIXEntryList.get(j);
      if (localPortalModuleDescriptor.getMaxWidth() < i) {
        i = localPortalModuleDescriptor.getMaxWidth();
      }
    }
    if (i == Integer.MAX_VALUE) {
      i = 50;
    }
    int m = getMinWidth();
    if (i < m) {
      i = m;
    }
    return i;
  }
  
  public void insertModule(int paramInt, PortalModuleDescriptor paramPortalModuleDescriptor)
  {
    IXEntryList localIXEntryList = getModules();
    if (paramInt < 0) {
      paramInt = 0;
    }
    if (paramInt >= localIXEntryList.size()) {
      localIXEntryList.add(paramPortalModuleDescriptor);
    } else {
      localIXEntryList.add(paramInt, paramPortalModuleDescriptor);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\portal\config\PortalColumnDescriptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */