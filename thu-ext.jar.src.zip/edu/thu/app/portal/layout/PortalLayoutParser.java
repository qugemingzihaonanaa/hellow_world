package edu.thu.app.portal.layout;

import edu.thu.app.portal.PortalConstants;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IVariant;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceContext;
import java.util.List;

public class PortalLayoutParser
  implements PortalConstants
{
  public PortalLayout parse(TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    if (paramTreeNode == null) {
      return null;
    }
    PortalLayout localPortalLayout = new PortalLayout();
    int j = paramTreeNode.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(i);
      if (!localTreeNode.getName().equals("portal:Module")) {
        throw Exceptions.code("portal.CAN_err_not_portal_module_node").param(localTreeNode);
      }
      int k = localTreeNode.attribute("width").intValue(0);
      int m = localTreeNode.attribute("height").intValue(0);
      int n = localTreeNode.attribute("x").intValue(0);
      int i1 = localTreeNode.attribute("y").intValue(0);
      List localList = localTreeNode.attribute("selector").listValue();
      String str = localTreeNode.attribute("id").stripedStringValue();
      PortalLayoutModule localPortalLayoutModule = new PortalLayoutModule();
      localPortalLayoutModule.setWidth(k);
      localPortalLayoutModule.setHeight(m);
      localPortalLayoutModule.setX(n);
      localPortalLayoutModule.setY(i1);
      localPortalLayoutModule.setId(str);
      localPortalLayoutModule.setSelectors(localList);
      localPortalLayout.addModule(localPortalLayoutModule);
    }
    return localPortalLayout;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\portal\layout\PortalLayoutParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */