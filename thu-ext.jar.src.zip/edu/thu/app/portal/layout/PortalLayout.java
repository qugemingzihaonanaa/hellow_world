package edu.thu.app.portal.layout;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.model.entity.SelectableEntity;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PortalLayout
  implements Serializable
{
  private static final long serialVersionUID = 3057200259096609734L;
  List A = new ArrayList();
  
  public List getModules()
  {
    return this.A;
  }
  
  public PortalLayoutModule getModuleById(String paramString)
  {
    return (PortalLayoutModule)SelectableEntity.getEntityById(this.A, paramString);
  }
  
  public PortalLayoutModule getModuleBySelector(String paramString)
  {
    return (PortalLayoutModule)SelectableEntity.getEntityBySelector(this.A, paramString);
  }
  
  public List getModuleListBySelector(String paramString)
  {
    return SelectableEntity.getEntityListBySelector(this.A, paramString);
  }
  
  public void addModule(PortalLayoutModule paramPortalLayoutModule)
  {
    PortalLayoutModule localPortalLayoutModule = getModuleById(paramPortalLayoutModule.getId());
    if (localPortalLayoutModule != null) {
      throw Exceptions.code("portal.CAN_err_duplicate_portal_module_id").param(paramPortalLayoutModule.getId());
    }
    this.A.add(paramPortalLayoutModule);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\portal\layout\PortalLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */