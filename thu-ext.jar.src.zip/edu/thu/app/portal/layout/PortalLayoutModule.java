package edu.thu.app.portal.layout;

import edu.thu.model.entity.SelectableEntity;
import java.io.Serializable;

public class PortalLayoutModule
  extends SelectableEntity
  implements Serializable
{
  private static final long serialVersionUID = 9055161719352380128L;
  int G;
  int E;
  int D;
  int H;
  String F;
  
  public int getHeight()
  {
    return this.E;
  }
  
  public void setHeight(int paramInt)
  {
    this.E = paramInt;
  }
  
  public String getPortletId()
  {
    return this.F;
  }
  
  public void setPortletId(String paramString)
  {
    this.F = paramString;
  }
  
  public int getWidth()
  {
    return this.G;
  }
  
  public void setWidth(int paramInt)
  {
    this.G = paramInt;
  }
  
  public int getX()
  {
    return this.D;
  }
  
  public void setX(int paramInt)
  {
    this.D = paramInt;
  }
  
  public int getY()
  {
    return this.H;
  }
  
  public void setY(int paramInt)
  {
    this.H = paramInt;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\portal\layout\PortalLayoutModule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */