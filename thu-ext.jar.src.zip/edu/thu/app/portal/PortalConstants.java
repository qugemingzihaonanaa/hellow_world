package edu.thu.app.portal;

public abstract interface PortalConstants
{
  public static final String PORTAL_LAYOUT_NAME = "portal:Layout";
  public static final String PORTAL_MODULE_NAME = "portal:Module";
  public static final String CONFIG_NAME = "config";
  public static final String LAYOUT_NO_NAME = "layoutNo";
  public static final String SMALL_ICON_NAME = "smallIcon";
  public static final String LARGE_ICON_NAME = "largeIcon";
  public static final String DESCRIPTION_NAME = "description";
  public static final String ID_NAME = "id";
  public static final String NAME_NAME = "name";
  public static final String CREATER_NAME = "creater";
  public static final String CREATE_TIME_NAME = "createTime";
  public static final String UPDATER_NAME = "updater";
  public static final String UPDATE_TIME_NAME = "updateTime";
  public static final String SINGLETON_NAME = "singleton";
  public static final String CACHE_NAME = "cache";
  public static final String EXPIRE_NAME = "expire";
  public static final String SHARED_NAME = "shared";
  public static final String SUPPORTS_NAME = "supports";
  public static final String RESOURCE_NAME = "resource";
  public static final String STRING_NAME = "string";
  public static final String VALUE_NAME = "value";
  public static final String LANGUAGE_NAME = "language";
  public static final String LOCALE_NAME = "locale";
  public static final String DEFAULT_LOCALE_NAME = "defaultLocale";
  public static final String VIEWS_NAME = "views";
  public static final String DEFAULT_NAME = "default";
  public static final String TPL_NAME = "tpl";
  public static final String OBJECT_TYPE_NAME = "objectType";
  public static final String OBJECT_NAME_NAME = "objectName";
  public static final String OBJECT_EVENT_NAME = "objectEvent";
  public static final String URL_NAME = "url";
  public static final String NORMAL_NAME = "normal";
  public static final String PORTAL_NAME = "portal";
  public static final String PORTLET_NAME = "portlet";
  public static final String PORTLETS_NAME = "portlets";
  public static final String PAGES_NAME = "pages";
  public static final String PAGE_NAME = "page";
  public static final String COLUMN_NAME = "column";
  public static final String MODULE_NAME = "module";
  public static final String SHOW_STATE_MAXIMIZED = "maximized";
  public static final String SHOW_STATE_MINIMIZED = "minimized";
  public static final String SHOW_STATE_NORMAL = "normal";
  public static final String VIEW_NAME = "view";
  public static final String COLUMNS_NAME = "columns";
  public static final String CURRENT_PAGE_NAME = "currentPage";
  public static final String DEFAULT_EXT_CONFIG_TPL = "/_config/portal/portal_config.tpl";
  public static final String X_NAME = "x";
  public static final String Y_NAME = "y";
  public static final String SELECTOR_NAME = "selector";
  public static final String HEIGHT_NAME = "height";
  public static final String WIDTH_NAME = "width";
  public static final String TITLE_NAME = "title";
  public static final String CONTENT_NAME = "content";
  public static final String PORTLET_ID_NAME = "portletId";
  public static final String MIN_WIDTH_NAME = "minWidth";
  public static final String MIN_HEIGHT_NAME = "minHeight";
  public static final String MAX_WIDTH_NAME = "maxWidth";
  public static final String MAX_HEIGHT_NAME = "maxHeight";
  public static final String STATE_NAME = "state";
  public static final String STATE_NORMAL = "normal";
  public static final String STATE_MINIMIZED = "minimized";
  public static final String STATE_MAXMIMIZED = "maximized";
  public static final int DEFAULT_MODULE_HEIGHT = 200;
  public static final int DEFAULT_MODULE_WIDTH = 100;
  public static final int DEFAULT_COLUMN_WIDTH = 200;
  public static final int DEFAULT_MIN_MODULE_WIDTH = 50;
  public static final int DEFAULT_MIN_MODULE_HEIGHT = 50;
  public static final int DEFAULT_MAX_MODULE_WIDTH = 800;
  public static final int DEFAULT_MAX_MODULE_HEIGHT = 800;
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\portal\PortalConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */