package edu.thu.app.portal;

import edu.thu.apm.AppResourceLoader;
import edu.thu.app.portal.config.PortletCompiler;
import edu.thu.app.portal.config.PortletDescriptor;
import edu.thu.core.IResource;
import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.exceptions.StdException;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.SystemServiceContext;
import edu.thu.service.util.ContextHelper;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class PortletManager
  implements PortalConstants
{
  static PortletManager M = new PortletManager();
  static Log O = LogFactory.getLog(PortletManager.class);
  Map N = new Hashtable();
  List Q = new ArrayList();
  int P = 0;
  
  public static PortletManager getInstance()
  {
    return M;
  }
  
  public synchronized void clear()
  {
    this.N.clear();
  }
  
  public synchronized void refresh()
  {
    this.N.clear();
    int j = this.Q.size();
    for (int i = 0; i < j; i++)
    {
      String str = (String)this.Q.get(i);
      addDefinitionFromVirtualPath(str);
    }
  }
  
  public void addDefinition(IResource paramIResource, boolean paramBoolean)
  {
    Object localObject1 = ContextHelper.loadCpObject(paramIResource.getPath());
    if ((localObject1 instanceof Map)) {
      addPortlets(((Map)localObject1).values(), paramBoolean);
    } else if ((localObject1 instanceof PortletDescriptor)) {
      A((PortletDescriptor)localObject1, paramBoolean);
    } else if (localObject1 != null) {
      throw Exceptions.code("portal.CAN_err_invalid_cp_portlet").param(paramIResource.getPath()).param(localObject1);
    }
    if (localObject1 != null) {
      return;
    }
    TreeNode localTreeNode = ContextHelper.loadXml(paramIResource.getPath());
    if (localTreeNode == null)
    {
      Debug.trace("portal.CAN_err_null_definition::" + paramIResource.getPath());
      return;
    }
    String str = localTreeNode.getName();
    Object localObject2;
    if (str.equals("portlets"))
    {
      localObject2 = PortletCompiler.getInstance().compilePortlets(localTreeNode, SystemServiceContext.getInstance());
      addPortlets(((Map)localObject2).values(), paramBoolean);
    }
    else
    {
      localObject2 = PortletCompiler.getInstance().compilePortlet(localTreeNode, SystemServiceContext.getInstance());
      A((PortletDescriptor)localObject2, paramBoolean);
    }
  }
  
  public synchronized void addDefinitionFromVirtualPath(String paramString)
  {
    Collection localCollection = AppResourceLoader.getInstance().getAllCustomizableResources(paramString, ".ptl.xml").values();
    Iterator localIterator = localCollection.iterator();
    while (localIterator.hasNext())
    {
      IResource localIResource = (IResource)localIterator.next();
      addDefinition(localIResource, true);
    }
    if (!this.Q.contains(paramString)) {
      this.Q.add(paramString);
    }
  }
  
  void A(PortletDescriptor paramPortletDescriptor, boolean paramBoolean)
  {
    if (this.N.containsKey(paramPortletDescriptor.getId())) {
      if (paramBoolean) {
        O.info("portal.CAN_duplicate_portlet::" + paramPortletDescriptor.getId());
      } else {
        throw Exceptions.code("portal.CAN_err_duplicate_portlet_id").param(paramPortletDescriptor.getId());
      }
    }
    this.N.put(paramPortletDescriptor.getId(), paramPortletDescriptor);
  }
  
  public void addPortlets(Collection paramCollection, boolean paramBoolean)
  {
    if (paramCollection == null) {
      return;
    }
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      PortletDescriptor localPortletDescriptor = (PortletDescriptor)localIterator.next();
      A(localPortletDescriptor, paramBoolean);
    }
  }
  
  public String generatePortletId()
  {
    String str;
    do
    {
      str = "portlet" + this.P++;
    } while (getPortlet(str) == null);
    return str;
  }
  
  public PortletDescriptor getPortlet(String paramString)
  {
    if (paramString == null)
    {
      Debug.traceErr("portal.CAN_err_null_portlet_id");
      return null;
    }
    return (PortletDescriptor)this.N.get(paramString);
  }
  
  public List getPortletListByLayoutNo(int paramInt)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = this.N.values().iterator();
    while (localIterator.hasNext())
    {
      PortletDescriptor localPortletDescriptor = (PortletDescriptor)localIterator.next();
      int i = localPortletDescriptor.getLayoutNo();
      if ((i >= paramInt * 100) && (i < (paramInt + 1) * 100)) {
        localArrayList.add(localPortletDescriptor);
      }
    }
    return localArrayList;
  }
  
  public PortletDescriptor getPortletByLayoutNo(int paramInt)
  {
    Iterator localIterator = this.N.values().iterator();
    while (localIterator.hasNext())
    {
      PortletDescriptor localPortletDescriptor = (PortletDescriptor)localIterator.next();
      int i = localPortletDescriptor.getLayoutNo();
      if (paramInt == i) {
        return localPortletDescriptor;
      }
    }
    return null;
  }
  
  public void removePortlet(String paramString)
  {
    if (paramString == null) {
      return;
    }
    this.N.remove(paramString);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\portal\PortletManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */