package edu.thu.app.pref;

import java.io.Serializable;

public class EntityPrefKey
  implements Serializable
{
  private static final long serialVersionUID = 2286872547088479224L;
  String B;
  String A;
  String C;
  
  public EntityPrefKey(String paramString1, String paramString2, String paramString3)
  {
    setType(paramString1);
    setEntityName(paramString2);
    setField(paramString3);
  }
  
  public String getEntityName()
  {
    return this.A;
  }
  
  public void setEntityName(String paramString)
  {
    if (paramString == null) {
      paramString = "";
    }
    this.A = paramString;
  }
  
  public String getField()
  {
    return this.C;
  }
  
  public void setField(String paramString)
  {
    if (paramString == null) {
      paramString = "";
    }
    this.C = paramString;
  }
  
  public String getType()
  {
    return this.B;
  }
  
  public void setType(String paramString)
  {
    if (paramString == null) {
      paramString = "";
    }
    this.B = paramString;
  }
  
  public int hashCode()
  {
    return this.B.hashCode() + this.A.hashCode() + this.C.hashCode();
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof EntityPrefKey)) {
      return false;
    }
    EntityPrefKey localEntityPrefKey = (EntityPrefKey)paramObject;
    return (this.B.equals(localEntityPrefKey.getType())) && (this.A.equals(localEntityPrefKey.getEntityName())) && (this.C.equals(localEntityPrefKey.getField()));
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\pref\EntityPrefKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */