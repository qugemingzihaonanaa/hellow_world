package edu.thu.app.pref;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class EntityPrefConfig
  implements Serializable
{
  private static final long serialVersionUID = -4174777178585998910L;
  String D;
  String B;
  PrefAction F;
  PrefAction E;
  Map<String, PrefAction> A = new HashMap();
  Map<String, PrefAction> C = new HashMap();
  
  public String toString()
  {
    return this.D + "-" + this.B;
  }
  
  public String getEntityName()
  {
    return this.B;
  }
  
  public void setEntityName(String paramString)
  {
    this.B = paramString;
  }
  
  public String getType()
  {
    return this.D;
  }
  
  public void setType(String paramString)
  {
    this.D = paramString;
  }
  
  public PrefAction getLoadAction()
  {
    return this.E;
  }
  
  public void setLoadAction(PrefAction paramPrefAction)
  {
    this.E = paramPrefAction;
  }
  
  public PrefAction getSaveAction()
  {
    return this.F;
  }
  
  public void setSaveAction(PrefAction paramPrefAction)
  {
    this.F = paramPrefAction;
  }
  
  public Map<String, PrefAction> getFieldLoadActions()
  {
    return this.C;
  }
  
  public void setFieldLoadActions(Map<String, PrefAction> paramMap)
  {
    this.C = paramMap;
  }
  
  public Map<String, PrefAction> getFieldSaveActions()
  {
    return this.A;
  }
  
  public void setFieldSaveActions(Map<String, PrefAction> paramMap)
  {
    this.A = paramMap;
  }
  
  public void addFieldSaveAction(String paramString, PrefAction paramPrefAction)
  {
    this.A.put(paramString, paramPrefAction);
  }
  
  public void addFieldLoadAction(String paramString, PrefAction paramPrefAction)
  {
    this.C.put(paramString, paramPrefAction);
  }
  
  public PrefAction getFieldSaveAction(String paramString)
  {
    return (PrefAction)this.A.get(paramString);
  }
  
  public PrefAction getFieldLoadAction(String paramString)
  {
    return (PrefAction)this.C.get(paramString);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\pref\EntityPrefConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */