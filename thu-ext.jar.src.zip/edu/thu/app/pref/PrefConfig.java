package edu.thu.app.pref;

import edu.thu.apm.AppResourceLoader;
import edu.thu.core.IResource;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IVariant;
import edu.thu.lang.exceptions.StdException;
import edu.thu.lang.util.TplC;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceCall;
import edu.thu.service.IServiceContext;
import edu.thu.tools.cp.tpl.AbstractConfigParser;
import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class PrefConfig
  implements Serializable, PrefConfigConstants
{
  private static final long serialVersionUID = -895043507794035457L;
  Map<String, EntityPrefConfig> A = new HashMap();
  
  protected String getEntityKey(String paramString1, String paramString2)
  {
    return paramString1 + "-" + paramString2;
  }
  
  public EntityPrefConfig getEntityConfig(String paramString1, String paramString2)
  {
    if ((paramString1 == null) || (paramString1.equals("default"))) {
      return (EntityPrefConfig)this.A.get(getEntityKey("default", paramString2));
    }
    EntityPrefConfig localEntityPrefConfig = (EntityPrefConfig)this.A.get(getEntityKey(paramString1, paramString2));
    if (localEntityPrefConfig == null) {
      localEntityPrefConfig = (EntityPrefConfig)this.A.get(getEntityKey(paramString1, paramString2));
    }
    return localEntityPrefConfig;
  }
  
  EntityPrefConfig A(String paramString1, String paramString2)
  {
    if (paramString1 == null) {
      paramString1 = "default";
    }
    String str = getEntityKey(paramString1, paramString2);
    EntityPrefConfig localEntityPrefConfig = (EntityPrefConfig)this.A.get(str);
    if (localEntityPrefConfig == null)
    {
      localEntityPrefConfig = new EntityPrefConfig();
      localEntityPrefConfig.setType(paramString1);
      localEntityPrefConfig.setEntityName(paramString2);
      this.A.put(str, localEntityPrefConfig);
    }
    return localEntityPrefConfig;
  }
  
  public void clear()
  {
    this.A.clear();
  }
  
  public void loadFromVirtualPath(String paramString)
  {
    clear();
    Collection localCollection = AppResourceLoader.getInstance().getAllCustomizableResources(paramString, ".pref.xml").values();
    Iterator localIterator = localCollection.iterator();
    while (localIterator.hasNext())
    {
      IResource localIResource = (IResource)localIterator.next();
      loadFromFile(localIResource);
    }
  }
  
  void A(TreeNode paramTreeNode)
  {
    Map localMap = paramTreeNode.getAttributes();
    if (localMap == null) {
      return;
    }
    if (!PREF_ACTION_ATTRS.containsAll(localMap.keySet())) {
      throw Exceptions.code("pref.CAN_err_invalid_action_arg").param(PREF_ACTION_ATTRS).param(paramTreeNode);
    }
  }
  
  void A(TreeNode paramTreeNode, TplC paramTplC, IServiceContext paramIServiceContext)
  {
    A(paramTreeNode);
    String str1 = paramTreeNode.attribute("type").stripedStringValue("default");
    String str2 = paramTreeNode.attribute("entityName").stripedStringValue();
    String str3 = paramTreeNode.attribute("field").stripedStringValue();
    boolean bool1 = paramTreeNode.attribute("ignoreNull").booleanValue(true);
    boolean bool2 = paramTreeNode.attribute("sysPref").booleanValue(false);
    if (str2 == null) {
      throw Exceptions.code("pref.CAN_err_pref_action_no_entityName").param(paramTreeNode);
    }
    IServiceCall localIServiceCall = TplC.toServiceCall(paramTplC.compileBody(paramTreeNode, null, paramIServiceContext));
    PrefAction localPrefAction = new PrefAction(localIServiceCall, bool1, bool2);
    boolean bool3 = paramTreeNode.getName().equals("load");
    EntityPrefConfig localEntityPrefConfig = A(str1, str2);
    if (str3 == null)
    {
      if (bool3)
      {
        if (localEntityPrefConfig.getLoadAction() != null) {
          throw Exceptions.code("pref.CAN_err_duplicate_pref_entity_load").param(localEntityPrefConfig).param(paramTreeNode);
        }
        localEntityPrefConfig.setLoadAction(localPrefAction);
      }
      else
      {
        if (localEntityPrefConfig.getSaveAction() != null) {
          throw Exceptions.code("pref.CAN_err_duplicate_pref_entity_save").param(localEntityPrefConfig).param(paramTreeNode);
        }
        localEntityPrefConfig.setSaveAction(localPrefAction);
      }
    }
    else if (bool3)
    {
      if (localEntityPrefConfig.getFieldLoadAction(str3) != null) {
        throw Exceptions.code("pref.CAN_err_duplicate_pref_entity_field_load").param(localEntityPrefConfig).param(paramTreeNode);
      }
      localEntityPrefConfig.addFieldLoadAction(str3, localPrefAction);
    }
    else
    {
      if (localEntityPrefConfig.getFieldSaveAction(str3) != null) {
        throw Exceptions.code("pref.CAN_err_duplicate_pref_entity_field_save").param(localEntityPrefConfig).param(paramTreeNode);
      }
      localEntityPrefConfig.addFieldSaveAction(str3, localPrefAction);
    }
  }
  
  public void loadFromFile(IResource paramIResource)
  {
    new PrefConfigParser().parseFromResource(paramIResource, false);
  }
  
  public class PrefConfigParser
    extends AbstractConfigParser<Object>
  {
    public PrefConfigParser() {}
    
    protected TreeNode mergeMainNode(TreeNode paramTreeNode1, TreeNode paramTreeNode2)
    {
      return paramTreeNode1;
    }
    
    protected Object doParse(TreeNode paramTreeNode, IServiceContext paramIServiceContext)
    {
      paramTreeNode = prepareNode(paramTreeNode, paramIServiceContext);
      TplC localTplC = newTplC(paramTreeNode, paramIServiceContext);
      int j = paramTreeNode.getChildCount();
      for (int i = 0; i < j; i++)
      {
        TreeNode localTreeNode = paramTreeNode.getChild(i);
        String str = localTreeNode.getName();
        if (str.equals("config")) {
          localTplC.run(localTreeNode, paramIServiceContext);
        } else if (str.equals("save")) {
          PrefConfig.this.A(localTreeNode, localTplC, paramIServiceContext);
        } else if (str.equals("load")) {
          PrefConfig.this.A(localTreeNode, localTplC, paramIServiceContext);
        } else {
          throw Exceptions.code("pref.CAN_err_unknown_pref_config").param(localTreeNode);
        }
      }
      return paramTreeNode;
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\pref\PrefConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */