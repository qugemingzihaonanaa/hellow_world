package edu.thu.app.pref;

import edu.thu.service.IServiceCall;
import edu.thu.service.IServiceContext;
import java.io.Serializable;
import java.util.Map;

public class PrefAction
  implements Serializable
{
  private static final long serialVersionUID = -6199790151666918194L;
  IServiceCall C;
  boolean A;
  boolean B;
  
  public PrefAction(IServiceCall paramIServiceCall, boolean paramBoolean1, boolean paramBoolean2)
  {
    this.C = paramIServiceCall;
    this.A = paramBoolean1;
    this.B = paramBoolean2;
  }
  
  public Object transformValue(Object paramObject, Map<String, Object> paramMap, IServiceContext paramIServiceContext)
  {
    if (this.C == null) {
      return paramObject;
    }
    paramMap.put("value", paramObject);
    return this.C.invoke(paramMap, paramIServiceContext);
  }
  
  public void invoke(Map<String, Object> paramMap, IServiceContext paramIServiceContext)
  {
    if (this.C == null) {
      return;
    }
    paramMap.remove("value");
    this.C.invoke(paramMap, paramIServiceContext);
  }
  
  public IServiceCall getAction()
  {
    return this.C;
  }
  
  public void setAction(IServiceCall paramIServiceCall)
  {
    this.C = paramIServiceCall;
  }
  
  public boolean isIgnoreNull()
  {
    return this.A;
  }
  
  public void setIgnoreNull(boolean paramBoolean)
  {
    this.A = paramBoolean;
  }
  
  public boolean isSysPref()
  {
    return this.B;
  }
  
  public void setSysPref(boolean paramBoolean)
  {
    this.B = paramBoolean;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\pref\PrefAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */