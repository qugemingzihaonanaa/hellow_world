package edu.thu.app.pref;

import java.util.Arrays;
import java.util.List;

public abstract interface PrefConfigConstants
{
  public static final String DEFAULT_NAME = "default";
  public static final String TYPE_ADD = "add";
  public static final String TYPE_UPDATE = "update";
  public static final String PREF_POSTFIX = ".pref.xml";
  public static final String TYPE_NAME = "type";
  public static final String ENTITY_NAME_NAME = "entityName";
  public static final String FIELD_NAME = "field";
  public static final String IGNORE_NULL_NAME = "ignoreNull";
  public static final String SYS_PREF_NAME = "sysPref";
  public static final String CONFIG_NAME = "config";
  public static final String LOAD_NAME = "load";
  public static final String SAVE_NAME = "save";
  public static final String VAR_ENTITY = "entity";
  public static final String VAR_VALUE = "value";
  public static final String SYS_VAR_CONTEXT = "$context";
  public static final String VAR_PREF_KEY = "prefKey";
  public static final String VAR_UPDATE_VALUES = "updateValues";
  public static final String PREF_HELPER_NAME = "prefHelper";
  public static final List<String> PREF_ACTION_ATTRS = Arrays.asList(new String[] { "type", "entityName", "field", "ignoreNull", "sysPref" });
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\pref\PrefConfigConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */