package edu.thu.app.pref;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.util.ClassUtils;
import edu.thu.java.util.MethodUtils;
import edu.thu.model.tree.IXObject;
import edu.thu.model.tree.TreeNode;
import edu.thu.xml.dom.DomToTree;
import java.io.Serializable;

public class PreferenceNode
  implements Serializable
{
  private static final long serialVersionUID = 5726936788719748183L;
  String B;
  String A;
  
  public PreferenceNode() {}
  
  public PreferenceNode(Object paramObject)
  {
    fromObject(paramObject);
  }
  
  public String getClassName()
  {
    return this.B;
  }
  
  public void setClassName(String paramString)
  {
    this.B = paramString;
  }
  
  public String getXml()
  {
    return this.A;
  }
  
  public void setXml(String paramString)
  {
    this.A = paramString;
  }
  
  public Object toObject()
  {
    if (this.A == null) {
      return null;
    }
    TreeNode localTreeNode = DomToTree.getInstance().allowText(true).transform(this.A);
    if (this.B == null) {
      return localTreeNode;
    }
    Object localObject = ClassUtils.stringToObject(this.B);
    MethodUtils.invokeExactMethod(localObject, "fromNode", new Class[] { TreeNode.class }, new Object[] { localTreeNode });
    return localObject;
  }
  
  public void fromObject(Object paramObject)
  {
    if (paramObject == null)
    {
      this.A = null;
      return;
    }
    if (!(paramObject instanceof IXObject)) {
      throw Exceptions.code("pref.CAN_err_not_xobject").param(paramObject);
    }
    if ((paramObject instanceof TreeNode))
    {
      this.A = ((TreeNode)paramObject).toXml();
      this.B = null;
      return;
    }
    TreeNode localTreeNode = ((IXObject)paramObject).toNode();
    this.A = localTreeNode.toXml();
    this.B = paramObject.getClass().getName();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\app\pref\PreferenceNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */