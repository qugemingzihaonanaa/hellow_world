package edu.thu.io.le;

import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public final class LEDataOutputStream
  implements DataOutput
{
  private static final String A = "copyright (c) 1999-2008 Roedy Green, Canadian Mind Products, http://mindprod.com";
  protected final DataOutputStream dis;
  protected final byte[] work;
  
  public LEDataOutputStream(OutputStream paramOutputStream)
  {
    this.dis = new DataOutputStream(paramOutputStream);
    this.work = new byte[8];
  }
  
  public final void close()
    throws IOException
  {
    this.dis.close();
  }
  
  public void flush()
    throws IOException
  {
    this.dis.flush();
  }
  
  public final int size()
  {
    return this.dis.size();
  }
  
  public final synchronized void write(int paramInt)
    throws IOException
  {
    this.dis.write(paramInt);
  }
  
  public final void write(byte[] paramArrayOfByte)
    throws IOException
  {
    this.dis.write(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public final synchronized void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    this.dis.write(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  public final void writeBoolean(boolean paramBoolean)
    throws IOException
  {
    this.dis.writeBoolean(paramBoolean);
  }
  
  public final void writeByte(int paramInt)
    throws IOException
  {
    this.dis.writeByte(paramInt);
  }
  
  public final void writeBytes(String paramString)
    throws IOException
  {
    this.dis.writeBytes(paramString);
  }
  
  public final void writeChar(int paramInt)
    throws IOException
  {
    this.work[0] = ((byte)paramInt);
    this.work[1] = ((byte)(paramInt >> 8));
    this.dis.write(this.work, 0, 2);
  }
  
  public final void writeChars(String paramString)
    throws IOException
  {
    int i = paramString.length();
    for (int j = 0; j < i; j++) {
      writeChar(paramString.charAt(j));
    }
  }
  
  public final void writeDouble(double paramDouble)
    throws IOException
  {
    writeLong(Double.doubleToLongBits(paramDouble));
  }
  
  public final void writeFloat(float paramFloat)
    throws IOException
  {
    writeInt(Float.floatToIntBits(paramFloat));
  }
  
  public final void writeInt(int paramInt)
    throws IOException
  {
    this.work[0] = ((byte)paramInt);
    this.work[1] = ((byte)(paramInt >> 8));
    this.work[2] = ((byte)(paramInt >> 16));
    this.work[3] = ((byte)(paramInt >> 24));
    this.dis.write(this.work, 0, 4);
  }
  
  public final void writeLong(long paramLong)
    throws IOException
  {
    this.work[0] = ((byte)(int)paramLong);
    this.work[1] = ((byte)(int)(paramLong >> 8));
    this.work[2] = ((byte)(int)(paramLong >> 16));
    this.work[3] = ((byte)(int)(paramLong >> 24));
    this.work[4] = ((byte)(int)(paramLong >> 32));
    this.work[5] = ((byte)(int)(paramLong >> 40));
    this.work[6] = ((byte)(int)(paramLong >> 48));
    this.work[7] = ((byte)(int)(paramLong >> 56));
    this.dis.write(this.work, 0, 8);
  }
  
  public final void writeShort(int paramInt)
    throws IOException
  {
    this.work[0] = ((byte)paramInt);
    this.work[1] = ((byte)(paramInt >> 8));
    this.dis.write(this.work, 0, 2);
  }
  
  public final void writeUTF(String paramString)
    throws IOException
  {
    this.dis.writeUTF(paramString);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\io\le\LEDataOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */