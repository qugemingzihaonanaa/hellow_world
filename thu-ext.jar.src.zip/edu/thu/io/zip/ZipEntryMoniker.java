package edu.thu.io.zip;

import edu.thu.global.exceptions.Exceptions;
import edu.thu.model.stg.IBinaryStreamMoniker;
import java.io.InputStream;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class ZipEntryMoniker
  implements IBinaryStreamMoniker
{
  private static final long serialVersionUID = 604611872333016082L;
  ZipFile zipFile;
  ZipEntry zipEntry;
  
  public ZipEntryMoniker(ZipFile paramZipFile, ZipEntry paramZipEntry)
  {
    this.zipFile = paramZipFile;
    this.zipEntry = paramZipEntry;
  }
  
  public long getContentLength()
  {
    return this.zipEntry.getSize();
  }
  
  public InputStream getInputStream()
  {
    try
    {
      return this.zipFile.getInputStream(this.zipEntry);
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
  }
  
  /* Error */
  public void saveTo(java.io.File paramFile)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 57	edu/thu/io/zip/ZipEntryMoniker:getInputStream	()Ljava/io/InputStream;
    //   4: astore_2
    //   5: aload_1
    //   6: aload_2
    //   7: invokestatic 59	edu/thu/util/FileUtils:save	(Ljava/io/File;Ljava/io/InputStream;)V
    //   10: goto +10 -> 20
    //   13: astore_3
    //   14: aload_2
    //   15: invokestatic 65	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/InputStream;)V
    //   18: aload_3
    //   19: athrow
    //   20: aload_2
    //   21: invokestatic 65	edu/thu/io/util/IoUtils:safeClose	(Ljava/io/InputStream;)V
    //   24: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	25	0	this	ZipEntryMoniker
    //   0	25	1	paramFile	java.io.File
    //   4	17	2	localInputStream	InputStream
    //   13	6	3	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   5	13	13	finally
  }
  
  public String getReferenceName()
  {
    return this.zipEntry.getName();
  }
  
  public Map<String, Object> getAttributes()
  {
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\io\zip\ZipEntryMoniker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */