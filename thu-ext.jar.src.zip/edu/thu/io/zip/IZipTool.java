package edu.thu.io.zip;

import edu.thu.model.stg.IBinaryStreamMoniker;
import java.io.File;

public abstract interface IZipTool
{
  public abstract IBinaryStreamMoniker getEntry(File paramFile, String paramString);
  
  public abstract void zipDirToFile(File paramFile1, File paramFile2, String paramString);
  
  public abstract void unzipFileToDir(File paramFile1, File paramFile2);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\io\zip\IZipTool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */