package edu.thu.io.zip;

import edu.thu.global.exceptions.Exceptions;
import edu.thu.io.util.IoUtils;
import edu.thu.model.stg.IBinaryStreamMoniker;
import edu.thu.util.ZipFileHelper;
import edu.thu.vfs.IFile;
import edu.thu.vfs.IFileFilter;
import edu.thu.vfs.spi.local.LocalFile;
import edu.thu.vfs.spi.local.LocalFileSystem;
import java.io.File;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class ZipTool
  implements IZipTool
{
  public IBinaryStreamMoniker getEntry(File paramFile, String paramString)
  {
    ZipFile localZipFile = null;
    InputStream localInputStream = null;
    try
    {
      localZipFile = ZipFileHelper.newZipFile(paramFile, 1, null);
      ZipEntry localZipEntry = localZipFile.getEntry(paramString);
      if (localZipEntry == null) {
        return null;
      }
      ZipEntryMoniker localZipEntryMoniker = new ZipEntryMoniker(localZipFile, localZipEntry);
      return localZipEntryMoniker;
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
    finally
    {
      IoUtils.safeClose(localInputStream);
    }
  }
  
  public void zipDirToFile(File paramFile1, File paramFile2, String paramString)
  {
    LocalFileSystem.getInstance().zipToFile(paramFile1.getAbsolutePath(), paramFile2.getAbsolutePath(), new IFileFilter()
    {
      public boolean accept(IFile paramAnonymousIFile)
      {
        return !paramAnonymousIFile.getName().equals(".svn");
      }
    });
  }
  
  public void unzipFileToDir(File paramFile1, File paramFile2)
  {
    paramFile2.mkdirs();
    LocalFileSystem.getInstance().unzipToDir(new LocalFile(paramFile1), new LocalFile(paramFile2));
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\io\zip\ZipTool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */