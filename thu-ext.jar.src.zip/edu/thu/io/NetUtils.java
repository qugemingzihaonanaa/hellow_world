package edu.thu.io;

import edu.thu.global.Debug;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;

public class NetUtils
{
  public static boolean isNetConnected()
  {
    try
    {
      Enumeration localEnumeration1 = NetworkInterface.getNetworkInterfaces();
      while (localEnumeration1.hasMoreElements())
      {
        NetworkInterface localNetworkInterface = (NetworkInterface)localEnumeration1.nextElement();
        Enumeration localEnumeration2 = localNetworkInterface.getInetAddresses();
        while (localEnumeration2.hasMoreElements())
        {
          InetAddress localInetAddress = (InetAddress)localEnumeration2.nextElement();
          if (!localInetAddress.isLoopbackAddress()) {
            return true;
          }
        }
      }
      return false;
    }
    catch (Exception localException) {}
    return false;
  }
  
  public static void main(String[] paramArrayOfString)
  {
    boolean bool = isNetConnected();
    Debug.trace(Boolean.valueOf(bool));
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\io\NetUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */