package edu.thu.lang.xconfig;

import edu.thu.apm.AppResourceLoader;
import edu.thu.core.IResource;
import edu.thu.lang.IVariant;
import edu.thu.lang.util.TplC;
import edu.thu.model.stg.ds.DataSourceMeta;
import edu.thu.model.stg.ds.spi.FieldMeta;
import edu.thu.model.stg.ds.spi.cp.DsMetaXParserFactory;
import edu.thu.model.stg.ds.spi.cp.IDsMetaXParser;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceContext;
import edu.thu.service.SystemServiceContext;
import edu.thu.xml.dom.DomToTree;
import java.io.File;
import java.util.Map;

public abstract class AbstractXParser<T>
  extends AbstractXConfigParser<T>
{
  DataSourceMeta dsMeta;
  
  public AbstractXParser(String paramString)
  {
    super(paramString);
  }
  
  public DataSourceMeta getDsMeta()
  {
    return this.dsMeta;
  }
  
  public void setDsMeta(DataSourceMeta paramDataSourceMeta)
  {
    this.dsMeta = paramDataSourceMeta;
  }
  
  protected boolean loadDsMeta(TreeNode paramTreeNode)
  {
    if (paramTreeNode.existingChild("dsMeta") == null) {
      return false;
    }
    String str = paramTreeNode.makeChild("dsMeta").stripedStringValue();
    if (str == null) {
      return false;
    }
    this.dsMeta = DataSourceMeta.load(str, SystemServiceContext.getInstance());
    return true;
  }
  
  protected <R> Map<String, R> mergeMap(Map<String, R> paramMap1, Map<String, R> paramMap2)
  {
    if (paramMap1 == null) {
      return paramMap2;
    }
    if (paramMap2 == null) {
      return paramMap1;
    }
    paramMap2.putAll(paramMap1);
    return paramMap2;
  }
  
  protected Map<String, FieldMeta> compileFields(TreeNode paramTreeNode, TplC paramTplC, IServiceContext paramIServiceContext)
  {
    TreeNode localTreeNode = paramTreeNode.existingChild("fields");
    Map localMap = null;
    if (localTreeNode != null)
    {
      IDsMetaXParser localIDsMetaXParser = DsMetaXParserFactory.newParser();
      localIDsMetaXParser.setTplC(paramTplC);
      localMap = localIDsMetaXParser.compileFields(localTreeNode, paramIServiceContext);
    }
    return localMap;
  }
  
  public T parseVirtualFile(String paramString)
  {
    return (T)parseVirtualFile(paramString, false);
  }
  
  @Deprecated
  public T parseVirtualFile(String paramString, boolean paramBoolean)
  {
    IResource localIResource = AppResourceLoader.getInstance().getCustomizableResource(paramString);
    return (T)parseFromResource(localIResource, paramBoolean);
  }
  
  public Object parseFile(File paramFile)
  {
    return doParse(DomToTree.getInstance().allowText(true).transform(paramFile), SystemServiceContext.getInstance());
  }
  
  public String parseName(TreeNode paramTreeNode)
  {
    String str = paramTreeNode.attribute("name").stripedStringValue();
    if ((str != null) && (str.startsWith("*"))) {
      str = str.substring(1);
    }
    return str;
  }
  
  public String parseSpecName(TreeNode paramTreeNode, String paramString)
  {
    String str = paramTreeNode.attribute(paramString).stripedStringValue();
    if ((str != null) && (str.startsWith("*"))) {
      str = str.substring(1);
    }
    return str;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\lang\xconfig\AbstractXParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */