package edu.thu.lang.util;

import edu.thu.lang.el.IExpressionReference;
import edu.thu.model.Pair;
import edu.thu.model.data.IListData;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

public abstract interface IWrapCollection
  extends IListData<Object>
{
  public static final String VAR_ITEM = "item";
  public static final String VAR_IDX = "idx";
  public static final String VAR_ITEM1 = "item1";
  public static final String VAR_ITEM2 = "item2";
  
  public abstract int indexOf(Object paramObject);
  
  public abstract int indexOf(Object paramObject, int paramInt);
  
  public abstract int lastIndexOf(Object paramObject);
  
  public abstract int lastIndexOf(Object paramObject, int paramInt);
  
  public abstract boolean every(IExpressionReference paramIExpressionReference);
  
  public abstract boolean some(IExpressionReference paramIExpressionReference);
  
  public abstract Object first();
  
  public abstract IWrapCollection first(int paramInt);
  
  public abstract Object last();
  
  public abstract IWrapCollection last(int paramInt);
  
  public abstract IWrapCollection initial();
  
  public abstract IWrapCollection initial(int paramInt);
  
  public abstract IWrapCollection rest();
  
  public abstract IWrapCollection rest(int paramInt);
  
  public abstract Object find(IExpressionReference paramIExpressionReference);
  
  public abstract Object findByFld(String paramString, Object paramObject);
  
  public abstract IWrapCollection pluck(String paramString);
  
  public abstract IWrapCollection pluckUnique(String paramString);
  
  public abstract IWrapCollection pluckWithDefault(String paramString, Object paramObject);
  
  public abstract IWrapCollection pluckWithKeyMap(Map<String, String> paramMap);
  
  public abstract IWrapCollection each(IExpressionReference paramIExpressionReference);
  
  public abstract IWrapCollection map(IExpressionReference paramIExpressionReference);
  
  public abstract IWrapCollection collectUnique(IExpressionReference paramIExpressionReference);
  
  public abstract IWrapCollection flatMap(IExpressionReference paramIExpressionReference);
  
  public abstract IWrapCollection filter(IExpressionReference paramIExpressionReference);
  
  public abstract IWrapCollection filterByFld(String paramString, Object paramObject);
  
  public abstract IWrapCollection filterByFldValues(String paramString, Collection<?> paramCollection);
  
  public abstract IWrapCollection reverse();
  
  public abstract IWrapCollection sort();
  
  public abstract IWrapCollection sort(boolean paramBoolean);
  
  public abstract IWrapCollection sortByFld(String paramString, boolean paramBoolean);
  
  public abstract IWrapCollection sortBy(IExpressionReference paramIExpressionReference);
  
  public abstract IWrapCollection cloneInstance();
  
  public abstract Object reduce(IExpressionReference paramIExpressionReference, Object paramObject);
  
  public abstract Object reduce(IExpressionReference paramIExpressionReference);
  
  public abstract Object reduceRight(IExpressionReference paramIExpressionReference, Object paramObject);
  
  public abstract Object reduceRight(IExpressionReference paramIExpressionReference);
  
  public abstract boolean contains(Object paramObject);
  
  public abstract boolean containsAll(Collection<?> paramCollection);
  
  public abstract IWrapCollection reject(IExpressionReference paramIExpressionReference);
  
  public abstract IWrapCollection rejectByFld(String paramString, Object paramObject);
  
  public abstract IWrapCollection rejectAll(Collection<?> paramCollection);
  
  public abstract IWrapCollection rejectAfter(IExpressionReference paramIExpressionReference, boolean paramBoolean);
  
  public abstract IWrapCollection rejectBefore(IExpressionReference paramIExpressionReference, boolean paramBoolean);
  
  public abstract Number max();
  
  public abstract Number max(IExpressionReference paramIExpressionReference);
  
  public abstract Number min();
  
  public abstract Number min(IExpressionReference paramIExpressionReference);
  
  public abstract Object maxObj();
  
  public abstract Object minObj();
  
  public abstract Map<Object, List<Object>> groupByFld(String paramString);
  
  public abstract Map<Object, List<Object>> groupBy(IExpressionReference paramIExpressionReference);
  
  public abstract Map<Object, Object> indexByFld(String paramString);
  
  public abstract Map<Object, Object> indexBy(IExpressionReference paramIExpressionReference);
  
  public abstract IWrapCollection invoke(String paramString);
  
  public abstract IWrapCollection invoke(String paramString, Object[] paramArrayOfObject);
  
  public abstract IWrapCollection call(String paramString);
  
  public abstract IWrapCollection call(String paramString, Object[] paramArrayOfObject);
  
  public abstract IWrapCollection shuffle();
  
  public abstract Object sample();
  
  public abstract Object sample(int paramInt);
  
  public abstract Object[] toArray();
  
  public abstract <T> Set<T> toSet();
  
  public abstract <T> List<T> toList();
  
  public abstract List<String> toStringList();
  
  public abstract int size();
  
  public abstract boolean isEmpty();
  
  public abstract boolean isNotEmpty();
  
  public abstract Map<Object, Integer> countByFld(String paramString);
  
  public abstract Map<Object, Integer> countBy(IExpressionReference paramIExpressionReference);
  
  public abstract int count(IExpressionReference paramIExpressionReference);
  
  public abstract Pair<List<Object>, List<Object>> partition(IExpressionReference paramIExpressionReference);
  
  public abstract IWrapCollection compact();
  
  public abstract IWrapCollection flattern();
  
  public abstract IWrapCollection without(Collection<?> paramCollection);
  
  public abstract IWrapCollection union(Collection<?> paramCollection);
  
  public abstract IWrapCollection addAll(Collection<?> paramCollection);
  
  public abstract IWrapCollection intersection(Collection<?> paramCollection);
  
  public abstract IWrapCollection difference(Collection<?> paramCollection);
  
  public abstract IWrapCollection zip();
  
  public abstract IWrapCollection unzip();
  
  public abstract IWrapCollection unique();
  
  @Deprecated
  public abstract IWrapCollection removeDuplicate();
  
  public abstract IWrapCollection unique(boolean paramBoolean);
  
  public abstract String join();
  
  public abstract String join(String paramString);
  
  public abstract IWrapCollection subList(int paramInt);
  
  public abstract IWrapCollection subList(int paramInt1, int paramInt2);
  
  public abstract Number sum();
  
  public abstract Number sum(String paramString);
  
  public abstract Number avg();
  
  public abstract Number avg(String paramString);
  
  public abstract Number weightAvg(String paramString1, String paramString2);
  
  public abstract IWrapCollection pad(IExpressionReference paramIExpressionReference, int paramInt, Object paramObject);
  
  public abstract List<List<Object>> splitBySize(int paramInt);
  
  public abstract List<List<Object>> splitBySize(int paramInt, boolean paramBoolean);
  
  public abstract IWrapCollection round(int paramInt);
  
  public abstract <T> List<T> listValue();
  
  public abstract Object objectValue();
  
  public abstract IWrapCollection removeAll(Collection<?> paramCollection);
  
  public abstract IWrapCollection retainAll(Collection<?> paramCollection);
  
  public abstract IWrapCollection remove(Object paramObject);
  
  public abstract IWrapCollection removeByFld(String paramString, Object paramObject);
  
  public abstract IWrapCollection removeBy(IExpressionReference paramIExpressionReference);
  
  public abstract IWrapCollection removeAfter(IExpressionReference paramIExpressionReference, boolean paramBoolean);
  
  public abstract IWrapCollection removeBefore(IExpressionReference paramIExpressionReference, boolean paramBoolean);
  
  public abstract IWrapCollection updateEach(Map<String, Object> paramMap);
  
  public abstract IWrapCollection findAll(IExpressionReference paramIExpressionReference);
  
  @Deprecated
  public abstract IWrapCollection findMany(String paramString, Object paramObject);
  
  @Deprecated
  public abstract Object findOne(String paramString, Object paramObject);
  
  public abstract void end();
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\lang\util\IWrapCollection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */