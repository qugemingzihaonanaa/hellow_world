package edu.thu.model.entity;

import edu.thu.ext.hibernate.AbstractEntity;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import java.util.Map;

public class MultiEntityProcessor
  implements IEntityProcessor
{
  Map<String, IEntityProcessor> B;
  IEntityProcessor A;
  
  public void setDefaultProcessor(IEntityProcessor paramIEntityProcessor)
  {
    this.A = paramIEntityProcessor;
  }
  
  public void setProcessors(Map<String, IEntityProcessor> paramMap)
  {
    this.B = paramMap;
  }
  
  public String getEntityType(Object paramObject)
  {
    if ((paramObject instanceof AbstractEntity)) {
      return ((AbstractEntity)paramObject).getEntityName_();
    }
    return paramObject.getClass().getName();
  }
  
  public IEntityProcessor getProcessor(String paramString)
  {
    IEntityProcessor localIEntityProcessor = null;
    if (this.B != null) {
      localIEntityProcessor = (IEntityProcessor)this.B.get(paramString);
    }
    if (localIEntityProcessor == null) {
      localIEntityProcessor = this.A;
    }
    if (localIEntityProcessor == null) {
      throw Exceptions.code("dist.CAN_err_unknown_entityType").param(paramString);
    }
    return localIEntityProcessor;
  }
  
  public Object processEntity(Object paramObject)
  {
    if (paramObject == null) {
      return null;
    }
    String str = getEntityType(paramObject);
    IEntityProcessor localIEntityProcessor = getProcessor(str);
    return localIEntityProcessor.processEntity(paramObject);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\MultiEntityProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */