package edu.thu.model.entity;

import edu.thu.service.IClosable;

public abstract interface IEntityStream
  extends IClosable
{
  public abstract int size();
  
  public abstract void setBatchSize(int paramInt);
  
  public abstract Object getNext();
  
  public abstract void skip(int paramInt);
  
  public abstract String getName();
  
  public abstract void setName(String paramString);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\IEntityStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */