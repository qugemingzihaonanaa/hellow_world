package edu.thu.model.entity;

import edu.thu.app.sys.entity.EntityPk;
import edu.thu.core.AppEnv;
import edu.thu.ext.hibernate.AbstractEntity;
import edu.thu.ext.hibernate.AbstractHibernateDao;
import edu.thu.io.NetUtils;
import edu.thu.lang.reflect.BeanInstance;
import edu.thu.orm.dao.IOrmTemplate;
import edu.thu.service.dist.DistConstants;
import edu.thu.service.dist.entity.DistProcHandler;
import edu.thu.service.dist.entity.DistProcRecord;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EntityProcRunnable
  extends AbstractHibernateDao
  implements Runnable
{
  private static final int I = 60000;
  private static final int H = 86400000;
  private static final long serialVersionUID = 489640826906509570L;
  static final Logger logger = LoggerFactory.getLogger(EntityProcRunnable.class);
  boolean checkNetConnected;
  boolean useDistRecord = true;
  List<EntityProcInfo> entityProcList;
  int fixedDelay = 0;
  
  public void setUseDistRecord(boolean paramBoolean)
  {
    this.useDistRecord = paramBoolean;
  }
  
  public void setFixedDelay(int paramInt)
  {
    this.fixedDelay = paramInt;
  }
  
  public void setCheckNetConnected(boolean paramBoolean)
  {
    this.checkNetConnected = paramBoolean;
  }
  
  public void setEntityProcList(List<EntityProcInfo> paramList)
  {
    this.entityProcList = paramList;
  }
  
  public void setEntityProcInfo(EntityProcInfo paramEntityProcInfo)
  {
    this.entityProcList = new ArrayList(1);
    this.entityProcList.add(paramEntityProcInfo);
  }
  
  protected boolean checkReady()
  {
    return (!this.checkNetConnected) || (NetUtils.isNetConnected());
  }
  
  public void run()
  {
    if ((this.entityProcList == null) || (this.entityProcList.isEmpty())) {
      return;
    }
    int i;
    do
    {
      if (!checkReady()) {
        return;
      }
      i = 0;
      int k = this.entityProcList.size();
      for (int j = 0; j < k; j++)
      {
        EntityProcInfo localEntityProcInfo = (EntityProcInfo)this.entityProcList.get(j);
        try
        {
          if (processData(localEntityProcInfo)) {
            i = 1;
          }
        }
        catch (Exception localException)
        {
          logger.error("entity.CAN_err_process_data", localException);
          localException.printStackTrace();
        }
        orm().clearSession();
      }
    } while (i != 0);
  }
  
  boolean processData(EntityProcInfo paramEntityProcInfo)
  {
    List localList = paramEntityProcInfo.B.fetchList();
    if ((localList == null) || (localList.size() < 1)) {
      return false;
    }
    boolean bool = false;
    int j = localList.size();
    for (int i = 0; i < j; i++)
    {
      Object localObject = localList.get(i);
      if (processEntity(paramEntityProcInfo, localObject) != IEntityProcessor.NOT_PROCESS) {
        bool = true;
      }
    }
    orm().flushSession();
    return bool;
  }
  
  protected Object processEntity(EntityProcInfo paramEntityProcInfo, Object paramObject)
  {
    if (this.useDistRecord)
    {
      localObject = DistProcHandler.getInstance();
      DistProcRecord localDistProcRecord = ((DistProcHandler)localObject).getDistProcRecord(getEntityPk(paramObject));
      if ((localDistProcRecord != null) && (!localDistProcRecord.isAllowTry())) {
        return IEntityProcessor.NOT_PROCESS;
      }
    }
    if (!beforeProcess(paramObject)) {
      return IEntityProcessor.NOT_PROCESS;
    }
    Object localObject = null;
    try
    {
      localObject = paramEntityProcInfo.A.processEntity(paramObject);
      processResult(paramObject, localObject);
    }
    catch (Exception localException)
    {
      logger.error("entity.CAN_err_process_result", localException);
      localException.printStackTrace();
    }
    return afterProcess(paramObject, localObject);
  }
  
  protected void processResult(Object paramObject1, Object paramObject2)
  {
    if ((paramObject2 instanceof List))
    {
      List localList = (List)paramObject2;
      if ((localList != null) && (localList.size() >= 0) && (localList.contains(DistConstants.DIST_PROCESS_RESULT_ERROR))) {
        errorProcess(paramObject1);
      }
    }
    if (paramObject2 == DistConstants.DIST_PROCESS_RESULT_ERROR) {
      errorProcess(paramObject1);
    }
  }
  
  protected boolean beforeProcess(Object paramObject)
  {
    return true;
  }
  
  protected Object afterProcess(Object paramObject1, Object paramObject2)
  {
    return paramObject2;
  }
  
  public EntityPk getEntityPk(Object paramObject)
  {
    return ((AbstractEntity)paramObject).getEntityPk();
  }
  
  protected void errorProcess(Object paramObject)
  {
    if (!this.useDistRecord) {
      return;
    }
    DistProcHandler localDistProcHandler = DistProcHandler.getInstance();
    DistProcRecord localDistProcRecord = localDistProcHandler.makeDistProcRecord(getEntityPk(paramObject));
    localDistProcRecord.incTryNum();
    localDistProcRecord.setLastTryTime(new Timestamp(AppEnv.currentTimeMillis()));
    localDistProcRecord.setTryDelay(Integer.valueOf(calcDelay(localDistProcRecord)));
    localDistProcHandler.saveDistProcRecord(localDistProcRecord);
    BeanInstance localBeanInstance = new BeanInstance(paramObject);
    if (localBeanInstance.isWritableProperty("distOrder"))
    {
      Integer localInteger = (Integer)localBeanInstance.getPropertyValue("distOrder");
      if (localInteger == null) {
        localInteger = Integer.valueOf(0);
      }
      localBeanInstance.setPropertyValue("distOrder", Integer.valueOf(localInteger.intValue() + 1));
    }
    if (localDistProcRecord.isTryTooManyTimes()) {
      localBeanInstance.setPropertyValue("distStatus", new Integer(1060));
    }
  }
  
  protected int calcDelay(DistProcRecord paramDistProcRecord)
  {
    if (this.fixedDelay > 0) {
      return this.fixedDelay;
    }
    Integer localInteger = paramDistProcRecord.getTryDelay();
    if (localInteger == null) {
      localInteger = Integer.valueOf(0);
    }
    if (localInteger.intValue() >= 86400000) {
      return 86400000;
    }
    int i = paramDistProcRecord.getTryNum().intValue();
    localInteger = Integer.valueOf((int)(Math.pow(2.0D, i) * 60000.0D));
    if (localInteger.intValue() > 86400000) {
      localInteger = Integer.valueOf(86400000);
    }
    return localInteger.intValue();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\EntityProcRunnable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */