package edu.thu.model.entity;

public abstract interface IEntity
{
  public abstract void entityBeforeSave();
  
  public abstract void entityBeforeUpdate();
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\IEntity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */