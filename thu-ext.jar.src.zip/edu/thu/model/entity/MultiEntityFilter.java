package edu.thu.model.entity;

import edu.thu.search.Query;
import edu.thu.service.IRefreshable;
import edu.thu.service.IServiceContext;
import java.util.ArrayList;
import java.util.List;

public class MultiEntityFilter
  extends AbstractEntityFilter
  implements IRefreshable
{
  List<IEntityFilter> filters;
  
  public MultiEntityFilter() {}
  
  public MultiEntityFilter(List<IEntityFilter> paramList)
  {
    this.filters = paramList;
  }
  
  public void afterInit(IServiceContext paramIServiceContext)
  {
    if (this.filters == null) {
      return;
    }
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IEntityFilter localIEntityFilter = (IEntityFilter)this.filters.get(i);
      localIEntityFilter.afterInit(paramIServiceContext);
    }
  }
  
  public void postProcess(IServiceContext paramIServiceContext)
  {
    if (this.filters == null) {
      return;
    }
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IEntityFilter localIEntityFilter = (IEntityFilter)this.filters.get(i);
      localIEntityFilter.postProcess(paramIServiceContext);
    }
  }
  
  public int getDefaultPageSize(IServiceContext paramIServiceContext)
  {
    if (this.filters == null) {
      return super.getDefaultPageSize(paramIServiceContext);
    }
    int i = super.getDefaultPageSize(paramIServiceContext);
    int k = this.filters.size();
    for (int j = 0; j < k; j++)
    {
      IEntityFilter localIEntityFilter = (IEntityFilter)this.filters.get(j);
      int m = localIEntityFilter.getDefaultPageSize(paramIServiceContext);
      if (m > 0) {
        i = m;
      }
    }
    return i;
  }
  
  public void refresh()
  {
    if (this.filters == null) {
      return;
    }
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      Object localObject = this.filters.get(i);
      if ((localObject instanceof IRefreshable)) {
        ((IRefreshable)localObject).refresh();
      }
    }
  }
  
  public void setFilters(List<IEntityFilter> paramList)
  {
    this.filters = paramList;
  }
  
  public MultiEntityFilter append(IEntityFilter paramIEntityFilter)
  {
    if (this.filters == null) {
      this.filters = new ArrayList();
    }
    this.filters.add(paramIEntityFilter);
    return this;
  }
  
  public void remove(IEntityFilter paramIEntityFilter)
  {
    if (this.filters == null) {
      return;
    }
    this.filters.remove(paramIEntityFilter);
  }
  
  public List<String> getAddableFields(IServiceContext paramIServiceContext)
  {
    ArrayList localArrayList = null;
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IEntityFilter localIEntityFilter = (IEntityFilter)this.filters.get(i);
      List localList = localIEntityFilter.getAddableFields(paramIServiceContext);
      if (localList != null) {
        if (localArrayList == null) {
          localArrayList = new ArrayList(localList);
        } else {
          localArrayList.retainAll(localList);
        }
      }
    }
    return localArrayList;
  }
  
  public List<String> getUpdatableFields(Object paramObject, IServiceContext paramIServiceContext)
  {
    ArrayList localArrayList = null;
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IEntityFilter localIEntityFilter = (IEntityFilter)this.filters.get(i);
      List localList = localIEntityFilter.getUpdatableFields(paramObject, paramIServiceContext);
      if (localList != null) {
        if (localArrayList == null) {
          localArrayList = new ArrayList(localList);
        } else {
          localArrayList.retainAll(localList);
        }
      }
    }
    return localArrayList;
  }
  
  public Query appendFilter(Query paramQuery, IServiceContext paramIServiceContext)
  {
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IEntityFilter localIEntityFilter = (IEntityFilter)this.filters.get(i);
      paramQuery = localIEntityFilter.appendFilter(paramQuery, paramIServiceContext);
    }
    return paramQuery;
  }
  
  public void aroundSave(Object paramObject, Invocation paramInvocation, IServiceContext paramIServiceContext)
  {
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IEntityFilter localIEntityFilter = (IEntityFilter)this.filters.get(i);
      localIEntityFilter.aroundSave(paramObject, paramInvocation, paramIServiceContext);
    }
  }
  
  public void aroundView(Object paramObject, Invocation paramInvocation, IServiceContext paramIServiceContext)
  {
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IEntityFilter localIEntityFilter = (IEntityFilter)this.filters.get(i);
      localIEntityFilter.aroundView(paramObject, paramInvocation, paramIServiceContext);
    }
  }
  
  public void aroundRemove(Object paramObject, Invocation paramInvocation, IServiceContext paramIServiceContext)
  {
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IEntityFilter localIEntityFilter = (IEntityFilter)this.filters.get(i);
      localIEntityFilter.aroundRemove(paramObject, paramInvocation, paramIServiceContext);
    }
  }
  
  public void aroundUpdate(Object paramObject, Invocation paramInvocation, IServiceContext paramIServiceContext)
  {
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IEntityFilter localIEntityFilter = (IEntityFilter)this.filters.get(i);
      localIEntityFilter.aroundUpdate(paramObject, paramInvocation, paramIServiceContext);
    }
  }
  
  public boolean passFilterForRead(Object paramObject, IServiceContext paramIServiceContext)
  {
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IEntityFilter localIEntityFilter = (IEntityFilter)this.filters.get(i);
      if (!localIEntityFilter.passFilterForRead(paramObject, paramIServiceContext)) {
        return false;
      }
    }
    return true;
  }
  
  public boolean passFilterForRemove(Object paramObject, IServiceContext paramIServiceContext)
  {
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IEntityFilter localIEntityFilter = (IEntityFilter)this.filters.get(i);
      if (!localIEntityFilter.passFilterForRemove(paramObject, paramIServiceContext)) {
        return false;
      }
    }
    return true;
  }
  
  public boolean passFilterForUpdate(Object paramObject, IServiceContext paramIServiceContext)
  {
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IEntityFilter localIEntityFilter = (IEntityFilter)this.filters.get(i);
      if (!localIEntityFilter.passFilterForUpdate(paramObject, paramIServiceContext)) {
        return false;
      }
    }
    return true;
  }
  
  public void afterPreAdd(Object paramObject, IServiceContext paramIServiceContext)
  {
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IEntityFilter localIEntityFilter = (IEntityFilter)this.filters.get(i);
      localIEntityFilter.afterPreAdd(paramObject, paramIServiceContext);
    }
  }
  
  public void afterPreUpdate(Object paramObject, IServiceContext paramIServiceContext)
  {
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IEntityFilter localIEntityFilter = (IEntityFilter)this.filters.get(i);
      localIEntityFilter.afterPreUpdate(paramObject, paramIServiceContext);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\MultiEntityFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */