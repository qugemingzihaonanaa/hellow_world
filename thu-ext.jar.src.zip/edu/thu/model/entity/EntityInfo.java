package edu.thu.model.entity;

import edu.thu.model.stg.ds.DataSourceMeta;
import edu.thu.service.SystemServiceContext;
import java.io.Serializable;

public class EntityInfo
  implements Serializable
{
  private static final long serialVersionUID = 2566225159699375454L;
  String C;
  String A;
  String B;
  
  public EntityInfo() {}
  
  public EntityInfo(EntityInfo paramEntityInfo)
  {
    this.C = paramEntityInfo.C;
    this.A = paramEntityInfo.A;
    this.B = paramEntityInfo.B;
  }
  
  public String getEntityName()
  {
    return this.A;
  }
  
  public void setEntityName(String paramString)
  {
    this.A = paramString;
  }
  
  public String getMetaName()
  {
    return this.B;
  }
  
  public void setMetaName(String paramString)
  {
    this.B = paramString;
  }
  
  public String getWebObjectName()
  {
    return this.C;
  }
  
  public void setWebObjectName(String paramString)
  {
    this.C = paramString;
  }
  
  public DataSourceMeta getDsMeta()
  {
    return DataSourceMeta.load(this.B, SystemServiceContext.getInstance());
  }
  
  public String getPkField()
  {
    DataSourceMeta localDataSourceMeta = getDsMeta();
    if (localDataSourceMeta == null) {
      return null;
    }
    return localDataSourceMeta.getPkField();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\EntityInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */