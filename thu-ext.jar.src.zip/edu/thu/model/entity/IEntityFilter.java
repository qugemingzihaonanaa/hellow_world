package edu.thu.model.entity;

import edu.thu.search.Query;
import edu.thu.service.IServiceContext;
import java.util.List;

public abstract interface IEntityFilter
{
  public abstract void afterInit(IServiceContext paramIServiceContext);
  
  public abstract void postProcess(IServiceContext paramIServiceContext);
  
  public abstract int getDefaultPageSize(IServiceContext paramIServiceContext);
  
  public abstract Query appendFilter(Query paramQuery, IServiceContext paramIServiceContext);
  
  public abstract boolean passFilterForRead(Object paramObject, IServiceContext paramIServiceContext);
  
  public abstract boolean passFilterForUpdate(Object paramObject, IServiceContext paramIServiceContext);
  
  public abstract boolean passFilterForRemove(Object paramObject, IServiceContext paramIServiceContext);
  
  public abstract void afterPreAdd(Object paramObject, IServiceContext paramIServiceContext);
  
  public abstract void afterPreUpdate(Object paramObject, IServiceContext paramIServiceContext);
  
  public abstract void aroundView(Object paramObject, Invocation paramInvocation, IServiceContext paramIServiceContext);
  
  public abstract void aroundSave(Object paramObject, Invocation paramInvocation, IServiceContext paramIServiceContext);
  
  public abstract void aroundUpdate(Object paramObject, Invocation paramInvocation, IServiceContext paramIServiceContext);
  
  public abstract void aroundRemove(Object paramObject, Invocation paramInvocation, IServiceContext paramIServiceContext);
  
  public abstract void aroundImport(IEntityImportor paramIEntityImportor, Invocation paramInvocation, IServiceContext paramIServiceContext);
  
  public abstract List<String> getAddableFields(IServiceContext paramIServiceContext);
  
  public abstract List<String> getBatchUpdatableFields(IServiceContext paramIServiceContext);
  
  public abstract List<String> getUpdatableFields(Object paramObject, IServiceContext paramIServiceContext);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\IEntityFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */