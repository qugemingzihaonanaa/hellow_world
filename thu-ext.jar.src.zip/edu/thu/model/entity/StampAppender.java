package edu.thu.model.entity;

import edu.thu.core.AppEnv;
import edu.thu.lang.reflect.BeanInstance;
import edu.thu.service.IServiceContext;
import java.sql.Timestamp;

public class StampAppender
  extends AbstractEntityFilter
{
  public static final StampAppender SINGLETON = new StampAppender();
  
  public void aroundSave(Object paramObject, IServiceContext paramIServiceContext)
  {
    BeanInstance localBeanInstance = new BeanInstance(paramObject);
    localBeanInstance.setPropertyValue("createrId", getUserId(paramIServiceContext));
    localBeanInstance.setPropertyValue("createTime", new Timestamp(AppEnv.currentTimeMillis()));
  }
  
  public void aroundUpdate(Object paramObject, IServiceContext paramIServiceContext)
  {
    BeanInstance localBeanInstance = new BeanInstance(paramObject);
    localBeanInstance.setPropertyValue("updaterId", getUserId(paramIServiceContext));
    localBeanInstance.setPropertyValue("updateTime", new Timestamp(AppEnv.currentTimeMillis()));
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\StampAppender.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */