package edu.thu.model.entity;

import java.util.ArrayList;
import java.util.List;

public class BatchEntityProcessor
  implements IEntityProcessor
{
  IEntityProcessor C;
  
  public void setProcessor(IEntityProcessor paramIEntityProcessor)
  {
    this.C = paramIEntityProcessor;
  }
  
  public Object processEntity(Object paramObject)
  {
    if ((paramObject instanceof List))
    {
      List localList = (List)paramObject;
      int j = localList.size();
      ArrayList localArrayList = new ArrayList(j);
      for (int i = 0; i < j; i++)
      {
        Object localObject = localList.get(i);
        localArrayList.add(this.C.processEntity(localObject));
      }
      return localArrayList;
    }
    return this.C.processEntity(paramObject);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\BatchEntityProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */