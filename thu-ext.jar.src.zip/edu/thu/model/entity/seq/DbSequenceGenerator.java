package edu.thu.model.entity.seq;

import edu.thu.config.AppConfig;
import edu.thu.db.SQL;
import edu.thu.db.SqlBuilder;
import edu.thu.db.core.IJdbcTemplate;
import edu.thu.java.util.Coercions;
import edu.thu.lang.IVariant;
import java.util.Map;

public class DbSequenceGenerator
  implements ISequenceGenerator
{
  IJdbcTemplate D;
  Map<String, String> C;
  String E = AppConfig.var("orm.sequence_name").stripedStringValue("hibernate_sequence");
  
  public void setJdbcTemplate(IJdbcTemplate paramIJdbcTemplate)
  {
    this.D = paramIJdbcTemplate;
  }
  
  public IJdbcTemplate jdbc()
  {
    return this.D;
  }
  
  public void setSeqMap(Map<String, String> paramMap)
  {
    this.C = paramMap;
  }
  
  public void setDefaultSeqName(String paramString)
  {
    this.E = paramString;
  }
  
  public boolean existsObjType(String paramString)
  {
    return (this.C != null) && (this.C.containsKey(paramString));
  }
  
  public String getSeqName(String paramString)
  {
    if ((this.C != null) && (this.C.containsKey(paramString))) {
      return (String)this.C.get(paramString);
    }
    return this.E;
  }
  
  public String peekNextValue(String paramString)
  {
    String str = getSeqName(paramString);
    SQL localSQL = SQL.begin().sql("select " + str + ".currval from dual").end();
    return Coercions.toString(jdbc().findFirstScalar(localSQL), null);
  }
  
  public String getNextValue(String paramString, boolean paramBoolean)
  {
    String str = getSeqName(paramString);
    SQL localSQL = SQL.begin().sql("select " + str + ".nextval from dual").end();
    return Coercions.toString(jdbc().findFirstScalar(localSQL), null);
  }
  
  public void resetValue(String paramString, long paramLong, int paramInt) {}
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\seq\DbSequenceGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */