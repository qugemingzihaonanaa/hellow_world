package edu.thu.model.entity.seq;

import edu.thu.service.BeanLoader;
import java.util.Map;

public class SequenceGenerator
  implements ISequenceGenerator
{
  Map<String, ISequenceGenerator> G;
  ISequenceGenerator F;
  
  public void setSeqMap(Map<String, ISequenceGenerator> paramMap)
  {
    this.G = paramMap;
  }
  
  public void setBaseGenerator(ISequenceGenerator paramISequenceGenerator)
  {
    this.F = paramISequenceGenerator;
  }
  
  public ISequenceGenerator getSeqGenerator(String paramString)
  {
    if ((this.G != null) && (this.G.containsKey(paramString))) {
      return (ISequenceGenerator)this.G.get(paramString);
    }
    return this.F;
  }
  
  public boolean existsObjType(String paramString)
  {
    ISequenceGenerator localISequenceGenerator = getSeqGenerator(paramString);
    return localISequenceGenerator.existsObjType(paramString);
  }
  
  public void resetValue(String paramString, long paramLong, int paramInt)
  {
    getSeqGenerator(paramString).resetValue(paramString, paramLong, paramInt);
  }
  
  public String peekNextValue(String paramString)
  {
    ISequenceGenerator localISequenceGenerator = getSeqGenerator(paramString);
    return localISequenceGenerator.peekNextValue(paramString);
  }
  
  public String getNextValue(String paramString, boolean paramBoolean)
  {
    ISequenceGenerator localISequenceGenerator = getSeqGenerator(paramString);
    return localISequenceGenerator.getNextValue(paramString, paramBoolean);
  }
  
  public static ISequenceGenerator getInstance()
  {
    return (ISequenceGenerator)BeanLoader.getBean(SequenceGenerator.class);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\seq\SequenceGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */