package edu.thu.model.entity.seq;

import edu.thu.java.util.Coercions;
import edu.thu.lang.el.IExpressionReference;
import edu.thu.lang.util.TplC;
import java.util.HashMap;
import java.util.Map;

public class FormatSequenceGenerator
  implements ISequenceGenerator
{
  IExpressionReference B;
  ISequenceGenerator A;
  
  public void setBaseGenerator(ISequenceGenerator paramISequenceGenerator)
  {
    this.A = paramISequenceGenerator;
  }
  
  public void setFormat(String paramString)
  {
    this.B = TplC.parseExpression(paramString);
  }
  
  public boolean existsObjType(String paramString)
  {
    return this.A.existsObjType(paramString);
  }
  
  public String peekNextValue(String paramString)
  {
    String str = this.A.peekNextValue(paramString);
    HashMap localHashMap = new HashMap(1);
    localHashMap.put("value", str);
    return Coercions.toString(TplC.evaluate(this.B, localHashMap), null);
  }
  
  public String getNextValue(String paramString, boolean paramBoolean)
  {
    String str = this.A.getNextValue(paramString, paramBoolean);
    HashMap localHashMap = new HashMap(1);
    localHashMap.put("value", str);
    return Coercions.toString(TplC.evaluate(this.B, localHashMap), null);
  }
  
  public void resetValue(String paramString, long paramLong, int paramInt)
  {
    this.A.resetValue(paramString, paramLong, paramInt);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\seq\FormatSequenceGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */