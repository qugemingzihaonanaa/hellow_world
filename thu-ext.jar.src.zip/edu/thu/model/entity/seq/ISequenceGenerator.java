package edu.thu.model.entity.seq;

public abstract interface ISequenceGenerator
{
  public abstract String peekNextValue(String paramString);
  
  public abstract String getNextValue(String paramString, boolean paramBoolean);
  
  public abstract void resetValue(String paramString, long paramLong, int paramInt);
  
  public abstract boolean existsObjType(String paramString);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\seq\ISequenceGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */