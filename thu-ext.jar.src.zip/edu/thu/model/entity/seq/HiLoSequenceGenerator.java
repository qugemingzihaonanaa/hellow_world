package edu.thu.model.entity.seq;

import java.util.HashMap;
import java.util.Map;

public class HiLoSequenceGenerator
  implements ISequenceGenerator
{
  ISequenceGenerator J;
  int K;
  long I = 1L;
  Map<String, _A> H = new HashMap();
  
  public boolean existsObjType(String paramString)
  {
    return this.J.existsObjType(paramString);
  }
  
  public void resetValue(String paramString, long paramLong, int paramInt)
  {
    synchronized (this.H)
    {
      this.H.remove(paramString);
      this.J.resetValue(paramString, paramLong, paramInt);
    }
  }
  
  public void setBaseGenerator(ISequenceGenerator paramISequenceGenerator)
  {
    this.J = paramISequenceGenerator;
  }
  
  public void setCacheSize(int paramInt)
  {
    this.K = paramInt;
  }
  
  public void setIncNum(long paramLong)
  {
    this.I = paramLong;
  }
  
  long A(String paramString, boolean paramBoolean)
  {
    return Long.valueOf(this.J.getNextValue(paramString, false)).longValue();
  }
  
  public String getNextValue(String paramString, boolean paramBoolean)
  {
    synchronized (this.H)
    {
      _A local_A1 = (_A)this.H.get(paramString);
      if ((local_A1 != null) && (local_A1.B < this.K))
      {
        long l2 = local_A1.A;
        local_A1.A += this.I;
        local_A1.B += 1;
        return String.valueOf(l2);
      }
    }
    long l1 = A(paramString, paramBoolean);
    synchronized (this.H)
    {
      _A local_A2 = (_A)this.H.get(paramString);
      if (local_A2 == null)
      {
        local_A2 = new _A();
        this.H.put(paramString, local_A2);
      }
      local_A2.A = (l1 + this.I);
      local_A2.B = 1;
    }
    return String.valueOf(l1);
  }
  
  public String peekNextValue(String paramString)
  {
    synchronized (this.H)
    {
      _A local_A = (_A)this.H.get(paramString);
      if ((local_A != null) && (local_A.B < this.K)) {
        return String.valueOf(local_A.A);
      }
    }
    return this.J.peekNextValue(paramString);
  }
  
  static class _A
  {
    long A;
    int B;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\seq\HiLoSequenceGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */