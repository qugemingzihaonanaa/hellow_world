package edu.thu.model.entity;

import edu.thu.model.stg.ds.spi.TreeMeta;
import edu.thu.model.tree.LayerCode;
import edu.thu.search.Query;
import java.util.List;
import java.util.Map;

public abstract interface IEntityTreeManager
{
  public abstract void setPkField(String paramString);
  
  public abstract void setTreeMeta(TreeMeta paramTreeMeta);
  
  public abstract TreeMeta getTreeMeta();
  
  public abstract Object getEntityById(String paramString);
  
  public abstract Object getEntityByLc(LayerCode paramLayerCode, Map<String, Object> paramMap);
  
  public abstract String getIdByLc(LayerCode paramLayerCode, Map<String, Object> paramMap);
  
  public abstract List<Object> getRoots(Query paramQuery);
  
  public abstract LayerCode getLcById(String paramString);
  
  public abstract void syncLayerLevel(Object paramObject, Map<String, Object> paramMap);
  
  public abstract boolean moveByLc(LayerCode paramLayerCode1, LayerCode paramLayerCode2, Map<String, Object> paramMap);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\IEntityTreeManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */