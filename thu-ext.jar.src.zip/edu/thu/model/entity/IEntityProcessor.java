package edu.thu.model.entity;

public abstract interface IEntityProcessor
{
  public static final Object NOT_PROCESS = new Object();
  
  public abstract Object processEntity(Object paramObject);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\IEntityProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */