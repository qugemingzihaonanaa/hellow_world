package edu.thu.model.entity;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class SelectableEntity
{
  String C;
  String A;
  List B;
  
  public String getName()
  {
    return this.A;
  }
  
  public void setName(String paramString)
  {
    this.A = paramString;
  }
  
  public List getSelectors()
  {
    return this.B;
  }
  
  public void setSelectors(List paramList)
  {
    this.B = paramList;
  }
  
  public String getId()
  {
    return this.C;
  }
  
  public void setId(String paramString)
  {
    this.C = paramString;
  }
  
  public boolean matchSelector(String paramString)
  {
    if (this.B == null) {
      return false;
    }
    return this.B.contains(paramString);
  }
  
  public static SelectableEntity getEntityById(Collection paramCollection, String paramString)
  {
    if (paramCollection == null) {
      return null;
    }
    if (paramString == null) {
      return null;
    }
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      SelectableEntity localSelectableEntity = (SelectableEntity)localIterator.next();
      if (paramString.equals(localSelectableEntity.getId())) {
        return localSelectableEntity;
      }
    }
    return null;
  }
  
  public static SelectableEntity getEntityBySelector(Collection paramCollection, String paramString)
  {
    if (paramCollection == null) {
      return null;
    }
    if (paramString == null) {
      return null;
    }
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      SelectableEntity localSelectableEntity = (SelectableEntity)localIterator.next();
      if (localSelectableEntity.matchSelector(paramString)) {
        return localSelectableEntity;
      }
    }
    return null;
  }
  
  public static List getEntityListBySelector(Collection paramCollection, String paramString)
  {
    if (paramCollection == null) {
      return null;
    }
    if (paramString == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      SelectableEntity localSelectableEntity = (SelectableEntity)localIterator.next();
      if (localSelectableEntity.matchSelector(paramString)) {
        localArrayList.add(localSelectableEntity);
      }
    }
    return localArrayList;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\SelectableEntity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */