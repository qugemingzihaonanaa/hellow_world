package edu.thu.model.entity;

import java.util.List;

public abstract interface IEntityFetcher
{
  public abstract List fetchList();
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\IEntityFetcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */