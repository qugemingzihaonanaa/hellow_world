package edu.thu.model.entity;

import edu.thu.db.SQL;
import edu.thu.db.SqlMap;
import edu.thu.ext.hibernate.AbstractHibernateDao;
import edu.thu.orm.dao.IOrmTemplate;
import java.util.List;
import java.util.Map;

public class HqlEntityFetcher
  extends AbstractHibernateDao
  implements IEntityFetcher
{
  private static final long serialVersionUID = -9031627405984309707L;
  String sqlName;
  Map args;
  int fetchCount = 100;
  
  public void setSqlName(String paramString)
  {
    this.sqlName = paramString;
  }
  
  public void setFetchCount(int paramInt)
  {
    this.fetchCount = paramInt;
  }
  
  public void setArgs(Map paramMap)
  {
    this.args = paramMap;
  }
  
  public List fetchList()
  {
    SQL localSQL = SqlMap.getInstance().getSql(this.sqlName, this.args);
    return orm().findPart(localSQL, 1L, this.fetchCount);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\HqlEntityFetcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */