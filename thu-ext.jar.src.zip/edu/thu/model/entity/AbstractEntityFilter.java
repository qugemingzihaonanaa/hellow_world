package edu.thu.model.entity;

import edu.thu.search.Query;
import edu.thu.service.IServiceContext;
import edu.thu.service.IUserServiceContext;
import edu.thu.user.IUserContext;
import java.util.List;

public class AbstractEntityFilter
  implements IEntityFilter
{
  public void afterInit(IServiceContext paramIServiceContext) {}
  
  public void postProcess(IServiceContext paramIServiceContext) {}
  
  public int getDefaultPageSize(IServiceContext paramIServiceContext)
  {
    return -1;
  }
  
  public IUserContext getUserContext(IServiceContext paramIServiceContext)
  {
    if ((paramIServiceContext instanceof IUserContext)) {
      return (IUserContext)paramIServiceContext;
    }
    if ((paramIServiceContext instanceof IUserServiceContext)) {
      return ((IUserServiceContext)paramIServiceContext).getUserContext();
    }
    return null;
  }
  
  public String getUserId(IServiceContext paramIServiceContext)
  {
    IUserContext localIUserContext = getUserContext(paramIServiceContext);
    if (localIUserContext == null) {
      return null;
    }
    return localIUserContext.getUserId().toString();
  }
  
  public List<String> getAddableFields(IServiceContext paramIServiceContext)
  {
    return null;
  }
  
  public List<String> getUpdatableFields(Object paramObject, IServiceContext paramIServiceContext)
  {
    return null;
  }
  
  public List<String> getBatchUpdatableFields(IServiceContext paramIServiceContext)
  {
    return null;
  }
  
  public Query appendFilter(Query paramQuery, IServiceContext paramIServiceContext)
  {
    return paramQuery;
  }
  
  public void aroundSave(Object paramObject, Invocation paramInvocation, IServiceContext paramIServiceContext)
  {
    beforeSave(paramObject, paramIServiceContext);
  }
  
  public void aroundRemove(Object paramObject, Invocation paramInvocation, IServiceContext paramIServiceContext)
  {
    beforeRemove(paramObject, paramIServiceContext);
  }
  
  public void aroundUpdate(Object paramObject, Invocation paramInvocation, IServiceContext paramIServiceContext)
  {
    beforeUpdate(paramObject, paramIServiceContext);
  }
  
  public void aroundImport(IEntityImportor paramIEntityImportor, Invocation paramInvocation, IServiceContext paramIServiceContext) {}
  
  public void aroundView(Object paramObject, Invocation paramInvocation, IServiceContext paramIServiceContext) {}
  
  public void beforeSave(Object paramObject, IServiceContext paramIServiceContext) {}
  
  public void beforeRemove(Object paramObject, IServiceContext paramIServiceContext) {}
  
  public void beforeUpdate(Object paramObject, IServiceContext paramIServiceContext) {}
  
  public void afterPreAdd(Object paramObject, IServiceContext paramIServiceContext) {}
  
  public void afterPreUpdate(Object paramObject, IServiceContext paramIServiceContext) {}
  
  public boolean passFilterForRead(Object paramObject, IServiceContext paramIServiceContext)
  {
    return passFilter(paramObject, paramIServiceContext);
  }
  
  public boolean passFilterForRemove(Object paramObject, IServiceContext paramIServiceContext)
  {
    return passFilter(paramObject, paramIServiceContext);
  }
  
  public boolean passFilterForUpdate(Object paramObject, IServiceContext paramIServiceContext)
  {
    return passFilter(paramObject, paramIServiceContext);
  }
  
  public boolean passFilter(Object paramObject, IServiceContext paramIServiceContext)
  {
    return true;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\AbstractEntityFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */