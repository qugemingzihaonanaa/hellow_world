package edu.thu.model.entity;

import edu.thu.service.BeanLoader;
import edu.thu.service.job.AbstractJob;

public class BatchEntityJob
  extends AbstractJob<Object>
{
  String entityBean;
  String processorBean;
  int batchSize = 1000;
  transient String logId;
  
  public void setBatchSize(int paramInt)
  {
    this.batchSize = paramInt;
  }
  
  public void setEntityBean(String paramString)
  {
    this.entityBean = paramString;
  }
  
  public void setProcessorBean(String paramString)
  {
    this.processorBean = paramString;
  }
  
  public IEntityStream getEntityStream()
  {
    return (IEntityStream)BeanLoader.getBean(this.entityBean);
  }
  
  public IEntityProcessor getEntityProcessor()
  {
    return (IEntityProcessor)BeanLoader.getBean(this.processorBean);
  }
  
  public void run()
  {
    IEntityProcessor localIEntityProcessor = getEntityProcessor();
    IEntityStream localIEntityStream = getEntityStream();
    processEntity(localIEntityStream, localIEntityProcessor);
  }
  
  /* Error */
  protected void processEntity(IEntityStream paramIEntityStream, IEntityProcessor paramIEntityProcessor)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual 58	edu/thu/model/entity/BatchEntityJob:initCount	(Ledu/thu/model/entity/IEntityStream;)I
    //   5: istore_3
    //   6: aload_1
    //   7: invokeinterface 62 1 0
    //   12: astore 4
    //   14: aload 4
    //   16: ifnonnull +6 -> 22
    //   19: goto +50 -> 69
    //   22: aload_2
    //   23: aload 4
    //   25: invokeinterface 66 2 0
    //   30: pop
    //   31: iinc 3 1
    //   34: iload_3
    //   35: aload_0
    //   36: getfield 16	edu/thu/model/entity/BatchEntityJob:batchSize	I
    //   39: irem
    //   40: ifne -34 -> 6
    //   43: aload_0
    //   44: iload_3
    //   45: invokevirtual 69	edu/thu/model/entity/BatchEntityJob:logCount	(I)V
    //   48: aload_0
    //   49: invokevirtual 72	edu/thu/model/entity/BatchEntityJob:flushSession	()V
    //   52: aload_0
    //   53: invokevirtual 75	edu/thu/model/entity/BatchEntityJob:clearSession	()V
    //   56: goto -50 -> 6
    //   59: astore 5
    //   61: aload_1
    //   62: invokestatic 78	edu/thu/global/util/CloseUtils:safeClose	(Ledu/thu/service/IClosable;)Z
    //   65: pop
    //   66: aload 5
    //   68: athrow
    //   69: aload_1
    //   70: invokestatic 78	edu/thu/global/util/CloseUtils:safeClose	(Ledu/thu/service/IClosable;)Z
    //   73: pop
    //   74: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	75	0	this	BatchEntityJob
    //   0	75	1	paramIEntityStream	IEntityStream
    //   0	75	2	paramIEntityProcessor	IEntityProcessor
    //   5	40	3	i	int
    //   12	12	4	localObject1	Object
    //   59	8	5	localObject2	Object
    // Exception table:
    //   from	to	target	type
    //   6	59	59	finally
  }
  
  protected int initCount(IEntityStream paramIEntityStream)
  {
    return 0;
  }
  
  protected void logCount(int paramInt) {}
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\BatchEntityJob.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */