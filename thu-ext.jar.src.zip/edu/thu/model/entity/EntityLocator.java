package edu.thu.model.entity;

import edu.thu.service.EntityManager;
import edu.thu.service.IEntityManager;

public class EntityLocator
  extends EntityInfo
{
  private static final long serialVersionUID = 5924284240601671718L;
  Object D;
  
  public EntityLocator() {}
  
  public EntityLocator(String paramString, EntityInfo paramEntityInfo)
  {
    super(paramEntityInfo);
    this.D = paramString;
  }
  
  public Object getEntityId()
  {
    return this.D;
  }
  
  public void setEntityId(Object paramObject)
  {
    this.D = paramObject;
  }
  
  public Object getEntity()
  {
    return EntityManager.getInstance().get(this.A, this.D);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\EntityLocator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */