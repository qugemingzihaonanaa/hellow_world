package edu.thu.model.entity;

import edu.thu.global.Debug;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Tags
  implements Serializable
{
  private static final long serialVersionUID = -3743664866115543965L;
  String B;
  transient List A;
  
  public Tags() {}
  
  public Tags(String paramString)
  {
    setText(paramString);
  }
  
  private void A(ObjectInputStream paramObjectInputStream)
    throws IOException, ClassNotFoundException
  {
    paramObjectInputStream.defaultReadObject();
    setText(this.B);
  }
  
  public String getText()
  {
    return this.B;
  }
  
  public String toString()
  {
    return this.B;
  }
  
  public void setText(String paramString)
  {
    this.A = parseTags(paramString);
    this.B = buildTags(this.A);
  }
  
  public List getTagList()
  {
    return this.A;
  }
  
  public boolean containsList(List paramList)
  {
    if ((paramList == null) || (paramList.isEmpty())) {
      return true;
    }
    return this.A == null ? false : this.A.containsAll(paramList);
  }
  
  public boolean notContainsTag(String paramString)
  {
    if (paramString == null) {
      return true;
    }
    return !containsTag(paramString);
  }
  
  public boolean notContainsAnyTag(String paramString)
  {
    if (paramString == null) {
      return true;
    }
    return !containsAnyTag(paramString);
  }
  
  public boolean containsAnyTag(String paramString)
  {
    if (paramString == null) {
      return true;
    }
    if (this.A == null) {
      return false;
    }
    if (paramString.indexOf(',') < 0) {
      return this.A.contains(paramString);
    }
    List localList = parseTags(paramString);
    if ((localList == null) || (localList.isEmpty())) {
      return true;
    }
    int j = localList.size();
    for (int i = 0; i < j; i++) {
      if (this.A.contains(localList.get(i))) {
        return true;
      }
    }
    return false;
  }
  
  public boolean containsTag(String paramString)
  {
    if (paramString == null) {
      return false;
    }
    if (this.A == null) {
      return false;
    }
    if (paramString.indexOf(',') < 0) {
      return this.A.contains(paramString);
    }
    return containsList(parseTags(paramString));
  }
  
  public Tags copy()
  {
    return new Tags(this.B);
  }
  
  public void sort()
  {
    if (this.A != null)
    {
      Collections.sort(this.A);
      this.B = buildTags(this.A);
    }
  }
  
  public boolean addTag(String paramString)
  {
    List localList = parseTags(paramString);
    if ((localList == null) || (localList.isEmpty())) {
      return false;
    }
    boolean bool = false;
    if (this.A == null)
    {
      this.A = localList;
      bool = true;
    }
    else
    {
      int j = localList.size();
      for (int i = 0; i < j; i++)
      {
        String str = (String)localList.get(i);
        if (!this.A.contains(str))
        {
          bool = true;
          this.A.add(str);
        }
      }
    }
    this.B = buildTags(this.A);
    return bool;
  }
  
  public void addList(List paramList)
  {
    if (paramList == null) {
      return;
    }
    if (this.A == null) {
      this.A = new ArrayList(paramList.size());
    }
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      String str = (String)paramList.get(i);
      if (!this.A.contains(str)) {
        this.A.add(str);
      }
    }
  }
  
  public boolean removeTag(String paramString)
  {
    if ((this.A == null) || (this.A.isEmpty())) {
      return false;
    }
    List localList = parseTags(paramString);
    if (localList == null) {
      return false;
    }
    if (!this.A.removeAll(localList)) {
      return false;
    }
    this.B = buildTags(this.A);
    return true;
  }
  
  public static List parseTags(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    if (paramString.length() <= 0) {
      return new ArrayList(0);
    }
    ArrayList localArrayList = new ArrayList(Arrays.asList(paramString.split(",")));
    int j = localArrayList.size();
    for (int i = 0; i < j; i++)
    {
      String str = (String)localArrayList.get(i);
      str = str.trim();
      localArrayList.set(i, str);
      if (str.length() <= 0)
      {
        localArrayList.remove(i);
        j--;
        i--;
      }
    }
    return localArrayList;
  }
  
  public static String buildTags(List paramList)
  {
    if (paramList == null) {
      return null;
    }
    StringBuffer localStringBuffer = new StringBuffer();
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      String str = (String)paramList.get(i);
      localStringBuffer.append(str);
      if (i != j - 1) {
        localStringBuffer.append(",");
      }
    }
    return localStringBuffer.toString();
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Tags localTags = new Tags("a , b");
    localTags.addTag("c ");
    Debug.check(localTags.getTagList().size() == 3);
    Debug.check(localTags.containsTag("a"));
    Debug.check(localTags.containsTag("b"));
    Debug.check(localTags.containsTag("c"));
    Debug.check(localTags.containsTag("a,c"));
    Debug.check(localTags.removeTag("a, c"));
    Debug.check(!localTags.containsTag("a"));
    Debug.check(localTags.getText().equals("b"));
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\Tags.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */