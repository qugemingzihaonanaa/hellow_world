package edu.thu.model.entity;

public class EntityProcInfo
{
  IEntityFetcher B;
  IEntityProcessor A;
  
  public void setFetcher(IEntityFetcher paramIEntityFetcher)
  {
    this.B = paramIEntityFetcher;
  }
  
  public void setProcessor(IEntityProcessor paramIEntityProcessor)
  {
    this.A = paramIEntityProcessor;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\EntityProcInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */