package edu.thu.model.entity;

public abstract class Invocation
{
  boolean invoked = false;
  Object returnValue;
  
  public static Invocation emptyInvocation()
  {
    new Invocation()
    {
      public Object execute()
      {
        return this.returnValue;
      }
    };
  }
  
  public boolean isInvoked()
  {
    return this.invoked;
  }
  
  public void setInvoked(boolean paramBoolean)
  {
    this.invoked = paramBoolean;
  }
  
  public void setInvoked(boolean paramBoolean, Object paramObject)
  {
    setInvoked(paramBoolean);
    setReturnValue(paramObject);
  }
  
  public void setReturnValue(Object paramObject)
  {
    this.returnValue = paramObject;
  }
  
  public final Object proceed()
  {
    if (this.invoked) {
      return this.returnValue;
    }
    this.invoked = true;
    this.returnValue = execute();
    return this.returnValue;
  }
  
  public abstract Object execute();
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\Invocation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */