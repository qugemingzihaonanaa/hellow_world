package edu.thu.model.entity;

import edu.thu.java.util.MethodUtils;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Method;
import org.aopalliance.intercept.MethodInvocation;

public class JavaMethodInvocation
  extends Invocation
  implements MethodInvocation
{
  Object thisObj;
  Object[] arguments;
  Method method;
  
  public JavaMethodInvocation(Object paramObject, Method paramMethod, Object[] paramArrayOfObject)
  {
    this.thisObj = paramObject;
    this.arguments = paramArrayOfObject;
    this.method = paramMethod;
  }
  
  public JavaMethodInvocation(MethodInvocation paramMethodInvocation)
  {
    this.thisObj = paramMethodInvocation.getThis();
    this.arguments = paramMethodInvocation.getArguments();
    this.method = paramMethodInvocation.getMethod();
  }
  
  public Object execute()
  {
    return MethodUtils.invokeExactMethod(this.thisObj, this.method, this.arguments);
  }
  
  public Method getMethod()
  {
    return this.method;
  }
  
  public Object[] getArguments()
  {
    return this.arguments;
  }
  
  public AccessibleObject getStaticPart()
  {
    return this.method;
  }
  
  public Object getThis()
  {
    return this.thisObj;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\entity\JavaMethodInvocation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */