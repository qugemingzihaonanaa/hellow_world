package edu.thu.model.stg.ds.filter;

import edu.thu.global.Debug;
import edu.thu.service.IServiceContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CompositeDsFilter
  implements IDataSourceInterceptor
{
  List filters;
  boolean parameterizable;
  
  public CompositeDsFilter()
  {
    this.filters = new ArrayList();
  }
  
  public CompositeDsFilter(List paramList)
  {
    Debug.check(paramList);
    this.filters = new ArrayList(paramList);
    syncFlags();
  }
  
  protected CompositeDsFilter(List paramList, boolean paramBoolean)
  {
    this.filters = paramList;
    this.parameterizable = paramBoolean;
  }
  
  void syncFlags()
  {
    this.parameterizable = false;
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IDataSourceInterceptor localIDataSourceInterceptor = (IDataSourceInterceptor)this.filters.get(i);
      if (localIDataSourceInterceptor.isParameterizable())
      {
        this.parameterizable = true;
        break;
      }
    }
  }
  
  public Object clone()
  {
    return new CompositeDsFilter(this.filters);
  }
  
  public void addFilter(IDataSourceInterceptor paramIDataSourceInterceptor)
  {
    Debug.check(paramIDataSourceInterceptor);
    if (paramIDataSourceInterceptor.isParameterizable()) {
      this.parameterizable = true;
    }
    this.filters.add(paramIDataSourceInterceptor);
  }
  
  public void removeFilter(IDataSourceInterceptor paramIDataSourceInterceptor)
  {
    this.filters.remove(paramIDataSourceInterceptor);
    syncFlags();
  }
  
  public boolean onBeforeQuery(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IDataSourceInterceptor localIDataSourceInterceptor = (IDataSourceInterceptor)this.filters.get(i);
      if (localIDataSourceInterceptor.onBeforeQuery(paramDataSourceRequest, paramIServiceContext)) {
        return true;
      }
    }
    return false;
  }
  
  public boolean onBeforeAdd(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IDataSourceInterceptor localIDataSourceInterceptor = (IDataSourceInterceptor)this.filters.get(i);
      if (localIDataSourceInterceptor.onBeforeAdd(paramDataSourceRequest, paramIServiceContext)) {
        return true;
      }
    }
    return false;
  }
  
  public boolean onBeforeAddMany(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IDataSourceInterceptor localIDataSourceInterceptor = (IDataSourceInterceptor)this.filters.get(i);
      if (localIDataSourceInterceptor.onBeforeAddMany(paramDataSourceRequest, paramIServiceContext)) {
        return true;
      }
    }
    return false;
  }
  
  public boolean onBeforeRemove(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IDataSourceInterceptor localIDataSourceInterceptor = (IDataSourceInterceptor)this.filters.get(i);
      if (localIDataSourceInterceptor.onBeforeRemove(paramDataSourceRequest, paramIServiceContext)) {
        return true;
      }
    }
    return false;
  }
  
  public boolean onBeforeUpdate(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IDataSourceInterceptor localIDataSourceInterceptor = (IDataSourceInterceptor)this.filters.get(i);
      if (localIDataSourceInterceptor.onBeforeUpdate(paramDataSourceRequest, paramIServiceContext)) {
        return true;
      }
    }
    return false;
  }
  
  public boolean onBeforeProcess(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    int j = this.filters.size();
    for (int i = 0; i < j; i++)
    {
      IDataSourceInterceptor localIDataSourceInterceptor = (IDataSourceInterceptor)this.filters.get(i);
      if (localIDataSourceInterceptor.onBeforeProcess(paramDataSourceRequest, paramIServiceContext)) {
        return true;
      }
    }
    return false;
  }
  
  public boolean isParameterizable()
  {
    return this.parameterizable;
  }
  
  public Object parameterize(Map paramMap)
  {
    if ((!this.parameterizable) || (paramMap == null)) {
      return this;
    }
    ArrayList localArrayList = new ArrayList(this.filters);
    int j = localArrayList.size();
    for (int i = 0; i < j; i++)
    {
      IDataSourceInterceptor localIDataSourceInterceptor = (IDataSourceInterceptor)localArrayList.get(i);
      localArrayList.set(i, localIDataSourceInterceptor.parameterize(paramMap));
    }
    return new CompositeDsFilter(localArrayList, true);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\filter\CompositeDsFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */