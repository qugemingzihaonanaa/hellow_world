package edu.thu.model.stg.ds.filter;

import edu.thu.search.IQuery;
import java.util.Collection;
import java.util.Map;

public class DataSourceRequest
{
  IQuery A;
  Map B;
  Collection C;
  
  public DataSourceRequest() {}
  
  public DataSourceRequest(IQuery paramIQuery)
  {
    this.A = paramIQuery;
  }
  
  public DataSourceRequest(IQuery paramIQuery, Map paramMap)
  {
    this.A = paramIQuery;
    this.B = paramMap;
  }
  
  public DataSourceRequest(Map paramMap)
  {
    this.B = paramMap;
  }
  
  public DataSourceRequest(Collection paramCollection)
  {
    this.C = paramCollection;
  }
  
  public Collection getInfos()
  {
    return this.C;
  }
  
  public Map getInfo()
  {
    return this.B;
  }
  
  public void setInfo(Map paramMap)
  {
    this.B = paramMap;
  }
  
  public IQuery getQuery()
  {
    return this.A;
  }
  
  public void setQuery(IQuery paramIQuery)
  {
    this.A = paramIQuery;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\filter\DataSourceRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */