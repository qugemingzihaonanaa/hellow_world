package edu.thu.model.stg.ds.filter;

import edu.thu.global.Debug;
import edu.thu.search.Condition;
import edu.thu.search.IQuery;
import edu.thu.search.Query;
import edu.thu.search.Query.ConditionSpec;
import edu.thu.service.IServiceContext;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class FixedValueDsFilter
  implements IDataSourceInterceptor
{
  Map conds;
  
  public FixedValueDsFilter(Map paramMap)
  {
    Debug.check(paramMap != null);
    this.conds = new HashMap(paramMap);
  }
  
  public FixedValueDsFilter(String paramString, Object paramObject)
  {
    Debug.check(paramString);
    this.conds = new HashMap(2);
    this.conds.put(paramString, paramObject);
  }
  
  public Object clone()
  {
    return new FixedValueDsFilter(this.conds);
  }
  
  public boolean onBeforeAdd(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    paramDataSourceRequest.getInfo().putAll(this.conds);
    return false;
  }
  
  public boolean onBeforeAddMany(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    Collection localCollection = paramDataSourceRequest.getInfos();
    Iterator localIterator = localCollection.iterator();
    while (localIterator.hasNext())
    {
      Map localMap = (Map)localIterator.next();
      localMap.putAll(this.conds);
    }
    return false;
  }
  
  void _doFilter(DataSourceRequest paramDataSourceRequest)
  {
    Map localMap = paramDataSourceRequest.getInfo();
    if (localMap != null) {
      localMap.putAll(this.conds);
    }
    Object localObject = paramDataSourceRequest.getQuery();
    if (localObject == null)
    {
      localObject = Condition.eq(this.conds);
      paramDataSourceRequest.setQuery((IQuery)localObject);
    }
    else
    {
      ((Query)localObject).condition().eq(this.conds);
    }
  }
  
  public boolean onBeforeQuery(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    _doFilter(paramDataSourceRequest);
    return false;
  }
  
  public boolean onBeforeRemove(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    _doFilter(paramDataSourceRequest);
    return false;
  }
  
  public boolean onBeforeUpdate(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    _doFilter(paramDataSourceRequest);
    return false;
  }
  
  public boolean onBeforeProcess(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    _doFilter(paramDataSourceRequest);
    return false;
  }
  
  public boolean isParameterizable()
  {
    return false;
  }
  
  public Object parameterize(Map paramMap)
  {
    return this;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\filter\FixedValueDsFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */