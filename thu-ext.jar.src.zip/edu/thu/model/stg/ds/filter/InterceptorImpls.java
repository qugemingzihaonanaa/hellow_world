package edu.thu.model.stg.ds.filter;

import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.aop.ISupportMethodName;
import edu.thu.lang.IGetter;
import edu.thu.lang.IVariant;
import edu.thu.lang.el.IExpressionReference;
import edu.thu.lang.util.TplC;
import edu.thu.model.stg.ds.spi.DsConstants;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceContext;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.aopalliance.intercept.MethodInvocation;

public class InterceptorImpls
  implements DsConstants
{
  public static String getMethodName(MethodInvocation paramMethodInvocation)
  {
    String str = null;
    Method localMethod = paramMethodInvocation.getMethod();
    if (localMethod != null) {
      str = localMethod.getName();
    } else if ((paramMethodInvocation instanceof ISupportMethodName)) {
      str = ((ISupportMethodName)paramMethodInvocation).getMethodName();
    }
    if (str == null) {
      throw Exceptions.code("ds.CAN_err_ds_invocation_no_method_name").param(paramMethodInvocation);
    }
    return str;
  }
  
  public static Map getVars(IServiceContext paramIServiceContext)
  {
    if ((paramIServiceContext instanceof Map)) {
      return (Map)paramIServiceContext;
    }
    if ((paramIServiceContext instanceof IGetter)) {
      return new A((IGetter)paramIServiceContext);
    }
    Debug.trace("ds.CAN_err_context_no_vars::" + paramIServiceContext);
    return Collections.EMPTY_MAP;
  }
  
  public static void applyExInfo(Map paramMap1, Map paramMap2, IServiceContext paramIServiceContext)
  {
    if (paramMap1 == null) {
      return;
    }
    Map localMap = getVars(paramIServiceContext);
    Iterator localIterator = paramMap1.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      Object localObject1 = localEntry.getKey();
      Object localObject2 = localEntry.getValue();
      if (TplC.isExpr(localObject2)) {
        localObject2 = TplC.evaluate((IExpressionReference)localObject2, localMap);
      }
      localObject2 = paramMap2.put(localObject1, localObject2);
      if (localObject2 != null) {
        Debug.traceErr("ds.CAN_err_override_var::" + localObject1);
      }
    }
  }
  
  public static void applyExInfoMany(Map paramMap, Collection paramCollection, IServiceContext paramIServiceContext)
  {
    Map localMap1 = getVars(paramIServiceContext);
    Iterator localIterator1 = paramMap.entrySet().iterator();
    while (localIterator1.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator1.next();
      Object localObject1 = localEntry.getKey();
      Object localObject2 = localEntry.getValue();
      if (TplC.isExpr(localObject2)) {
        localObject2 = TplC.evaluate((IExpressionReference)localObject2, localMap1);
      }
      Iterator localIterator2 = paramCollection.iterator();
      while (localIterator2.hasNext())
      {
        Map localMap2 = (Map)localIterator2.next();
        localObject2 = localMap2.put(localObject1, localObject2);
        if (localObject2 != null) {
          Debug.traceErr("ds.CAN_err_override_add::" + localObject1);
        }
      }
    }
  }
  
  public static Map parseSet(TreeNode paramTreeNode, boolean paramBoolean)
  {
    if (paramTreeNode == null)
    {
      if (paramBoolean) {
        throw Exceptions.code("ds.CAN_err_no_set_node").param(paramTreeNode);
      }
      return null;
    }
    int j = paramTreeNode.getChildCount();
    if (j <= 0) {
      return null;
    }
    HashMap localHashMap = new HashMap(j);
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(i);
      String str = localTreeNode.attribute("name").stripedStringValue();
      if (str == null) {
        throw Exceptions.code("ds.CAN_err_set_no_name_arg").param(localTreeNode);
      }
      if (!localTreeNode.hasAttribute("value")) {
        throw Exceptions.code("ds.CAN_err_set_no_value_arg").param(localTreeNode);
      }
      IExpressionReference localIExpressionReference = TplC.parseExpression(localTreeNode.attribute("value").stringValue());
      localHashMap.put(str, localIExpressionReference);
    }
    return localHashMap;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\filter\InterceptorImpls.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */