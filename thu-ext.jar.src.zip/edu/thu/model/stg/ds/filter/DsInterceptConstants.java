package edu.thu.model.stg.ds.filter;

import java.util.Arrays;
import java.util.List;

public abstract interface DsInterceptConstants
{
  public static final String METHOD_FIND_ONE = "findOne";
  public static final String METHOD_FIND_MANY = "findMany";
  public static final String METHOD_ADD = "add";
  public static final String METHOD_ADD_MANY = "addAll";
  public static final String METHOD_UPDATE = "update";
  public static final String METHOD_EXECUTE = "execute";
  public static final String METHOD_EXISTS = "exists";
  public static final String METHOD_CLEAR = "clear";
  public static final String METHOD_REMOVE = "remove";
  public static final String METHOD_SELECT_FOR_UPDATE = "selectForUpdate";
  public static final String APPLY_TO_NAME = "applyTo";
  public static final String FILTER_NAME = "filter";
  public static final String EX_ADD_NAME = "exAdd";
  public static final String EX_UPDATE_NAME = "exUpdate";
  public static final String SYSTEM_NAME = "system";
  public static final List DATA_OP_METHODS = Arrays.asList(new String[] { "add", "remove", "update", "findOne", "clear", "findMany", "exists", "selectForUpdate" });
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\filter\DsInterceptConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */