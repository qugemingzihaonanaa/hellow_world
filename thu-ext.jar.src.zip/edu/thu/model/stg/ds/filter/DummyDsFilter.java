package edu.thu.model.stg.ds.filter;

import edu.thu.service.IServiceContext;
import java.util.Map;

public class DummyDsFilter
  implements IDataSourceInterceptor
{
  public static final DummyDsFilter SINGLETON = new DummyDsFilter();
  
  public Object clone()
  {
    return this;
  }
  
  public boolean onBeforeAdd(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    return false;
  }
  
  public boolean onBeforeAddMany(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    return false;
  }
  
  public boolean onBeforeQuery(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    return false;
  }
  
  public boolean onBeforeRemove(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    return false;
  }
  
  public boolean onBeforeUpdate(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    return false;
  }
  
  public boolean onBeforeProcess(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    return false;
  }
  
  public boolean isParameterizable()
  {
    return false;
  }
  
  public Object parameterize(Map paramMap)
  {
    return this;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\filter\DummyDsFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */