package edu.thu.model.stg.ds.filter;

import edu.thu.config.IConfigInfo;
import edu.thu.config.IConfigurable;
import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IGetter;
import edu.thu.lang.IVariant;
import edu.thu.lang.el.IExpressionReference;
import edu.thu.lang.util.TplC;
import edu.thu.model.stg.ds.spi.DsConstants;
import edu.thu.model.tree.TreeNode;
import edu.thu.search.Query;
import edu.thu.service.IServiceContext;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class XmlConfigDsFilter
  implements IDataSourceInterceptor, IConfigurable, DsConstants
{
  TreeNode queryFilter;
  TreeNode updateFilter;
  TreeNode removeFilter;
  TreeNode procFilter;
  Map exAdd;
  Map exUpdate;
  
  protected Map getVars(IServiceContext paramIServiceContext)
  {
    if ((paramIServiceContext instanceof Map)) {
      return (Map)paramIServiceContext;
    }
    if ((paramIServiceContext instanceof IGetter)) {
      return new A((IGetter)paramIServiceContext);
    }
    throw Exceptions.code("ds.CAN_err_unknown_context_type").param(paramIServiceContext);
  }
  
  void applyExInfo(Map paramMap, DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    if (paramMap == null) {
      return;
    }
    Map localMap1 = paramDataSourceRequest.getInfo();
    Map localMap2 = getVars(paramIServiceContext);
    Iterator localIterator = this.exAdd.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      Object localObject1 = localEntry.getKey();
      Object localObject2 = localEntry.getValue();
      if (TplC.isExpr(localObject2)) {
        localObject2 = TplC.evaluate((IExpressionReference)localObject2, localMap2);
      }
      localObject2 = localMap1.put(localObject1, localObject2);
      if (localObject2 != null) {
        Debug.traceErr("ds.CAN_err_override_var::" + localObject1);
      }
    }
  }
  
  public boolean onBeforeAdd(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    applyExInfo(this.exAdd, paramDataSourceRequest, paramIServiceContext);
    return false;
  }
  
  public boolean onBeforeAddMany(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    Collection localCollection = paramDataSourceRequest.getInfos();
    Debug.check(localCollection);
    Map localMap1 = getVars(paramIServiceContext);
    Iterator localIterator1 = this.exAdd.entrySet().iterator();
    while (localIterator1.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator1.next();
      Object localObject1 = localEntry.getKey();
      Object localObject2 = localEntry.getValue();
      if (TplC.isExpr(localObject2)) {
        localObject2 = TplC.evaluate((IExpressionReference)localObject2, localMap1);
      }
      Iterator localIterator2 = localCollection.iterator();
      while (localIterator2.hasNext())
      {
        Map localMap2 = (Map)localIterator2.next();
        localObject2 = localMap2.put(localObject1, localObject2);
        if (localObject2 != null) {
          Debug.traceErr("ds.CAN_err_override_add::" + localObject1);
        }
      }
    }
    return false;
  }
  
  void applyFilter(TreeNode paramTreeNode, DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    if (paramTreeNode == null) {
      return;
    }
    paramTreeNode = null;
    Query localQuery = (Query)paramDataSourceRequest.getQuery();
    if (localQuery == null)
    {
      localQuery = new Query();
      localQuery.filter().appendChild(paramTreeNode);
      paramDataSourceRequest.setQuery(localQuery);
    }
    else
    {
      localQuery.filter().appendChild(paramTreeNode);
    }
  }
  
  public boolean onBeforeProcess(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    applyFilter(this.procFilter, paramDataSourceRequest, paramIServiceContext);
    return false;
  }
  
  public boolean onBeforeQuery(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    applyFilter(this.queryFilter, paramDataSourceRequest, paramIServiceContext);
    return false;
  }
  
  public boolean onBeforeRemove(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    applyFilter(this.removeFilter, paramDataSourceRequest, paramIServiceContext);
    return false;
  }
  
  public boolean onBeforeUpdate(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext)
  {
    applyFilter(this.updateFilter, paramDataSourceRequest, paramIServiceContext);
    applyExInfo(this.exUpdate, paramDataSourceRequest, paramIServiceContext);
    return false;
  }
  
  public Object clone()
  {
    return this;
  }
  
  public boolean isParameterizable()
  {
    return false;
  }
  
  public Object parameterize(Map paramMap)
  {
    return this;
  }
  
  TreeNode parseFilter(TreeNode paramTreeNode, boolean paramBoolean)
  {
    TreeNode localTreeNode = paramTreeNode.existingChild("filter");
    if (localTreeNode == null)
    {
      if (paramBoolean) {
        throw Exceptions.code("ds.CAN_err_no_filter_node").param(paramTreeNode);
      }
      return null;
    }
    return null;
  }
  
  Map parseSet(TreeNode paramTreeNode, boolean paramBoolean)
  {
    TreeNode localTreeNode1 = paramTreeNode.existingChild("filter");
    if (localTreeNode1 == null)
    {
      if (paramBoolean) {
        throw Exceptions.code("ds.CAN_err_no_set_node").param(paramTreeNode);
      }
      return null;
    }
    int j = localTreeNode1.getChildCount();
    if (j <= 0) {
      return null;
    }
    HashMap localHashMap = new HashMap(j);
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode2 = localTreeNode1.getChild(i);
      String str = localTreeNode2.attribute("name").stripedStringValue();
      if (str == null) {
        throw Exceptions.code("ds.CAN_err_set_no_name_arg").param(localTreeNode2);
      }
      if (!localTreeNode2.hasAttribute("value")) {
        throw Exceptions.code("ds.CAN_err_set_no_value_arg").param(localTreeNode2);
      }
      IExpressionReference localIExpressionReference = TplC.parseExpression(localTreeNode2.attribute("value").stringValue());
      localHashMap.put(str, localIExpressionReference);
    }
    return localHashMap;
  }
  
  public void setConfig(IConfigInfo paramIConfigInfo)
  {
    TreeNode localTreeNode1 = TreeNode.toNode(paramIConfigInfo);
    int j = localTreeNode1.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode2 = localTreeNode1.getChild(i);
      if (localTreeNode2.getName().equals("applyTo")) {
        throw Exceptions.code("ds.CAN_err_not_apply_to_node").param(localTreeNode2);
      }
      String str = localTreeNode2.attribute("operation").stripedStringValue();
      if (str == null) {
        throw Exceptions.code("ds.CAN_err_apply_to_no_operation_arg").param(localTreeNode2);
      }
      if (str.equals("*"))
      {
        TreeNode localTreeNode3 = parseFilter(localTreeNode2, true);
        this.queryFilter = localTreeNode3;
        this.removeFilter = localTreeNode3;
        this.updateFilter = localTreeNode3;
        this.procFilter = localTreeNode3;
      }
      else if (str.equals("query"))
      {
        this.queryFilter = parseFilter(localTreeNode2, true);
      }
      else if (str.equals("remove"))
      {
        this.removeFilter = parseFilter(localTreeNode2, true);
      }
      else if (str.equals("update"))
      {
        this.updateFilter = parseFilter(localTreeNode2, false);
        this.exUpdate = parseSet(localTreeNode2, false);
      }
      else if (str.equals("process"))
      {
        this.procFilter = parseFilter(localTreeNode2, true);
      }
      else if (str.equals("add"))
      {
        this.exAdd = parseSet(localTreeNode2, true);
      }
      else
      {
        throw Exceptions.code("ds.CAN_err_unknown_operation").param(str);
      }
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\filter\XmlConfigDsFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */