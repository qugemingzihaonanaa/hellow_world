package edu.thu.model.stg.ds.filter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

public class DsCacheInterceptor
  implements MethodInterceptor, DsInterceptConstants
{
  Map<Object, Object> cache = new ConcurrentHashMap();
  static final Map INVALID_OBJECT = new HashMap(0);
  
  public List getApplyTo()
  {
    return DATA_OP_METHODS;
  }
  
  public Object invoke(MethodInvocation paramMethodInvocation)
    throws Throwable
  {
    String str = InterceptorImpls.getMethodName(paramMethodInvocation);
    if (!"findOne".equals(str)) {
      "update".equals(str);
    }
    Object localObject = null;
    Map localMap = (Map)this.cache.get(localObject);
    if (localMap == INVALID_OBJECT) {
      return null;
    }
    if (localMap == null) {
      localMap = (Map)paramMethodInvocation.proceed();
    }
    if (localMap == null)
    {
      this.cache.put(localObject, INVALID_OBJECT);
      return null;
    }
    this.cache.put(localObject, localMap);
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\filter\DsCacheInterceptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */