package edu.thu.model.stg.ds.filter;

import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IGetter;
import java.util.AbstractMap;
import java.util.Set;

class A
  extends AbstractMap
{
  IGetter A;
  
  public A(IGetter paramIGetter)
  {
    this.A = paramIGetter;
  }
  
  public Object get(Object paramObject)
  {
    return this.A.get(paramObject);
  }
  
  public Set entrySet()
  {
    throw Exceptions.notAllowed();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\filter\A.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */