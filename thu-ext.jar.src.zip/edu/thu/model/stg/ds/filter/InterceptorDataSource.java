package edu.thu.model.stg.ds.filter;

import edu.thu.java.aop.spi.MapMethodInvocation;
import edu.thu.java.aop.spi.MethodInvocationImpl;
import edu.thu.java.util.Coercions;
import edu.thu.model.stg.ds.IDataSource;
import edu.thu.model.stg.ds.IDataSourceUpdator;
import edu.thu.model.stg.ds.spi.ProxyDataSource;
import edu.thu.model.stg.view.IPageViewer;
import edu.thu.search.IQuery;
import edu.thu.service.ICancelMonitor;
import edu.thu.service.IServiceContext;
import java.util.Map;

public class InterceptorDataSource
  extends ProxyDataSource
  implements DsInterceptConstants
{
  MapMethodInvocation invocation;
  
  public InterceptorDataSource(IDataSource paramIDataSource)
  {
    super(paramIDataSource);
    this.invocation = new MapMethodInvocation();
  }
  
  public InterceptorDataSource(IDataSource paramIDataSource, MapMethodInvocation paramMapMethodInvocation)
  {
    super(paramIDataSource);
    this.invocation = paramMapMethodInvocation;
  }
  
  protected Object createThis(IDataSource paramIDataSource)
  {
    return new InterceptorDataSource(paramIDataSource, this.invocation);
  }
  
  public IDataSourceUpdator getUpdator(Object paramObject)
  {
    return new InterceptorDataSourceUpdator(super.getUpdator(paramObject), this.invocation);
  }
  
  public Object execute(String paramString, Map paramMap, IServiceContext paramIServiceContext)
  {
    return this.invocation.invoke("execute", new _C(paramString, paramMap, paramIServiceContext));
  }
  
  public boolean exists(IQuery paramIQuery, ICancelMonitor paramICancelMonitor)
  {
    return Coercions.toBoolean(this.invocation.invoke("exists", new _A(paramIQuery, paramICancelMonitor)), false);
  }
  
  public IPageViewer findMany(Object paramObject, IQuery paramIQuery, ICancelMonitor paramICancelMonitor)
  {
    return (IPageViewer)this.invocation.invoke("findMany", new _B(paramObject, paramIQuery, paramICancelMonitor));
  }
  
  public Object findOne(Object paramObject, IQuery paramIQuery, ICancelMonitor paramICancelMonitor)
  {
    return this.invocation.invoke("findOne", new _D(paramObject, paramIQuery, paramICancelMonitor));
  }
  
  class _C
    extends MethodInvocationImpl
  {
    public _C(String paramString, Map paramMap, IServiceContext paramIServiceContext)
    {
      super("execute", new Object[] { paramString, paramMap, paramIServiceContext });
    }
    
    public Object proceed()
    {
      return InterceptorDataSource.this.getDataSource().execute((String)getArguments()[0], (Map)getArguments()[1], (IServiceContext)getArguments()[2]);
    }
  }
  
  class _A
    extends MethodInvocationImpl
  {
    public _A(IQuery paramIQuery, ICancelMonitor paramICancelMonitor)
    {
      super("exists", new Object[] { paramIQuery, paramICancelMonitor });
    }
    
    public Object proceed()
    {
      return InterceptorDataSource.this.getDataSource().exists((IQuery)getArguments()[0], (ICancelMonitor)getArguments()[1]) ? Boolean.TRUE : Boolean.FALSE;
    }
  }
  
  class _B
    extends MethodInvocationImpl
  {
    public _B(Object paramObject, IQuery paramIQuery, ICancelMonitor paramICancelMonitor)
    {
      super("findMany", new Object[] { paramObject, paramIQuery, paramICancelMonitor });
    }
    
    public Object proceed()
    {
      Object[] arrayOfObject = getArguments();
      return InterceptorDataSource.this.getDataSource().findMany(arrayOfObject[0], (IQuery)arrayOfObject[1], (ICancelMonitor)arrayOfObject[2]);
    }
  }
  
  class _D
    extends MethodInvocationImpl
  {
    public _D(Object paramObject, IQuery paramIQuery, ICancelMonitor paramICancelMonitor)
    {
      super("findOne", new Object[] { paramObject, paramIQuery, paramICancelMonitor });
    }
    
    public Object proceed()
    {
      Object[] arrayOfObject = getArguments();
      return InterceptorDataSource.this.getDataSource().findOne(arrayOfObject[0], (IQuery)arrayOfObject[1], (ICancelMonitor)arrayOfObject[2]);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\filter\InterceptorDataSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */