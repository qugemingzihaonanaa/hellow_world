package edu.thu.model.stg.ds.filter;

import edu.thu.java.aop.spi.MapMethodInvocation;
import edu.thu.java.aop.spi.MethodInvocationImpl;
import edu.thu.java.util.Coercions;
import edu.thu.model.data.table.IRowSet;
import edu.thu.model.stg.ds.IDataSourceUpdator;
import edu.thu.model.stg.ds.spi.ProxyDataSourceUpdator;
import edu.thu.search.IQuery;
import java.util.Collection;
import java.util.Map;

public class InterceptorDataSourceUpdator
  extends ProxyDataSourceUpdator
  implements DsInterceptConstants
{
  MapMethodInvocation invocation;
  
  public InterceptorDataSourceUpdator(IDataSourceUpdator paramIDataSourceUpdator, MapMethodInvocation paramMapMethodInvocation)
  {
    super(paramIDataSourceUpdator);
    this.invocation = paramMapMethodInvocation;
  }
  
  protected ProxyDataSourceUpdator createThis(IDataSourceUpdator paramIDataSourceUpdator)
  {
    return new InterceptorDataSourceUpdator(paramIDataSourceUpdator, this.invocation);
  }
  
  public Object add(Map paramMap)
  {
    return this.invocation.invoke("add", new _F(paramMap));
  }
  
  public void addMany(Collection paramCollection)
  {
    this.invocation.invoke("addAll", new _B(paramCollection));
  }
  
  public void clear()
  {
    this.invocation.invoke("clear", new _C());
  }
  
  public int remove(IQuery paramIQuery)
  {
    return Coercions.toInt(this.invocation.invoke("remove", new _A(paramIQuery)), 0);
  }
  
  public IRowSet selectForUpdate(IQuery paramIQuery)
  {
    return (IRowSet)this.invocation.invoke("selectForUpdate", new _D(paramIQuery));
  }
  
  public int update(Map paramMap, IQuery paramIQuery)
  {
    return Coercions.toInt(this.invocation.invoke("update", new _E(paramMap, paramIQuery)), 0);
  }
  
  class _B
    extends MethodInvocationImpl
  {
    public _B(Collection paramCollection)
    {
      super("addAll", new Object[] { paramCollection });
    }
    
    public Object proceed()
    {
      InterceptorDataSourceUpdator.this.du.addMany((Collection)getArguments()[0]);
      return null;
    }
  }
  
  class _F
    extends MethodInvocationImpl
  {
    public _F(Map paramMap)
    {
      super("add", new Object[] { paramMap });
    }
    
    public Object proceed()
    {
      return InterceptorDataSourceUpdator.this.du.add((Map)getArguments()[0]);
    }
  }
  
  class _C
    extends MethodInvocationImpl
  {
    public _C()
    {
      super("clear", new Object[0]);
    }
    
    public Object proceed()
    {
      InterceptorDataSourceUpdator.this.du.clear();
      return null;
    }
  }
  
  class _A
    extends MethodInvocationImpl
  {
    public _A(IQuery paramIQuery)
    {
      super("remove", new Object[] { paramIQuery });
    }
    
    public Object proceed()
    {
      return new Integer(InterceptorDataSourceUpdator.this.du.remove((IQuery)getArguments()[0]));
    }
  }
  
  class _D
    extends MethodInvocationImpl
  {
    public _D(IQuery paramIQuery)
    {
      super("selectForUpdate", new Object[] { paramIQuery });
    }
    
    public Object proceed()
    {
      return InterceptorDataSourceUpdator.this.du.selectForUpdate((IQuery)getArguments()[0]);
    }
  }
  
  class _E
    extends MethodInvocationImpl
  {
    public _E(Map paramMap, IQuery paramIQuery)
    {
      super("update", new Object[] { paramMap, paramIQuery });
    }
    
    public Object proceed()
    {
      return new Integer(InterceptorDataSourceUpdator.this.du.update((Map)getArguments()[0], (IQuery)getArguments()[1]));
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\filter\InterceptorDataSourceUpdator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */