package edu.thu.model.stg.ds.filter;

import edu.thu.config.IConfigInfo;
import edu.thu.config.IConfigurable;
import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IVariant;
import edu.thu.lang.exceptions.StdException;
import edu.thu.model.stg.ds.IDataSource;
import edu.thu.model.stg.ds.IDataSourceUpdator;
import edu.thu.model.tree.TreeNode;
import edu.thu.search.IQuery;
import edu.thu.search.Query;
import edu.thu.service.IServiceContext;
import edu.thu.service.SystemServiceContext;
import java.util.List;
import java.util.Map;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

public class DsFilterInterceptor
  implements MethodInterceptor, DsInterceptConstants, IConfigurable
{
  Map exAdd;
  Map exUpdate;
  TreeNode filter;
  boolean system;
  
  public void setConfig(IConfigInfo paramIConfigInfo)
  {
    TreeNode localTreeNode1 = TreeNode.toNode(paramIConfigInfo);
    this.system = localTreeNode1.attribute("system").booleanValue(false);
    TreeNode localTreeNode2 = localTreeNode1.existingChild("filter");
    TreeNode localTreeNode3 = localTreeNode1.existingChild("exAdd");
    TreeNode localTreeNode4 = localTreeNode1.existingChild("exUpdate");
    this.filter = null;
    if (this.filter != null) {
      Debug.trace("ds.CAN_load_filter_interceptor::" + localTreeNode2);
    }
    this.exAdd = InterceptorImpls.parseSet(localTreeNode3, false);
    if (this.exAdd != null) {
      Debug.trace("ds.CAN_parse_ex_add_interceptor::" + localTreeNode3);
    }
    this.exUpdate = InterceptorImpls.parseSet(localTreeNode4, false);
    if (this.exUpdate != null) {
      Debug.trace("ds.CAN_parse_ex_update_interceptor::" + localTreeNode4);
    }
  }
  
  public List getApplyTo()
  {
    return DATA_OP_METHODS;
  }
  
  IServiceContext getContext(MethodInvocation paramMethodInvocation)
  {
    Object localObject = paramMethodInvocation.getThis();
    if ((localObject instanceof IDataSource)) {
      return ((IDataSource)localObject).getContext();
    }
    if ((localObject instanceof IDataSourceUpdator)) {
      return ((IDataSourceUpdator)localObject).getContext();
    }
    return null;
  }
  
  public Object invoke(MethodInvocation paramMethodInvocation)
    throws Throwable
  {
    IServiceContext localIServiceContext = getContext(paramMethodInvocation);
    if ((!this.system) && ((localIServiceContext == null) || ((localIServiceContext instanceof SystemServiceContext)))) {
      return paramMethodInvocation.proceed();
    }
    String str = InterceptorImpls.getMethodName(paramMethodInvocation);
    Object[] arrayOfObject = paramMethodInvocation.getArguments();
    Object localObject1;
    Object localObject2;
    if (this.filter != null) {
      if (("findOne".equals(str)) || ("findMany".equals(str)))
      {
        localObject1 = (Query)arrayOfObject[1];
        localObject2 = (IDataSource)paramMethodInvocation.getThis();
        localObject1 = null;
        arrayOfObject[1] = localObject1;
      }
      else if ("exists".equals(str))
      {
        localObject1 = (Query)arrayOfObject[0];
        localObject2 = (IDataSource)paramMethodInvocation.getThis();
        localObject1 = null;
        arrayOfObject[0] = localObject1;
      }
      else if ("update".equals(str))
      {
        localObject1 = (Query)arrayOfObject[1];
        localObject2 = (IDataSourceUpdator)paramMethodInvocation.getThis();
        localObject1 = null;
        arrayOfObject[1] = localObject1;
      }
      else if (("remove".equals(str)) || ("selectForUpdate".equals(str)))
      {
        localObject1 = (Query)arrayOfObject[0];
        localObject2 = (IDataSourceUpdator)paramMethodInvocation.getThis();
        localObject1 = null;
        arrayOfObject[0] = localObject1;
      }
      else
      {
        if ("clear".equals(str))
        {
          localObject1 = (IDataSourceUpdator)paramMethodInvocation.getThis();
          if ((localObject1 instanceof InterceptorDataSourceUpdator)) {
            localObject1 = ((InterceptorDataSourceUpdator)localObject1).getDataSourceUpdator();
          }
          localObject2 = null;
          ((IDataSourceUpdator)localObject1).remove((IQuery)localObject2);
          return null;
        }
        if (!"add".equals(str)) {
          throw Exceptions.code("ds.CAN_err_invalid_intercept_method").param(str).param(paramMethodInvocation);
        }
      }
    }
    if ((this.exAdd != null) && ("add".equals(str)))
    {
      localObject1 = (Map)arrayOfObject[0];
      localObject2 = (IDataSourceUpdator)paramMethodInvocation.getThis();
      InterceptorImpls.applyExInfo(this.exAdd, (Map)localObject1, ((IDataSourceUpdator)localObject2).getContext());
    }
    if ((this.exUpdate != null) && ("update".equals(str)))
    {
      localObject1 = (Map)arrayOfObject[0];
      localObject2 = (IDataSourceUpdator)paramMethodInvocation.getThis();
      InterceptorImpls.applyExInfo(this.exUpdate, (Map)localObject1, ((IDataSourceUpdator)localObject2).getContext());
    }
    return paramMethodInvocation.proceed();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\filter\DsFilterInterceptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */