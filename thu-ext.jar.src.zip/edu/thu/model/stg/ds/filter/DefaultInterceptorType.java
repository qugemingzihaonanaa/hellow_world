package edu.thu.model.stg.ds.filter;

import edu.thu.global.spi.ClassType;
import org.aopalliance.intercept.Interceptor;

public class DefaultInterceptorType
  extends ClassType
{
  private static final long serialVersionUID = 4731145658105593645L;
  
  public DefaultInterceptorType()
  {
    super(Interceptor.class);
  }
  
  public Object getInstance(Object paramObject)
  {
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\filter\DefaultInterceptorType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */