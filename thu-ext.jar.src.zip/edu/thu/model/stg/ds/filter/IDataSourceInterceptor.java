package edu.thu.model.stg.ds.filter;

import edu.thu.global.ICloneable;
import edu.thu.service.IParameterizable;
import edu.thu.service.IServiceContext;

public abstract interface IDataSourceInterceptor
  extends ICloneable, IParameterizable
{
  public abstract boolean onBeforeQuery(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext);
  
  public abstract boolean onBeforeAdd(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext);
  
  public abstract boolean onBeforeAddMany(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext);
  
  public abstract boolean onBeforeUpdate(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext);
  
  public abstract boolean onBeforeRemove(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext);
  
  public abstract boolean onBeforeProcess(DataSourceRequest paramDataSourceRequest, IServiceContext paramIServiceContext);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\filter\IDataSourceInterceptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */