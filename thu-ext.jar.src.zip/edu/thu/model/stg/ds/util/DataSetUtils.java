package edu.thu.model.stg.ds.util;

import edu.thu.global.Debug;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class DataSetUtils
{
  public static List joinSub(List paramList, String paramString1, String paramString2)
  {
    if ((paramList == null) || (paramList.size() <= 0)) {
      return null;
    }
    ArrayList localArrayList = new ArrayList();
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      Map localMap = (Map)paramList.get(i);
      Object localObject1 = localMap.get(paramString1);
      Debug.check(localObject1);
      Object localObject2 = getFirstMatchRow(localArrayList, paramString1, localObject1);
      if (localObject2 == null)
      {
        localObject2 = new HashMap();
        ((Map)localObject2).put(paramString1, localObject1);
        ((Map)localObject2).put(paramString2, localMap.get(paramString2));
        localArrayList.add(localObject2);
      }
      else
      {
        Object localObject3 = ((Map)localObject2).get(paramString2);
        Object localObject4 = localMap.get(paramString2);
        localObject3 = localObject3 == null ? "" : localObject3;
        localObject4 = localObject4 == null ? "" : localObject4;
        localObject4 = localObject3 + "," + localObject4;
        ((Map)localObject2).put(paramString2, localObject4);
      }
    }
    return localArrayList;
  }
  
  public static void leftJoinUnique(List paramList1, String paramString1, List paramList2, String paramString2)
  {
    Debug.check(paramString1);
    Debug.check(paramString2);
    if ((paramList1 == null) || (paramList1.isEmpty()) || (paramList2 == null) || (paramList2.isEmpty())) {
      return;
    }
    int j = paramList1.size();
    for (int i = 0; i < j; i++)
    {
      Map localMap1 = (Map)paramList1.get(i);
      Object localObject = localMap1.get(paramString1);
      if (localObject != null)
      {
        Map localMap2 = getFirstMatchRow(paramList2, paramString2, localObject);
        if (localMap2 != null) {
          localMap1.putAll(localMap2);
        }
      }
    }
  }
  
  public static void leftJoinUnique(List paramList1, List paramList2, Map paramMap)
  {
    if ((paramList1 == null) || (paramList1.isEmpty()) || (paramList2 == null) || (paramList2.isEmpty())) {
      return;
    }
    int j = paramList1.size();
    HashMap localHashMap1 = new HashMap(paramMap.size());
    for (int i = 0; i < j; i++)
    {
      Map localMap = (Map)paramList1.get(i);
      Iterator localIterator = paramMap.entrySet().iterator();
      HashMap localHashMap2 = localHashMap1;
      localHashMap1.clear();
      Object localObject1;
      while (localIterator.hasNext())
      {
        localObject1 = (Map.Entry)localIterator.next();
        String str1 = (String)((Map.Entry)localObject1).getKey();
        String str2 = (String)((Map.Entry)localObject1).getValue();
        Object localObject2 = localMap.get(str1);
        if (localObject2 == null)
        {
          localHashMap2 = null;
          break;
        }
        localHashMap1.put(str2, localObject2);
      }
      if (localHashMap2 != null)
      {
        localObject1 = getFirstMatchRow(paramList2, localHashMap2);
        if (localObject1 != null) {
          localMap.putAll((Map)localObject1);
        }
      }
    }
  }
  
  public static Map getFirstMatchRow(List paramList, String paramString, Object paramObject)
  {
    Debug.check(paramObject);
    if (paramList == null) {
      return null;
    }
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      Map localMap = (Map)paramList.get(i);
      if (paramObject.equals(localMap.get(paramString))) {
        return localMap;
      }
    }
    return null;
  }
  
  public static Map getFirstMatchRow(List paramList, Map paramMap)
  {
    Debug.check(paramMap);
    if (paramList == null) {
      return null;
    }
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      Map localMap = (Map)paramList.get(i);
      Iterator localIterator = paramMap.entrySet().iterator();
      int k = 1;
      while (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        String str = (String)localEntry.getKey();
        Object localObject = localEntry.getValue();
        if (!localObject.equals(localMap.get(str)))
        {
          k = 0;
          break;
        }
      }
      if (k != 0) {
        return localMap;
      }
    }
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\util\DataSetUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */