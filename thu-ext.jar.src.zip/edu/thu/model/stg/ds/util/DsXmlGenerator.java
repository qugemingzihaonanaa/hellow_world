package edu.thu.model.stg.ds.util;

import edu.thu.global.Debug;
import edu.thu.lang.IVariant;
import edu.thu.model.data.transform.spi.ClobToStringTransformer;
import edu.thu.model.data.transform.spi.StringDateTransformer;
import edu.thu.model.data.transform.spi.StringToClobTransformer;
import edu.thu.model.stg.ds.spi.DsConstants;
import edu.thu.model.tree.TreeNode;
import edu.thu.text.TextCoder;
import edu.thu.util.FileUtils;
import java.io.File;

public class DsXmlGenerator
  implements DsConstants
{
  String ß = TextCoder.getDefaultCharacterEncoding();
  
  public TreeNode transformFromTableMeta(TreeNode paramTreeNode)
  {
    Debug.check(paramTreeNode.getName().equals("table"));
    TreeNode localTreeNode1 = TreeNode.make("dataSource");
    localTreeNode1.setAttribute("xmlns:ds", "ds");
    Object localObject = null;
    localTreeNode1.makeChild("pkField").setValue("");
    TreeNode localTreeNode2 = localTreeNode1.makeChild("fields");
    TreeNode localTreeNode3 = paramTreeNode.makeChild("columns");
    int j = localTreeNode3.getChildCount();
    Debug.check(j > 0, "ds.CAN_err_table_no_columns");
    for (int i = 0; i < j; i++)
    {
      localTreeNode4 = localTreeNode3.getChild(i);
      TreeNode localTreeNode5 = TreeNode.make("field");
      String str1 = localTreeNode4.attribute("name").stringValue().toLowerCase();
      String str2 = str1;
      if (str2.equals("creater_id")) {
        str2 = "creater";
      } else if (str2.equals("create_time")) {
        str2 = "createTime";
      } else if (str2.equals("updater_id")) {
        str2 = "updater";
      } else if (str2.equals("update_time")) {
        str2 = "updateTime";
      }
      localTreeNode5.setAttribute("name", str2);
      localTreeNode5.setAttribute("baseName", str1);
      boolean bool = localTreeNode4.makeChild("isPrimaryKey").booleanValue(false);
      if (bool) {
        localObject = str2;
      }
      String str3 = localTreeNode4.makeChild("type").stringValue();
      localTreeNode5.makeChild("type").setValue(str3);
      localTreeNode5.makeChild("storeType").setValue(str3);
      String str4 = localTreeNode4.makeChild("nullable").stringValue();
      localTreeNode5.makeChild("nullable").setValue(str4);
      int k = localTreeNode4.makeChild("size").intValue(50);
      localTreeNode5.makeChild("size").setValue(String.valueOf(k));
      localTreeNode5.makeChild("storeSize").setValue(String.valueOf(k));
      int m = k;
      if ((str3.equalsIgnoreCase("string")) && (k > 1)) {
        m = k / 2;
      }
      localTreeNode5.makeChild("maxLength").setValue(String.valueOf(m));
      localTreeNode5.makeChild("visible").setValue(Boolean.TRUE);
      localTreeNode5.makeChild("updatable").setValue(Boolean.TRUE);
      localTreeNode5.makeChild("listable").setValue(Boolean.TRUE);
      localTreeNode5.makeChild("viewable").setValue(Boolean.TRUE);
      localTreeNode5.makeChild("addable").setValue(Boolean.TRUE);
      if (("date".equals(str3)) || ("datetime".equals(str3)))
      {
        localTreeNode5.makeChild("inTransformer").setAttribute("class", StringDateTransformer.class.getName());
      }
      else if ("clob".equals(str3))
      {
        localTreeNode5.makeChild("inTransformer").setAttribute("class", StringToClobTransformer.class.getName());
        localTreeNode5.makeChild("outTransformer").setAttribute("class", ClobToStringTransformer.class.getName());
      }
      localTreeNode5.makeChild("inputor").makeChild("ds:Inputor");
      localTreeNode2.appendChild(localTreeNode5);
    }
    localTreeNode1.makeChild("pkField").setValue(localObject);
    TreeNode localTreeNode4 = localTreeNode1.makeChild("provider");
    localTreeNode4.makeChild("table").setValue(paramTreeNode.getAttribute("name"));
    localTreeNode4.makeChild("view").setValue(paramTreeNode.getAttribute("name"));
    localTreeNode4.makeChild("engine").setValue("default");
    return localTreeNode1;
  }
  
  String A()
  {
    return "<?xml version='1.0' encoding='" + this.ß + "'?>";
  }
  
  public void saveToFile(String paramString, TreeNode paramTreeNode)
  {
    FileUtils.saveNode(new File(paramString), this.ß, paramTreeNode);
  }
  
  public void transformTableAndSave(TreeNode paramTreeNode, String paramString)
  {
    TreeNode localTreeNode = transformFromTableMeta(paramTreeNode);
    saveToFile(paramString, localTreeNode);
  }
  
  public void transformTablesAndSave(TreeNode paramTreeNode, String paramString)
  {
    Debug.check(paramTreeNode.getName().equals("tables"));
    int j = paramTreeNode.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(i);
      transformTableAndSave(localTreeNode, paramString + localTreeNode.getAttribute("name") + ".xml");
    }
  }
  
  String[] A(String paramString1, String paramString2)
  {
    return null;
  }
  
  public void generateEnum(String paramString1, TreeNode paramTreeNode, String paramString2)
  {
    String str = paramTreeNode.getAttribute("name").toString();
    TreeNode localTreeNode = TreeNode.make(str);
    String[] arrayOfString = A(paramString1, str);
    localTreeNode.setAttribute("type", "db");
    localTreeNode.makeChild("idField").setValue("id");
    int j = arrayOfString.length;
    for (int i = 0; i < j; i++) {
      if (!arrayOfString[i].equals("id"))
      {
        localTreeNode.makeChild("valueField").setValue(arrayOfString[i]);
        break;
      }
    }
    localTreeNode.makeChild("table").setValue(str);
    localTreeNode.makeChild("engine").setValue(paramString1);
    saveToFile(paramString2, localTreeNode);
  }
  
  public void generateEnums(String paramString1, TreeNode paramTreeNode, String paramString2)
  {
    Debug.check(paramTreeNode.getName().equals("tables"));
    int j = paramTreeNode.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(i);
      generateEnum(paramString1, localTreeNode, paramString2 + localTreeNode.getAttribute("name") + ".xml");
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\util\DsXmlGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */