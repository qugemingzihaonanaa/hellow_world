package edu.thu.model.stg.ds.meta;

import edu.thu.lang.IVariant;
import edu.thu.model.tree.TreeNode;
import edu.thu.text.TextCoder;
import edu.thu.xml.dom.DomToTree;
import java.io.File;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MetaTool
{
  static final Logger A = LoggerFactory.getLogger(MetaTool.class);
  boolean C = true;
  String B = TextCoder.getDefaultCharacterEncoding();
  
  public String getEncoding()
  {
    return this.B;
  }
  
  public void setEncoding(String paramString)
  {
    this.B = paramString;
  }
  
  public void setSyncFieldAttr(boolean paramBoolean)
  {
    this.C = paramBoolean;
  }
  
  public void syncMeta(TreeNode paramTreeNode, File paramFile)
  {
    if (!paramFile.exists())
    {
      paramFile.getParentFile().mkdirs();
      A(paramTreeNode.toXml(), paramFile);
      return;
    }
    TreeNode localTreeNode = DomToTree.getInstance().allowText(true).transform(paramFile);
    String str1 = localTreeNode.toXml();
    E(paramTreeNode, localTreeNode);
    String str2 = localTreeNode.toXml();
    if (str1.equals(str2)) {
      return;
    }
    A(str2, paramFile);
  }
  
  /* Error */
  void A(String paramString, File paramFile)
  {
    // Byte code:
    //   0: aload_2
    //   1: invokevirtual 52	java/io/File:getParentFile	()Ljava/io/File;
    //   4: astore_3
    //   5: aload_3
    //   6: ifnull +8 -> 14
    //   9: aload_3
    //   10: invokevirtual 56	java/io/File:mkdirs	()Z
    //   13: pop
    //   14: aconst_null
    //   15: astore 4
    //   17: aload_1
    //   18: astore 5
    //   20: new 100	java/io/FileOutputStream
    //   23: dup
    //   24: aload_2
    //   25: invokespecial 102	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   28: astore 4
    //   30: new 105	java/io/OutputStreamWriter
    //   33: dup
    //   34: aload 4
    //   36: aload_0
    //   37: invokevirtual 107	edu/thu/model/stg/ds/meta/MetaTool:getEncoding	()Ljava/lang/String;
    //   40: invokespecial 109	java/io/OutputStreamWriter:<init>	(Ljava/io/OutputStream;Ljava/lang/String;)V
    //   43: astore 6
    //   45: aload 6
    //   47: new 112	java/lang/StringBuilder
    //   50: dup
    //   51: ldc 114
    //   53: invokespecial 116	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   56: aload_0
    //   57: invokevirtual 107	edu/thu/model/stg/ds/meta/MetaTool:getEncoding	()Ljava/lang/String;
    //   60: invokevirtual 118	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   63: ldc 122
    //   65: invokevirtual 118	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   68: invokevirtual 124	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   71: invokevirtual 127	java/io/Writer:write	(Ljava/lang/String;)V
    //   74: aload 6
    //   76: aload 5
    //   78: invokevirtual 127	java/io/Writer:write	(Ljava/lang/String;)V
    //   81: aload 6
    //   83: invokevirtual 132	java/io/Writer:flush	()V
    //   86: goto +22 -> 108
    //   89: astore 5
    //   91: aload 5
    //   93: invokestatic 135	edu/thu/global/exceptions/Exceptions:source	(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;
    //   96: athrow
    //   97: astore 7
    //   99: aload 4
    //   101: invokestatic 141	edu/thu/io/IoUtils:safeClose	(Ljava/io/OutputStream;)Z
    //   104: pop
    //   105: aload 7
    //   107: athrow
    //   108: aload 4
    //   110: invokestatic 141	edu/thu/io/IoUtils:safeClose	(Ljava/io/OutputStream;)Z
    //   113: pop
    //   114: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	115	0	this	MetaTool
    //   0	115	1	paramString	String
    //   0	115	2	paramFile	File
    //   4	6	3	localFile	File
    //   15	94	4	localFileOutputStream	java.io.FileOutputStream
    //   18	59	5	str	String
    //   89	3	5	localException	Exception
    //   43	39	6	localOutputStreamWriter	java.io.OutputStreamWriter
    //   97	9	7	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   17	86	89	java/lang/Exception
    //   17	97	97	finally
  }
  
  void E(TreeNode paramTreeNode1, TreeNode paramTreeNode2)
  {
    String str1 = (String)paramTreeNode2.getAttribute("showName");
    paramTreeNode2.setAttributes(paramTreeNode1.getAttributes());
    if (paramTreeNode2.hasAttribute("showName")) {
      paramTreeNode2.setAttribute("showName", str1);
    }
    String str2 = paramTreeNode1.makeChild("pkField").stripedStringValue();
    if (str2 != null) {
      paramTreeNode2.makeChild("pkField").setValue(str2);
    }
    String str3 = paramTreeNode1.makeChild("nameField").stripedStringValue();
    if ((str3 != null) && (paramTreeNode2.makeChild("nameField").attribute("syncWithModel").booleanValue(true))) {
      paramTreeNode2.makeChild("nameField").setValue(str3);
    }
    String str4 = paramTreeNode1.makeChild("stampCreate").stripedStringValue();
    if (("true".equals(str4)) && (!"false".equals(paramTreeNode2.makeChild("stampCreate").stripedStringValue()))) {
      paramTreeNode2.makeChild("stampCreate").setValue("true");
    }
    String str5 = paramTreeNode1.makeChild("stampUpdate").stripedStringValue();
    if (("true".equals(str5)) && (!"false".equals(paramTreeNode2.makeChild("stampUpdate").stripedStringValue()))) {
      paramTreeNode2.makeChild("stampUpdate").setValue("true");
    }
    String str6 = paramTreeNode1.makeChild("activeFlagField").stripedStringValue();
    if (str6 != null) {
      paramTreeNode2.makeChild("activeFlagField").setValue(str6);
    }
    String str7 = paramTreeNode1.makeChild("orderField").stripedStringValue();
    if ((str7 != null) && (paramTreeNode2.makeChild("orderField").stripedStringValue() == null))
    {
      paramTreeNode2.makeChild("orderField").setValue(str7);
      paramTreeNode2.makeChild("defaultOrder").setValue(paramTreeNode1.makeChild("defaultOrder").stripedStringValue());
    }
    if ((paramTreeNode1.makeChild("treeMeta").hasChild()) && (paramTreeNode2.existingChild("treeMeta") == null)) {
      paramTreeNode2.replaceChild(paramTreeNode2.makeChild("treeMeta"), paramTreeNode1.makeChild("treeMeta").cloneNode());
    }
    D(paramTreeNode1, paramTreeNode2);
    B(paramTreeNode1, paramTreeNode2);
    C(paramTreeNode1, paramTreeNode2);
    A(paramTreeNode1, paramTreeNode2);
    syncLink(paramTreeNode1, paramTreeNode2);
  }
  
  public void syncLink(TreeNode paramTreeNode1, TreeNode paramTreeNode2)
  {
    TreeNode localTreeNode1 = paramTreeNode2.existingChild("link");
    TreeNode localTreeNode2 = paramTreeNode1.existingChild("link");
    if (localTreeNode1 == null)
    {
      if (localTreeNode2 != null) {
        paramTreeNode2.appendChild(localTreeNode2.cloneNode());
      }
    }
    else
    {
      boolean bool = localTreeNode1.attribute("syncWithModel").booleanValue(false);
      if (bool) {
        if (localTreeNode2 == null) {
          paramTreeNode2.removeChild(localTreeNode1);
        } else {
          paramTreeNode2.replaceChild(localTreeNode1, localTreeNode2.cloneNode());
        }
      }
    }
  }
  
  void C(TreeNode paramTreeNode1, TreeNode paramTreeNode2)
  {
    TreeNode localTreeNode1 = paramTreeNode1.makeChild("relations");
    TreeNode localTreeNode2 = paramTreeNode2.makeChild("relations");
    localTreeNode1.setValue(null);
    int j = localTreeNode1.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode3 = localTreeNode1.getChild(i);
      String str = localTreeNode3.attribute("name").stripedStringValue();
      if (str != null)
      {
        TreeNode localTreeNode4 = localTreeNode2.childWithAttr("name", str);
        if (localTreeNode4 == null)
        {
          TreeNode localTreeNode5 = localTreeNode3.cloneNode();
          localTreeNode5.setAttribute("visible", "false");
          localTreeNode2.appendChild(localTreeNode5);
        }
        else
        {
          boolean bool = localTreeNode4.attribute("syncWithModel").booleanValue(false);
          if (bool)
          {
            localTreeNode4.setAttribute("type", localTreeNode3.getAttribute("type"));
            localTreeNode4.setAttribute("showName", localTreeNode3.getAttribute("showName"));
            int m = localTreeNode3.getChildCount();
            for (int k = 0; k < m; k++)
            {
              TreeNode localTreeNode6 = localTreeNode3.getChild(k);
              localTreeNode4.makeChild(localTreeNode6.getName()).setValue(localTreeNode6.objectValue());
            }
          }
        }
      }
    }
  }
  
  void A(TreeNode paramTreeNode1, TreeNode paramTreeNode2)
  {
    TreeNode localTreeNode1 = paramTreeNode1.makeChild("relations");
    TreeNode localTreeNode2 = paramTreeNode2.makeChild("relations");
    localTreeNode2.setValue(null);
    int j = localTreeNode2.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode3 = localTreeNode2.getChild(i);
      String str = localTreeNode3.attribute("name").stripedStringValue("");
      boolean bool = localTreeNode3.attribute("syncWithModel").booleanValue(false);
      if ((bool) && (localTreeNode1.childWithAttr("name", str) == null))
      {
        localTreeNode2.removeChildByIndex(i);
        i--;
        j--;
      }
    }
  }
  
  void B(TreeNode paramTreeNode1, TreeNode paramTreeNode2)
  {
    TreeNode localTreeNode1 = paramTreeNode1.makeChild("fields");
    TreeNode localTreeNode2 = paramTreeNode2.makeChild("fields");
    int j = localTreeNode2.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode3 = localTreeNode2.getChild(i);
      String str = localTreeNode3.attribute("name").stripedStringValue("");
      boolean bool = localTreeNode3.attribute("syncWithModel").booleanValue(false);
      if ((bool) && (localTreeNode1.childWithAttr("name", str) == null))
      {
        localTreeNode2.removeChildByIndex(i);
        i--;
        j--;
      }
    }
  }
  
  void D(TreeNode paramTreeNode1, TreeNode paramTreeNode2)
  {
    TreeNode localTreeNode1 = paramTreeNode1.makeChild("fields");
    TreeNode localTreeNode2 = paramTreeNode2.makeChild("fields");
    localTreeNode2.setValue(null);
    int j = localTreeNode1.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode3 = localTreeNode1.getChild(i);
      String str1 = localTreeNode3.attribute("name").stripedStringValue();
      String str2 = localTreeNode3.attribute("showName").stripedStringValue();
      if (str1 != null)
      {
        TreeNode localTreeNode4 = localTreeNode2.childWithAttr("name", str1);
        if (localTreeNode4 == null)
        {
          TreeNode localTreeNode5 = localTreeNode3.cloneNode();
          localTreeNode5.makeChild("listable").setValue("false");
          localTreeNode2.appendChild(localTreeNode5);
        }
        else
        {
          boolean bool1 = localTreeNode4.attribute("syncWithModel").booleanValue(false);
          if (bool1)
          {
            beforeSyncField(localTreeNode3, localTreeNode4);
            if (this.C)
            {
              localTreeNode4.setAttributes(localTreeNode3.getAttributes());
              localTreeNode4.setAttribute("syncWithModel", "true");
            }
            String str3 = (String)localTreeNode3.getAttribute("meta:domain");
            if (str3 != null) {
              localTreeNode4.setAttribute("meta:domain", str3);
            }
            if (str2 != null) {
              localTreeNode4.setAttribute("showName", str2);
            }
            String str4 = localTreeNode3.makeChild("idField").stripedStringValue();
            String str5 = localTreeNode3.makeChild("nameField").stripedStringValue();
            String str6 = localTreeNode3.makeChild("enumName").stripedStringValue();
            String str7 = localTreeNode3.makeChild("maxLength").stripedStringValue();
            String str8 = localTreeNode3.makeChild("storeSize").stripedStringValue();
            String str9 = localTreeNode3.makeChild("precision").stripedStringValue();
            String str10 = localTreeNode3.makeChild("type").stripedStringValue();
            String str11 = localTreeNode3.makeChild("storeType").stripedStringValue();
            TreeNode localTreeNode6 = localTreeNode3.existingChild("inTransformer");
            TreeNode localTreeNode7 = localTreeNode3.existingChild("entityFormula");
            String str12 = localTreeNode3.makeChild("nullable").stripedStringValue();
            boolean bool2 = localTreeNode4.makeChild("type").attribute("syncWithModel").booleanValue(true);
            if (bool2) {
              localTreeNode4.makeChild("type").setValue(str10);
            }
            localTreeNode4.makeChild("storeType").setValue(str11);
            localTreeNode4.makeChild("storeSize").setValue(str8);
            localTreeNode4.makeChild("precision").setValue(str9);
            if (localTreeNode4.makeChild("maxLength").attribute("syncWithModel").booleanValue(true)) {
              localTreeNode4.makeChild("maxLength").setValue(str7);
            }
            if (str4 != null) {
              localTreeNode4.makeChild("idField").setValue(str4);
            } else {
              localTreeNode4.removeChildByTagName("idField");
            }
            if ((str5 != null) && (localTreeNode4.makeChild("nameField").attribute("syncWithModel").booleanValue(true))) {
              localTreeNode4.makeChild("nameField").setValue(str5);
            } else if (str5 == null) {
              localTreeNode4.removeChildByTagName("nameField");
            }
            if ((str6 != null) && ((!localTreeNode4.hasChild("enumName")) || (localTreeNode4.makeChild("enumName").attribute("syncWithModel").booleanValue(true)))) {
              localTreeNode4.makeChild("enumName").setValue(str6);
            }
            boolean bool3 = localTreeNode4.makeChild("nullable").attribute("syncWithModel").booleanValue(true);
            if (bool3) {
              localTreeNode4.makeChild("nullable").setValue(str12);
            }
            if (localTreeNode6 != null) {
              localTreeNode4.replaceChild(localTreeNode4.makeChild("inTransformer"), localTreeNode6.cloneNode());
            }
            if (localTreeNode7 != null) {
              localTreeNode4.replaceChild(localTreeNode4.makeChild("entityFormula"), localTreeNode7.cloneNode());
            }
            afterSyncField(localTreeNode3, localTreeNode4);
          }
        }
      }
    }
  }
  
  protected void beforeSyncField(TreeNode paramTreeNode1, TreeNode paramTreeNode2) {}
  
  protected void afterSyncField(TreeNode paramTreeNode1, TreeNode paramTreeNode2) {}
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\meta\MetaTool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */