package edu.thu.model.stg.ds.spi;

import edu.thu.config.IConfigInfo;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IVariant;
import edu.thu.lang.Variant;
import edu.thu.lang.util.TplC;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceCall;
import edu.thu.service.IServiceContext;
import edu.thu.service.ThreadServiceContext;
import edu.thu.service.txn.ITransactionMode;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TplSubDataProvider
  extends AbstractSubDataProvider
{
  IServiceCall addTpl;
  IServiceCall removeTpl;
  IServiceCall updateTpl;
  IServiceCall getTpl;
  
  public void setConfig(IConfigInfo paramIConfigInfo)
  {
    super.setConfig(paramIConfigInfo);
  }
  
  public void compileActionTpl(TreeNode paramTreeNode, TplC paramTplC, IServiceContext paramIServiceContext)
  {
    TreeNode localTreeNode1 = paramTreeNode.makeChild("actions");
    int j = localTreeNode1.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode2 = localTreeNode1.getChild(i);
      String str = localTreeNode2.getName();
      if ("get".equals(str)) {
        this.getTpl = TplC.toServiceCall(paramTplC.compileBody(localTreeNode2, null, paramIServiceContext));
      } else if ("remove".equals(str)) {
        this.removeTpl = TplC.toServiceCall(paramTplC.compileBody(localTreeNode2, null, paramIServiceContext));
      } else if ("update".equals(str)) {
        this.updateTpl = TplC.toServiceCall(paramTplC.compileBody(localTreeNode2, null, paramIServiceContext));
      } else if ("add".equals(str)) {
        this.addTpl = TplC.toServiceCall(paramTplC.compileBody(localTreeNode2, null, paramIServiceContext));
      } else {
        throw Exceptions.code("ds.CAN_err_sub_provider_unkown_action").param(localTreeNode2);
      }
    }
    if ((this.forAdd) && (this.addTpl == null)) {
      throw Exceptions.code("ds.CAN_err_sub_provider_no_add_action").param(paramTreeNode);
    }
    if ((this.forGet) && (this.getTpl == null)) {
      throw Exceptions.code("ds.CAN_err_sub_provider_no_get_action").param(paramTreeNode);
    }
    if ((this.forRemove) && (this.removeTpl == null)) {
      throw Exceptions.code("ds.CAN_err_sub_provider_no_remove_action").param(paramTreeNode);
    }
    if ((this.forUpdate) && (this.updateTpl == null)) {
      throw Exceptions.code("ds.CAN_err_sub_provider_no_update_action").param(paramTreeNode);
    }
  }
  
  public void add(ITransactionMode paramITransactionMode, List paramList, Map paramMap, Object paramObject)
  {
    HashMap localHashMap = new HashMap(4);
    localHashMap.put("tm", paramITransactionMode);
    localHashMap.put("keys", paramList);
    localHashMap.put("info", paramMap);
    localHashMap.put("updater", paramObject);
    localHashMap.put("thisObj", this);
    this.addTpl.invoke(localHashMap, ThreadServiceContext.getCurrentContext());
  }
  
  public List get(ITransactionMode paramITransactionMode, List paramList1, List paramList2)
  {
    HashMap localHashMap = new HashMap(4);
    localHashMap.put("tm", paramITransactionMode);
    localHashMap.put("keys", paramList1);
    localHashMap.put("fields", paramList2);
    localHashMap.put("thisObj", this);
    Object localObject = this.getTpl.invoke(localHashMap, ThreadServiceContext.getCurrentContext());
    return Variant.valueOf(localObject).listValue();
  }
  
  public int remove(ITransactionMode paramITransactionMode, List paramList, Object paramObject)
  {
    HashMap localHashMap = new HashMap(4);
    localHashMap.put("tm", paramITransactionMode);
    localHashMap.put("keys", paramList);
    localHashMap.put("updater", paramObject);
    localHashMap.put("thisObj", this);
    Object localObject = this.removeTpl.invoke(localHashMap, ThreadServiceContext.getCurrentContext());
    return Variant.valueOf(localObject).intValue(-1);
  }
  
  public int update(ITransactionMode paramITransactionMode, List paramList, Map paramMap, Object paramObject)
  {
    HashMap localHashMap = new HashMap(4);
    localHashMap.put("tm", paramITransactionMode);
    localHashMap.put("keys", paramList);
    localHashMap.put("updater", paramObject);
    localHashMap.put("info", paramMap);
    localHashMap.put("thisObj", this);
    Object localObject = this.updateTpl.invoke(localHashMap, ThreadServiceContext.getCurrentContext());
    return Variant.valueOf(localObject).intValue(-1);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\TplSubDataProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */