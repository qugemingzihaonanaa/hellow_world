package edu.thu.model.stg.ds.spi;

import edu.thu.global.Debug;
import edu.thu.global.IFactory;
import edu.thu.global.spi.CachedFactory;
import edu.thu.global.spi.MetaFactory;
import edu.thu.io.util.IoUtils;
import edu.thu.model.stg.ds.DataSourceLoader;
import edu.thu.model.stg.ds.DataSourceMeta;
import edu.thu.model.stg.ds.IDataSource;
import edu.thu.model.tree.TreeNode;
import edu.thu.xml.dom.DomToTree;
import java.io.InputStream;

public class MetaDataSourceLoader
  extends MetaFactory
  implements DsConstants
{
  public static IFactory register(String paramString)
  {
    MetaDataSourceLoader localMetaDataSourceLoader = new MetaDataSourceLoader();
    localMetaDataSourceLoader.setMetaPath(paramString);
    CachedFactory localCachedFactory = new CachedFactory(localMetaDataSourceLoader);
    DataSourceLoader.setDataSourceLoader(localCachedFactory);
    DataSourceMeta.setDefaultProduer(new DataSourceMetaProducer());
    return localCachedFactory;
  }
  
  public Object getInstance(String paramString, Object paramObject)
  {
    Object localObject1 = null;
    Object localObject2;
    Object localObject3;
    Object localObject4;
    if (paramString.startsWith("classpath:"))
    {
      localObject2 = paramString.substring("classpath:".length());
      localObject3 = DataSourceLoader.class.getResourceAsStream((String)localObject2);
      if (localObject3 == null)
      {
        Debug.traceErr("ds.CAN_err_unknown_class_ds::" + (String)localObject2);
        return null;
      }
      try
      {
        localObject4 = DomToTree.getInstance().transform((InputStream)localObject3);
        if (localObject4 == null) {
          return null;
        }
        ((TreeNode)localObject4).setSystemId(paramString);
        localObject1 = super.createInstance(paramString, (TreeNode)localObject4);
      }
      finally
      {
        IoUtils.safeClose((InputStream)localObject3);
      }
      IoUtils.safeClose((InputStream)localObject3);
    }
    else
    {
      if (paramString.startsWith("orm/"))
      {
        localObject1 = super.getInstance("custom/" + paramString.substring("orm/".length()), paramObject);
        if (localObject1 != null)
        {
          localObject2 = (IDataSource)localObject1;
          localObject3 = ((IDataSource)localObject2).getMeta();
          localObject4 = DataSourceMeta.make((TreeNode)localObject3);
          ((DataSourceMeta)localObject4).setMetaName(paramString);
          return localObject1;
        }
      }
      localObject1 = super.getInstance(paramString, paramObject);
    }
    if ((localObject1 instanceof IDataSource))
    {
      localObject2 = (IDataSource)localObject1;
      localObject3 = ((IDataSource)localObject2).getMeta();
      localObject4 = DataSourceMeta.make((TreeNode)localObject3);
      ((DataSourceMeta)localObject4).setMetaName(paramString);
    }
    return localObject1;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\MetaDataSourceLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */