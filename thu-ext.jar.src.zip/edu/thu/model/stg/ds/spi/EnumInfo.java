package edu.thu.model.stg.ds.spi;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IVariant;
import edu.thu.model.stg.ds.EnumItem;
import edu.thu.model.tree.TreeNode;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class EnumInfo
  extends AbstractEnumInfo
{
  private static final long serialVersionUID = 4128154575466147437L;
  List<EnumItem> items;
  boolean useCode;
  
  public EnumInfo(List<EnumItem> paramList)
  {
    this.items = paramList;
  }
  
  public EnumInfo() {}
  
  public EnumInfo(TreeNode paramTreeNode)
  {
    initFromNode(paramTreeNode);
  }
  
  public boolean isUseCodeField()
  {
    return this.useCode;
  }
  
  public void setUseCodeField(boolean paramBoolean)
  {
    this.useCode = paramBoolean;
  }
  
  public int size()
  {
    if (this.items == null) {
      return 0;
    }
    return this.items.size();
  }
  
  public EnumItem getFirstItem()
  {
    return size() == 0 ? null : (EnumItem)this.items.get(0);
  }
  
  public void addItem(EnumItem paramEnumItem)
  {
    if (this.items == null) {
      this.items = new ArrayList();
    }
    this.items.add(paramEnumItem);
  }
  
  public List<EnumItem> getItems()
  {
    return this.items;
  }
  
  public void setItems(List<EnumItem> paramList)
  {
    this.items = paramList;
  }
  
  public EnumItem getItemByValue(Object paramObject)
  {
    if (this.items == null) {
      return null;
    }
    Iterator localIterator = this.items.iterator();
    while (localIterator.hasNext())
    {
      EnumItem localEnumItem = (EnumItem)localIterator.next();
      Object localObject = localEnumItem.getValue();
      if (localObject != null)
      {
        if (localObject.equals(paramObject)) {
          return localEnumItem;
        }
      }
      else if (paramObject == null) {
        return localEnumItem;
      }
    }
    return null;
  }
  
  public void initFromNode(TreeNode paramTreeNode)
  {
    int j = paramTreeNode.getChildCount();
    ArrayList localArrayList = new ArrayList(j);
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(i);
      if (!localTreeNode.getName().equals("li")) {
        throw Exceptions.code("ds.CAN_err_enum_not_item").param(localTreeNode);
      }
      String str1 = localTreeNode.stripedStringValue();
      if (str1 == null) {
        throw Exceptions.code("ds.CAN_err_enum_null_value").param(str1);
      }
      String str2 = localTreeNode.attribute("id").stripedStringValue(str1.toString());
      String str3 = localTreeNode.attribute("code").stripedStringValue(null);
      String str4 = localTreeNode.attribute("tip").stripedStringValue();
      EnumItem localEnumItem = new EnumItem();
      localEnumItem.setId(str2);
      localEnumItem.setValue(str1);
      if (str3 != null) {
        localEnumItem.setCode(str3);
      }
      localEnumItem.setTip(str4);
      if (str3 != null) {
        this.useCode = true;
      }
      localArrayList.add(localEnumItem);
    }
    this.items = localArrayList;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\EnumInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */