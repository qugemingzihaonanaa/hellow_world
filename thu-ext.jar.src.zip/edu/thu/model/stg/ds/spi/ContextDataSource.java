package edu.thu.model.stg.ds.spi;

import edu.thu.model.stg.ds.IDataSource;
import edu.thu.service.IServiceContext;

public class ContextDataSource
  extends ProxyDataSource
{
  IServiceContext context;
  
  public ContextDataSource(IServiceContext paramIServiceContext, IDataSource paramIDataSource)
  {
    super(paramIDataSource);
    this.context = paramIServiceContext;
  }
  
  protected Object createThis(IDataSource paramIDataSource)
  {
    return new ContextDataSource(getContext(), paramIDataSource);
  }
  
  public boolean isContextualizable()
  {
    return true;
  }
  
  public IServiceContext getContext()
  {
    return this.context;
  }
  
  public Object contextualize(IServiceContext paramIServiceContext)
  {
    return new ContextDataSource(paramIServiceContext, getDataSource());
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\ContextDataSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */