package edu.thu.model.stg.ds.spi;

import edu.thu.config.IConfigInfo;
import edu.thu.config.IConfigurable;
import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IVariant;
import edu.thu.lang.exceptions.StdException;
import edu.thu.model.stg.ds.ISubDataProvider;
import edu.thu.model.tree.TreeNode;
import edu.thu.search.Condition;
import edu.thu.search.Query;
import edu.thu.service.txn.ITransactionMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AbstractSubDataProvider
  implements ISubDataProvider, IConfigurable, DsConstants
{
  boolean forAdd = false;
  boolean forUpdate = false;
  boolean forGet = false;
  boolean forRemove = false;
  List localKeyNames;
  List foreignKeyNames;
  List localValueNames;
  List foreignValueNames;
  
  public void setForAdd(boolean paramBoolean)
  {
    this.forAdd = paramBoolean;
  }
  
  public void setForGet(boolean paramBoolean)
  {
    this.forGet = paramBoolean;
  }
  
  public void setForRemove(boolean paramBoolean)
  {
    this.forRemove = paramBoolean;
  }
  
  public void setForUpdate(boolean paramBoolean)
  {
    this.forUpdate = paramBoolean;
  }
  
  public void setLocalKeyNames(List paramList)
  {
    if ((paramList == null) || (paramList.isEmpty())) {
      throw Exceptions.code("ds.CAN_err_sub_data_provider_null_key_names");
    }
    this.localKeyNames = paramList;
  }
  
  public void setLocalValueNames(List paramList)
  {
    if ((paramList == null) || (paramList.isEmpty())) {
      throw Exceptions.code("ds.CAN_err_sub_data_provider_null_key_names");
    }
    this.localValueNames = paramList;
  }
  
  public void setForeignValueNames(List paramList)
  {
    this.foreignValueNames = paramList;
  }
  
  public List getForeignKeyNames()
  {
    return this.foreignKeyNames;
  }
  
  public String getForeignKeyName()
  {
    return (String)this.foreignKeyNames.get(0);
  }
  
  public String getLocalValueName()
  {
    return (String)this.localValueNames.get(0);
  }
  
  public void setForeignKeyNames(List paramList)
  {
    this.foreignKeyNames = paramList;
  }
  
  public boolean isForAdd()
  {
    return this.forAdd;
  }
  
  public boolean isForGet()
  {
    return this.forGet;
  }
  
  public boolean isForRemove()
  {
    return this.forRemove;
  }
  
  public boolean isForUpdate()
  {
    return this.forUpdate;
  }
  
  public static Map toMap(List paramList1, List paramList2)
  {
    Debug.check(paramList1);
    Debug.check(paramList2);
    Debug.check(paramList1.size() == paramList2.size());
    int j = paramList1.size();
    HashMap localHashMap = new HashMap(j);
    for (int i = 0; i < j; i++) {
      localHashMap.put(paramList1.get(i), paramList2.get(i));
    }
    return localHashMap;
  }
  
  protected Query makeCond(List paramList)
  {
    return Condition.eq(toMap(this.foreignKeyNames, paramList));
  }
  
  public void add(ITransactionMode paramITransactionMode, List paramList, Map paramMap, Object paramObject)
  {
    throw Exceptions.notAllowed();
  }
  
  public List get(ITransactionMode paramITransactionMode, List paramList1, List paramList2)
  {
    throw Exceptions.notAllowed();
  }
  
  public List getLocalKeyNames()
  {
    return this.localKeyNames;
  }
  
  public List getLocalValueNames()
  {
    return this.localValueNames;
  }
  
  public List getForeignValueNames()
  {
    return this.foreignValueNames;
  }
  
  public int remove(ITransactionMode paramITransactionMode, List paramList, Object paramObject)
  {
    throw Exceptions.notAllowed();
  }
  
  public int update(ITransactionMode paramITransactionMode, List paramList, Map paramMap, Object paramObject)
  {
    throw Exceptions.notAllowed();
  }
  
  public boolean isParameterizable()
  {
    return false;
  }
  
  public Object parameterize(Map paramMap)
  {
    return this;
  }
  
  public void setConfig(IConfigInfo paramIConfigInfo)
  {
    TreeNode localTreeNode = TreeNode.toNode(paramIConfigInfo);
    setConfigNode(localTreeNode);
  }
  
  void _loadValueNames(TreeNode paramTreeNode)
  {
    TreeNode localTreeNode1 = paramTreeNode.makeChild("valueFields");
    int j = localTreeNode1.getChildCount();
    if (j <= 0) {
      throw Exceptions.code("ds.CAN_err_sub_provider_no_valueFields").param(paramTreeNode);
    }
    this.localValueNames = new ArrayList(j);
    this.foreignValueNames = new ArrayList(j);
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode2 = localTreeNode1.getChild(i);
      String str1 = localTreeNode2.attribute("localName").stripedStringValue();
      if (str1 == null) {
        throw Exceptions.code("ds.CAN_err_sub_provider_null_local_key").param(localTreeNode2);
      }
      String str2 = localTreeNode2.attribute("foreignName").stripedStringValue();
      if (str2 == null) {
        throw Exceptions.code("ds.CAN_err_sub_provider_null_foreign_key").param(localTreeNode2);
      }
      this.localValueNames.add(str1);
      this.foreignValueNames.add(str2);
    }
  }
  
  public void setConfigNode(TreeNode paramTreeNode)
  {
    TreeNode localTreeNode = paramTreeNode.makeChild("keyFields");
    if (!localTreeNode.hasChild()) {
      throw Exceptions.code("ds.CAN_err_sub_provider_no_key_fields").param(paramTreeNode);
    }
    int j = localTreeNode.getChildCount();
    ArrayList localArrayList1 = new ArrayList(j);
    ArrayList localArrayList2 = new ArrayList(j);
    for (int i = 0; i < j; i++)
    {
      localObject = localTreeNode.getChild(i);
      String str1 = ((TreeNode)localObject).attribute("localName").stripedStringValue();
      if (str1 == null) {
        throw Exceptions.code("ds.CAN_err_sub_provider_null_local_key").param(localObject);
      }
      String str2 = ((TreeNode)localObject).attribute("foreignName").stripedStringValue();
      if (str2 == null) {
        throw Exceptions.code("ds.CAN_err_sub_provider_null_foreign_key").param(localObject);
      }
      localArrayList1.add(str1);
      localArrayList2.add(str2);
    }
    setLocalKeyNames(localArrayList1);
    setForeignKeyNames(localArrayList2);
    _loadValueNames(paramTreeNode);
    Object localObject = paramTreeNode.makeChild("actions").attribute("for").listValue();
    if ((localObject == null) || (((List)localObject).isEmpty())) {
      throw Exceptions.code("ds.CAN_err_sub_provider_actions_no_for_arg").param(paramTreeNode);
    }
    int m = ((List)localObject).size();
    for (int k = 0; k < m; k++)
    {
      String str3 = (String)((List)localObject).get(k);
      if ("add".equals(str3)) {
        setForAdd(true);
      } else if ("remove".equals(str3)) {
        setForRemove(true);
      } else if ("get".equals(str3)) {
        setForGet(true);
      } else if ("update".equals(str3)) {
        setForUpdate(true);
      } else {
        throw Exceptions.code("ds.CAN_err_sub_provider_unkown_action").param(str3).param(paramTreeNode);
      }
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\AbstractSubDataProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */