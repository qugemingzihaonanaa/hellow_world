package edu.thu.model.stg.ds.spi;

import java.util.List;

public class DpIdxInfo
{
  List A;
  NameIndex B;
  List C;
  List D;
  
  public DpIdxInfo(List paramList1, NameIndex paramNameIndex, List paramList2, List paramList3)
  {
    this.A = paramList1;
    this.B = paramNameIndex;
    this.C = paramList2;
    this.D = paramList3;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\DpIdxInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */