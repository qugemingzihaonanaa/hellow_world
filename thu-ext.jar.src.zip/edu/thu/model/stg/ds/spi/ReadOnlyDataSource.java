package edu.thu.model.stg.ds.spi;

import edu.thu.global.Debug;
import edu.thu.model.stg.ds.IDataSource;
import edu.thu.model.stg.ds.IDataSourceUpdator;

public class ReadOnlyDataSource
  extends ProxyDataSource
{
  public ReadOnlyDataSource(IDataSource paramIDataSource)
  {
    Debug.check(paramIDataSource);
    this.ds = paramIDataSource;
  }
  
  public IDataSourceUpdator getUpdator(Object paramObject)
  {
    return null;
  }
  
  protected Object createThis(IDataSource paramIDataSource)
  {
    return new ReadOnlyDataSource(paramIDataSource);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\ReadOnlyDataSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */