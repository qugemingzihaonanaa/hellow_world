package edu.thu.model.stg.ds.spi.cp;

import edu.thu.config.AppConfig;
import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IVariant;
import edu.thu.lang.el.IExpressionReference;
import edu.thu.lang.util.ITplReference;
import edu.thu.lang.util.TplC;
import edu.thu.lang.xconfig.AbstractXParser;
import edu.thu.lang.xconfig.TplPieceSet;
import edu.thu.lang.xconfig.XConfigConstants;
import edu.thu.model.stg.ds.BatchAddMeta;
import edu.thu.model.stg.ds.DataSourceMeta;
import edu.thu.model.stg.ds.EntityRelation;
import edu.thu.model.stg.ds.OrderBy;
import edu.thu.model.stg.ds.QueryItem;
import edu.thu.model.stg.ds.QueryMeta;
import edu.thu.model.stg.ds.spi.DataSourceMetaImpl;
import edu.thu.model.stg.ds.spi.FieldMeta;
import edu.thu.model.stg.ds.spi.GroupMeta;
import edu.thu.model.stg.ds.spi.TreeMeta;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceCall;
import edu.thu.service.IServiceContext;
import edu.thu.text.ContentLoader;
import edu.thu.text.res.FixStrResource;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

public class DsMetaXParser
  extends AbstractXParser<DataSourceMeta>
  implements XConfigConstants, IDsMetaXParser
{
  List<String> localFields;
  List<String> localLayouts;
  
  public DsMetaXParser()
  {
    super("classpath:resource/metameta/ds_meta.metameta.xml");
  }
  
  protected TreeNode transformNode(TreeNode paramTreeNode)
  {
    if (paramTreeNode == null) {
      return null;
    }
    if (!FixStrResource.isUseFix()) {
      return paramTreeNode;
    }
    FixStrResource localFixStrResource = FixStrResource.getInstance();
    localFixStrResource.fixAttr(paramTreeNode, "showName");
    TreeNode localTreeNode1 = paramTreeNode.existingChild("fields");
    localFixStrResource.fixChildAttr(localTreeNode1, "showName");
    TreeNode localTreeNode2 = paramTreeNode.existingChild("relations");
    localFixStrResource.fixChildAttr(localTreeNode2, "showName");
    return paramTreeNode;
  }
  
  protected TreeNode transformFieldsNode(TreeNode paramTreeNode)
  {
    return paramTreeNode;
  }
  
  public Object parseMeta(TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    return compileMeta(paramTreeNode, paramIServiceContext);
  }
  
  public Map<String, FieldMeta> compileFields(TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    paramTreeNode = transformFieldsNode(paramTreeNode);
    FieldsInfo localFieldsInfo = new FieldsInfo();
    doCompileFields(localFieldsInfo, paramTreeNode, paramIServiceContext);
    DsViewCompiler localDsViewCompiler = new DsViewCompiler(getTplC());
    localDsViewCompiler.compileFields(paramTreeNode, paramIServiceContext, false);
    return localFieldsInfo.fieldsMap;
  }
  
  void doCompileFields(FieldsInfo paramFieldsInfo, TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    TplC localTplC = getTplC();
    int j = paramTreeNode.getChildCount();
    if (j <= 0) {
      Debug.trace("ds.CAN_err_empty_fields::" + paramTreeNode);
    }
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(i);
      FieldMeta localFieldMeta = DsCpImpls.compileField(paramFieldsInfo, localTreeNode, localTplC, paramIServiceContext);
      localFieldMeta.setAttributes(new HashMap(localTreeNode.attributes()));
      localFieldMeta.setExtChildren(getExtChildren(localTreeNode));
    }
  }
  
  public DataSourceMeta compileMeta(TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    return doParse(paramTreeNode, paramIServiceContext);
  }
  
  protected void parseLocal(TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    TreeNode localTreeNode1;
    int j;
    ArrayList localArrayList;
    int i;
    TreeNode localTreeNode2;
    if (paramTreeNode.hasChild("fields"))
    {
      localTreeNode1 = paramTreeNode.makeChild("fields");
      j = localTreeNode1.getChildCount();
      localArrayList = new ArrayList(j);
      for (i = 0; i < j; i++)
      {
        localTreeNode2 = localTreeNode1.getChild(i);
        localArrayList.add((String)localTreeNode2.getAttribute("name"));
      }
      this.localFields = localArrayList;
    }
    if (paramTreeNode.hasChild("layouts"))
    {
      localTreeNode1 = paramTreeNode.makeChild("layouts");
      j = localTreeNode1.getChildCount();
      localArrayList = new ArrayList(j);
      for (i = 0; i < j; i++)
      {
        localTreeNode2 = localTreeNode1.getChild(i);
        localArrayList.add((String)localTreeNode2.getAttribute("name"));
      }
      this.localLayouts = localArrayList;
    }
  }
  
  boolean isMetaInternText()
  {
    return AppConfig.var("meta.use_intern_text").booleanValue(true);
  }
  
  public DataSourceMeta parseFieldsAsDsMeta(TreeNode paramTreeNode, IServiceContext paramIServiceContext, boolean paramBoolean)
  {
    paramTreeNode = paramTreeNode.copyDocNode();
    paramTreeNode = transformNode(paramTreeNode);
    if (paramBoolean)
    {
      localObject1 = getTplC() == null ? newTplC(paramTreeNode, paramIServiceContext) : getTplC();
      ((TplC)localObject1).loadLib("ds", "/_config/ds/ds_meta.xml");
      localObject2 = TreeNode.make("ds:FixMetaNode");
      localObject3 = new HashMap();
      ((Map)localObject3).put("metaNode", paramTreeNode);
      ((TplC)localObject1).compileNode((TreeNode)localObject2, (Map)localObject3, paramIServiceContext);
    }
    Object localObject1 = DsCpImpls.compileTreeMeta(paramTreeNode, getTplC(), paramIServiceContext);
    Object localObject2 = new FieldsInfo();
    doCompileFields((FieldsInfo)localObject2, paramTreeNode.makeChild("fields"), paramIServiceContext);
    Object localObject3 = new DataSourceMetaImpl(paramTreeNode);
    ((DataSourceMetaImpl)localObject3).setTreeMeta((TreeMeta)localObject1);
    ((DataSourceMetaImpl)localObject3).setFieldsInfo((FieldsInfo)localObject2);
    ((DataSourceMetaImpl)localObject3).setShowName(paramTreeNode.attribute("showName").stripedStringValue());
    ((DataSourceMetaImpl)localObject3).setTableName(paramTreeNode.attribute("tableName").stripedStringValue());
    ((DataSourceMetaImpl)localObject3).setEntityName(paramTreeNode.attribute("entityName").stripedStringValue());
    ((DataSourceMetaImpl)localObject3).setName(paramTreeNode.attribute("name").stripedStringValue());
    if (isMetaInternText()) {
      ((DataSourceMetaImpl)localObject3).internText();
    }
    if (paramBoolean)
    {
      DsViewCompiler localDsViewCompiler = new DsViewCompiler(getTplC());
      localDsViewCompiler.setDsMeta((DataSourceMetaImpl)localObject3);
      localDsViewCompiler.compileFields(paramTreeNode.makeChild("fields"), paramIServiceContext, true);
    }
    ((DataSourceMetaImpl)localObject3).detachMetaNode();
    return (DataSourceMeta)localObject3;
  }
  
  protected DataSourceMeta doParse(TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    parseLocal(paramTreeNode, paramIServiceContext);
    paramTreeNode = prepareNode(paramTreeNode, paramIServiceContext);
    paramTreeNode = transformNode(paramTreeNode);
    TplC localTplC = newTplC(paramTreeNode, paramIServiceContext);
    localTplC.loadLib("ds", "/_config/ds/ds_meta.xml");
    TreeNode localTreeNode1 = TreeNode.make("ds:FixMetaNode");
    HashMap localHashMap = new HashMap();
    localHashMap.put("metaNode", paramTreeNode);
    localTplC.compileNode(localTreeNode1, localHashMap, paramIServiceContext);
    List localList1 = DsCpImpls.compileKeys(paramTreeNode, localTplC, paramIServiceContext);
    List localList2 = paramTreeNode.makeChild("refFields").stringListValue();
    TreeNode localTreeNode2 = DsCpImpls.compileLink(paramTreeNode, localTplC, paramIServiceContext);
    if (localTreeNode2 != null)
    {
      localObject1 = paramTreeNode.makeChild("fields");
      ((TreeNode)localObject1).setValue(null);
      ((TreeNode)localObject1).appendChildren(localTreeNode2.makeChild("fields").cloneChildren());
    }
    Object localObject1 = new HashMap();
    Map localMap1 = DsCpImpls.parseFieldGroups(paramTreeNode.existingChild("fieldGroups"), localTplC, paramIServiceContext, (Map)localObject1);
    FieldsInfo localFieldsInfo = new FieldsInfo();
    localFieldsInfo.setFieldGroups(localMap1);
    doCompileFields(localFieldsInfo, paramTreeNode.makeChild("fields"), paramIServiceContext);
    Map localMap2 = DsCpImpls.compileReferences(paramTreeNode.existingChild("references"));
    TreeMeta localTreeMeta = DsCpImpls.compileTreeMeta(paramTreeNode, localTplC, paramIServiceContext);
    GroupMeta localGroupMeta = DsCpImpls.compileGroupMeta(paramTreeNode, localTplC, paramIServiceContext);
    List localList3 = compileRelations(paramTreeNode, localTplC, paramIServiceContext);
    QueryItem localQueryItem = QueryItem.parseQuickQuery(paramTreeNode.existingChild("quick-query"));
    QueryMeta localQueryMeta = QueryMeta.fromTreeNode(paramTreeNode.existingChild("queries"), true);
    OrderBy localOrderBy = OrderBy.parse(paramTreeNode);
    Map localMap3 = getExtChildren(paramTreeNode);
    DataSourceMetaImpl localDataSourceMetaImpl = new DataSourceMetaImpl(paramTreeNode);
    localDataSourceMetaImpl.setExtChildren(localMap3);
    localDataSourceMetaImpl.setLocalFields(this.localFields);
    localDataSourceMetaImpl.setLocalLayouts(this.localLayouts);
    localDataSourceMetaImpl.setRefFields(localList2);
    localMap1 = DsCpImpls.mergeFieldGroups(localMap1, localFieldsInfo.fields);
    localDataSourceMetaImpl.setFieldGroups(localMap1);
    localDataSourceMetaImpl.setReferences(localMap2);
    localDataSourceMetaImpl.setTreeMeta(localTreeMeta);
    localDataSourceMetaImpl.setFieldsInfo(localFieldsInfo);
    localDataSourceMetaImpl.setGroupMeta(localGroupMeta);
    localDataSourceMetaImpl.setEntityRelations(localList3);
    localDataSourceMetaImpl.setQueryMeta(localQueryMeta);
    localDataSourceMetaImpl.setQuickQuery(localQueryItem);
    localDataSourceMetaImpl.setOrderBy(localOrderBy);
    localDataSourceMetaImpl.setKeys(localList1);
    localDataSourceMetaImpl.setShowName(paramTreeNode.attribute("showName").stripedStringValue());
    localDataSourceMetaImpl.setTableName(paramTreeNode.attribute("tableName").stripedStringValue());
    localDataSourceMetaImpl.setEntityName(paramTreeNode.attribute("entityName").stripedStringValue());
    localDataSourceMetaImpl.setName(paramTreeNode.attribute("name").stripedStringValue());
    if ((localTreeMeta != null) && (localTreeMeta.getLabelField() == null)) {
      localTreeMeta.setLabelField(localDataSourceMetaImpl.getNameField());
    }
    BatchAddMeta localBatchAddMeta = BatchAddMeta.parse(paramTreeNode.existingChild("batchAdd"), localDataSourceMetaImpl);
    localDataSourceMetaImpl.setBatchAdd(localBatchAddMeta);
    TplPieceSet localTplPieceSet = parseTpls(paramTreeNode, getTplC(), paramIServiceContext);
    localDataSourceMetaImpl.setTpls(localTplPieceSet);
    TreeNode localTreeNode3 = paramTreeNode.existingChild("filter");
    if (localTreeNode3 != null)
    {
      localTplC.setNodeMode(true);
      localObject2 = localTreeNode3.copyDocNode();
      ((TreeNode)localObject2).setName("and");
      ITplReference localITplReference = localTplC.compileNode((TreeNode)localObject2, null, paramIServiceContext);
      localDataSourceMetaImpl.setFilterTpl(localITplReference);
      localTplC.setNodeMode(false);
    }
    if (isMetaInternText()) {
      localDataSourceMetaImpl.internText();
    }
    Object localObject2 = new DsViewCompiler(localTplC);
    ((DsViewCompiler)localObject2).compile(paramTreeNode, localDataSourceMetaImpl, paramIServiceContext);
    localDataSourceMetaImpl.setLayouts(((DsViewCompiler)localObject2).getLayouts());
    DsCpImpls.fixFieldGroupShowNames(localMap1, (Map)localObject1, localDataSourceMetaImpl);
    localDataSourceMetaImpl.detachMetaNode();
    return localDataSourceMetaImpl;
  }
  
  public List<EntityRelation> compileRelations(TreeNode paramTreeNode, TplC paramTplC, IServiceContext paramIServiceContext)
  {
    ContentLoader.load();
    TreeNode localTreeNode1 = paramTreeNode.existingChild("relations");
    if (localTreeNode1 == null) {
      return null;
    }
    String str1 = paramTreeNode.makeChild("pkField").stripedStringValue();
    String str2 = paramTreeNode.makeChild("nameField").stripedStringValue();
    boolean bool1 = paramTreeNode.attribute("default").booleanValue(false);
    ContentLoader.load();
    List localList1 = localTreeNode1.children();
    int j = localList1.size();
    ArrayList localArrayList = new ArrayList(j);
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode2 = (TreeNode)localList1.get(i);
      if (!localTreeNode2.getName().equals("relation")) {
        throw Exceptions.code("ds.err_not_relation_node").param(localTreeNode2);
      }
      String str3 = localTreeNode2.attribute("name").stripedStringValue();
      if (str3 == null) {
        throw Exceptions.code("ds.err_relation_no_name_arg").param(localTreeNode2);
      }
      String str4 = localTreeNode2.attribute("showName").stripedStringValue(str3);
      String str5 = localTreeNode2.attribute("type").stripedStringValue();
      if (str5 == null) {
        throw Exceptions.code("ds.err_relation_no_type");
      }
      boolean bool2 = localTreeNode2.attribute("visible").booleanValue(true);
      String str6 = localTreeNode2.attribute("ops").stripedStringValue();
      String str7 = localTreeNode2.makeChild("localField").stripedStringValue();
      if (str7 == null) {
        if ((str5.equals("to-one")) || (str5.equals("to-mapping"))) {
          str7 = str3;
        } else if (str5.equals("to-many")) {
          str7 = str1;
        } else {
          str7 = str1;
        }
      }
      String str8 = localTreeNode2.makeChild("localNameField").stripedStringValue();
      if (str8 == null) {
        if (str5.equals("to-one")) {
          str8 = str7;
        } else if (str5.equals("to-many")) {
          str8 = str2;
        }
      }
      String str9 = localTreeNode2.makeChild("relatedField").stripedStringValue();
      String str10 = localTreeNode2.makeChild("relatedNameField").stripedStringValue(str9);
      String str11 = localTreeNode2.makeChild("relatedEntity").stripedStringValue();
      if ((str11 == null) && (!str5.equals("to-link")) && (!str5.equals("group"))) {
        throw Exceptions.code("ds.err_relation_no_relatedEntity_arg").param(localTreeNode2);
      }
      String str12 = localTreeNode2.makeChild("relatedObject").stripedStringValue();
      if ((str12 == null) && (str11 != null))
      {
        int k = str11.lastIndexOf('.');
        if (k < 0) {
          str12 = str11;
        } else {
          str12 = str11.substring(k + 1);
        }
      }
      String str13 = localTreeNode2.makeChild("relatedMeta").stripedStringValue();
      String str14 = localTreeNode2.makeChild("mappingField").stripedStringValue();
      if ((str14 == null) && (str5.equals("to-mapping"))) {
        throw Exceptions.code("ds.CAN_err_relation_no_mappingField_arg").param(localTreeNode2);
      }
      String str15 = localTreeNode2.makeChild("mappingNameField").stripedStringValue(str14);
      String str16 = localTreeNode2.makeChild("mappingEnum").stripedStringValue();
      if ((str16 == null) && (str5.equals("to-mapping"))) {
        throw Exceptions.code("ds.CAN_err_relation_no_mappingEnum_arg").param(localTreeNode2);
      }
      String str17 = localTreeNode2.makeChild("url").stripedStringValue();
      if ((str17 == null) && (str5.equals("to-link"))) {
        throw Exceptions.code("ds.CAN_err_relation_no_url_arg").param(localTreeNode2);
      }
      IExpressionReference localIExpressionReference = TplC.parseExpression(str17);
      Object localObject1 = localTreeNode2.attribute("selector").stringListValue();
      if (localObject1 == null) {
        localObject1 = new ArrayList();
      }
      String str18 = localTreeNode2.attribute("viewType").stripedStringValue();
      boolean bool3 = localTreeNode2.attribute("lazy").booleanValue(false);
      Map localMap = getExtAttributes(localTreeNode2);
      EntityRelation localEntityRelation = new EntityRelation();
      localEntityRelation.setAttributes(localMap);
      TreeNode localTreeNode3 = localTreeNode2.existingChild("conditions");
      if (localTreeNode3 != null)
      {
        localObject2 = TplC.toServiceCall(paramTplC.compilePredicateNode(localTreeNode3, paramIServiceContext));
        localEntityRelation.setCondition((IServiceCall)localObject2);
      }
      Object localObject2 = localTreeNode2.existingChild("action");
      if (localObject2 != null)
      {
        localObject3 = paramTplC.compileBody((TreeNode)localObject2, null, paramIServiceContext);
        localEntityRelation.setActionTpl(localObject3);
      }
      Object localObject3 = parseTpls(localTreeNode2, getTplC(), paramIServiceContext);
      localEntityRelation.setTpls((TplPieceSet)localObject3);
      localEntityRelation.setOps(str6);
      localEntityRelation.setViewType(str18);
      localEntityRelation.setSelectors(new HashSet((Collection)localObject1));
      localEntityRelation.setName(str3);
      localEntityRelation.setShowName(str4);
      localEntityRelation.setType(str5);
      localEntityRelation.setVisible(bool2);
      localEntityRelation.setDefault(bool1);
      localEntityRelation.setLazy(bool3);
      localEntityRelation.setRelatedMetaName(str13);
      localEntityRelation.setLocalField(str7);
      localEntityRelation.setRelatedField(str9);
      localEntityRelation.setLocalNameField(str8);
      localEntityRelation.setRelatedNameField(str10);
      localEntityRelation.setRelatedEntityName(str11);
      localEntityRelation.setRelatedObjectName(str12);
      localEntityRelation.setMappingField(str14);
      localEntityRelation.setMappingNameField(str15);
      localEntityRelation.setMappingEnum(str16);
      localEntityRelation.setUrlExpr(localIExpressionReference);
      localEntityRelation.setExtChildren(getExtChildren(localTreeNode2));
      TreeNode localTreeNode4 = localTreeNode2.existingChild("relations");
      if (localTreeNode4 != null)
      {
        List localList2 = compileRelations(localTreeNode4, paramTplC, paramIServiceContext);
        localEntityRelation.setSubRelations(localList2);
      }
      localArrayList.add(localEntityRelation);
    }
    return localArrayList;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\cp\DsMetaXParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */