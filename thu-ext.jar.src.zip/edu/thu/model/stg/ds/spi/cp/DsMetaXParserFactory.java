package edu.thu.model.stg.ds.spi.cp;

import edu.thu.config.AppConfig;
import edu.thu.lang.IVariant;

public class DsMetaXParserFactory
{
  public static IDsMetaXParser createOldParser()
  {
    return new DsMetaCompilerEx();
  }
  
  public static IDsMetaXParser createXParser()
  {
    return new DsMetaXParser();
  }
  
  public static IDsMetaXParser newParser()
  {
    boolean bool = AppConfig.var("ds.meta.use_xparser").booleanValue(true);
    if (bool) {
      return new DsMetaXParser();
    }
    return new DsMetaCompilerEx();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\cp\DsMetaXParserFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */