package edu.thu.model.stg.ds.spi.cp;

import edu.thu.config.AppConfig;
import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.aop.spi.MapMethodInvocation;
import edu.thu.java.util.MethodUtils;
import edu.thu.lang.IVariant;
import edu.thu.lang.Variant;
import edu.thu.lang.el.IExpressionReference;
import edu.thu.lang.exceptions.StdException;
import edu.thu.lang.util.TplC;
import edu.thu.model.data.transform.ExpressionTransformer;
import edu.thu.model.data.transform.ITransformer;
import edu.thu.model.stg.ds.IDataProvider;
import edu.thu.model.stg.ds.ISubDataProvider;
import edu.thu.model.stg.ds.filter.DsFilterInterceptor;
import edu.thu.model.stg.ds.spi.DataSourceLocation;
import edu.thu.model.stg.ds.spi.DataSourceMapping;
import edu.thu.model.stg.ds.spi.DataSourceMetaImpl;
import edu.thu.model.stg.ds.spi.DataSourceReference;
import edu.thu.model.stg.ds.spi.DsConstants;
import edu.thu.model.stg.ds.spi.FieldMeta;
import edu.thu.model.stg.ds.spi.FieldNameList;
import edu.thu.model.stg.ds.spi.GroupMeta;
import edu.thu.model.stg.ds.spi.KeyMeta;
import edu.thu.model.stg.ds.spi.TplSubDataProvider;
import edu.thu.model.stg.ds.spi.TreeMeta;
import edu.thu.model.stg.ds.spi.db.DbTableDataProvider;
import edu.thu.model.stg.ds.util.EnumTransformer;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceContext;
import edu.thu.util.StringUtils;
import edu.thu.util.StringUtilsEx;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.aopalliance.intercept.MethodInterceptor;

public class DsCpImpls
  implements DsConstants
{
  static boolean H = AppConfig.var("db.use_utf8_string").booleanValue(false);
  
  public static List compileSubProviders(TreeNode paramTreeNode, TplC paramTplC, IServiceContext paramIServiceContext)
  {
    TreeNode localTreeNode = paramTreeNode.existingChild("subProviders");
    if (localTreeNode == null) {
      return null;
    }
    int j = localTreeNode.getChildCount();
    if (j == 0) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(j);
    for (int i = 0; i < j; i++)
    {
      ISubDataProvider localISubDataProvider = compileSubProvider(localTreeNode.getChild(i), paramTplC, paramIServiceContext);
      localArrayList.add(localISubDataProvider);
    }
    return localArrayList;
  }
  
  public static ISubDataProvider compileSubProvider(TreeNode paramTreeNode, TplC paramTplC, IServiceContext paramIServiceContext)
  {
    if (!paramTreeNode.getName().equals("subProvider")) {
      throw Exceptions.code("ds.CAN_err_not_sub_provider_node").param(paramTreeNode);
    }
    Debug.trace("ds.CAN_ds_load_sub_provider::" + paramTreeNode);
    if ((!paramTreeNode.hasAttribute("tpl:tag")) && (!paramTreeNode.hasAttribute("class")))
    {
      localObject = new TplSubDataProvider();
      ((TplSubDataProvider)localObject).setConfigNode(paramTreeNode);
      ((TplSubDataProvider)localObject).compileActionTpl(paramTreeNode, paramTplC, paramIServiceContext);
      return (ISubDataProvider)localObject;
    }
    Object localObject = (ISubDataProvider)paramTplC.loadObject(paramTreeNode, ISubDataProvider.class, paramIServiceContext);
    return (ISubDataProvider)localObject;
  }
  
  public static MapMethodInvocation compileInterceptors(TreeNode paramTreeNode, TplC paramTplC, IServiceContext paramIServiceContext)
  {
    TreeNode localTreeNode1 = paramTreeNode.existingChild("interceptors");
    if (localTreeNode1 == null) {
      return null;
    }
    int j = localTreeNode1.getChildCount();
    if (j <= 0) {
      return null;
    }
    MapMethodInvocation localMapMethodInvocation = new MapMethodInvocation();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode2 = localTreeNode1.getChild(i);
      String str = localTreeNode2.attribute("applyTo").stripedStringValue();
      if (!localTreeNode2.getName().equals("interceptor")) {
        throw Exceptions.code("ds.CAN_err_not_interceptor_node").param(localTreeNode2);
      }
      if ((!localTreeNode2.hasAttribute("tpl:tag")) && (!localTreeNode2.hasAttribute("class"))) {
        localTreeNode2.setAttribute("class", DsFilterInterceptor.class.getName());
      }
      MethodInterceptor localMethodInterceptor = (MethodInterceptor)paramTplC.loadObject(localTreeNode2, MethodInterceptor.class, paramIServiceContext);
      if (localMethodInterceptor == null) {
        throw Exceptions.code("ds.CAN_err_compile_null_interceptor").param(localTreeNode2);
      }
      List localList = null;
      if ((str == null) || (str.equals("*"))) {
        localList = (List)MethodUtils.getProperty(localMethodInterceptor, "applyTo");
      } else {
        localList = StringUtils.stripedSplit(str, ',');
      }
      if (localList == null) {
        throw Exceptions.code("ds.CAN_err_interceptor_no_applyTo_args").param(localMethodInterceptor);
      }
      Debug.trace("ds.CAN_apply_interceptor_to::" + localList + "," + localMethodInterceptor);
    }
    return localMapMethodInvocation;
  }
  
  public static IDataProvider compileProvider(TreeNode paramTreeNode, TplC paramTplC, IServiceContext paramIServiceContext)
  {
    TreeNode localTreeNode = paramTreeNode.existingChild("provider");
    if (localTreeNode == null) {
      throw Exceptions.code("ds.CAN_err_compile_no_provider").param(paramTreeNode);
    }
    if ((!localTreeNode.hasAttribute("tpl:tag")) && (!localTreeNode.hasAttribute("class"))) {
      localTreeNode.setAttribute("class", DbTableDataProvider.class.getName());
    }
    IDataProvider localIDataProvider = (IDataProvider)paramTplC.loadObject(localTreeNode, IDataProvider.class, paramIServiceContext);
    if (localIDataProvider == null) {
      throw Exceptions.code("ds.CAN_err_compile_null_provider").param(paramTreeNode);
    }
    try
    {
      Method localMethod = localIDataProvider.getClass().getMethod("bindMeta", new Class[] { TreeNode.class });
      localMethod.setAccessible(true);
      localMethod.invoke(localIDataProvider, new Object[] { paramTreeNode });
    }
    catch (NoSuchMethodException localNoSuchMethodException) {}catch (InvocationTargetException localInvocationTargetException)
    {
      throw Exceptions.source(localInvocationTargetException.getTargetException());
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw Exceptions.source(localIllegalAccessException);
    }
    return localIDataProvider;
  }
  
  public static Map compileReferences(TreeNode paramTreeNode)
  {
    if (paramTreeNode == null) {
      return null;
    }
    int j = paramTreeNode.getChildCount();
    if (j == 0) {
      return null;
    }
    HashMap localHashMap = new HashMap(j);
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(i);
      String str = localTreeNode.getName();
      Object localObject1 = null;
      if (str.equals("reference")) {
        localObject1 = new DataSourceReference(localTreeNode);
      } else if (str.equals("mapping")) {
        localObject1 = new DataSourceMapping(localTreeNode);
      } else if (str.equals("location")) {
        localObject1 = new DataSourceLocation(localTreeNode);
      } else {
        throw Exceptions.code("ds.CAN_err_unknown_reference_type").param(localTreeNode);
      }
      Object localObject2 = localHashMap.put(((DataSourceLocation)localObject1).getReferenceName(), localObject1);
      if (localObject2 != null) {
        throw Exceptions.code("ds.CAN_err_duplicate_reference").param(localObject2).param(localTreeNode);
      }
    }
    return localHashMap;
  }
  
  public static Map compileModes()
  {
    return null;
  }
  
  public static Map compileCommands(TreeNode paramTreeNode, TplC paramTplC, IServiceContext paramIServiceContext)
  {
    return null;
  }
  
  static IVariant A(TreeNode paramTreeNode, String paramString)
  {
    TreeNode localTreeNode = paramTreeNode.existingChild(paramString);
    if (localTreeNode == null) {
      return Variant.NULL;
    }
    return localTreeNode;
  }
  
  public static FieldMeta compileField(FieldsInfo paramFieldsInfo, TreeNode paramTreeNode, TplC paramTplC, IServiceContext paramIServiceContext)
  {
    FieldMeta localFieldMeta = new FieldMeta();
    String str1 = paramTreeNode.attribute("name").stripedStringValue();
    if (str1 == null) {
      throw Exceptions.code("ds.CAN_err_compile_field_no_name").param(paramTreeNode);
    }
    localFieldMeta.setName(str1);
    String str2 = paramTreeNode.attribute("baseName").stripedStringValue();
    if (str2 == null) {
      str2 = str1;
    }
    localFieldMeta.setBaseName(str2);
    String str3 = paramTreeNode.attribute("dbName").stripedStringValue();
    localFieldMeta.setDbName(str3);
    String str4 = paramTreeNode.attribute("showName").stringValue(str1);
    localFieldMeta.setShowName(str4);
    String str5 = paramTreeNode.attribute("fullName").stripedStringValue(str4);
    localFieldMeta.setFullName(str5);
    boolean bool1 = str1.startsWith("dummy.");
    if ((str4 == null) || (str4.length() <= 0)) {
      bool1 = true;
    }
    String str6 = A(paramTreeNode, "storeType").stripedStringValue();
    localFieldMeta.setStoreType(str6);
    String str7 = A(paramTreeNode, "type").stripedStringValue(str6);
    localFieldMeta.setType(str7);
    String str8 = A(paramTreeNode, "tip").stripedStringValue();
    localFieldMeta.setTip(str8);
    int i = A(paramTreeNode, "storeSize").intValue(0);
    localFieldMeta.setStoreSize(i);
    int j = A(paramTreeNode, "maxLength").intValue(0);
    if ((H) && ("string".equals(str7)) && (j * 2 == i))
    {
      j = j * 2 / 3;
      if ((j <= 0) && (i > 0)) {
        j = 1;
      }
    }
    localFieldMeta.setMaxLength(j);
    int k = A(paramTreeNode, "precision").intValue(Integer.MAX_VALUE);
    if (k != Integer.MAX_VALUE) {
      localFieldMeta.setPrecision(Integer.valueOf(k));
    }
    String str9 = A(paramTreeNode, "width").stripedStringValue();
    localFieldMeta.setWidth(str9);
    List localList = paramTreeNode.attribute("selector").listValue();
    if (localList == null) {
      localList = Collections.emptyList();
    }
    localFieldMeta.setSelectors(new HashSet(localList));
    localFieldMeta.addSelector("all");
    TreeNode localTreeNode1 = paramTreeNode.existingChild("formula");
    if (localTreeNode1 != null)
    {
      str10 = localTreeNode1.stripedStringValue();
      if (str10 != null)
      {
        str10 = str10 + " as " + str1;
        localFieldMeta.setFormula(str10);
      }
    }
    String str10 = paramTreeNode.attribute("align").stripedStringValue();
    String str11 = paramTreeNode.attribute("valign").stripedStringValue();
    String str12 = paramTreeNode.attribute("style").stripedStringValue();
    localFieldMeta.setAlign(str10);
    localFieldMeta.setValign(str11);
    localFieldMeta.setStyle(str12);
    boolean bool2 = A(paramTreeNode, "virtual").booleanValue(false);
    boolean bool3 = A(paramTreeNode, "visible").booleanValue(true);
    bool3 = paramFieldsInfo.checkGroupConfig("visible", str1, bool3);
    localFieldMeta.setVisible(bool3);
    if (bool3) {
      localFieldMeta.addSelector("visible");
    }
    boolean bool4 = A(paramTreeNode, "addable").booleanValue(true);
    bool4 = paramFieldsInfo.checkGroupConfig("addable", str1, bool4);
    if ((bool4) && (bool2)) {
      throw Exceptions.code("ds.CAN_err_virtual_field_not_addable").param(paramTreeNode);
    }
    localFieldMeta.setAddable(bool4);
    if (bool4) {
      localFieldMeta.addSelector("addable");
    }
    boolean bool5 = A(paramTreeNode, "updatable").booleanValue(true);
    bool5 = paramFieldsInfo.checkGroupConfig("updatable", str1, bool5);
    if ((bool5) && (bool2)) {
      throw Exceptions.code("ds.CAN_err_virtual_field_not_updatable").param(paramTreeNode);
    }
    localFieldMeta.setUpdatable(bool5);
    if (bool5) {
      localFieldMeta.addSelector("updatable");
    }
    boolean bool6 = A(paramTreeNode, "listable").booleanValue(true);
    bool6 = paramFieldsInfo.checkGroupConfig("listable", str1, bool6);
    localFieldMeta.setListable(bool6);
    if (bool6) {
      localFieldMeta.addSelector("listable");
    }
    boolean bool7 = A(paramTreeNode, "viewable").booleanValue(true);
    bool7 = paramFieldsInfo.checkGroupConfig("viewable", str1, bool7);
    localFieldMeta.setViewable(bool7);
    if (bool7) {
      localFieldMeta.addSelector("viewable");
    }
    boolean bool8 = true;
    bool8 = (bool8) && (!bool1);
    boolean bool9 = A(paramTreeNode, "queriable").booleanValue(bool8);
    bool9 = paramFieldsInfo.checkGroupConfig("queriable", str1, bool9);
    if ((bool9) && (bool2)) {
      throw Exceptions.code("ds.CAN_err_virtual_field_not_queriable").param(paramTreeNode);
    }
    localFieldMeta.setQueriable(bool9);
    if (bool9) {
      localFieldMeta.addSelector("queriable");
    }
    boolean bool10 = A(paramTreeNode, "supportQueryBuilder").booleanValue(bool9);
    localFieldMeta.setSupportQueryBuilder(bool10);
    boolean bool11 = !str1.startsWith("dummy.");
    if (str1.startsWith("ext_")) {
      bool11 = false;
    }
    boolean bool12 = A(paramTreeNode, "orderable").booleanValue(bool11);
    bool12 = paramFieldsInfo.checkGroupConfig("orderable", str1, bool12);
    if ("clob".equals(str7))
    {
      bool12 = false;
      paramTreeNode.makeChild("orderable").setValue("false");
    }
    localFieldMeta.setOrderable(bool12);
    if (bool12) {
      localFieldMeta.addSelector("orderable");
    }
    boolean bool13 = (bool4) || (bool5);
    if (str1.indexOf('.') >= 0) {
      bool13 = false;
    }
    boolean bool14 = A(paramTreeNode, "loggable").booleanValue(bool13);
    localFieldMeta.setLoggable(bool14);
    if (bool14) {
      localFieldMeta.addSelector("log");
    }
    boolean bool15 = A(paramTreeNode, "showForEdit").booleanValue(true);
    localFieldMeta.setShowForEdit(bool15);
    boolean bool16 = A(paramTreeNode, "exportable").booleanValue((bool3) && (!bool1) && (!"collection".equals(str7)));
    localFieldMeta.setExportable(bool16);
    boolean bool17 = A(paramTreeNode, "batchUpdatable").booleanValue((bool6) && (bool5) && (bool3) && (!bool1));
    localFieldMeta.setBatchUpdatable(bool17);
    boolean bool18 = A(paramTreeNode, "batchUpdate").booleanValue((bool6) && (bool3));
    localFieldMeta.setBatchUpdate(bool18);
    TreeNode localTreeNode2 = paramTreeNode.existingChild("defaultExpr");
    if ((localTreeNode2 != null) && (paramTplC != null))
    {
      localObject1 = paramTplC.parseValueExpression(localTreeNode2, paramIServiceContext);
      localTreeNode2.setValue(localObject1);
      if (localObject1 != null)
      {
        paramFieldsInfo.defaultExprs.put(str1, localObject1);
        localFieldMeta.setDefaultExpr((IExpressionReference)localObject1);
      }
    }
    Object localObject1 = paramTreeNode.existingChild("exportExpr");
    if ((localObject1 != null) && (paramTplC != null))
    {
      localObject2 = paramTplC.parseValueExpression((TreeNode)localObject1, paramIServiceContext);
      ((TreeNode)localObject1).setValue(localObject2);
      if (localObject2 != null) {
        localFieldMeta.setExportExpr((IExpressionReference)localObject2);
      }
    }
    Object localObject2 = paramTreeNode.existingChild("importExpr");
    if ((localObject2 != null) && (paramTplC != null))
    {
      localObject3 = paramTplC.parseValueExpression((TreeNode)localObject2, paramIServiceContext);
      ((TreeNode)localObject2).setValue(localObject3);
      if (localObject3 != null) {
        localFieldMeta.setImportExpr((IExpressionReference)localObject3);
      }
    }
    Object localObject3 = paramTreeNode.existingChild("inTransformer");
    ITransformer localITransformer1 = (localObject3 == null) || (paramTplC == null) ? null : (ITransformer)paramTplC.loadObject(((TreeNode)localObject3).cloneNode(), ITransformer.class, paramIServiceContext);
    localFieldMeta.setInTransformer(localITransformer1);
    TreeNode localTreeNode3 = paramTreeNode.existingChild("outTransformer");
    ITransformer localITransformer2 = (localTreeNode3 == null) || (paramTplC == null) ? null : (ITransformer)paramTplC.loadObject(localTreeNode3.cloneNode(), ITransformer.class, paramIServiceContext);
    localFieldMeta.setOutTransformer(localITransformer2);
    TreeNode localTreeNode4 = paramTreeNode.existingChild("enum");
    if (localTreeNode4 != null)
    {
      localObject4 = localTreeNode4.attribute("src").stripedStringValue();
      if (localObject4 != null)
      {
        localObject5 = localTreeNode4.attribute("default").stripedStringValue();
        localObject6 = new EnumTransformer((String)localObject4, localObject5);
        localFieldMeta.setOutTransformer((ITransformer)localObject6);
      }
    }
    Object localObject4 = paramTreeNode.existingChild("enumName");
    if (localObject4 != null) {
      localFieldMeta.setEnumName(((TreeNode)localObject4).stripedStringValue());
    }
    Object localObject5 = paramTreeNode.existingChild("outExpr");
    if ((localObject5 != null) && (paramTplC != null))
    {
      localObject6 = paramTplC.parseValueExpression((TreeNode)localObject5, paramIServiceContext);
      if (localObject6 != null)
      {
        localObject7 = new ExpressionTransformer((IExpressionReference)localObject6);
        localFieldMeta.setOutTransformer((ITransformer)localObject7);
      }
    }
    Object localObject6 = paramTreeNode.existingChild("entityFormula");
    if ((localObject6 != null) && (paramTplC != null))
    {
      localObject7 = paramTplC.parseValueExpression((TreeNode)localObject6, paramIServiceContext);
      if (localObject7 != null)
      {
        localFieldMeta.setEntityFormula(localObject7);
        localFieldMeta.setEntityFormulaText(((TreeNode)localObject6).stripedStringValue());
      }
    }
    Object localObject7 = paramTreeNode.existingChild("inExpr");
    if ((localObject7 != null) && (paramTplC != null))
    {
      IExpressionReference localIExpressionReference = paramTplC.parseValueExpression((TreeNode)localObject7, paramIServiceContext);
      if (localIExpressionReference != null)
      {
        ExpressionTransformer localExpressionTransformer = new ExpressionTransformer(localIExpressionReference);
        localFieldMeta.setInTransformer(localExpressionTransformer);
      }
    }
    boolean bool19 = paramTreeNode.attribute("isExtField").booleanValue((str1.startsWith("ext_")) || (str1.indexOf(".ext_") > 0));
    boolean bool20 = A(paramTreeNode, "nullable").booleanValue(true);
    localFieldMeta.setNullable(bool20);
    localFieldMeta.setExtField(bool19);
    TreeNode localTreeNode5 = paramTreeNode.existingChild("autoExpr");
    if ((localTreeNode5 != null) && (paramTplC != null))
    {
      localObject8 = paramTplC.parseValueExpression(localTreeNode5, paramIServiceContext);
      if (localObject8 != null) {
        localFieldMeta.setAutoExpr((IExpressionReference)localObject8);
      }
    }
    Object localObject8 = A(paramTreeNode, "idField").stripedStringValue();
    localFieldMeta.setIdField((String)localObject8);
    String str13 = A(paramTreeNode, "nameField").stripedStringValue();
    localFieldMeta.setNameField(str13);
    String str14 = A(paramTreeNode, "layerCodeField").stripedStringValue();
    localFieldMeta.setLayerCodeField(str14);
    String str15 = A(paramTreeNode, "serializer").stripedStringValue();
    localFieldMeta.setSerializer(str15);
    paramFieldsInfo.A(localFieldMeta);
    return localFieldMeta;
  }
  
  public static Map<String, List<String>> parseFieldGroups(TreeNode paramTreeNode, TplC paramTplC, IServiceContext paramIServiceContext, Map<String, Map<String, String>> paramMap)
  {
    if (paramTreeNode == null) {
      return null;
    }
    HashMap localHashMap = new HashMap();
    int j = paramTreeNode.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(i);
      if (!localTreeNode.getName().equals("fieldGroup")) {
        throw Exceptions.code("ds.CAN_err_not_field_group_node").param(localTreeNode);
      }
      String str1 = localTreeNode.attribute("name").stripedStringValue();
      if (str1 == null) {
        throw Exceptions.code("ds.CAN_err_field_group_no_name_arg").param(localTreeNode);
      }
      List localList1 = localTreeNode.stringListValue();
      A(str1, localList1, paramMap);
      localHashMap.put(str1, localList1);
      List localList2 = localTreeNode.attribute("alias").listValue();
      if (localList2 != null)
      {
        Iterator localIterator = localList2.iterator();
        while (localIterator.hasNext())
        {
          String str2 = (String)localIterator.next();
          localHashMap.put(str2, localList1);
        }
      }
    }
    return localHashMap;
  }
  
  static void A(String paramString, List<String> paramList, Map<String, Map<String, String>> paramMap)
  {
    if (paramMap != null)
    {
      int i = 0;
      int j = paramList.size();
      while (i < j)
      {
        String str1 = (String)paramList.get(i);
        if (str1.indexOf('[') > 0)
        {
          int k = str1.indexOf('[');
          int m = str1.lastIndexOf(']');
          if (m < 0) {
            throw new StdException("ds.err_invalid_field_name").param("field", str1).param("fieldGroup", paramString);
          }
          String str2 = str1.substring(k + 1, m);
          str1 = str1.substring(0, k).trim();
          Object localObject = (Map)paramMap.get(paramString);
          if (localObject == null)
          {
            localObject = new HashMap();
            paramMap.put(paramString, localObject);
          }
          ((Map)localObject).put(str1, str2);
          paramList.set(i, str1);
        }
        i++;
      }
    }
  }
  
  public static Map<String, List<String>> buildFieldGroups(List<FieldMeta> paramList)
  {
    HashMap localHashMap = new HashMap();
    Iterator localIterator1 = paramList.iterator();
    while (localIterator1.hasNext())
    {
      FieldMeta localFieldMeta = (FieldMeta)localIterator1.next();
      Set localSet = localFieldMeta.getSelectors();
      if (localSet != null)
      {
        Iterator localIterator2 = localSet.iterator();
        while (localIterator2.hasNext())
        {
          String str = (String)localIterator2.next();
          Object localObject = (List)localHashMap.get(str);
          if (localObject == null)
          {
            localObject = new ArrayList();
            localHashMap.put(str, localObject);
          }
          if (!((List)localObject).contains(localFieldMeta.getName())) {
            ((List)localObject).add(localFieldMeta.getName());
          }
        }
      }
    }
    return localHashMap;
  }
  
  public static Map<String, List<String>> mergeFieldGroups(Map<String, List<String>> paramMap, List<FieldMeta> paramList)
  {
    Map localMap = buildFieldGroups(paramList);
    if (paramMap != null) {
      localMap.putAll(paramMap);
    }
    HashMap localHashMap = new HashMap(localMap.size());
    Iterator localIterator = localMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      Object localObject = (List)localEntry.getValue();
      localObject = localObject == null ? new ArrayList(0) : new ArrayList((Collection)localObject);
      StringUtilsEx.internList((List)localObject);
      localHashMap.put((String)localEntry.getKey(), Collections.unmodifiableList((List)localObject));
    }
    return localHashMap;
  }
  
  public static void fixFieldGroupShowNames(Map<String, List<String>> paramMap, Map<String, Map<String, String>> paramMap1, DataSourceMetaImpl paramDataSourceMetaImpl)
  {
    Iterator localIterator1 = paramMap.entrySet().iterator();
    while (localIterator1.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator1.next();
      String str1 = (String)localEntry.getKey();
      List localList = (List)localEntry.getValue();
      ArrayList localArrayList = new ArrayList(localList.size());
      Iterator localIterator2 = localList.iterator();
      while (localIterator2.hasNext())
      {
        String str2 = (String)localIterator2.next();
        FieldMeta localFieldMeta = paramDataSourceMetaImpl.getFieldMeta(str2);
        if (localFieldMeta == null) {
          throw new StdException("ds.err_field_group_contains_unknown_field").param("field", str2).param("fieldGroup", str1).param("dsMeta", paramDataSourceMetaImpl);
        }
        String str3 = null;
        Map localMap = paramMap1 == null ? null : (Map)paramMap1.get(str1);
        if (localMap != null) {
          str3 = (String)localMap.get(str2);
        }
        if (str3 == null) {
          str3 = localFieldMeta.getShowName();
        }
        localArrayList.add(str3);
      }
      localEntry.setValue(new FieldNameList(localList, localArrayList));
    }
  }
  
  public static FieldsInfo compileFields(FieldsInfo paramFieldsInfo, TreeNode paramTreeNode, TplC paramTplC, IServiceContext paramIServiceContext)
  {
    int j = paramTreeNode.getChildCount();
    if (j <= 0) {
      Debug.trace("ds.CAN_err_empty_fields::" + paramTreeNode);
    }
    for (int i = 0; i < j; i++) {
      compileField(paramFieldsInfo, paramTreeNode.getChild(i), paramTplC, paramIServiceContext);
    }
    return paramFieldsInfo;
  }
  
  public static void updateBooleanNode(TreeNode paramTreeNode1, TreeNode paramTreeNode2, String paramString, boolean paramBoolean)
  {
    TreeNode localTreeNode = paramTreeNode2.existingChild(paramString);
    if (localTreeNode != null)
    {
      boolean bool = localTreeNode.booleanValue(paramBoolean);
      paramTreeNode1.makeChild(paramString).setValue(bool ? Boolean.TRUE : Boolean.FALSE);
      paramTreeNode2.removeChild(localTreeNode);
    }
  }
  
  public static void updateNode(TreeNode paramTreeNode1, TreeNode paramTreeNode2)
  {
    paramTreeNode1.getAttributes().putAll(paramTreeNode2.getAttributes());
    paramTreeNode1.setValue(paramTreeNode2.objectValue());
  }
  
  public static TreeNode createModeMeta(TreeNode paramTreeNode1, TreeNode paramTreeNode2)
  {
    paramTreeNode2 = paramTreeNode2.cloneNode();
    String str1 = paramTreeNode2.attribute("name").stripedStringValue();
    if (str1 == null) {
      throw Exceptions.code("ds.CAN_err_mode_no_name").param(str1);
    }
    if (str1.equals("default")) {
      throw Exceptions.code("ds.CAN_err_named_mode_can_not_be_default").param(paramTreeNode2);
    }
    TreeNode localTreeNode1 = paramTreeNode1.cloneNode();
    localTreeNode1.setAttribute("mode", str1);
    updateBooleanNode(localTreeNode1, paramTreeNode2, "secure", false);
    updateBooleanNode(localTreeNode1, paramTreeNode2, "useTxnManager", true);
    updateBooleanNode(localTreeNode1, paramTreeNode2, "readOnly", false);
    TreeNode localTreeNode2 = paramTreeNode2.existingChild("fields");
    if (localTreeNode2 != null)
    {
      boolean bool1 = localTreeNode2.attribute("reset").booleanValue(true);
      if (bool1) {
        localTreeNode1.removeChildByTagName("fields");
      }
      int j = localTreeNode2.getChildCount();
      if ((j <= 0) && (bool1)) {
        throw Exceptions.code("ds.CAN_err_mode_no_fields").param(localTreeNode1);
      }
      TreeNode localTreeNode3 = localTreeNode1.makeChild("fields");
      for (int i = 0; i < j; i++)
      {
        TreeNode localTreeNode4 = localTreeNode2.getChild(i);
        String str2 = localTreeNode4.attribute("name").stripedStringValue();
        if (str2 == null) {
          throw Exceptions.code("ds.CAN_err_field_no_name").param(localTreeNode4);
        }
        TreeNode localTreeNode5 = localTreeNode3.childWithAttr("name", str2);
        if (localTreeNode5 == null)
        {
          localTreeNode5 = TreeNode.make("field");
          localTreeNode3.appendChild(localTreeNode5);
        }
        boolean bool2 = localTreeNode4.attribute("reset").booleanValue(true);
        if (bool2) {
          localTreeNode5.clear();
        }
        A(localTreeNode5, localTreeNode4);
      }
    }
    return paramTreeNode2;
  }
  
  static void A(TreeNode paramTreeNode1, TreeNode paramTreeNode2)
  {
    paramTreeNode1.setAttributes(paramTreeNode2.getAttributes());
    int j = paramTreeNode2.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode1 = paramTreeNode2.getChild(i);
      String str = localTreeNode1.getName();
      TreeNode localTreeNode2 = paramTreeNode1.makeChild(str);
      paramTreeNode1.replaceChild(localTreeNode2, localTreeNode1.cloneNode());
    }
  }
  
  public static TreeMeta compileTreeMeta(TreeNode paramTreeNode, TplC paramTplC, IServiceContext paramIServiceContext)
  {
    TreeNode localTreeNode = paramTreeNode.existingChild("treeMeta");
    if (localTreeNode == null) {
      return null;
    }
    return new TreeMeta(localTreeNode);
  }
  
  public static GroupMeta compileGroupMeta(TreeNode paramTreeNode, TplC paramTplC, IServiceContext paramIServiceContext)
  {
    TreeNode localTreeNode = paramTreeNode.existingChild("group");
    if (localTreeNode == null) {
      return null;
    }
    if (localTreeNode.attribute("name").stripedStringValue() == null) {
      return new GroupMeta();
    }
    return new GroupMeta(localTreeNode);
  }
  
  public static List<KeyMeta> compileKeys(TreeNode paramTreeNode, TplC paramTplC, IServiceContext paramIServiceContext)
  {
    TreeNode localTreeNode1 = paramTreeNode.existingChild("keys");
    if (localTreeNode1 == null) {
      return null;
    }
    int j = localTreeNode1.getChildCount();
    ArrayList localArrayList = new ArrayList(j);
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode2 = localTreeNode1.getChild(i);
      if (!localTreeNode2.getName().equals("key")) {
        throw Exceptions.code("ds.CAN_err_not_key_node").param(localTreeNode2);
      }
      String str1 = localTreeNode2.attribute("id").stripedStringValue();
      String str2 = localTreeNode2.attribute("name").stripedStringValue(str1);
      List localList = localTreeNode2.stringListValue();
      if ((localList == null) || (localList.isEmpty())) {
        throw Exceptions.code("ds.CAN_err_key_node_no_fields").param(localTreeNode1);
      }
      KeyMeta localKeyMeta = new KeyMeta();
      localKeyMeta.setId(str1);
      localKeyMeta.setName(str2);
      localKeyMeta.setFields(localList);
      localArrayList.add(localKeyMeta);
    }
    return localArrayList;
  }
  
  public static TreeNode compileLink(TreeNode paramTreeNode, TplC paramTplC, IServiceContext paramIServiceContext)
  {
    TreeNode localTreeNode = paramTreeNode.existingChild("link");
    if (localTreeNode == null) {
      return null;
    }
    throw Exceptions.notAllowed();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\cp\DsCpImpls.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */