package edu.thu.model.stg.ds.spi.cp;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IVariant;
import edu.thu.lang.Variant;
import edu.thu.lang.el.IExpressionReference;
import edu.thu.lang.exceptions.StdException;
import edu.thu.lang.util.ITplReference;
import edu.thu.lang.util.TplC;
import edu.thu.lang.util.TplExpressionReference;
import edu.thu.model.stg.ds.spi.DataSourceMetaImpl;
import edu.thu.model.stg.ds.spi.DsConstants;
import edu.thu.model.stg.ds.spi.FieldMeta;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceContext;
import edu.thu.util.StringUtils;
import edu.thu.util.validate.IValidatorSet;
import edu.thu.web.layout.CardLayout;
import edu.thu.web.layout.LayoutMeta;
import edu.thu.web.layout.LayoutParser;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DsViewCompiler
  implements DsConstants
{
  TplC G;
  Map<String, Object> C = new HashMap();
  Map<String, CardLayout> F;
  DataSourceMetaImpl B;
  FieldMeta E;
  Map<String, Object> D = new HashMap();
  List<ITplReference> A;
  
  public DsViewCompiler(TplC paramTplC)
  {
    this.G = paramTplC;
  }
  
  public void compile(TreeNode paramTreeNode, DataSourceMetaImpl paramDataSourceMetaImpl, IServiceContext paramIServiceContext)
  {
    TreeNode localTreeNode = paramTreeNode.existingChild("initTpl");
    if (localTreeNode != null)
    {
      localObject1 = B(paramTreeNode.existingChild("initTpl"), paramIServiceContext);
      paramDataSourceMetaImpl.setInitTpl(localObject1);
    }
    Object localObject1 = paramTreeNode.existingChild("afterTpl");
    if (localObject1 != null)
    {
      localObject2 = B(paramTreeNode.existingChild("afterTpl"), paramIServiceContext);
      paramDataSourceMetaImpl.setAfterTpl(localObject2);
    }
    this.B = paramDataSourceMetaImpl;
    Object localObject2 = paramTreeNode.makeChild("fields");
    compileFields((TreeNode)localObject2, paramIServiceContext, true);
    D(paramTreeNode, paramIServiceContext);
  }
  
  public void setDsMeta(DataSourceMetaImpl paramDataSourceMetaImpl)
  {
    this.B = paramDataSourceMetaImpl;
  }
  
  public void compileFields(TreeNode paramTreeNode, IServiceContext paramIServiceContext, boolean paramBoolean)
  {
    int j = paramTreeNode.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode = paramTreeNode.getChild(i);
      try
      {
        D(localTreeNode, paramIServiceContext, paramBoolean);
      }
      catch (Exception localException)
      {
        throw new StdException("ds.err_compile_field_fail", localException).param(localTreeNode);
      }
    }
  }
  
  void A(TreeNode paramTreeNode, Map<String, ITplReference> paramMap, String paramString, ITplReference paramITplReference)
  {
    List localList = Variant.valueOf(paramString).listValue();
    int j = localList.size();
    for (int i = 0; i < j; i++)
    {
      String str = (String)localList.get(i);
      if (paramMap.containsKey(str)) {
        throw Exceptions.code("ds.CAN_err_duplicate_mode").param(paramTreeNode).param(paramString);
      }
      str = str.intern();
      paramMap.put(str, paramITplReference);
    }
  }
  
  void D(TreeNode paramTreeNode, IServiceContext paramIServiceContext, boolean paramBoolean)
  {
    String str = paramTreeNode.attribute("name").stripedStringValue();
    this.E = this.B.getFieldMeta(str);
    this.C.clear();
    this.C.put("fieldMeta", this.E);
    this.C.put("dsMeta", this.B);
    IExpressionReference localIExpressionReference1 = A(paramTreeNode, paramIServiceContext, "importExpr");
    IExpressionReference localIExpressionReference2 = A(paramTreeNode, paramIServiceContext, "autoExpr");
    IExpressionReference localIExpressionReference3 = A(paramTreeNode, paramIServiceContext, "defaultExpr");
    IExpressionReference localIExpressionReference4 = A(paramTreeNode, paramIServiceContext, "exportExpr");
    if (localIExpressionReference1 != null) {
      this.E.setImportExpr(localIExpressionReference1);
    }
    if (localIExpressionReference2 != null)
    {
      this.E.setAutoExpr(localIExpressionReference2);
      this.B.setAutoExpr(str, localIExpressionReference2);
    }
    if (localIExpressionReference3 != null)
    {
      this.E.setDefaultExpr(localIExpressionReference3);
      this.B.setDefaultExpr(str, localIExpressionReference3);
    }
    if (localIExpressionReference4 != null) {
      this.E.setExportExpr(localIExpressionReference4);
    }
    this.B.setProcessors(this.A);
    C(paramTreeNode, paramIServiceContext, paramBoolean);
    A(paramTreeNode, paramIServiceContext, paramBoolean);
    B(paramTreeNode, paramIServiceContext, paramBoolean);
    C(paramTreeNode, paramIServiceContext);
    A(paramTreeNode, paramIServiceContext);
  }
  
  IExpressionReference A(TreeNode paramTreeNode, IServiceContext paramIServiceContext, String paramString)
  {
    TreeNode localTreeNode = paramTreeNode.existingChild(paramString);
    if (localTreeNode == null)
    {
      localTreeNode = TreeNode.make("ds:" + StringUtils.capitalize(paramString));
      ITplReference localITplReference = this.G.compileNode(localTreeNode, null, paramIServiceContext);
      if (localITplReference == null) {
        return null;
      }
      return new TplExpressionReference(localITplReference);
    }
    return null;
  }
  
  void A(TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    TreeNode localTreeNode = paramTreeNode.existingChild("processor");
    if (localTreeNode == null) {
      localTreeNode = TreeNode.make("ds:" + StringUtils.capitalize("processor"));
    }
    ITplReference localITplReference = this.G.compileBody(localTreeNode, null, paramIServiceContext);
    if (localITplReference != null)
    {
      this.E.setProcessorTpl(localITplReference);
      if (this.A == null) {
        this.A = new ArrayList();
      }
      this.A.add(localITplReference);
    }
  }
  
  void C(TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    TreeNode localTreeNode = paramTreeNode.existingChild("validators");
    if (localTreeNode == null)
    {
      localTreeNode = TreeNode.make("validators");
      localTreeNode.makeChild("ds:" + StringUtils.capitalize("validator"));
    }
    IValidatorSet localIValidatorSet = this.G.compileValidatorSet(localTreeNode, this.C, paramIServiceContext);
    if (localIValidatorSet != null) {
      this.E.setValidators(localIValidatorSet);
    }
  }
  
  ITplReference B(TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    if (paramTreeNode == null) {
      return null;
    }
    Object localObject = TplC.getToken(this.C, "const");
    this.C.clear();
    this.C.put("fieldMeta", this.E);
    this.C.put("dsMeta", this.B);
    if (localObject != null) {
      this.C.put("const", localObject);
    }
    this.G.clearInnerCpVars();
    return this.G.compileBody(paramTreeNode, this.C, paramIServiceContext);
  }
  
  Map<String, ITplReference> A(TreeNode paramTreeNode, IServiceContext paramIServiceContext, boolean paramBoolean, String paramString)
  {
    HashMap localHashMap = new HashMap();
    TreeNode localTreeNode1 = paramTreeNode.existingChild(paramString);
    if (localTreeNode1 != null)
    {
      if (!localTreeNode1.hasBody()) {
        localTreeNode1.makeChild("ds:" + StringUtils.capitalize(paramString));
      }
      localObject = B(localTreeNode1, paramIServiceContext);
      if (localObject == null) {
        throw Exceptions.code("ds.CAN_err_ds_empty_tpl").param(localTreeNode1);
      }
      String str1 = localTreeNode1.attribute("mode").stripedStringValue("default");
      A(localTreeNode1, localHashMap, str1, (ITplReference)localObject);
    }
    Object localObject = paramTreeNode.existingChild(paramString + "s");
    if (localObject != null)
    {
      int j = ((TreeNode)localObject).getChildCount();
      for (int i = 0; i < j; i++)
      {
        localTreeNode1 = ((TreeNode)localObject).getChild(i);
        ITplReference localITplReference2 = B(localTreeNode1, paramIServiceContext);
        if (localITplReference2 == null) {
          throw Exceptions.code("ds.CAN_err_ds_empty_tpl").param(localTreeNode1);
        }
        String str2 = localTreeNode1.attribute("mode").stripedStringValue();
        if (str2 == null) {
          throw Exceptions.code("ds.CAN_err_ds_tpl_no_mode").param(localTreeNode1);
        }
        A(localTreeNode1, localHashMap, str2, localITplReference2);
      }
    }
    if (!localHashMap.containsKey("default"))
    {
      TreeNode localTreeNode2 = TreeNode.make("c:div");
      localTreeNode2.makeChild("ds:" + StringUtils.capitalize(paramString));
      ITplReference localITplReference1 = B(localTreeNode2, paramIServiceContext);
      if (localITplReference1 == null) {
        throw Exceptions.code("ds.CAN_err_ds_empty_tpl").param(paramTreeNode).param(paramString);
      }
      A(paramTreeNode, localHashMap, "default", localITplReference1);
    }
    return localHashMap;
  }
  
  void C(TreeNode paramTreeNode, IServiceContext paramIServiceContext, boolean paramBoolean)
  {
    Map localMap = A(paramTreeNode, paramIServiceContext, paramBoolean, "querier");
    FieldMeta localFieldMeta = this.E;
    localFieldMeta.setQueriers(new HashMap(localMap));
  }
  
  void A(TreeNode paramTreeNode, IServiceContext paramIServiceContext, boolean paramBoolean)
  {
    Map localMap = A(paramTreeNode, paramIServiceContext, paramBoolean, "viewer");
    FieldMeta localFieldMeta = this.E;
    localFieldMeta.setViewers(new HashMap(localMap));
  }
  
  void B(TreeNode paramTreeNode, IServiceContext paramIServiceContext, boolean paramBoolean)
  {
    Map localMap = A(paramTreeNode, paramIServiceContext, paramBoolean, "inputor");
    FieldMeta localFieldMeta = this.E;
    localFieldMeta.setInputors(new HashMap(localMap));
  }
  
  void D(TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    TreeNode localTreeNode = paramTreeNode.existingChild("layouts");
    LayoutParser localLayoutParser = new LayoutParser();
    localLayoutParser.setLayoutMeta(new LayoutMeta(this.B));
    localLayoutParser.setCp(this.G);
    this.F = localLayoutParser.compileLayouts(localTreeNode);
  }
  
  public Map<String, CardLayout> getLayouts()
  {
    return this.F;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\cp\DsViewCompiler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */