package edu.thu.model.stg.ds.spi.cp;

import edu.thu.lang.xconfig.IXConfigParser;
import edu.thu.model.stg.ds.DataSourceMeta;
import edu.thu.model.stg.ds.spi.FieldMeta;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceContext;
import java.util.Map;

public abstract interface IDsMetaXParser
  extends IXConfigParser<DataSourceMeta>
{
  public abstract Map<String, FieldMeta> compileFields(TreeNode paramTreeNode, IServiceContext paramIServiceContext);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\cp\IDsMetaXParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */