package edu.thu.model.stg.ds.spi.cp;

import edu.thu.model.stg.ds.spi.FieldMeta;
import java.util.HashMap;

class A
  extends HashMap<String, FieldMeta>
{
  private static final long serialVersionUID = 2279795558236044269L;
  
  public String toString()
  {
    return getClass().toString();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\cp\A.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */