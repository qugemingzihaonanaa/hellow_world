package edu.thu.model.stg.ds.spi.cp;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.el.IExpressionReference;
import edu.thu.model.stg.ds.spi.FieldMeta;
import edu.thu.util.validate.spi.ValidatorSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class FieldsInfo
{
  public Map<String, FieldMeta> fieldsMap = new A();
  public List<FieldMeta> fields = new ArrayList();
  public Map<String, IExpressionReference> defaultExprs = new HashMap(3);
  public Map<String, IExpressionReference> autoExprs = new LinkedHashMap(3);
  public Map<String, Object> entityFormulas = new LinkedHashMap();
  Map<String, List<String>> A;
  public ValidatorSet validatorSet = new ValidatorSet();
  
  public Map<String, List<String>> getFieldGroups()
  {
    return this.A;
  }
  
  public void setFieldGroups(Map<String, List<String>> paramMap)
  {
    this.A = paramMap;
  }
  
  public boolean checkGroupConfig(String paramString1, String paramString2, boolean paramBoolean)
  {
    if (this.A == null) {
      return paramBoolean;
    }
    List localList = (List)this.A.get(paramString1);
    if (localList == null) {
      return paramBoolean;
    }
    return localList.contains(paramString2);
  }
  
  void A(FieldMeta paramFieldMeta)
  {
    String str = paramFieldMeta.getName();
    if (this.fieldsMap.containsKey(str)) {
      throw Exceptions.code("ds.CAN_err_duplicate_field").param(str);
    }
    this.fields.add(paramFieldMeta);
    this.fieldsMap.put(str, paramFieldMeta);
    if (paramFieldMeta.getDefaultExpr() != null) {
      this.defaultExprs.put(str, paramFieldMeta.getDefaultExpr());
    }
    if (paramFieldMeta.getAutoExpr() != null) {
      this.autoExprs.put(str, paramFieldMeta.getAutoExpr());
    }
    if (paramFieldMeta.getEntityFormula() != null) {
      this.entityFormulas.put(str, paramFieldMeta.getEntityFormula());
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\cp\FieldsInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */