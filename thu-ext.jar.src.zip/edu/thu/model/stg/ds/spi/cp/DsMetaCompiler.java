package edu.thu.model.stg.ds.spi.cp;

import edu.thu.config.AppConfig;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IVariant;
import edu.thu.lang.el.IExpressionReference;
import edu.thu.lang.util.TplC;
import edu.thu.lang.xconfig.TplPieceSet;
import edu.thu.model.bean.IMetaParser;
import edu.thu.model.stg.ds.BatchAddMeta;
import edu.thu.model.stg.ds.DataSourceMeta;
import edu.thu.model.stg.ds.EntityRelation;
import edu.thu.model.stg.ds.OrderBy;
import edu.thu.model.stg.ds.QueryItem;
import edu.thu.model.stg.ds.QueryMeta;
import edu.thu.model.stg.ds.spi.DataSourceMetaImpl;
import edu.thu.model.stg.ds.spi.FieldMeta;
import edu.thu.model.stg.ds.spi.GroupMeta;
import edu.thu.model.stg.ds.spi.TreeMeta;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceCall;
import edu.thu.service.IServiceContext;
import edu.thu.text.ContentLoader;
import edu.thu.text.res.FixStrResource;
import edu.thu.tools.cp.tpl.AbstractConfigParser;
import edu.thu.tools.cp.tpl.IChildNodeMerger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

public class DsMetaCompiler
  extends AbstractConfigParser<DataSourceMeta>
  implements IMetaParser, IDsMetaXParser
{
  TplC cp;
  List<String> localFields;
  List<String> localLayouts;
  
  public TplC getCp()
  {
    return this.cp;
  }
  
  protected TreeNode transformNode(TreeNode paramTreeNode)
  {
    if (paramTreeNode == null) {
      return null;
    }
    if (!FixStrResource.isUseFix()) {
      return paramTreeNode;
    }
    FixStrResource localFixStrResource = FixStrResource.getInstance();
    localFixStrResource.fixAttr(paramTreeNode, "showName");
    TreeNode localTreeNode1 = paramTreeNode.existingChild("fields");
    localFixStrResource.fixChildAttr(localTreeNode1, "showName");
    TreeNode localTreeNode2 = paramTreeNode.existingChild("relations");
    localFixStrResource.fixChildAttr(localTreeNode2, "showName");
    return paramTreeNode;
  }
  
  protected TreeNode transformFieldsNode(TreeNode paramTreeNode)
  {
    return paramTreeNode;
  }
  
  protected TreeNode mergeMainNode(TreeNode paramTreeNode1, TreeNode paramTreeNode2)
  {
    TreeNode localTreeNode = paramTreeNode1.cloneNode();
    mergeNodeAndChild(localTreeNode, paramTreeNode2, Arrays.asList(new String[] { "fields", "relations", "layouts", "fieldGroups" }));
    mergeChildContainer(localTreeNode, paramTreeNode2, "fieldGroups", "name", null);
    mergeChildContainer(localTreeNode, paramTreeNode2, "fields", "name", new IChildNodeMerger()
    {
      public void merge(TreeNode paramAnonymousTreeNode1, TreeNode paramAnonymousTreeNode2)
      {
        DsMetaCompiler.this.mergeNodeAndChild(paramAnonymousTreeNode1, paramAnonymousTreeNode2, null);
      }
    });
    mergeChildContainer(localTreeNode, paramTreeNode2, "relations", "name", new IChildNodeMerger()
    {
      public void merge(TreeNode paramAnonymousTreeNode1, TreeNode paramAnonymousTreeNode2)
      {
        DsMetaCompiler.this.mergeNodeAndChild(paramAnonymousTreeNode1, paramAnonymousTreeNode2, null);
      }
    });
    mergeChildContainer(localTreeNode, paramTreeNode2, "layouts", "name", null);
    return localTreeNode;
  }
  
  public Object parseMeta(TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    return parseFromNode(paramTreeNode, paramIServiceContext);
  }
  
  public Map<String, FieldMeta> compileFields(TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    paramTreeNode = transformFieldsNode(paramTreeNode);
    FieldsInfo localFieldsInfo = DsCpImpls.compileFields(new FieldsInfo(), paramTreeNode, this.cp, paramIServiceContext);
    DsViewCompiler localDsViewCompiler = new DsViewCompiler(this.cp);
    localDsViewCompiler.compileFields(paramTreeNode, paramIServiceContext, false);
    return localFieldsInfo.fieldsMap;
  }
  
  public DataSourceMeta parseFromNode(TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    return doParse(paramTreeNode, paramIServiceContext);
  }
  
  protected void parseLocal(TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    TreeNode localTreeNode1;
    int j;
    ArrayList localArrayList;
    int i;
    TreeNode localTreeNode2;
    if (paramTreeNode.hasChild("fields"))
    {
      localTreeNode1 = paramTreeNode.makeChild("fields");
      j = localTreeNode1.getChildCount();
      localArrayList = new ArrayList(j);
      for (i = 0; i < j; i++)
      {
        localTreeNode2 = localTreeNode1.getChild(i);
        localArrayList.add((String)localTreeNode2.getAttribute("name"));
      }
      this.localFields = localArrayList;
    }
    if (paramTreeNode.hasChild("layouts"))
    {
      localTreeNode1 = paramTreeNode.makeChild("layouts");
      j = localTreeNode1.getChildCount();
      localArrayList = new ArrayList(j);
      for (i = 0; i < j; i++)
      {
        localTreeNode2 = localTreeNode1.getChild(i);
        localArrayList.add((String)localTreeNode2.getAttribute("name"));
      }
      this.localLayouts = localArrayList;
    }
  }
  
  boolean isMetaInternText()
  {
    return AppConfig.var("meta.use_intern_text").booleanValue(true);
  }
  
  protected DataSourceMeta doParse(TreeNode paramTreeNode, IServiceContext paramIServiceContext)
  {
    paramTreeNode = prepareNode(paramTreeNode, paramIServiceContext);
    paramTreeNode = transformNode(paramTreeNode);
    this.cp = newTplC(paramTreeNode, paramIServiceContext);
    this.cp.loadLib("ds", "/_config/ds/ds_meta.xml");
    List localList1 = DsCpImpls.compileKeys(paramTreeNode, this.cp, paramIServiceContext);
    List localList2 = paramTreeNode.makeChild("refFields").stringListValue();
    TreeNode localTreeNode = DsCpImpls.compileLink(paramTreeNode, this.cp, paramIServiceContext);
    if (localTreeNode != null)
    {
      localObject = paramTreeNode.makeChild("fields");
      ((TreeNode)localObject).setValue(null);
      ((TreeNode)localObject).appendChildren(localTreeNode.makeChild("fields").cloneChildren());
    }
    Object localObject = DsCpImpls.parseFieldGroups(paramTreeNode.existingChild("fieldGroups"), this.cp, paramIServiceContext, null);
    FieldsInfo localFieldsInfo = new FieldsInfo();
    localFieldsInfo.setFieldGroups((Map)localObject);
    DsCpImpls.compileFields(localFieldsInfo, paramTreeNode.makeChild("fields"), this.cp, paramIServiceContext);
    Map localMap = DsCpImpls.compileReferences(paramTreeNode.existingChild("references"));
    TreeMeta localTreeMeta = DsCpImpls.compileTreeMeta(paramTreeNode, this.cp, paramIServiceContext);
    GroupMeta localGroupMeta = DsCpImpls.compileGroupMeta(paramTreeNode, this.cp, paramIServiceContext);
    List localList3 = compileRelations(paramTreeNode, this.cp, paramIServiceContext);
    QueryItem localQueryItem = QueryItem.parseQuickQuery(paramTreeNode.existingChild("quick-query"));
    QueryMeta localQueryMeta = QueryMeta.fromTreeNode(paramTreeNode.existingChild("queries"), true);
    OrderBy localOrderBy = OrderBy.parse(paramTreeNode);
    DataSourceMetaImpl localDataSourceMetaImpl = new DataSourceMetaImpl(paramTreeNode);
    localDataSourceMetaImpl.setLocalFields(this.localFields);
    localDataSourceMetaImpl.setLocalLayouts(this.localLayouts);
    localDataSourceMetaImpl.setRefFields(localList2);
    localObject = DsCpImpls.mergeFieldGroups((Map)localObject, localFieldsInfo.fields);
    localDataSourceMetaImpl.setFieldGroups((Map)localObject);
    localDataSourceMetaImpl.setFieldGroups((Map)localObject);
    localDataSourceMetaImpl.setReferences(localMap);
    localDataSourceMetaImpl.setTreeMeta(localTreeMeta);
    localDataSourceMetaImpl.setFieldsInfo(localFieldsInfo);
    localDataSourceMetaImpl.setGroupMeta(localGroupMeta);
    localDataSourceMetaImpl.setEntityRelations(localList3);
    localDataSourceMetaImpl.setQueryMeta(localQueryMeta);
    localDataSourceMetaImpl.setQuickQuery(localQueryItem);
    localDataSourceMetaImpl.setOrderBy(localOrderBy);
    localDataSourceMetaImpl.setKeys(localList1);
    localDataSourceMetaImpl.setShowName(paramTreeNode.attribute("showName").stripedStringValue());
    localDataSourceMetaImpl.setTableName(paramTreeNode.attribute("tableName").stripedStringValue());
    localDataSourceMetaImpl.setEntityName(paramTreeNode.attribute("entityName").stripedStringValue());
    if ((localTreeMeta != null) && (localTreeMeta.getLabelField() == null)) {
      localTreeMeta.setLabelField(localDataSourceMetaImpl.getNameField());
    }
    BatchAddMeta localBatchAddMeta = BatchAddMeta.parse(paramTreeNode.existingChild("batchAdd"), localDataSourceMetaImpl);
    localDataSourceMetaImpl.setBatchAdd(localBatchAddMeta);
    TplPieceSet localTplPieceSet = parseTpls(paramTreeNode, this.cp, paramIServiceContext);
    localDataSourceMetaImpl.setTpls(localTplPieceSet);
    if (isMetaInternText()) {
      localDataSourceMetaImpl.internText();
    }
    DsViewCompiler localDsViewCompiler = new DsViewCompiler(this.cp);
    localDsViewCompiler.compile(paramTreeNode, localDataSourceMetaImpl, paramIServiceContext);
    localDataSourceMetaImpl.setLayouts(localDsViewCompiler.getLayouts());
    localDataSourceMetaImpl.detachMetaNode();
    return localDataSourceMetaImpl;
  }
  
  public List<EntityRelation> compileRelations(TreeNode paramTreeNode, TplC paramTplC, IServiceContext paramIServiceContext)
  {
    TreeNode localTreeNode1 = paramTreeNode.existingChild("relations");
    if (localTreeNode1 == null) {
      return null;
    }
    String str1 = paramTreeNode.makeChild("pkField").stripedStringValue();
    String str2 = paramTreeNode.makeChild("nameField").stripedStringValue();
    boolean bool1 = paramTreeNode.attribute("default").booleanValue(false);
    ContentLoader.load();
    List localList1 = localTreeNode1.children();
    int j = localList1.size();
    ArrayList localArrayList = new ArrayList(j);
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode2 = (TreeNode)localList1.get(i);
      if (!localTreeNode2.getName().equals("relation")) {
        throw Exceptions.code("ds.err_not_relation_node").param(localTreeNode2);
      }
      String str3 = localTreeNode2.attribute("name").stripedStringValue();
      if (str3 == null) {
        throw Exceptions.code("ds.err_relation_no_name_arg").param(localTreeNode2);
      }
      String str4 = localTreeNode2.attribute("showName").stripedStringValue(str3);
      String str5 = localTreeNode2.attribute("type").stripedStringValue();
      if (str5 == null) {
        throw Exceptions.code("ds.err_relation_no_type");
      }
      boolean bool2 = localTreeNode2.attribute("visible").booleanValue(true);
      String str6 = localTreeNode2.attribute("ops").stripedStringValue();
      String str7 = localTreeNode2.makeChild("localField").stripedStringValue();
      if (str7 == null) {
        if ((str5.equals("to-one")) || (str5.equals("to-mapping"))) {
          str7 = str3;
        } else if (str5.equals("to-many")) {
          str7 = str1;
        } else {
          str7 = str1;
        }
      }
      String str8 = localTreeNode2.makeChild("localNameField").stripedStringValue();
      if (str8 == null) {
        if (str5.equals("to-one")) {
          str8 = str7;
        } else if (str5.equals("to-many")) {
          str8 = str2;
        }
      }
      String str9 = localTreeNode2.makeChild("relatedField").stripedStringValue();
      String str10 = localTreeNode2.makeChild("relatedNameField").stripedStringValue(str9);
      String str11 = localTreeNode2.makeChild("relatedEntity").stripedStringValue();
      if ((str11 == null) && (!str5.equals("to-link")) && (!str5.equals("group"))) {
        throw Exceptions.code("ds.err_relation_no_relatedEntity_arg").param(localTreeNode2);
      }
      String str12 = localTreeNode2.makeChild("relatedObject").stripedStringValue();
      if ((str12 == null) && (str11 != null))
      {
        int k = str11.lastIndexOf('.');
        if (k < 0) {
          str12 = str11;
        } else {
          str12 = str11.substring(k + 1);
        }
      }
      String str13 = localTreeNode2.makeChild("relatedMeta").stripedStringValue();
      String str14 = localTreeNode2.makeChild("mappingField").stripedStringValue();
      if ((str14 == null) && (str5.equals("to-mapping"))) {
        throw Exceptions.code("ds.CAN_err_relation_no_mappingField_arg").param(localTreeNode2);
      }
      String str15 = localTreeNode2.makeChild("mappingNameField").stripedStringValue(str14);
      String str16 = localTreeNode2.makeChild("mappingEnum").stripedStringValue();
      if ((str16 == null) && (str5.equals("to-mapping"))) {
        throw Exceptions.code("ds.CAN_err_relation_no_mappingEnum_arg").param(localTreeNode2);
      }
      String str17 = localTreeNode2.makeChild("url").stripedStringValue();
      if ((str17 == null) && (str5.equals("to-link"))) {
        throw Exceptions.code("ds.CAN_err_relation_no_url_arg").param(localTreeNode2);
      }
      IExpressionReference localIExpressionReference = TplC.parseExpression(str17);
      Object localObject1 = localTreeNode2.attribute("selector").stringListValue();
      if (localObject1 == null) {
        localObject1 = new ArrayList();
      }
      String str18 = localTreeNode2.attribute("viewType").stripedStringValue();
      boolean bool3 = localTreeNode2.attribute("lazy").booleanValue(false);
      EntityRelation localEntityRelation = new EntityRelation();
      TreeNode localTreeNode3 = localTreeNode2.existingChild("conditions");
      if (localTreeNode3 != null)
      {
        localObject2 = TplC.toServiceCall(paramTplC.compilePredicateNode(localTreeNode3, paramIServiceContext));
        localEntityRelation.setCondition((IServiceCall)localObject2);
      }
      Object localObject2 = localTreeNode2.existingChild("action");
      if (localObject2 != null)
      {
        localObject3 = paramTplC.compileBody((TreeNode)localObject2, null, paramIServiceContext);
        localEntityRelation.setActionTpl(localObject3);
      }
      Object localObject3 = parseTpls(localTreeNode2, paramTplC, paramIServiceContext);
      localEntityRelation.setTpls((TplPieceSet)localObject3);
      localEntityRelation.setOps(str6);
      localEntityRelation.setViewType(str18);
      localEntityRelation.setSelectors(new HashSet((Collection)localObject1));
      localEntityRelation.setName(str3);
      localEntityRelation.setShowName(str4);
      localEntityRelation.setType(str5);
      localEntityRelation.setVisible(bool2);
      localEntityRelation.setDefault(bool1);
      localEntityRelation.setLazy(bool3);
      localEntityRelation.setRelatedMetaName(str13);
      localEntityRelation.setLocalField(str7);
      localEntityRelation.setRelatedField(str9);
      localEntityRelation.setLocalNameField(str8);
      localEntityRelation.setRelatedNameField(str10);
      localEntityRelation.setRelatedEntityName(str11);
      localEntityRelation.setRelatedObjectName(str12);
      localEntityRelation.setMappingField(str14);
      localEntityRelation.setMappingNameField(str15);
      localEntityRelation.setMappingEnum(str16);
      localEntityRelation.setUrlExpr(localIExpressionReference);
      TreeNode localTreeNode4 = localTreeNode2.existingChild("relations");
      if (localTreeNode4 != null)
      {
        List localList2 = compileRelations(localTreeNode4, paramTplC, paramIServiceContext);
        localEntityRelation.setSubRelations(localList2);
      }
      localArrayList.add(localEntityRelation);
    }
    return localArrayList;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\cp\DsMetaCompiler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */