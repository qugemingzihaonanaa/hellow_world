package edu.thu.model.stg.ds.spi;

import edu.thu.global.Debug;
import edu.thu.model.stg.ds.IDataCollection;
import edu.thu.model.stg.ds.IDataSource;
import edu.thu.model.stg.ds.IDataSourceUpdator;
import edu.thu.model.stg.ds.IRecordProcessor;
import edu.thu.model.stg.view.IPageViewer;
import edu.thu.model.tree.TreeNode;
import edu.thu.search.IPreparedQuery;
import edu.thu.search.IQuery;
import edu.thu.service.ICancelMonitor;
import edu.thu.service.IServiceContext;
import java.util.Map;

public abstract class ProxyDataSource
  extends DsTransactionSupport
  implements IDataSource
{
  public ProxyDataSource()
  {
    super(null);
  }
  
  public ProxyDataSource(IDataSource paramIDataSource)
  {
    super(paramIDataSource);
    Debug.check(paramIDataSource);
  }
  
  public Object switchToMode(String paramString)
  {
    return getDataSource().switchToMode(paramString);
  }
  
  public Object contextualize(IServiceContext paramIServiceContext)
  {
    if (!isContextualizable()) {
      return this;
    }
    return createThis((IDataSource)getDataSource().contextualize(paramIServiceContext));
  }
  
  public Object execute(String paramString, Map paramMap, IServiceContext paramIServiceContext)
  {
    return getDataSource().execute(paramString, paramMap, paramIServiceContext);
  }
  
  public boolean exists(IQuery paramIQuery, ICancelMonitor paramICancelMonitor)
  {
    return getDataSource().exists(paramIQuery, paramICancelMonitor);
  }
  
  public IPageViewer findMany(Object paramObject, IQuery paramIQuery, ICancelMonitor paramICancelMonitor)
  {
    return getDataSource().findMany(paramObject, paramIQuery, paramICancelMonitor);
  }
  
  public Object findOne(Object paramObject, IQuery paramIQuery, ICancelMonitor paramICancelMonitor)
  {
    return getDataSource().findOne(paramObject, paramIQuery, paramICancelMonitor);
  }
  
  public TreeNode getMeta()
  {
    return getDataSource().getMeta();
  }
  
  public String getName()
  {
    return getDataSource().getName();
  }
  
  public IDataSourceUpdator getUpdator(Object paramObject)
  {
    return getDataSource().getUpdator(paramObject);
  }
  
  public boolean isParameterizable()
  {
    return getDataSource().isParameterizable();
  }
  
  public Object parameterize(Map paramMap)
  {
    if (!isParameterizable()) {
      return this;
    }
    return createThis((IDataSource)getDataSource().parameterize(paramMap));
  }
  
  public IPreparedQuery parseQuery(Object paramObject, IQuery paramIQuery)
  {
    return getDataSource().parseQuery(paramObject, paramIQuery);
  }
  
  public void process(IQuery paramIQuery, IRecordProcessor paramIRecordProcessor, IServiceContext paramIServiceContext)
  {
    getDataSource().process(paramIQuery, paramIRecordProcessor, paramIServiceContext);
  }
  
  public void setName(String paramString)
  {
    getDataSource().setName(paramString);
  }
  
  public IDataSource getDataSource(String paramString, IServiceContext paramIServiceContext)
  {
    return getDataSource().getDataSource(paramString, paramIServiceContext);
  }
  
  public IDataCollection getMapping(String paramString, Map paramMap, IServiceContext paramIServiceContext)
  {
    return getDataSource().getMapping(paramString, paramMap, paramIServiceContext);
  }
  
  public IServiceContext getContext()
  {
    return getDataSource().getContext();
  }
  
  public boolean isContextualizable()
  {
    return getDataSource().isContextualizable();
  }
  
  public String getCurrentMode()
  {
    return getDataSource().getCurrentMode();
  }
  
  public boolean isCacheable()
  {
    return getDataSource().isCacheable();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\ProxyDataSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */