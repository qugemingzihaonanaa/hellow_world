package edu.thu.model.stg.ds.spi;

import edu.thu.java.util.ClassUtils;
import edu.thu.model.stg.ds.IDataSource;
import edu.thu.model.stg.ds.ISupportDataSource;
import edu.thu.service.txn.ITransactionMode;
import edu.thu.service.txn.ITransactionSupport;

public abstract class DsTransactionSupport
  implements ISupportDataSource, ITransactionSupport
{
  protected IDataSource ds;
  
  public IDataSource getDataSource()
  {
    return this.ds;
  }
  
  public DsTransactionSupport(IDataSource paramIDataSource)
  {
    this.ds = paramIDataSource;
  }
  
  protected Object createThis(IDataSource paramIDataSource)
  {
    return ClassUtils.classToObject(getClass(), paramIDataSource);
  }
  
  public Object beginTransaction()
  {
    return createThis((IDataSource)getDataSource().beginTransaction());
  }
  
  public Object cooperate(ITransactionMode paramITransactionMode)
  {
    return createThis((IDataSource)getDataSource().cooperate(paramITransactionMode));
  }
  
  public void endTransaction(boolean paramBoolean)
  {
    getDataSource().endTransaction(paramBoolean);
  }
  
  public ITransactionMode getTransactionMode()
  {
    return getDataSource().getTransactionMode();
  }
  
  public boolean supportTransaction()
  {
    return getDataSource().supportTransaction();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\DsTransactionSupport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */