package edu.thu.model.stg.ds.spi;

import edu.thu.global.Debug;
import edu.thu.lang.el.IExpressionReference;
import edu.thu.lang.exceptions.ErrorInfo;
import edu.thu.lang.util.ITplReference;
import edu.thu.lang.util.TplC;
import edu.thu.lang.xconfig.TplPieceSet;
import edu.thu.model.data.transform.ITransformer;
import edu.thu.model.stg.ds.EnumItem;
import edu.thu.model.stg.ds.EnumLoader;
import edu.thu.model.stg.ds.IEnumInfo;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceContext;
import edu.thu.service.SystemServiceContext;
import edu.thu.service.ThreadServiceContext;
import edu.thu.util.StringUtils;
import edu.thu.util.validate.IValidatorSet;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class FieldMeta
  implements DsConstants, Serializable
{
  private static final long serialVersionUID = -8808162425794532211L;
  String i;
  String º;
  String b;
  String s;
  String Ì;
  String y;
  String a;
  String Î;
  String m;
  boolean r;
  boolean f;
  boolean l;
  boolean £;
  boolean q;
  boolean g;
  boolean Ã;
  boolean u;
  boolean o;
  boolean t;
  boolean p;
  boolean W;
  boolean Ä;
  boolean X;
  Set<String> w;
  IExpressionReference Z;
  IExpressionReference ¤;
  IExpressionReference É;
  IExpressionReference Y;
  ITransformer ª;
  ITransformer k;
  String h;
  Map<String, ITplReference> ¢;
  Map<String, ITplReference> x;
  Map<String, ITplReference> _;
  ITplReference Æ;
  Object z;
  String Í;
  IValidatorSet Ë;
  int d;
  int c;
  String Á;
  String À;
  String j;
  boolean Ê;
  String Ç;
  String V;
  Integer È;
  String n;
  String Å;
  String µ;
  String Â;
  Map<String, Object> ¥;
  Map<String, TreeNode> v;
  TplPieceSet e;
  
  public boolean isExtField()
  {
    return this.X;
  }
  
  public void setExtField(boolean paramBoolean)
  {
    this.X = paramBoolean;
  }
  
  public ITplReference getProcessorTpl()
  {
    return this.Æ;
  }
  
  public void setProcessorTpl(ITplReference paramITplReference)
  {
    this.Æ = paramITplReference;
  }
  
  public String getTip()
  {
    return this.a;
  }
  
  public void setTip(String paramString)
  {
    this.a = paramString;
  }
  
  public TplPieceSet getTpls()
  {
    return this.e;
  }
  
  public void setTpls(TplPieceSet paramTplPieceSet)
  {
    this.e = paramTplPieceSet;
  }
  
  public ITplReference getFirstTplContentBySelector(String paramString)
  {
    if (this.e == null) {
      return null;
    }
    return this.e.getFirstTplContentBySelector(paramString);
  }
  
  public ITplReference getTplContentById(String paramString)
  {
    if (this.e == null) {
      return null;
    }
    return this.e.getTplContentById(paramString);
  }
  
  public void setAttributes(Map<String, Object> paramMap)
  {
    this.¥ = paramMap;
  }
  
  public TreeNode getExtNode(String paramString)
  {
    return getExtChild(paramString);
  }
  
  public TreeNode getExtChild(String paramString)
  {
    if (this.v == null) {
      return null;
    }
    return (TreeNode)this.v.get(paramString);
  }
  
  public void setExtChildren(Map<String, TreeNode> paramMap)
  {
    this.v = paramMap;
  }
  
  public void internText()
  {
    if (this.i != null) {
      this.i = this.i.intern();
    }
    if (this.º != null) {
      this.º = this.º.intern();
    }
    if (this.b != null) {
      this.b = this.b.intern();
    }
    if (this.s != null) {
      this.s = this.s.intern();
    }
    if (this.Ì != null) {
      this.Ì = this.Ì.intern();
    }
    if (this.y != null) {
      this.y = this.y.intern();
    }
    if (this.Î != null) {
      this.Î = this.Î.intern();
    }
    if (this.m != null) {
      this.m = this.m.intern();
    }
    if (this.Á != null) {
      this.Á = this.Á.intern();
    }
    if (this.À != null) {
      this.À = this.À.intern();
    }
    if (this.j != null) {
      this.j = this.j.intern();
    }
    if (this.Ç != null) {
      this.Ç = this.Ç.intern();
    }
    if (this.V != null) {
      this.V = this.V.intern();
    }
    if (this.n != null) {
      this.n = this.n.intern();
    }
    if (this.Å != null) {
      this.Å = this.Å.intern();
    }
    if (this.µ != null) {
      this.µ = this.µ.intern();
    }
    if (this.Â != null) {
      this.Â = this.Â.intern();
    }
    if (this.¥ != null)
    {
      Iterator localIterator = this.¥.entrySet().iterator();
      while (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        Object localObject = localEntry.getValue();
        if ((localObject instanceof String)) {
          localEntry.setValue(localObject.toString().intern());
        }
      }
    }
  }
  
  public String getFullName()
  {
    if (this.y == null) {
      return getShowName();
    }
    return this.y;
  }
  
  public void setFullName(String paramString)
  {
    this.y = paramString;
  }
  
  public String getStyle()
  {
    return this.Â;
  }
  
  public void setStyle(String paramString)
  {
    this.Â = paramString;
  }
  
  public String getAlign()
  {
    return this.Å;
  }
  
  public void setAlign(String paramString)
  {
    this.Å = paramString;
  }
  
  public String getValign()
  {
    return this.µ;
  }
  
  public void setValign(String paramString)
  {
    this.µ = paramString;
  }
  
  public boolean isSupportQueryBuilder()
  {
    return this.W;
  }
  
  public void setSupportQueryBuilder(boolean paramBoolean)
  {
    this.W = paramBoolean;
  }
  
  public boolean isBatchUpdate()
  {
    return this.p;
  }
  
  public void setBatchUpdate(boolean paramBoolean)
  {
    this.p = paramBoolean;
  }
  
  public boolean isBatchUpdatable()
  {
    return this.t;
  }
  
  public void setBatchUpdatable(boolean paramBoolean)
  {
    this.t = paramBoolean;
  }
  
  public String getDbName()
  {
    return this.Ì;
  }
  
  public void setDbName(String paramString)
  {
    this.Ì = paramString;
  }
  
  public IExpressionReference getExportExpr()
  {
    return this.É;
  }
  
  public String getSerializer()
  {
    return this.n;
  }
  
  public void setSerializer(String paramString)
  {
    this.n = paramString;
  }
  
  public void setExportExpr(IExpressionReference paramIExpressionReference)
  {
    this.É = paramIExpressionReference;
  }
  
  public IExpressionReference getImportExpr()
  {
    return this.Y;
  }
  
  public void setImportExpr(IExpressionReference paramIExpressionReference)
  {
    this.Y = paramIExpressionReference;
  }
  
  public String getLayerCodeField()
  {
    return this.j;
  }
  
  public void setLayerCodeField(String paramString)
  {
    this.j = paramString;
  }
  
  public boolean isExportable()
  {
    return this.o;
  }
  
  public void setExportable(boolean paramBoolean)
  {
    this.o = paramBoolean;
  }
  
  public Integer getPrecision()
  {
    return this.È;
  }
  
  public void setPrecision(Integer paramInteger)
  {
    this.È = paramInteger;
  }
  
  public Object getEntityFormula()
  {
    return this.z;
  }
  
  public void setEntityFormula(Object paramObject)
  {
    this.z = paramObject;
  }
  
  public String getEntityFormulaText()
  {
    return this.Í;
  }
  
  public void setEntityFormulaText(String paramString)
  {
    this.Í = paramString;
  }
  
  public String getShowKey()
  {
    return this.s;
  }
  
  public void setShowKey(String paramString)
  {
    this.s = paramString;
  }
  
  public String getEnumName()
  {
    return this.Ç;
  }
  
  public void setEnumName(String paramString)
  {
    this.Ç = paramString;
  }
  
  public String getIdField()
  {
    return this.Á;
  }
  
  public void setIdField(String paramString)
  {
    this.Á = paramString;
  }
  
  public boolean isListable()
  {
    return this.r;
  }
  
  public void setListable(boolean paramBoolean)
  {
    this.r = paramBoolean;
  }
  
  public String getNameField()
  {
    return this.À;
  }
  
  public void setNameField(String paramString)
  {
    this.À = paramString;
  }
  
  public boolean isOrderable()
  {
    return this.u;
  }
  
  public void setOrderable(boolean paramBoolean)
  {
    this.u = paramBoolean;
  }
  
  public boolean isQueriable()
  {
    return this.Ã;
  }
  
  public void setQueriable(boolean paramBoolean)
  {
    this.Ã = paramBoolean;
  }
  
  public boolean isShowForEdit()
  {
    return this.Ê;
  }
  
  public void setShowForEdit(boolean paramBoolean)
  {
    this.Ê = paramBoolean;
  }
  
  public String getStoreType()
  {
    return this.m;
  }
  
  public void setStoreType(String paramString)
  {
    this.m = paramString;
  }
  
  public boolean isViewable()
  {
    return this.f;
  }
  
  public void setViewable(boolean paramBoolean)
  {
    this.f = paramBoolean;
  }
  
  public String getType()
  {
    if (this.Î == null) {
      return "object";
    }
    return this.Î;
  }
  
  public void setType(String paramString)
  {
    this.Î = paramString;
  }
  
  public String getName()
  {
    return this.i;
  }
  
  public String getBaseName()
  {
    return this.º;
  }
  
  public String getShowName()
  {
    return this.b;
  }
  
  public boolean isNullable()
  {
    return this.g;
  }
  
  public boolean isUpdatable()
  {
    return this.l;
  }
  
  public boolean isAddable()
  {
    return this.£;
  }
  
  public boolean isVisible()
  {
    return this.q;
  }
  
  public IExpressionReference getDefaultExpr()
  {
    return this.¤;
  }
  
  public ITransformer getInTransformer()
  {
    return this.ª;
  }
  
  public ITransformer getOutTransformer()
  {
    return this.k;
  }
  
  public String getFormula()
  {
    return this.h;
  }
  
  public IExpressionReference getAutoExpr()
  {
    return this.Z;
  }
  
  public void setAutoExpr(IExpressionReference paramIExpressionReference)
  {
    this.Z = paramIExpressionReference;
  }
  
  public Map<String, ITplReference> getInputors()
  {
    return this.¢;
  }
  
  public void setInputors(Map<String, ITplReference> paramMap)
  {
    this.¢ = paramMap;
  }
  
  public IValidatorSet getValidators()
  {
    return this.Ë;
  }
  
  public void setValidators(IValidatorSet paramIValidatorSet)
  {
    this.Ë = paramIValidatorSet;
  }
  
  public List<ErrorInfo> checkValid(String paramString, Map<String, Object> paramMap)
  {
    if (this.Ë == null) {
      return null;
    }
    return this.Ë.checkValid(paramString, paramMap);
  }
  
  public void validate(String paramString, Map<String, Object> paramMap)
  {
    this.Ë.validate(paramString, paramMap);
  }
  
  public Map<String, ITplReference> getViewers()
  {
    return this.x;
  }
  
  public void setViewers(Map<String, ITplReference> paramMap)
  {
    this.x = paramMap;
  }
  
  public void setAddable(boolean paramBoolean)
  {
    this.£ = paramBoolean;
  }
  
  public void setBaseName(String paramString)
  {
    this.º = paramString;
  }
  
  public void setDefaultExpr(IExpressionReference paramIExpressionReference)
  {
    this.¤ = paramIExpressionReference;
  }
  
  public void setFormula(String paramString)
  {
    this.h = paramString;
  }
  
  public void setInTransformer(ITransformer paramITransformer)
  {
    this.ª = paramITransformer;
  }
  
  public void setName(String paramString)
  {
    this.i = paramString;
  }
  
  public void setNullable(boolean paramBoolean)
  {
    this.g = paramBoolean;
  }
  
  public void setOutTransformer(ITransformer paramITransformer)
  {
    this.k = paramITransformer;
  }
  
  public void setUpdatable(boolean paramBoolean)
  {
    this.l = paramBoolean;
  }
  
  public void setShowName(String paramString)
  {
    this.b = paramString;
  }
  
  public void setVisible(boolean paramBoolean)
  {
    this.q = paramBoolean;
  }
  
  public String transToBase()
  {
    return this.h != null ? this.h : this.º;
  }
  
  public ITplReference getInputor(String paramString)
  {
    if ((paramString == null) || (this.¢ == null)) {
      return null;
    }
    return (ITplReference)this.¢.get(paramString);
  }
  
  public ITplReference getViewer(String paramString)
  {
    if ((paramString == null) || (this.x == null)) {
      return null;
    }
    return (ITplReference)this.x.get(paramString);
  }
  
  public ITplReference getQuerier(String paramString)
  {
    if ((paramString == null) || (this._ == null)) {
      return null;
    }
    return (ITplReference)this._.get(paramString);
  }
  
  public ITplReference getInputorWithDefault(String paramString)
  {
    ITplReference localITplReference = getInputor(paramString);
    if (localITplReference == null) {
      localITplReference = getInputor("default");
    }
    return localITplReference;
  }
  
  public ITplReference getViewerWithDefault(String paramString)
  {
    ITplReference localITplReference = getViewer(paramString);
    if (localITplReference == null) {
      localITplReference = getViewer("default");
    }
    return localITplReference;
  }
  
  public ITplReference inputor(String paramString)
  {
    if (this.¢ == null) {
      return null;
    }
    if (paramString == null) {
      paramString = "default";
    }
    ITplReference localITplReference = (ITplReference)this.¢.get(paramString);
    if (localITplReference == null) {
      localITplReference = (ITplReference)this.¢.get("default");
    }
    return localITplReference;
  }
  
  public ITplReference viewer(String paramString)
  {
    if (this.x == null) {
      return null;
    }
    if (paramString == null) {
      paramString = "default";
    }
    ITplReference localITplReference = (ITplReference)this.x.get(paramString);
    if (localITplReference == null) {
      localITplReference = (ITplReference)this.x.get("default");
    }
    return localITplReference;
  }
  
  public ITplReference querier(String paramString)
  {
    if (this._ == null) {
      return null;
    }
    if (paramString == null) {
      paramString = "default";
    }
    ITplReference localITplReference = (ITplReference)this._.get(paramString);
    if (localITplReference == null) {
      localITplReference = (ITplReference)this._.get("default");
    }
    return localITplReference;
  }
  
  public ITplReference getQuerierWithDefault(String paramString)
  {
    ITplReference localITplReference = getQuerier(paramString);
    if (localITplReference == null) {
      localITplReference = getQuerier("default");
    }
    return localITplReference;
  }
  
  public ITplReference getInputor()
  {
    return inputor("default");
  }
  
  public ITplReference getViewer()
  {
    return viewer("default");
  }
  
  public ITplReference getQuerier()
  {
    return querier("default");
  }
  
  public boolean isAuto()
  {
    return this.Z != null;
  }
  
  public String getWidth()
  {
    return this.V;
  }
  
  public void setWidth(String paramString)
  {
    this.V = paramString;
  }
  
  public int getMaxLength()
  {
    return this.d;
  }
  
  public void setMaxLength(int paramInt)
  {
    this.d = paramInt;
  }
  
  public int getStoreSize()
  {
    return this.c;
  }
  
  public void setStoreSize(int paramInt)
  {
    this.c = paramInt;
  }
  
  public Map<String, ITplReference> getQueriers()
  {
    return this._;
  }
  
  public void setQueriers(Map<String, ITplReference> paramMap)
  {
    this._ = paramMap;
  }
  
  public Set<String> getSelectors()
  {
    return this.w;
  }
  
  public void setSelectors(Set<String> paramSet)
  {
    this.w = paramSet;
  }
  
  public boolean addSelector(String paramString)
  {
    return this.w.add(paramString);
  }
  
  public boolean matchSelector(String paramString)
  {
    if (this.w == null) {
      return false;
    }
    return this.w.contains(paramString);
  }
  
  public List<EnumItem> getEnumData(IServiceContext paramIServiceContext)
  {
    if (this.Ç == null)
    {
      Debug.traceErr("ds.CAN_err_null_enumName");
      return null;
    }
    return EnumLoader.loadEnum(this.Ç, paramIServiceContext).getItems();
  }
  
  public List<EnumItem> getEnumData()
  {
    return getEnumData(ThreadServiceContext.getCurrentContext());
  }
  
  public Object getEnumValue(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    IEnumInfo localIEnumInfo = EnumLoader.loadEnum(this.Ç, ThreadServiceContext.getCurrentContext());
    return localIEnumInfo.getItemValue(paramString);
  }
  
  public String getAttribute(String paramString)
  {
    if (this.¥ == null) {
      return null;
    }
    return (String)this.¥.get(paramString);
  }
  
  public boolean isLoggable()
  {
    return this.Ä;
  }
  
  public void setLoggable(boolean paramBoolean)
  {
    this.Ä = paramBoolean;
  }
  
  public String toJs()
  {
    FieldMeta localFieldMeta = this;
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("{");
    localStringBuffer.append("name:'").append(StringUtils.escape(localFieldMeta.getName())).append("'");
    localStringBuffer.append(",type:'").append(localFieldMeta.getType()).append("'");
    localStringBuffer.append(",showName:'").append(StringUtils.escape(localFieldMeta.getShowName())).append("'");
    localStringBuffer.append(",isEnum:").append(localFieldMeta.getEnumName() != null);
    localStringBuffer.append(",maxLength:").append(localFieldMeta.getMaxLength());
    localStringBuffer.append(",nullable:").append(localFieldMeta.isNullable());
    localStringBuffer.append(",updatable:").append(localFieldMeta.isUpdatable());
    localStringBuffer.append(",addable:").append(localFieldMeta.isAddable());
    localStringBuffer.append(",visible:").append(localFieldMeta.isVisible());
    localStringBuffer.append(",orderable:").append(localFieldMeta.isOrderable());
    if (this.Å != null) {
      localStringBuffer.append(",align:'").append(this.Å).append("'");
    }
    if (this.V != null) {
      localStringBuffer.append(",width:").append(this.V);
    }
    if (localFieldMeta.getDefaultExpr() != null)
    {
      localObject = TplC.evaluate(localFieldMeta.getDefaultExpr(), new HashMap(0));
      if (localObject != null) {
        localStringBuffer.append(",defaultValue:'").append(StringUtils.escape(localObject.toString())).append("'");
      }
    }
    Object localObject = localFieldMeta.getInputor("jsEditor");
    if (localObject != null)
    {
      String str = TplC.getTplOut((ITplReference)localObject, null, SystemServiceContext.getInstance());
      str = StringUtils.strip(str);
      if (str != null) {
        localStringBuffer.append(",jsEditor:").append(str);
      }
    }
    localStringBuffer.append("}");
    return localStringBuffer.toString();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\FieldMeta.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */