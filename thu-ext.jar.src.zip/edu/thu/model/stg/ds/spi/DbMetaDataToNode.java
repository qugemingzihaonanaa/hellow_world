package edu.thu.model.stg.ds.spi;

import edu.thu.global.Debug;
import edu.thu.lang.IVariant;
import edu.thu.model.tree.TreeNode;
import java.util.List;
import java.util.Vector;

public class DbMetaDataToNode
  implements DbDataConstants
{
  String B;
  String A;
  TreeNode C;
  
  public DbMetaDataToNode(TreeNode paramTreeNode, String paramString)
  {
    Debug.check(paramTreeNode);
    Debug.check(paramString);
    this.B = paramString;
    this.C = A(paramTreeNode);
    this.A = getEngineName(paramTreeNode);
  }
  
  TreeNode A(TreeNode paramTreeNode)
  {
    TreeNode localTreeNode1 = paramTreeNode.makeChild("tables");
    TreeNode localTreeNode2 = null;
    int j = localTreeNode1.getChildCount();
    for (int i = 0; i < j; i++)
    {
      localTreeNode2 = localTreeNode1.getChild(i);
      String str = localTreeNode2.attribute("TABLE_NAME").stripedStringValue();
      if (str.equals(this.B)) {
        break;
      }
    }
    return localTreeNode2;
  }
  
  public String getEngineName(TreeNode paramTreeNode)
  {
    String str = paramTreeNode.makeChild("engine").stripedStringValue("default");
    return str;
  }
  
  public void setTableName(String paramString)
  {
    Debug.check(paramString);
    this.B = paramString;
  }
  
  public TreeNode transform()
  {
    String str = B();
    List localList = A();
    TreeNode localTreeNode1 = A(str, localList);
    TreeNode localTreeNode2 = C();
    TreeNode localTreeNode3 = TreeNode.make("dataSource");
    localTreeNode3.appendChild(localTreeNode1);
    localTreeNode3.appendChild(localTreeNode2);
    return localTreeNode3;
  }
  
  String B()
  {
    TreeNode localTreeNode = this.C.makeChild("primaryKeys");
    String str = localTreeNode.attribute("COLUMN_NAME").stripedStringValue(null);
    return str;
  }
  
  List A()
  {
    Vector localVector = new Vector();
    TreeNode localTreeNode = this.C.makeChild("indices");
    int j = localTreeNode.getChildCount();
    for (int i = 0; i < j; i++)
    {
      String str = localTreeNode.getChild(i).attribute("COLUMN_NAME").stripedStringValue();
      localVector.add(str);
    }
    return localVector;
  }
  
  TreeNode A(String paramString, List paramList)
  {
    TreeNode localTreeNode2 = TreeNode.make("fields");
    TreeNode localTreeNode4 = this.C.makeChild("columns");
    int j = localTreeNode4.getChildCount();
    for (int i = 0; i < j; i++)
    {
      TreeNode localTreeNode3 = localTreeNode4.getChild(i);
      String str1 = localTreeNode3.attribute("COLUMN_NAME").stripedStringValue();
      TreeNode localTreeNode1 = TreeNode.make("field");
      localTreeNode1.setAttribute("name", str1);
      localTreeNode1.setAttribute("uiName", str1);
      String str3 = DbMetaDataUtils.getLocalType(localTreeNode3.attribute("DATA_TYPE").intValue(12));
      localTreeNode1.makeChild("type").setValue(str3);
      String str4 = DbMetaDataUtils.fixBoolType(localTreeNode3.attribute("IS_NULLABLE").stripedStringValue());
      localTreeNode1.makeChild("nullable").setValue(str4);
      localTreeNode1.makeChild("maxLength").setValue(localTreeNode3.attribute("COLUMN_SIZE"));
      String str2 = localTreeNode3.attribute("COLUMN_DEF").stripedStringValue();
      if (str2 != null) {
        localTreeNode1.makeChild("defaultValue").setValue(str2);
      }
      if (str1.equals(paramString))
      {
        localTreeNode1.makeChild("visible").setValue("false");
        localTreeNode1.makeChild("isPrimaryKey").setValue("true");
      }
      else
      {
        localTreeNode1.makeChild("visible").setValue("true");
        localTreeNode1.makeChild("isPrimaryKey").setValue("false");
      }
      if (paramList.contains(str1)) {
        localTreeNode1.makeChild("unique").setValue("true");
      } else {
        localTreeNode1.makeChild("unique").setValue("false");
      }
      localTreeNode2.appendChild(localTreeNode1);
    }
    return localTreeNode2;
  }
  
  TreeNode C()
  {
    TreeNode localTreeNode = TreeNode.make("db");
    localTreeNode.makeChild("schema").setValue(this.C.attribute("TABLE_SCHEM"));
    localTreeNode.makeChild("table").setValue(this.B);
    localTreeNode.makeChild("engine").setValue(this.A);
    localTreeNode.makeChild("idMapTable").setValue("id_map");
    localTreeNode.makeChild("idMapName").setValue(this.B);
    return localTreeNode;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\DbMetaDataToNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */