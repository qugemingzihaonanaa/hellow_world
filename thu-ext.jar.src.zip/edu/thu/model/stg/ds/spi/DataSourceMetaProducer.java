package edu.thu.model.stg.ds.spi;

import edu.thu.cache.ICacheManagement;
import edu.thu.cache.ResourceCacheLoader;
import edu.thu.core.IResource;
import edu.thu.core.IResourceObjectParser;
import edu.thu.global.IProducer;
import edu.thu.java.DefaultRuntime;
import edu.thu.model.stg.ds.DataSourceMeta;
import edu.thu.model.stg.ds.spi.cp.DsMetaXParserFactory;
import edu.thu.model.stg.ds.spi.cp.IDsMetaXParser;

public class DataSourceMetaProducer
  implements IProducer, ICacheManagement<String>, IResourceObjectParser<DataSourceMeta>
{
  static final int part = new DefaultRuntime().init();
  ResourceCacheLoader<DataSourceMeta> loader = new ResourceCacheLoader("ds.meta.", this);
  
  public void removeCacheItem(String paramString)
  {
    this.loader.removeCacheItem(paramString);
    if (!paramString.startsWith("/_config/ds/")) {
      this.loader.removeCacheItem("/_config/ds/" + paramString);
    }
  }
  
  public void clearCache()
  {
    this.loader.clearCache();
  }
  
  public DataSourceMeta parseFromResource(IResource paramIResource, boolean paramBoolean)
  {
    DataSourceMeta localDataSourceMeta = (DataSourceMeta)DsMetaXParserFactory.newParser().parseFromResource(paramIResource, paramBoolean);
    if (localDataSourceMeta != null) {
      if (paramIResource.getStdPath().startsWith("/_config/ds/")) {
        localDataSourceMeta.setMetaName(paramIResource.getStdPath().substring("/_config/ds/".length()));
      } else {
        localDataSourceMeta.setMetaName(paramIResource.getStdPath());
      }
    }
    return localDataSourceMeta;
  }
  
  public Object getInstance(String paramString, Object paramObject)
  {
    if (paramString == null) {
      return null;
    }
    String str = paramString;
    if (paramString.startsWith("/_config/ds/"))
    {
      str = paramString;
      paramString = paramString.substring("/_config/ds/".length());
    }
    else if (paramString.indexOf("/_config/") < 0)
    {
      str = "/_config/ds/" + paramString;
    }
    DataSourceMeta localDataSourceMeta = (DataSourceMeta)this.loader.getObject(str);
    return localDataSourceMeta;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\DataSourceMetaProducer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */