package edu.thu.model.stg.ds.spi;

import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IVariant;
import edu.thu.lang.Variant;
import edu.thu.model.tree.TreeNode;
import java.io.Serializable;

public class TreeMeta
  implements DsConstants, Serializable
{
  private static final long serialVersionUID = 3177851844323033225L;
  boolean O;
  String M;
  String S;
  String P;
  char I = '.';
  String R;
  String Q;
  String J;
  String L;
  int N;
  boolean K;
  
  public TreeMeta(TreeNode paramTreeNode)
  {
    this.O = paramTreeNode.attribute("dynamicLoad").booleanValue(false);
    this.M = paramTreeNode.makeChild("layerCodeField").stripedStringValue();
    if (this.M == null) {
      throw Exceptions.code("tree.CAN_err_no_layer_code_field");
    }
    this.S = paramTreeNode.makeChild("layerLevelField").stripedStringValue();
    this.P = paramTreeNode.makeChild("parentIdField").stripedStringValue();
    String str = paramTreeNode.makeChild("layerCodeSeparator").stripedStringValue();
    this.I = Variant.valueOf(str).charValue('.');
    this.R = paramTreeNode.makeChild("supportInstanceField").stripedStringValue();
    this.Q = paramTreeNode.makeChild("childrenField").stripedStringValue();
    this.J = paramTreeNode.makeChild("isLeafField").stripedStringValue();
    this.L = paramTreeNode.makeChild("labelField").stripedStringValue();
    this.N = paramTreeNode.attribute("rootLayerLevel").intValue(0);
    this.K = paramTreeNode.makeChild("supportTreeEdit").booleanValue(false);
  }
  
  public void internText()
  {
    if (this.M != null) {
      this.M = this.M.intern();
    }
    if (this.S != null) {
      this.S = this.S.intern();
    }
    if (this.P != null) {
      this.P = this.P.intern();
    }
    if (this.R != null) {
      this.R = this.R.intern();
    }
    if (this.Q != null) {
      this.Q = this.Q.intern();
    }
    if (this.J != null) {
      this.J = this.J.intern();
    }
    if (this.L != null) {
      this.L = this.L.intern();
    }
  }
  
  public boolean isSupportTreeEdit()
  {
    return this.K;
  }
  
  public int getRootLayerLevel()
  {
    return this.N;
  }
  
  public String getLabelField()
  {
    return this.L;
  }
  
  public void setLabelField(String paramString)
  {
    this.L = paramString;
  }
  
  public boolean isDynamicLoad()
  {
    return this.O;
  }
  
  public String getChildrenField()
  {
    return this.Q;
  }
  
  public String getIsLeafField()
  {
    return this.J;
  }
  
  public String getSupportInstanceField()
  {
    return this.R;
  }
  
  public String getLayerCodeField()
  {
    return this.M;
  }
  
  public char getLayerCodeSeparator()
  {
    return this.I;
  }
  
  public String getLayerLevelField()
  {
    return this.S;
  }
  
  public String getParentIdField()
  {
    return this.P;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\TreeMeta.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */