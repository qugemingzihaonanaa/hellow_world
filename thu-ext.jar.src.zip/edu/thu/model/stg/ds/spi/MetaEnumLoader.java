package edu.thu.model.stg.ds.spi;

import edu.thu.app.sys.WxEnumHandler;
import edu.thu.app.sys.com.WxEnum;
import edu.thu.cache.GlobalCacheRegistry;
import edu.thu.config.AppConfig;
import edu.thu.db.SQL;
import edu.thu.db.SqlBuilder;
import edu.thu.global.IProducer;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IVariant;
import edu.thu.lang.Variant;
import edu.thu.lang.exceptions.StdException;
import edu.thu.lang.util.ITplReference;
import edu.thu.lang.util.TplC;
import edu.thu.model.stg.ds.DataSourceLoader;
import edu.thu.model.stg.ds.DataSourceMeta;
import edu.thu.model.stg.ds.EnumLoader;
import edu.thu.model.stg.ds.IEnumInfo;
import edu.thu.model.stg.ds.OrderBy;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceContext;
import edu.thu.service.SystemServiceContext;
import edu.thu.service.util.ContextHelper;
import edu.thu.util.StringUtils;
import edu.thu.util.ThreadLocalVars;
import java.util.HashMap;
import java.util.Map;

public class MetaEnumLoader
  implements IProducer, DsConstants
{
  String dataPath = "/_config/enum/";
  
  public String getDataPath()
  {
    return this.dataPath;
  }
  
  public void setDataPath(String paramString)
  {
    this.dataPath = paramString;
  }
  
  public static IProducer register(String paramString)
  {
    MetaEnumLoader localMetaEnumLoader = new MetaEnumLoader();
    B localB = new B("meta_enum_cache", localMetaEnumLoader);
    GlobalCacheRegistry.getInstance().register(localB);
    EnumLoader.setEnumLoader(localB);
    EnumLoader.registerForExpr();
    return localB;
  }
  
  public Object getInstance(String paramString, Object paramObject)
  {
    Object localObject = null;
    if (Variant.valueOf(AppConfig.getVar("enum.use_request_cache")).booleanValue(true))
    {
      localObject = ThreadLocalVars.getVar("enum:" + paramString);
      if (localObject != null) {
        return localObject;
      }
    }
    localObject = _getInstance(paramString, paramObject);
    if (localObject != null)
    {
      if ((localObject instanceof AbstractEnumInfo)) {
        ((AbstractEnumInfo)localObject).setCacheListKey("enumList:" + paramString);
      }
      ThreadLocalVars.setVar("enum:" + paramString, localObject);
    }
    return localObject;
  }
  
  Object _getInstance(String paramString, Object paramObject)
  {
    if (paramString == null) {
      throw Exceptions.code("ds.CAN_err_null_enum_name");
    }
    Object localObject2;
    if (paramString.startsWith("dao:"))
    {
      localObject1 = StringUtils.strip(paramString.substring("dao:".length()));
      localObject2 = (DataSourceMetaImpl)DataSourceMeta.load("orm/" + ((String)localObject1).replace('.', '/') + ".meta.xml", (IServiceContext)paramObject);
      if (localObject2 == null)
      {
        localObject2 = (DataSourceMetaImpl)DataSourceMeta.load("orm/" + (String)localObject1 + ".xml", (IServiceContext)paramObject);
        if (localObject2 == null) {
          throw Exceptions.code("ds.CAN_err_missing_entity_meta").param(localObject1);
        }
      }
      DaoEnumInfo localDaoEnumInfo = new DaoEnumInfo((String)localObject1, ((DataSourceMetaImpl)localObject2).getPkField(), ((DataSourceMetaImpl)localObject2).getNameField(), ((DataSourceMetaImpl)localObject2).getCodeField(), ((DataSourceMetaImpl)localObject2).getTipField(), ((DataSourceMetaImpl)localObject2).getOrderBy());
      appendFilter(localDaoEnumInfo, (DataSourceMetaImpl)localObject2);
      return localDaoEnumInfo;
    }
    if (paramString.startsWith("wx:"))
    {
      localObject1 = StringUtils.strip(paramString.substring("wx:".length()));
      localObject2 = WxEnumHandler.getInstance().getEnumByName((String)localObject1);
      return new WxEnumInfo((WxEnum)localObject2);
    }
    Object localObject1 = _loadEnum(paramString, paramObject);
    if (localObject1 == null) {
      return null;
    }
    ((TreeNode)localObject1).setAttribute("src", paramString);
    return _transform((TreeNode)localObject1, paramObject);
  }
  
  void appendFilter(DaoEnumInfo paramDaoEnumInfo, DataSourceMetaImpl paramDataSourceMetaImpl)
  {
    Object localObject1 = null;
    Object localObject2;
    Object localObject3;
    if (paramDataSourceMetaImpl.getActiveFlagField() != null)
    {
      localObject2 = paramDataSourceMetaImpl.getValidFieldMeta(paramDataSourceMetaImpl.getActiveFlagField());
      localObject3 = TreeNode.make("eq");
      ((TreeNode)localObject3).setAttribute("name", ((FieldMeta)localObject2).getName());
      ((TreeNode)localObject3).setAttribute("value", "Y");
      if (((FieldMeta)localObject2).isNullable())
      {
        localObject1 = TreeNode.make("or");
        TreeNode localTreeNode = TreeNode.make("eq");
        localTreeNode.setAttribute("name", ((FieldMeta)localObject2).getName());
        localTreeNode.setValue(null);
        ((TreeNode)localObject1).appendChild((TreeNode)localObject3);
        ((TreeNode)localObject1).appendChild(localTreeNode);
      }
      else
      {
        localObject1 = localObject3;
      }
    }
    if (localObject1 != null)
    {
      localObject2 = new TplC();
      ((TplC)localObject2).setNodeMode(true);
      localObject3 = ((TplC)localObject2).compileNode((TreeNode)localObject1, SystemServiceContext.getInstance());
      paramDaoEnumInfo.setFilter((ITplReference)localObject3);
    }
  }
  
  TreeNode _loadEnum(String paramString, Object paramObject)
  {
    String str = this.dataPath + paramString;
    return ContextHelper.loadCustomizableXml(str);
  }
  
  protected IEnumInfo _transform(TreeNode paramTreeNode, Object paramObject)
  {
    if (paramTreeNode == null) {
      return null;
    }
    boolean bool1 = paramTreeNode.attribute("cacheable").booleanValue(false);
    String str1 = paramTreeNode.attribute("type").stripedStringValue();
    Object localObject2;
    Object localObject3;
    Object localObject4;
    Object localObject5;
    Object localObject6;
    Object localObject7;
    Object localObject8;
    Object localObject9;
    Object localObject10;
    Object localObject1;
    if ("db".equals(str1))
    {
      localObject2 = paramTreeNode.existingChild("sql");
      localObject3 = null;
      localObject4 = null;
      if (localObject2 == null)
      {
        localObject5 = paramTreeNode.makeChild("valueField").stripedStringValue("value");
        localObject6 = paramTreeNode.makeChild("idField").stripedStringValue("id");
        localObject7 = paramTreeNode.makeChild("codeField").stripedStringValue((String)localObject6);
        localObject8 = paramTreeNode.makeChild("tipField").stripedStringValue();
        localObject9 = paramTreeNode.makeChild("table").stripedStringValue();
        if (localObject9 == null) {
          throw Exceptions.code("ds.CAN_err_db_enum_no_sql").param(paramTreeNode);
        }
        localObject10 = paramTreeNode.makeChild("orderField").stripedStringValue((String)localObject5);
        String str2 = paramTreeNode.makeChild("defaultOrder").stripedStringValue("asc");
        boolean bool2 = ("asc".equals(str2)) || ("true".equals(str2));
        localObject3 = SQL.begin().select().field((String)localObject6).switchOpen(!((String)localObject6).equals("id")).as("id").switchClose().comma().field((String)localObject5).as("enumValue").switchOpen(localObject7 != localObject6).comma().field((String)localObject7).as("code").switchClose().switchOpen(localObject8 != null).comma().field((String)localObject8).as("tip").switchClose().from().table((String)localObject9).orderby().field((String)localObject10).asc(bool2).end();
        localObject4 = SQL.begin().select().field((String)localObject6).switchOpen(!((String)localObject6).equals("id")).as("id").switchClose().comma().field((String)localObject5).as("enumValue").switchOpen(localObject7 != localObject6).comma().field((String)localObject7).as("code").switchClose().switchOpen(localObject8 != null).comma().field((String)localObject8).as("tip").switchClose().from().table((String)localObject9).where().eq((String)localObject6, "").end();
      }
      else
      {
        localObject5 = new HashMap();
        ((Map)localObject5).put("$context", paramObject);
        localObject6 = new TplC();
        localObject7 = ((TplC)localObject6).compileBody((TreeNode)localObject2, null, SystemServiceContext.getInstance());
        localObject3 = TplC.runForSql((ITplReference)localObject7, (Map)localObject5, (IServiceContext)paramObject);
      }
      localObject5 = paramTreeNode.makeChild("engine").stripedStringValue("default");
      localObject1 = new SqlEnumInfo((SQL)localObject3, (SQL)localObject4, (String)localObject5);
    }
    else
    {
      if ("dataSource".equals(str1))
      {
        localObject2 = paramTreeNode.makeChild("valueField").stripedStringValue("value");
        localObject3 = paramTreeNode.makeChild("idField").stripedStringValue("id");
        localObject4 = paramTreeNode.makeChild("dataSource").stripedStringValue();
        if (localObject4 == null) {
          throw Exceptions.code("ds.CAN_err_null_enum_datasource");
        }
        localObject5 = DataSourceLoader.loadDataSource((String)localObject4, paramObject);
        if (localObject5 == null) {
          throw Exceptions.code("ds.CAN_err_missing_datasource").param(localObject4);
        }
        throw new StdException("ds.CAN_err_deprecated_dataSource_enum").param(localObject4).param(paramTreeNode);
      }
      if ("dao".equals(str1))
      {
        localObject2 = paramTreeNode.makeChild("valueField").stripedStringValue();
        localObject3 = paramTreeNode.makeChild("idField").stripedStringValue((String)localObject2);
        if (localObject2 == null) {
          throw Exceptions.code("ds.CAN_err_enum_no_valueField").param(paramTreeNode);
        }
        localObject4 = paramTreeNode.makeChild("codeField").stripedStringValue();
        localObject5 = paramTreeNode.childValue("tipField").stripedStringValue();
        localObject6 = OrderBy.parse(paramTreeNode);
        localObject7 = paramTreeNode.makeChild("entityName").stripedStringValue();
        if (localObject7 == null) {
          throw Exceptions.code("ds.CAN_err_null_enum_entity").param(paramTreeNode);
        }
        localObject1 = new DaoEnumInfo((String)localObject7, (String)localObject3, (String)localObject2, (String)localObject4, (String)localObject5, (OrderBy)localObject6);
        localObject8 = paramTreeNode.existingChild("filter");
        if (localObject8 != null)
        {
          ((TreeNode)localObject8).setAttribute("tpl:tag", "and");
          localObject9 = new TplC();
          ((TplC)localObject9).setNodeMode(true);
          localObject10 = ((TplC)localObject9).compileNode((TreeNode)localObject8, SystemServiceContext.getInstance());
          ((DaoEnumInfo)localObject1).setFilter((ITplReference)localObject10);
        }
      }
      else
      {
        localObject1 = new EnumInfo(paramTreeNode);
        bool1 = AppConfig.isUseCache("enum.");
      }
    }
    if (bool1) {
      localObject1 = new CacheEnumInfo((IEnumInfo)localObject1);
    }
    return (IEnumInfo)localObject1;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\MetaEnumLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */