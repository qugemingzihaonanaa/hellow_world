package edu.thu.model.stg.ds.spi.db;

import edu.thu.db.TransactionMode;
import edu.thu.model.data.IHaveMeta;
import edu.thu.model.data.table.IRowSet;
import edu.thu.model.stg.ds.IDataProvider;
import edu.thu.model.stg.ds.IRecordProcessor;
import edu.thu.model.stg.view.IPageViewer;
import edu.thu.model.tree.TreeNode;
import edu.thu.search.IPreparedQuery;
import edu.thu.search.IQuery;
import edu.thu.service.ICancelMonitor;
import edu.thu.service.IServiceContext;
import edu.thu.service.txn.DbTransactionSupport;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public class DynamicTable
  extends DbTransactionSupport
  implements IHaveMeta, IDataProvider
{
  DynamicTableMeta dtMeta;
  boolean readOnly = false;
  
  protected Object createThis(TransactionMode paramTransactionMode)
  {
    return null;
  }
  
  public TreeNode getMeta()
  {
    return this.dtMeta.toNode();
  }
  
  public List getBaseFields()
  {
    return this.dtMeta.getBaseFields();
  }
  
  public List getExtFields()
  {
    return this.dtMeta.getExtFields();
  }
  
  public void addColumn(TreeNode paramTreeNode) {}
  
  public void removeColumn(String paramString) {}
  
  public void drop() {}
  
  public void truncate() {}
  
  public boolean isReadOnly()
  {
    return this.readOnly;
  }
  
  public void setReadOnly(boolean paramBoolean)
  {
    this.readOnly = paramBoolean;
  }
  
  public Object add(Map paramMap, Object paramObject)
  {
    return null;
  }
  
  public void addMany(Collection paramCollection, Object paramObject) {}
  
  public void clear(Object paramObject) {}
  
  public int remove(IQuery paramIQuery, Object paramObject)
  {
    return 0;
  }
  
  public int update(Map paramMap, IQuery paramIQuery, Object paramObject)
  {
    return 0;
  }
  
  public boolean exists(IQuery paramIQuery, ICancelMonitor paramICancelMonitor)
  {
    return false;
  }
  
  public IPageViewer findMany(Object paramObject, IQuery paramIQuery, ICancelMonitor paramICancelMonitor)
  {
    return null;
  }
  
  public Object findOne(Object paramObject, IQuery paramIQuery, ICancelMonitor paramICancelMonitor)
  {
    return null;
  }
  
  public IPreparedQuery parseQuery(Object paramObject, IQuery paramIQuery)
  {
    return null;
  }
  
  public boolean isParameterizable()
  {
    return false;
  }
  
  public Object parameterize(Map paramMap)
  {
    return this;
  }
  
  public void process(IQuery paramIQuery, IRecordProcessor paramIRecordProcessor, IServiceContext paramIServiceContext) {}
  
  public IRowSet selectForUpdate(IQuery paramIQuery)
  {
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\db\DynamicTable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */