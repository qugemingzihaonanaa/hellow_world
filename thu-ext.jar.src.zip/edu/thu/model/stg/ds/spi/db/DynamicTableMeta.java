package edu.thu.model.stg.ds.spi.db;

import edu.thu.model.tree.IXObject;
import edu.thu.model.tree.TreeNode;
import java.util.List;

public class DynamicTableMeta
  implements IXObject
{
  TreeNode metaNode;
  List baseFields;
  List extFields;
  
  public TreeNode toNode()
  {
    return this.metaNode;
  }
  
  public List getBaseFields()
  {
    return this.baseFields;
  }
  
  public List getExtFields()
  {
    return this.extFields;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\db\DynamicTableMeta.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */