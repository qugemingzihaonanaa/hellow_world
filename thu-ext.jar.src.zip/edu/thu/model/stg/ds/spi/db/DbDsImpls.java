package edu.thu.model.stg.ds.spi.db;

import edu.thu.db.SQL;
import edu.thu.db.SqlBuilder;
import edu.thu.db.TransactionMode;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.model.data.table.IRowVisitor;
import edu.thu.model.data.table.ITableVisitor;
import edu.thu.model.stg.view.IPageViewer;
import edu.thu.model.tree.TreeNode;
import edu.thu.search.IConditionQuery;
import edu.thu.search.IFieldQuery;
import edu.thu.search.IPrimaryKeyQuery;
import edu.thu.search.IQuery;
import edu.thu.search.spi.QueryImpls;
import java.util.List;

public class DbDsImpls
{
  public static void queryToSelectCondition(SqlBuilder paramSqlBuilder, IQuery paramIQuery, DbTableMeta paramDbTableMeta)
  {
    if (paramIQuery == null) {
      return;
    }
    paramSqlBuilder.where().field(paramDbTableMeta.getDbPkField()).in().lb().select().field(paramDbTableMeta.getDbPkField()).from().table(paramDbTableMeta.getViewSql());
    queryToCondition(paramSqlBuilder, paramIQuery, paramDbTableMeta, false);
    paramSqlBuilder.rb();
  }
  
  public static SQL buildSelectCondition(IQuery paramIQuery, DbTableMeta paramDbTableMeta)
  {
    SqlBuilder localSqlBuilder = SQL.begin().select().field(paramDbTableMeta.getDbPkField()).from().table(paramDbTableMeta.getViewSql());
    queryToCondition(localSqlBuilder, paramIQuery, paramDbTableMeta, false);
    return localSqlBuilder.end();
  }
  
  public static void queryToCondition(SqlBuilder paramSqlBuilder, IQuery paramIQuery, DbTableMeta paramDbTableMeta, boolean paramBoolean)
  {
    Object localObject;
    if ((paramIQuery instanceof IPrimaryKeyQuery))
    {
      localObject = ((IPrimaryKeyQuery)paramIQuery).getPkValue();
      paramSqlBuilder.where().eq(paramDbTableMeta.getDbPkField(), localObject);
    }
    else if ((paramIQuery instanceof IFieldQuery))
    {
      localObject = (IFieldQuery)paramIQuery;
      if (paramBoolean)
      {
        QueryImpls.conditionToSql(paramSqlBuilder, ((IFieldQuery)localObject).getCondition());
      }
      else
      {
        QueryImpls.buildWhere(paramSqlBuilder, ((IFieldQuery)localObject).getCondition());
        QueryImpls.buildGroupBy(paramSqlBuilder, ((IFieldQuery)localObject).getCondition());
      }
    }
    else
    {
      throw Exceptions.code("ds.CAN_err_unknown_query_type").param(paramIQuery);
    }
  }
  
  public static boolean useOrderBy(IQuery paramIQuery)
  {
    IConditionQuery localIConditionQuery = (IConditionQuery)paramIQuery;
    TreeNode localTreeNode1 = localIConditionQuery.getCondition();
    if (localTreeNode1 == null) {
      return false;
    }
    TreeNode localTreeNode2 = localTreeNode1.existingChild("orderBy");
    return (localTreeNode2 != null) && (localTreeNode2.getChildCount() > 0);
  }
  
  public static SQL queryToCountSql(IQuery paramIQuery, DbTableMeta paramDbTableMeta)
  {
    if (paramIQuery == null) {
      return SQL.begin().countAll().from().table(paramDbTableMeta.getViewSql()).end();
    }
    SqlBuilder localSqlBuilder = SQL.begin().select();
    int i = 0;
    if ((paramIQuery instanceof IFieldQuery))
    {
      IFieldQuery localIFieldQuery = (IFieldQuery)paramIQuery;
      if (localIFieldQuery.onlyQueryDistinct()) {
        i = 1;
      }
      localSqlBuilder.countAll();
      if (i != 0)
      {
        localSqlBuilder.from().lb();
        List localList = localIFieldQuery.getFields();
        if ((localList == null) || (localList.isEmpty())) {
          localSqlBuilder.field(paramDbTableMeta.getDbPkField());
        } else {
          localSqlBuilder.fields(localList);
        }
      }
    }
    else
    {
      localSqlBuilder.countAll();
    }
    localSqlBuilder.from().table(paramDbTableMeta.getViewSql());
    queryToCondition(localSqlBuilder, paramIQuery, paramDbTableMeta, false);
    if (i != 0) {
      localSqlBuilder.rb();
    }
    return localSqlBuilder.end();
  }
  
  public static SQL queryToSelectSql(IQuery paramIQuery, DbTableMeta paramDbTableMeta)
  {
    if (paramIQuery == null) {
      return SQL.begin().select().field(paramDbTableMeta.getDbPkField()).from().table(paramDbTableMeta.getViewSql()).end();
    }
    SqlBuilder localSqlBuilder = SQL.begin().select();
    if ((paramIQuery instanceof IFieldQuery))
    {
      IFieldQuery localIFieldQuery = (IFieldQuery)paramIQuery;
      if (localIFieldQuery.onlyQueryDistinct()) {
        localSqlBuilder.distinct();
      }
      List localList = localIFieldQuery.getFields();
      if ((localList == null) || (localList.isEmpty())) {
        localSqlBuilder.field(paramDbTableMeta.getDbPkField());
      } else {
        localSqlBuilder.fields(localList);
      }
    }
    else
    {
      localSqlBuilder.field(paramDbTableMeta.getDbPkField());
    }
    localSqlBuilder.from().table(paramDbTableMeta.getViewSql());
    queryToCondition(localSqlBuilder, paramIQuery, paramDbTableMeta, true);
    return localSqlBuilder.end();
  }
  
  public static IPageViewer findMany(TransactionMode paramTransactionMode, Object paramObject, SQL paramSQL1, SQL paramSQL2, boolean paramBoolean)
  {
    if ((paramObject instanceof IRowVisitor))
    {
      IRowVisitor localIRowVisitor = (IRowVisitor)paramObject;
      return null;
    }
    throw Exceptions.code("ds.CAN_err_invalid_result_type_for_many").param(paramObject);
  }
  
  public static Object findOne(TransactionMode paramTransactionMode, Object paramObject, SQL paramSQL)
  {
    Object localObject;
    if ((paramObject instanceof ITableVisitor))
    {
      localObject = (ITableVisitor)paramObject;
      return null;
    }
    if ((paramObject instanceof IRowVisitor))
    {
      localObject = (IRowVisitor)paramObject;
      return null;
    }
    throw Exceptions.code("ds.CAN_err_invalid_result_type_for_one").param(paramObject);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\db\DbDsImpls.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */