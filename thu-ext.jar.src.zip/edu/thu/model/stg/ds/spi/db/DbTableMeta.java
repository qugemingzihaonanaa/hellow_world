package edu.thu.model.stg.ds.spi.db;

import edu.thu.config.loader.util.ConfigLoadUtils;
import edu.thu.db.util.DbIdGenerator;
import edu.thu.global.Debug;
import edu.thu.global.IUniqueIdGenerator;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.model.stg.ds.spi.DsMetaImpls;
import edu.thu.model.tree.TreeNode;

public class DbTableMeta
  implements DbDsConstants
{
  String D;
  String C;
  String E;
  String B;
  String A;
  IUniqueIdGenerator F;
  
  public DbTableMeta() {}
  
  public DbTableMeta(TreeNode paramTreeNode)
  {
    this.A = paramTreeNode.makeChild("engine").stripedStringValue("default");
    this.C = paramTreeNode.makeChild("table").stripedStringValue();
    this.E = paramTreeNode.makeChild("view").stripedStringValue(this.C);
    String str1 = paramTreeNode.makeChild("sql").stripedStringValue();
    if ((this.C == null) && (this.E == null) && (str1 == null)) {
      throw Exceptions.code("ds.CAN_err_no_table_or_view_arg").param(paramTreeNode);
    }
    if (str1 != null) {
      this.B = ("(" + str1 + ")");
    } else {
      this.B = this.E;
    }
    this.D = paramTreeNode.makeChild("dbPkField").stripedStringValue();
    TreeNode localTreeNode = paramTreeNode.existingChild("idGenerator");
    if (localTreeNode != null) {
      this.F = ((IUniqueIdGenerator)ConfigLoadUtils.loadObjectByType(localTreeNode, IUniqueIdGenerator.class, null));
    }
    if ((this.F == null) && (this.C != null))
    {
      String str2 = paramTreeNode.makeChild("idMapTable").stripedStringValue();
      String str3 = paramTreeNode.makeChild("idObject").stripedStringValue(this.C);
      if (str3 == null) {
        throw Exceptions.code("ds.CAN_err_no_id_map_name").param(paramTreeNode);
      }
      this.F = new DbIdGenerator(this.A, str2, str3);
    }
  }
  
  public void bindMeta(TreeNode paramTreeNode)
  {
    this.D = DsMetaImpls.getBasePkField(paramTreeNode);
    if ((this.D == null) && (!this.C.equals(this.E))) {
      Debug.traceErr("ds.CAN_err_no_pk_field::" + paramTreeNode);
    }
  }
  
  public String getDbPkField()
  {
    Debug.check(this.D, "ds.CAN_err_no_pk_field");
    return this.D;
  }
  
  public void setDbPkField(String paramString)
  {
    this.D = paramString;
  }
  
  public String getDbEngineName()
  {
    return this.A;
  }
  
  public void setDbEngineName(String paramString)
  {
    this.A = paramString;
  }
  
  public IUniqueIdGenerator getIdGenerator()
  {
    return this.F;
  }
  
  public void setIdGenerator(IUniqueIdGenerator paramIUniqueIdGenerator)
  {
    this.F = paramIUniqueIdGenerator;
  }
  
  public Object generateId()
  {
    return this.F.generateId(this.C);
  }
  
  public String getTableName()
  {
    return this.C;
  }
  
  public void setTableName(String paramString)
  {
    this.C = paramString;
  }
  
  public String getViewName()
  {
    return this.E;
  }
  
  public void setViewName(String paramString)
  {
    this.E = paramString;
  }
  
  public String getViewSql()
  {
    if (this.B == null) {
      return getViewName();
    }
    return this.B;
  }
  
  public void setViewSql(String paramString)
  {
    this.B = paramString;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\db\DbTableMeta.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */