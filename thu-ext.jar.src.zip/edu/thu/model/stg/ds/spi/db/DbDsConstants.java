package edu.thu.model.stg.ds.spi.db;

public abstract interface DbDsConstants
{
  public static final String DB_PK_FIELD_NAME = "dbPkField";
  public static final String TABLE_NAME = "table";
  public static final String VIEW_NAME = "view";
  public static final String SQL_NAME = "sql";
  public static final String ENGINE_NAME = "engine";
  public static final String DEFAULT_NAME = "default";
  public static final String ID_GENERATOR_NAME = "idGenerator";
  public static final String ID_MAP_TABLE_NAME = "idMapTable";
  public static final String ID_OBJECT_NAME = "idObject";
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\db\DbDsConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */