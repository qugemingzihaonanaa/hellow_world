package edu.thu.model.stg.ds.spi.db;

import edu.thu.db.SQL;
import edu.thu.db.TransactionMode;
import edu.thu.global.Debug;
import edu.thu.model.stg.view.IPageViewer;
import edu.thu.search.IPreparedQuery;
import edu.thu.service.ICancelMonitor;
import edu.thu.service.txn.DbTransactionSupport;

public class DbPreparedQuery
  extends DbTransactionSupport
  implements IPreparedQuery
{
  SQL sql;
  Object resultType;
  
  public DbPreparedQuery(TransactionMode paramTransactionMode, Object paramObject, SQL paramSQL)
  {
    Debug.check(paramSQL);
    this._db = paramTransactionMode;
    this.sql = paramSQL;
  }
  
  protected DbPreparedQuery(TransactionMode paramTransactionMode, DbPreparedQuery paramDbPreparedQuery)
  {
    this._db = paramTransactionMode;
    this.useTxnManager = paramDbPreparedQuery.useTxnManager;
    this.sql = paramDbPreparedQuery.sql;
    this.resultType = paramDbPreparedQuery.resultType;
  }
  
  protected Object createThis(TransactionMode paramTransactionMode)
  {
    return new DbPreparedQuery(paramTransactionMode, this);
  }
  
  protected SQL getSql(ICancelMonitor paramICancelMonitor)
  {
    if (paramICancelMonitor == null) {
      return this.sql;
    }
    return null;
  }
  
  public boolean exists(ICancelMonitor paramICancelMonitor)
  {
    return false;
  }
  
  public IPageViewer findMany(ICancelMonitor paramICancelMonitor)
  {
    return DbDsImpls.findMany(getTxnDb(), this.resultType, getSql(paramICancelMonitor), null, isUseTxnManager());
  }
  
  public Object findOne(ICancelMonitor paramICancelMonitor)
  {
    return DbDsImpls.findOne(getTxnDb(), this.resultType, getSql(paramICancelMonitor));
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\db\DbPreparedQuery.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */