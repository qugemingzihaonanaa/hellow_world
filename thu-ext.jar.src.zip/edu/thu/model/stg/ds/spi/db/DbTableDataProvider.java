package edu.thu.model.stg.ds.spi.db;

import edu.thu.config.IConfigInfo;
import edu.thu.config.IConfigurable;
import edu.thu.db.SQL;
import edu.thu.db.SqlBuilder;
import edu.thu.db.SqlQueryResult;
import edu.thu.db.TransactionMode;
import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.model.data.table.IRowSet;
import edu.thu.model.data.table.spi.SqlResultRowSet;
import edu.thu.model.stg.ds.IDataProvider;
import edu.thu.model.stg.ds.IRecordProcessor;
import edu.thu.model.stg.view.IPageViewer;
import edu.thu.model.tree.IXObject;
import edu.thu.model.tree.TreeNode;
import edu.thu.search.IFieldQuery;
import edu.thu.search.IPreparedQuery;
import edu.thu.search.IQuery;
import edu.thu.search.Query;
import edu.thu.search.spi.QueryImpls;
import edu.thu.service.ICancelMonitor;
import edu.thu.service.IServiceContext;
import edu.thu.service.txn.DbTransactionSupport;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class DbTableDataProvider
  extends DbTransactionSupport
  implements IDataProvider, IConfigurable
{
  DbTableMeta dbMeta;
  boolean readOnly = false;
  
  public DbTableDataProvider(DbTableMeta paramDbTableMeta)
  {
    Debug.check(paramDbTableMeta);
    this.dbMeta = paramDbTableMeta;
    this._db = new TransactionMode(paramDbTableMeta.getDbEngineName());
  }
  
  public DbTableDataProvider() {}
  
  public void setConfig(IConfigInfo paramIConfigInfo)
  {
    if (!(paramIConfigInfo instanceof IXObject)) {
      throw Exceptions.code("ds.CAN_err_unknown_config_type").param(paramIConfigInfo);
    }
    TreeNode localTreeNode = TreeNode.toNode(paramIConfigInfo);
    this.dbMeta = new DbTableMeta(localTreeNode);
    this._db = new TransactionMode(this.dbMeta.getDbEngineName());
  }
  
  protected DbTableDataProvider(TransactionMode paramTransactionMode, DbTableDataProvider paramDbTableDataProvider)
  {
    Debug.check(paramTransactionMode);
    this._db = paramTransactionMode;
    this.useTxnManager = paramDbTableDataProvider.useTxnManager;
    this.dbMeta = paramDbTableDataProvider.dbMeta;
    this.readOnly = paramDbTableDataProvider.readOnly;
  }
  
  protected Object createThis(TransactionMode paramTransactionMode)
  {
    return new DbTableDataProvider(paramTransactionMode, this);
  }
  
  public void bindMeta(TreeNode paramTreeNode)
  {
    this.dbMeta.bindMeta(paramTreeNode);
  }
  
  public boolean isReadOnly()
  {
    return this.readOnly;
  }
  
  public void setReadOnly(boolean paramBoolean)
  {
    this.readOnly = paramBoolean;
  }
  
  void checkNotReadOnly()
  {
    if (isReadOnly()) {
      throw Exceptions.notAllowed();
    }
  }
  
  String _add(TransactionMode paramTransactionMode, Map paramMap, Object paramObject)
  {
    Object localObject = paramMap.get(this.dbMeta.getDbPkField());
    if (localObject == null)
    {
      localObject = this.dbMeta.generateId();
      paramMap.put(this.dbMeta.getDbPkField(), localObject);
    }
    SQL.begin().insert().into(this.dbMeta.getTableName(), paramMap).end();
    return localObject.toString();
  }
  
  public Object add(Map paramMap, Object paramObject)
  {
    checkNotReadOnly();
    return _add(getTxnDb(), paramMap, paramObject);
  }
  
  /* Error */
  public void addMany(java.util.Collection paramCollection, Object paramObject)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 157	edu/thu/model/stg/ds/spi/db/DbTableDataProvider:checkNotReadOnly	()V
    //   4: aload_0
    //   5: invokevirtual 159	edu/thu/model/stg/ds/spi/db/DbTableDataProvider:getTxnDb	()Ledu/thu/db/TransactionMode;
    //   8: invokevirtual 167	edu/thu/db/TransactionMode:beginTransaction	()Ledu/thu/db/TransactionMode;
    //   11: astore_3
    //   12: iconst_0
    //   13: istore 4
    //   15: aload_1
    //   16: invokeinterface 170 1 0
    //   21: astore 5
    //   23: goto +24 -> 47
    //   26: aload 5
    //   28: invokeinterface 176 1 0
    //   33: checkcast 111	java/util/Map
    //   36: astore 6
    //   38: aload_0
    //   39: aload_3
    //   40: aload 6
    //   42: aload_2
    //   43: invokevirtual 163	edu/thu/model/stg/ds/spi/db/DbTableDataProvider:_add	(Ledu/thu/db/TransactionMode;Ljava/util/Map;Ljava/lang/Object;)Ljava/lang/String;
    //   46: pop
    //   47: aload 5
    //   49: invokeinterface 181 1 0
    //   54: ifne -28 -> 26
    //   57: iconst_1
    //   58: istore 4
    //   60: goto +14 -> 74
    //   63: astore 7
    //   65: aload_3
    //   66: iload 4
    //   68: invokevirtual 184	edu/thu/db/TransactionMode:endTransaction	(Z)V
    //   71: aload 7
    //   73: athrow
    //   74: aload_3
    //   75: iload 4
    //   77: invokevirtual 184	edu/thu/db/TransactionMode:endTransaction	(Z)V
    //   80: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	81	0	this	DbTableDataProvider
    //   0	81	1	paramCollection	java.util.Collection
    //   0	81	2	paramObject	Object
    //   11	64	3	localTransactionMode	TransactionMode
    //   13	63	4	bool	boolean
    //   21	27	5	localIterator	Iterator
    //   36	5	6	localMap	Map
    //   63	9	7	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   15	63	63	finally
  }
  
  public void clear(Object paramObject)
  {
    checkNotReadOnly();
  }
  
  public int remove(IQuery paramIQuery, Object paramObject)
  {
    checkNotReadOnly();
    if (this.dbMeta.getTableName().equals(this.dbMeta.getViewName()))
    {
      localSqlBuilder = SQL.begin().delete().from().table(this.dbMeta.getTableName());
      DbDsImpls.queryToCondition(localSqlBuilder, paramIQuery, this.dbMeta, false);
      return 0;
    }
    SqlBuilder localSqlBuilder = SQL.begin().delete().from().table(this.dbMeta.getTableName());
    DbDsImpls.queryToSelectCondition(localSqlBuilder, paramIQuery, this.dbMeta);
    return 0;
  }
  
  public int update(Map paramMap, IQuery paramIQuery, Object paramObject)
  {
    checkNotReadOnly();
    SqlBuilder localSqlBuilder = SQL.begin().update().table(this.dbMeta.getTableName()).set(paramMap);
    if (paramIQuery != null) {
      if (this.dbMeta.getTableName().equals(this.dbMeta.getViewName()))
      {
        DbDsImpls.queryToCondition(localSqlBuilder, paramIQuery, this.dbMeta, false);
      }
      else
      {
        SQL localSQL = DbDsImpls.buildSelectCondition(paramIQuery, this.dbMeta);
        localSqlBuilder.where().field(this.dbMeta.getDbPkField()).in().lb().exsql(localSQL).rb();
      }
    }
    return 0;
  }
  
  public void process(IQuery paramIQuery, IRecordProcessor paramIRecordProcessor, IServiceContext paramIServiceContext)
  {
    Debug.check(paramIQuery);
    Debug.check(paramIRecordProcessor);
    IFieldQuery localIFieldQuery = (IFieldQuery)paramIQuery;
    List localList = localIFieldQuery.getFields();
    TreeNode localTreeNode = localIFieldQuery.getCondition();
    SqlBuilder localSqlBuilder = SQL.begin();
    SQL localSQL = QueryImpls.queryToSql(localSqlBuilder, false, localList, localTreeNode, this.dbMeta.getTableName());
    TransactionMode localTransactionMode = getTxnDb();
    Object localObject1 = null;
    try
    {
      ResultSet localResultSet = ((SqlQueryResult)localObject1).resultSet();
      try
      {
        Object localObject2 = new HashMap();
        while (localResultSet.next())
        {
          ((Map)localObject2).clear();
          int j = localList.size();
          Object localObject3;
          for (int i = 0; i < j; i++)
          {
            localObject3 = localResultSet.getObject(i + 1);
            ((Map)localObject2).put(localList.get(i), localObject3);
          }
          localObject2 = paramIRecordProcessor.process(localTransactionMode, (Map)localObject2);
          if (localObject2 != null)
          {
            localObject3 = ((Map)localObject2).entrySet().iterator();
            while (((Iterator)localObject3).hasNext())
            {
              Map.Entry localEntry = (Map.Entry)((Iterator)localObject3).next();
              String str = (String)localEntry.getKey();
              int k = localList.indexOf(str);
              if (k < 0) {
                throw Exceptions.code("ds.CAN_err_invalid_process_field").param(str);
              }
              localResultSet.updateObject(k + 1, localEntry.getValue());
            }
            localResultSet.updateRow();
          }
        }
      }
      catch (SQLException localSQLException)
      {
        throw Exceptions.source(localSQLException);
      }
    }
    finally
    {
      ((SqlQueryResult)localObject1).close();
    }
    ((SqlQueryResult)localObject1).close();
  }
  
  public IRowSet selectForUpdate(IQuery paramIQuery)
  {
    SqlBuilder localSqlBuilder = SQL.begin();
    IFieldQuery localIFieldQuery = (IFieldQuery)paramIQuery;
    List localList = localIFieldQuery.getFields();
    TreeNode localTreeNode = localIFieldQuery.getCondition();
    SQL localSQL = QueryImpls.queryToSql(localSqlBuilder, false, localList, localTreeNode, this.dbMeta.getTableName());
    TransactionMode localTransactionMode = getTxnDb();
    boolean bool = ((Query)paramIQuery).isScrollable();
    localSQL.scrollable(bool).updatable(true);
    SqlQueryResult localSqlQueryResult = null;
    return new SqlResultRowSet(localSqlQueryResult);
  }
  
  public boolean exists(IQuery paramIQuery, ICancelMonitor paramICancelMonitor)
  {
    SQL localSQL = DbDsImpls.queryToSelectSql(paramIQuery, this.dbMeta);
    return false;
  }
  
  public IPageViewer findMany(Object paramObject, IQuery paramIQuery, ICancelMonitor paramICancelMonitor)
  {
    SQL localSQL1 = DbDsImpls.queryToSelectSql(paramIQuery, this.dbMeta);
    SQL localSQL2 = null;
    localSQL2 = DbDsImpls.queryToCountSql(paramIQuery, this.dbMeta);
    return DbDsImpls.findMany(getTxnDb(), paramObject, localSQL1, localSQL2, isUseTxnManager());
  }
  
  public Object findOne(Object paramObject, IQuery paramIQuery, ICancelMonitor paramICancelMonitor)
  {
    SQL localSQL = DbDsImpls.queryToSelectSql(paramIQuery, this.dbMeta);
    return DbDsImpls.findOne(getTxnDb(), paramObject, localSQL);
  }
  
  public IPreparedQuery parseQuery(Object paramObject, IQuery paramIQuery)
  {
    SQL localSQL = DbDsImpls.queryToSelectSql(paramIQuery, this.dbMeta);
    return new DbPreparedQuery(new TransactionMode(this._db.getDbEngineName()), paramObject, localSQL);
  }
  
  public boolean isParameterizable()
  {
    return false;
  }
  
  public Object parameterize(Map paramMap)
  {
    return this;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\db\DbTableDataProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */