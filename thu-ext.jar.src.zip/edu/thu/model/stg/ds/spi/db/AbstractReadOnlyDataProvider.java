package edu.thu.model.stg.ds.spi.db;

import edu.thu.global.exceptions.Exceptions;
import edu.thu.model.stg.ds.IDataProvider;
import edu.thu.model.stg.ds.IRecordProcessor;
import edu.thu.search.IQuery;
import edu.thu.service.txn.DbTransactionSupport;
import java.util.Map;

public abstract class AbstractReadOnlyDataProvider
  extends DbTransactionSupport
  implements IDataProvider
{
  public Object add(Map paramMap, Object paramObject)
  {
    throw Exceptions.notAllowed();
  }
  
  public void clear(Object paramObject)
  {
    throw Exceptions.notAllowed();
  }
  
  public int remove(IQuery paramIQuery, Object paramObject)
  {
    throw Exceptions.notAllowed();
  }
  
  public int update(Map paramMap, IQuery paramIQuery, Object paramObject)
  {
    throw Exceptions.notAllowed();
  }
  
  public void process(IQuery paramIQuery, IRecordProcessor paramIRecordProcessor, Object paramObject)
  {
    throw Exceptions.notAllowed();
  }
  
  public boolean isReadOnly()
  {
    return true;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\db\AbstractReadOnlyDataProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */