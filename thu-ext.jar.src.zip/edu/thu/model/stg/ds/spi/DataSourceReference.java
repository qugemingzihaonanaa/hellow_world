package edu.thu.model.stg.ds.spi;

import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.model.stg.ds.IDataSourceReference;
import edu.thu.model.tree.TreeNode;
import edu.thu.util.StringUtils;
import java.io.Serializable;
import java.util.List;

public class DataSourceReference
  extends DataSourceLocation
  implements IDataSourceReference, Serializable
{
  private static final long serialVersionUID = 4521818905798112262L;
  String localKey;
  List localFields;
  String foreignKey;
  List foreignFields;
  
  public DataSourceReference(TreeNode paramTreeNode)
  {
    super(paramTreeNode);
  }
  
  public DataSourceReference() {}
  
  public TreeNode toNode()
  {
    throw Exceptions.notAllowed();
  }
  
  public String getLocalKeyField()
  {
    return this.localKey;
  }
  
  public String getForeignKeyField()
  {
    return this.foreignKey;
  }
  
  public List getLocalFields()
  {
    return this.localFields;
  }
  
  public List getForeignFields()
  {
    return this.foreignFields;
  }
  
  public void init(TreeNode paramTreeNode)
  {
    super.init(paramTreeNode);
    if (paramTreeNode.hasChild())
    {
      this.localKey = paramTreeNode.makeChild("localKey").stripedStringValue();
      this.foreignKey = paramTreeNode.makeChild("foreignKey").stripedStringValue();
      this.localFields = StringUtils.stripedSplit(paramTreeNode.makeChild("localFields").stringValue(), ',');
      if ((this.localFields == null) || (this.localFields.size() <= 0)) {
        Debug.traceErr("ds.CAN_err_reference_no_refFields::" + paramTreeNode);
      } else if (this.localFields.indexOf(null) >= 0) {
        throw Exceptions.code("ds.CAN_err_reference_contains_null_ref_field").param(paramTreeNode);
      }
      String str = paramTreeNode.makeChild("foreignFields").stripedStringValue();
      if (str != null) {
        this.foreignFields = StringUtils.stripedSplit(str, ',');
      }
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\DataSourceReference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */