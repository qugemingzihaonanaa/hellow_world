package edu.thu.model.stg.ds.spi;

import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IVariant;
import edu.thu.model.stg.ds.DataSourceLoader;
import edu.thu.model.stg.ds.IDataSource;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceContext;
import java.io.Serializable;

public class DataSourceLocation
  implements DsConstants, Serializable
{
  private static final long serialVersionUID = -2353840790980788770L;
  String refName;
  String dsName;
  String mode;
  
  public DataSourceLocation(String paramString1, String paramString2, String paramString3)
  {
    Debug.check(paramString1);
    Debug.check(paramString2);
    Debug.check(paramString3);
    this.refName = paramString1;
    this.dsName = paramString2;
    this.mode = paramString3;
  }
  
  public DataSourceLocation(TreeNode paramTreeNode)
  {
    init(paramTreeNode);
  }
  
  public DataSourceLocation() {}
  
  public void init(TreeNode paramTreeNode)
  {
    this.refName = paramTreeNode.attribute("name").stripedStringValue();
    if (this.refName == null) {
      throw Exceptions.code("ds.CAN_err_ds_location_no_ref_name_arg").param(paramTreeNode);
    }
    this.dsName = paramTreeNode.attribute("src").stripedStringValue();
    if (this.dsName == null) {
      throw Exceptions.code("ds.CAN_err_ds_location_no_src_arg").param(paramTreeNode);
    }
    this.mode = paramTreeNode.attribute("mode").stripedStringValue();
  }
  
  public String getReferenceName()
  {
    return this.refName;
  }
  
  public String getRefDataSourceName()
  {
    return this.dsName;
  }
  
  public String getRefDataSourceMode()
  {
    return this.mode;
  }
  
  public IDataSource getRefDataSource(IServiceContext paramIServiceContext)
  {
    IDataSource localIDataSource = DataSourceLoader.loadDataSource(this.dsName, paramIServiceContext);
    if (localIDataSource == null) {
      return localIDataSource;
    }
    if (this.mode != null) {
      localIDataSource = (IDataSource)localIDataSource.switchToMode(this.mode);
    }
    return localIDataSource;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\DataSourceLocation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */