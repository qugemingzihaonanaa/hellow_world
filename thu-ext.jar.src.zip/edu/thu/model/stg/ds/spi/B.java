package edu.thu.model.stg.ds.spi;

import edu.thu.cache.INamedCacheManagement;
import edu.thu.global.IProducer;
import edu.thu.global.spi.CachedProducer;

class B
  extends CachedProducer
  implements INamedCacheManagement<String>
{
  String cacheName;
  
  public B(String paramString, IProducer paramIProducer)
  {
    super(paramIProducer);
    this.cacheName = paramString;
  }
  
  protected boolean isCacheable(Object paramObject)
  {
    return paramObject instanceof CacheEnumInfo;
  }
  
  public void clearCache()
  {
    clear();
  }
  
  public void removeCacheItem(String paramString)
  {
    remove(paramString);
  }
  
  public String getCacheName()
  {
    return this.cacheName;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\B.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */