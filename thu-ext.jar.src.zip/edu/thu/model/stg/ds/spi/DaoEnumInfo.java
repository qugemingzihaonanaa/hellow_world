package edu.thu.model.stg.ds.spi;

import edu.thu.app.sys.PartitionHandler;
import edu.thu.db.SQL;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.util.Coercions;
import edu.thu.lang.exceptions.StdException;
import edu.thu.lang.util.ITplReference;
import edu.thu.lang.util.TplC;
import edu.thu.model.stg.ds.EnumItem;
import edu.thu.model.stg.ds.OrderBy;
import edu.thu.model.stg.view.IPageViewer;
import edu.thu.model.tree.TreeNode;
import edu.thu.orm.dao.DaoProvider;
import edu.thu.orm.dao.IDaoProvider;
import edu.thu.orm.dao.IEntityDao;
import edu.thu.orm.dao.IOrmTemplate;
import edu.thu.search.Condition;
import edu.thu.search.Query;
import edu.thu.search.Query.ConditionSpec;
import edu.thu.service.ThreadServiceContext;
import java.util.List;

public class DaoEnumInfo
  extends AbstractEnumInfo
{
  private static final long serialVersionUID = -2936507487969789759L;
  String entityName;
  String idField;
  String valueField;
  String codeField;
  String tipField;
  OrderBy orderBy;
  ITplReference filter;
  
  public DaoEnumInfo(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, OrderBy paramOrderBy)
  {
    this.entityName = paramString1;
    this.idField = paramString2;
    this.valueField = paramString3;
    this.codeField = paramString4;
    this.orderBy = paramOrderBy;
    this.tipField = paramString5;
  }
  
  public boolean isUseCodeField()
  {
    return this.codeField != null;
  }
  
  public String getTipField()
  {
    return this.tipField;
  }
  
  public void setTipField(String paramString)
  {
    this.tipField = paramString;
  }
  
  public void setFilter(ITplReference paramITplReference)
  {
    this.filter = paramITplReference;
  }
  
  SQL getFilterSql(String paramString, Object paramObject, boolean paramBoolean)
  {
    IEntityDao localIEntityDao = getDao();
    Query.ConditionSpec localConditionSpec = Condition.begin();
    if (this.filter != null)
    {
      localObject = TplC.runForNode(this.filter, null, ThreadServiceContext.getCurrentContext());
      if (localObject != null) {
        localConditionSpec.append((TreeNode)localObject);
      }
    }
    if (paramString != null) {
      localConditionSpec.eq(paramString, paramObject);
    }
    if (DaoProvider.orm().hasPartitionId(this.entityName)) {
      localConditionSpec.eq("partitionId", PartitionHandler.getInstance().getCurrentPartition());
    }
    Object localObject = localConditionSpec.end();
    if (this.orderBy != null) {
      this.orderBy.appendTo((Query)localObject);
    }
    localIEntityDao.transformCondition(((Query)localObject).getCondition());
    SQL localSQL = localIEntityDao.buildConditionSql(((Query)localObject).getCondition());
    return localSQL;
  }
  
  protected List loadItems()
  {
    IEntityDao localIEntityDao = getDao();
    SQL localSQL = getFilterSql(null, null, true);
    List localList = localIEntityDao.list(localSQL).getAll();
    if (localList == null) {
      return null;
    }
    int i = (this.idField != null) && (!this.idField.equals("id")) && (!this.idField.equals(localIEntityDao.getIdentifierPropertyName())) ? 0 : 1;
    int k = localList.size();
    for (int j = 0; j < k; j++)
    {
      Object localObject1 = localList.get(j);
      Object localObject2 = i != 0 ? localIEntityDao.getEntityId(localObject1) : localIEntityDao.getPropertyValue(localObject1, this.idField);
      if (localObject2 == null) {
        throw Exceptions.code("ds.CAN_err_enum_null_id").param(this.entityName).param(localObject1);
      }
      Object localObject3 = localIEntityDao.getPropertyValue(localObject1, this.valueField);
      String str = this.codeField == null ? localObject2.toString() : Coercions.toString(localIEntityDao.getPropertyValue(localObject1, this.codeField), null);
      EnumItem localEnumItem = new EnumItem(localObject2.toString(), str, localObject3);
      localList.set(j, localEnumItem);
    }
    return localList;
  }
  
  IEntityDao getDao()
  {
    return DaoProvider.getInstance().dao(this.entityName);
  }
  
  public EnumItem getItem(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    IEntityDao localIEntityDao = getDao();
    int i = (this.idField != null) && (!this.idField.equals("id")) && (!this.idField.equals(localIEntityDao.getIdentifierPropertyName())) ? 0 : 1;
    Object localObject1 = i != 0 ? localIEntityDao.getEntity(paramString) : localIEntityDao.findFirst(getFilterSql(this.idField, paramString, false));
    if (localObject1 == null) {
      return null;
    }
    Object localObject2 = localIEntityDao.getPropertyValue(localObject1, this.valueField);
    String str = this.codeField == null ? paramString.toString() : Coercions.toString(localIEntityDao.getPropertyValue(localObject1, this.codeField), null);
    EnumItem localEnumItem = new EnumItem(paramString.toString(), str, localObject2);
    localEnumItem.setTip(getTip(localIEntityDao, localObject1));
    return localEnumItem;
  }
  
  String getTip(IEntityDao paramIEntityDao, Object paramObject)
  {
    if (this.tipField == null) {
      return null;
    }
    return Coercions.toString(paramIEntityDao.getPropertyValue(paramObject, this.tipField), null);
  }
  
  public EnumItem getItemByValue(Object paramObject)
  {
    IEntityDao localIEntityDao = getDao();
    int i = (this.idField != null) && (!this.idField.equals("id")) && (!this.idField.equals(localIEntityDao.getIdentifierPropertyName())) ? 0 : 1;
    Object localObject1 = localIEntityDao.findFirst(getFilterSql(this.valueField, paramObject, false));
    if (localObject1 == null) {
      return null;
    }
    Object localObject2 = i != 0 ? localIEntityDao.getEntityId(localObject1) : localIEntityDao.getPropertyValue(localObject1, this.idField);
    return new EnumItem(localObject2.toString(), localObject2.toString(), paramObject);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\DaoEnumInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */