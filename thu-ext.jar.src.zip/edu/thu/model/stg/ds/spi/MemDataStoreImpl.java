package edu.thu.model.stg.ds.spi;

import edu.thu.global.Debug;
import edu.thu.global.IUniqueIdGenerator;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.model.stg.ds.IDataSource;
import edu.thu.model.stg.ds.IDataStore;
import edu.thu.model.stg.view.IPageViewer;
import edu.thu.model.stg.view.spi.ListPageViewer;
import edu.thu.model.tree.TreeNode;
import edu.thu.search.IQuery;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class MemDataStoreImpl
  implements IDataStore
{
  TreeNode meta;
  String pkField;
  List listableFieldNames;
  List viewableFieldNames;
  List visibleFieldNames;
  List data = new ArrayList();
  IUniqueIdGenerator idGenerator;
  
  public Object add(Map paramMap, Object paramObject)
  {
    Debug.check(paramMap);
    String str = (String)paramMap.get(this.pkField);
    if (str == null)
    {
      str = (String)this.idGenerator.generateId(null);
      paramMap.put(this.pkField, str);
    }
    if (containsKey(str)) {
      throw Exceptions.code("ds.CAN_err_item_already_exists").param(paramMap);
    }
    this.data.add(paramMap);
    return str;
  }
  
  public void addMany(Collection paramCollection, Object paramObject)
  {
    if ((paramCollection == null) || (paramCollection.isEmpty())) {
      return;
    }
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Map localMap = (Map)localIterator.next();
      add(localMap, paramObject);
    }
  }
  
  public void clear(Object paramObject)
  {
    this.data.clear();
  }
  
  public int remove(Object paramObject1, Object paramObject2)
  {
    return MapTableUtils.remove(this.data, this.pkField, paramObject1);
  }
  
  public int removeByCondition(IQuery paramIQuery, Object paramObject)
  {
    throw Exceptions.notAllowed();
  }
  
  public int removeMany(Collection paramCollection, Object paramObject)
  {
    return MapTableUtils.removeMany(this.data, this.pkField, paramCollection);
  }
  
  public int update(Object paramObject1, Map paramMap, Object paramObject2)
  {
    return MapTableUtils.update(this.data, this.pkField, paramObject1, paramMap);
  }
  
  public int updateByCondition(IQuery paramIQuery, Map paramMap, Object paramObject)
  {
    throw Exceptions.notAllowed();
  }
  
  public int updateMany(Collection paramCollection, Map paramMap, Object paramObject)
  {
    return MapTableUtils.updateMany(this.data, this.pkField, paramCollection, paramMap);
  }
  
  public boolean containsKey(Object paramObject)
  {
    return getInfo(paramObject) != null;
  }
  
  public long count(IQuery paramIQuery)
  {
    throw Exceptions.notAllowed();
  }
  
  public boolean exists(IQuery paramIQuery)
  {
    throw Exceptions.notAllowed();
  }
  
  public List getAll()
  {
    return this.data;
  }
  
  public Map getInfo(Object paramObject)
  {
    return MapTableUtils.find(this.data, this.pkField, paramObject);
  }
  
  public List getListableFieldNames()
  {
    return this.listableFieldNames;
  }
  
  public List getManyInfo(Collection paramCollection)
  {
    return MapTableUtils.getManyByField(this.data, this.pkField, paramCollection);
  }
  
  public String getPkField()
  {
    return this.pkField;
  }
  
  public List getViewableFieldNames()
  {
    return this.viewableFieldNames;
  }
  
  public List getVisibleFieldNames()
  {
    return this.visibleFieldNames;
  }
  
  public IPageViewer list(IQuery paramIQuery)
  {
    if (paramIQuery == null) {
      return new ListPageViewer(this.data);
    }
    throw Exceptions.notAllowed();
  }
  
  public IDataSource getDataSource()
  {
    return null;
  }
  
  public TreeNode getMeta()
  {
    return this.meta;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\MemDataStoreImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */