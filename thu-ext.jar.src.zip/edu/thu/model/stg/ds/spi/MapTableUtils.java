package edu.thu.model.stg.ds.spi;

import edu.thu.global.Debug;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class MapTableUtils
{
  public static int remove(List paramList, String paramString, Object paramObject)
  {
    if (paramList == null) {
      return 0;
    }
    int i = 0;
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      Map localMap = (Map)localIterator.next();
      Object localObject = localMap.get(paramString);
      if ((localObject == paramObject) || ((localObject != null) && (localObject.equals(paramObject))))
      {
        i++;
        localIterator.remove();
      }
    }
    return i;
  }
  
  public static Map find(List paramList, String paramString, Object paramObject)
  {
    if (paramList == null) {
      return null;
    }
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      Map localMap = (Map)paramList.get(i);
      Object localObject = localMap.get(paramString);
      if ((localObject == paramObject) || ((localObject != null) && (localObject.equals(paramObject)))) {
        return localMap;
      }
    }
    return null;
  }
  
  public static List getManyByField(List paramList, String paramString, Collection paramCollection)
  {
    if ((paramCollection == null) || (paramCollection.isEmpty())) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(paramCollection.size());
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      Map localMap = find(paramList, paramString, localObject);
      if (localMap != null) {
        localArrayList.add(localMap);
      }
    }
    return localArrayList;
  }
  
  public static int removeMany(List paramList, String paramString, Collection paramCollection)
  {
    if ((paramCollection == null) || (paramCollection.isEmpty())) {
      return 0;
    }
    int i = 0;
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      Map localMap = (Map)localIterator.next();
      Object localObject = localMap.get(paramString);
      if (paramCollection.contains(localObject))
      {
        i++;
        localIterator.remove();
      }
    }
    return i;
  }
  
  public static int update(List paramList, String paramString, Object paramObject, Map paramMap)
  {
    Debug.check(paramMap);
    if (paramList == null) {
      return 0;
    }
    int i = 0;
    int k = paramList.size();
    for (int j = 0; j < k; j++)
    {
      Map localMap = (Map)paramList.get(j);
      Object localObject = localMap.get(paramString);
      if ((localObject == paramObject) || ((localObject != null) && (localObject.equals(paramObject))))
      {
        localMap.putAll(paramMap);
        i++;
      }
    }
    return i;
  }
  
  public static int updateMany(List paramList, String paramString, Collection paramCollection, Map paramMap)
  {
    if ((paramList == null) || (paramCollection == null) || (paramCollection.isEmpty())) {
      return 0;
    }
    int i = 0;
    int k = paramList.size();
    for (int j = 0; j < k; j++)
    {
      Map localMap = (Map)paramList.get(j);
      Object localObject = localMap.get(paramString);
      if (paramCollection.contains(localObject))
      {
        localMap.putAll(paramMap);
        i++;
      }
    }
    return i;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\MapTableUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */