package edu.thu.model.stg.ds.spi;

import edu.thu.global.Debug;
import edu.thu.model.stg.ds.IDataCollection;
import edu.thu.model.stg.ds.IDataSource;
import edu.thu.model.stg.ds.IDataSourceUpdator;
import edu.thu.model.stg.ds.IRecordProcessor;
import edu.thu.model.stg.ds.filter.DataSourceRequest;
import edu.thu.model.stg.ds.filter.IDataSourceInterceptor;
import edu.thu.model.stg.view.IPageViewer;
import edu.thu.model.tree.TreeNode;
import edu.thu.search.IPreparedQuery;
import edu.thu.search.IQuery;
import edu.thu.service.ICancelMonitor;
import edu.thu.service.IServiceContext;
import edu.thu.service.SystemServiceContext;
import edu.thu.service.ThreadServiceContext;
import java.util.Map;

public class FilterDataSource
  extends DsTransactionSupport
  implements IDataSource
{
  protected IDataSourceInterceptor filter;
  protected int flags;
  protected IServiceContext context;
  
  public FilterDataSource(IDataSource paramIDataSource, IDataSourceInterceptor paramIDataSourceInterceptor, int paramInt, IServiceContext paramIServiceContext)
  {
    super(paramIDataSource);
    Debug.check(paramIDataSource);
    Debug.check(paramIDataSourceInterceptor);
    this.filter = paramIDataSourceInterceptor;
    this.flags = paramInt;
    this.context = paramIServiceContext;
  }
  
  public FilterDataSource(IDataSource paramIDataSource, IDataSourceInterceptor paramIDataSourceInterceptor)
  {
    this(paramIDataSource, paramIDataSourceInterceptor, 0, null);
  }
  
  public IDataSourceInterceptor getFilter()
  {
    return this.filter;
  }
  
  protected Object createThis(IDataSource paramIDataSource)
  {
    return new FilterDataSource(paramIDataSource, this.filter, this.flags, this.context);
  }
  
  public Object switchToMode(String paramString)
  {
    if ((this.flags & 0x1) != 0) {
      return new FilterDataSource((IDataSource)this.ds.switchToMode(paramString), this.filter, this.flags, this.context);
    }
    return this.ds.switchToMode(paramString);
  }
  
  public boolean isContextualizable()
  {
    return (this.flags & 0x4) != 0;
  }
  
  public IServiceContext getContext()
  {
    if (this.context != null) {
      return this.context;
    }
    if ((this.flags & 0x2) != 0) {
      return ThreadServiceContext.getCurrentContext();
    }
    return SystemServiceContext.getInstance();
  }
  
  public boolean isCacheable()
  {
    return (this.ds.isCacheable()) && (this.context == null);
  }
  
  public void setFlag(int paramInt)
  {
    this.flags |= paramInt;
  }
  
  public void clearFlag(int paramInt)
  {
    this.flags &= (paramInt ^ 0xFFFFFFFF);
  }
  
  public int getFlags()
  {
    return this.flags;
  }
  
  public Object contextualize(IServiceContext paramIServiceContext)
  {
    if (this.context == paramIServiceContext) {
      return this;
    }
    return new FilterDataSource((IDataSource)this.ds.contextualize(paramIServiceContext), this.filter, this.flags, paramIServiceContext);
  }
  
  public Object execute(String paramString, Map paramMap, IServiceContext paramIServiceContext)
  {
    if (this.context != null) {
      paramIServiceContext = this.context;
    }
    return this.ds.execute(paramString, paramMap, paramIServiceContext);
  }
  
  public boolean exists(IQuery paramIQuery, ICancelMonitor paramICancelMonitor)
  {
    DataSourceRequest localDataSourceRequest = new DataSourceRequest(paramIQuery);
    this.filter.onBeforeQuery(localDataSourceRequest, getContext());
    return this.ds.exists(paramIQuery, paramICancelMonitor);
  }
  
  public IPageViewer findMany(Object paramObject, IQuery paramIQuery, ICancelMonitor paramICancelMonitor)
  {
    DataSourceRequest localDataSourceRequest = new DataSourceRequest(paramIQuery);
    this.filter.onBeforeQuery(localDataSourceRequest, getContext());
    return this.ds.findMany(paramObject, localDataSourceRequest.getQuery(), paramICancelMonitor);
  }
  
  public Object findOne(Object paramObject, IQuery paramIQuery, ICancelMonitor paramICancelMonitor)
  {
    DataSourceRequest localDataSourceRequest = new DataSourceRequest(paramIQuery);
    this.filter.onBeforeQuery(localDataSourceRequest, getContext());
    return this.ds.findOne(paramObject, localDataSourceRequest.getQuery(), paramICancelMonitor);
  }
  
  public TreeNode getMeta()
  {
    return this.ds.getMeta();
  }
  
  public String getName()
  {
    return this.ds.getName();
  }
  
  public IDataSourceUpdator getUpdator(Object paramObject)
  {
    return new FilterDataSourceUpdator(this.ds.getUpdator(paramObject), this.filter, getContext());
  }
  
  public boolean isParameterizable()
  {
    return (this.ds.isParameterizable()) || (this.filter.isParameterizable());
  }
  
  public Object parameterize(Map paramMap)
  {
    if (!isParameterizable()) {
      return this;
    }
    return new FilterDataSource((IDataSource)this.ds.parameterize(paramMap), (IDataSourceInterceptor)this.filter.parameterize(paramMap), this.flags, this.context);
  }
  
  public void process(IQuery paramIQuery, IRecordProcessor paramIRecordProcessor, IServiceContext paramIServiceContext)
  {
    DataSourceRequest localDataSourceRequest = new DataSourceRequest(paramIQuery);
    this.filter.onBeforeProcess(localDataSourceRequest, this.context == null ? paramIServiceContext : this.context);
    this.ds.process(paramIQuery, paramIRecordProcessor, paramIServiceContext);
  }
  
  public IPreparedQuery parseQuery(Object paramObject, IQuery paramIQuery)
  {
    DataSourceRequest localDataSourceRequest = new DataSourceRequest(paramIQuery);
    this.filter.onBeforeQuery(localDataSourceRequest, getContext());
    return this.ds.parseQuery(paramObject, paramIQuery);
  }
  
  public void setName(String paramString)
  {
    this.ds.setName(paramString);
  }
  
  public IDataSource getDataSource(String paramString, IServiceContext paramIServiceContext)
  {
    if (this.context != null) {
      paramIServiceContext = this.context;
    }
    return this.ds.getDataSource(paramString, paramIServiceContext);
  }
  
  public IDataCollection getMapping(String paramString, Map paramMap, IServiceContext paramIServiceContext)
  {
    if (this.context != null) {
      paramIServiceContext = this.context;
    }
    return this.ds.getMapping(paramString, paramMap, paramIServiceContext);
  }
  
  public String getCurrentMode()
  {
    return this.ds.getCurrentMode();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\FilterDataSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */