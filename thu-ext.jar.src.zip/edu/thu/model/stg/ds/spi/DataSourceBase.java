package edu.thu.model.stg.ds.spi;

import edu.thu.global.Debug;
import edu.thu.model.stg.ds.IDataProvider;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IServiceContext;

public abstract class DataSourceBase
  extends DpTransactionSupport
{
  protected DataSourceMetaImpl dsMeta;
  
  public DataSourceBase(IDataProvider paramIDataProvider, DataSourceMetaImpl paramDataSourceMetaImpl)
  {
    super(paramIDataProvider);
    Debug.check(paramIDataProvider);
    Debug.check(paramDataSourceMetaImpl);
    this.dsMeta = paramDataSourceMetaImpl;
  }
  
  protected abstract Object createThis(IDataProvider paramIDataProvider);
  
  public Object contextualize(IServiceContext paramIServiceContext)
  {
    return this;
  }
  
  public TreeNode getMeta()
  {
    return this.dsMeta.toNode();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\DataSourceBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */