package edu.thu.model.stg.ds.spi;

import edu.thu.model.data.table.IRowSet;
import edu.thu.model.stg.ds.IDataSourceUpdator;
import edu.thu.search.IQuery;
import edu.thu.service.IServiceContext;
import edu.thu.service.txn.ITransactionMode;
import edu.thu.service.txn.ITransactionSupport;
import java.util.Collection;
import java.util.Map;

public abstract class ProxyDataSourceUpdator
  implements ITransactionSupport, IDataSourceUpdator
{
  protected IDataSourceUpdator du;
  
  public ProxyDataSourceUpdator(IDataSourceUpdator paramIDataSourceUpdator)
  {
    this.du = paramIDataSourceUpdator;
  }
  
  protected abstract ProxyDataSourceUpdator createThis(IDataSourceUpdator paramIDataSourceUpdator);
  
  public IServiceContext getContext()
  {
    return this.du.getContext();
  }
  
  public IDataSourceUpdator getDataSourceUpdator()
  {
    return this.du;
  }
  
  public Object add(Map paramMap)
  {
    return this.du.add(paramMap);
  }
  
  public void addMany(Collection paramCollection)
  {
    this.du.addMany(paramCollection);
  }
  
  public void clear()
  {
    this.du.clear();
  }
  
  public int remove(IQuery paramIQuery)
  {
    return this.du.remove(paramIQuery);
  }
  
  public IRowSet selectForUpdate(IQuery paramIQuery)
  {
    return this.du.selectForUpdate(paramIQuery);
  }
  
  public int update(Map paramMap, IQuery paramIQuery)
  {
    return this.du.update(paramMap, paramIQuery);
  }
  
  public Object beginTransaction()
  {
    return createThis((IDataSourceUpdator)this.du.beginTransaction());
  }
  
  public Object cooperate(ITransactionMode paramITransactionMode)
  {
    return createThis((IDataSourceUpdator)this.du.cooperate(paramITransactionMode));
  }
  
  public void endTransaction(boolean paramBoolean)
  {
    this.du.endTransaction(paramBoolean);
  }
  
  public ITransactionMode getTransactionMode()
  {
    return this.du.getTransactionMode();
  }
  
  public boolean supportTransaction()
  {
    return this.du.supportTransaction();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\ProxyDataSourceUpdator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */