package edu.thu.model.stg.ds.spi;

import edu.thu.global.Debug;
import edu.thu.model.data.table.IRowSet;
import edu.thu.model.stg.ds.IDataSourceUpdator;
import edu.thu.model.stg.ds.filter.DataSourceRequest;
import edu.thu.model.stg.ds.filter.IDataSourceInterceptor;
import edu.thu.search.IQuery;
import edu.thu.service.IServiceContext;
import edu.thu.service.txn.ITransactionMode;
import java.util.Collection;
import java.util.Map;

public class FilterDataSourceUpdator
  implements IDataSourceUpdator
{
  protected IDataSourceUpdator du;
  protected IDataSourceInterceptor filter;
  protected IServiceContext context;
  
  public FilterDataSourceUpdator(IDataSourceUpdator paramIDataSourceUpdator, IDataSourceInterceptor paramIDataSourceInterceptor, IServiceContext paramIServiceContext)
  {
    Debug.check(paramIDataSourceUpdator);
    Debug.check(paramIDataSourceInterceptor);
    this.du = paramIDataSourceUpdator;
    this.filter = paramIDataSourceInterceptor;
    this.context = paramIServiceContext;
  }
  
  public IServiceContext getContext()
  {
    return this.context;
  }
  
  public Object add(Map paramMap)
  {
    DataSourceRequest localDataSourceRequest = new DataSourceRequest(paramMap);
    this.filter.onBeforeAdd(localDataSourceRequest, getContext());
    return this.du.add(localDataSourceRequest.getInfo());
  }
  
  public void addMany(Collection paramCollection)
  {
    DataSourceRequest localDataSourceRequest = new DataSourceRequest(paramCollection);
    this.filter.onBeforeAddMany(localDataSourceRequest, this.context);
    this.du.addMany(localDataSourceRequest.getInfos());
  }
  
  public Object beginTransaction()
  {
    return new FilterDataSourceUpdator((IDataSourceUpdator)this.du.beginTransaction(), this.filter, this.context);
  }
  
  public void clear()
  {
    DataSourceRequest localDataSourceRequest = new DataSourceRequest();
    this.filter.onBeforeRemove(localDataSourceRequest, this.context);
    if (localDataSourceRequest.getQuery() == null) {
      this.du.clear();
    } else {
      this.du.remove(localDataSourceRequest.getQuery());
    }
  }
  
  public Object cooperate(ITransactionMode paramITransactionMode)
  {
    return this.du.cooperate(paramITransactionMode);
  }
  
  public void endTransaction(boolean paramBoolean)
  {
    this.du.endTransaction(paramBoolean);
  }
  
  public ITransactionMode getTransactionMode()
  {
    return this.du.getTransactionMode();
  }
  
  public int remove(IQuery paramIQuery)
  {
    DataSourceRequest localDataSourceRequest = new DataSourceRequest(paramIQuery);
    this.filter.onBeforeRemove(localDataSourceRequest, this.context);
    return this.du.remove(localDataSourceRequest.getQuery());
  }
  
  public boolean supportTransaction()
  {
    return this.du.supportTransaction();
  }
  
  public int update(Map paramMap, IQuery paramIQuery)
  {
    DataSourceRequest localDataSourceRequest = new DataSourceRequest(paramIQuery, paramMap);
    this.filter.onBeforeUpdate(localDataSourceRequest, getContext());
    return this.du.update(localDataSourceRequest.getInfo(), localDataSourceRequest.getQuery());
  }
  
  public IRowSet selectForUpdate(IQuery paramIQuery)
  {
    DataSourceRequest localDataSourceRequest = new DataSourceRequest(paramIQuery, null);
    this.filter.onBeforeQuery(localDataSourceRequest, this.context);
    return this.du.selectForUpdate(paramIQuery);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\FilterDataSourceUpdator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */