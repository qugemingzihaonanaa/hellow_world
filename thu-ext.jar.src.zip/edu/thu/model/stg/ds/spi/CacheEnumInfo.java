package edu.thu.model.stg.ds.spi;

import edu.thu.model.stg.ds.EnumItem;
import edu.thu.model.stg.ds.IEnumInfo;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class CacheEnumInfo
  extends AbstractEnumInfo
{
  private static final long serialVersionUID = 4018920690763239252L;
  Map idToItem = Collections.EMPTY_MAP;
  List items;
  IEnumInfo fetcher;
  
  public CacheEnumInfo(IEnumInfo paramIEnumInfo)
  {
    this.fetcher = paramIEnumInfo;
  }
  
  public boolean isUseCodeField()
  {
    return this.fetcher.isUseCodeField();
  }
  
  public boolean existsItem(String paramString)
  {
    checkLoaded();
    return this.idToItem.containsKey(paramString);
  }
  
  public EnumItem getItem(String paramString)
  {
    checkLoaded();
    return (EnumItem)this.idToItem.get(paramString);
  }
  
  public EnumItem getItemByValue(Object paramObject)
  {
    checkLoaded();
    Iterator localIterator = this.idToItem.values().iterator();
    while (localIterator.hasNext())
    {
      EnumItem localEnumItem = (EnumItem)localIterator.next();
      Object localObject = localEnumItem.getValue();
      if (localObject != null)
      {
        if (localObject.equals(paramObject)) {
          return localEnumItem;
        }
      }
      else if (paramObject == null) {
        return localEnumItem;
      }
    }
    return null;
  }
  
  public List getItems()
  {
    checkLoaded();
    return this.items;
  }
  
  public Object getItemValue(String paramString)
  {
    checkLoaded();
    EnumItem localEnumItem = getItem(paramString);
    if (localEnumItem == null) {
      return null;
    }
    return localEnumItem.getValue();
  }
  
  public boolean isEmpty()
  {
    checkLoaded();
    return this.idToItem.isEmpty();
  }
  
  public int size()
  {
    return this.idToItem.size();
  }
  
  public void refresh()
  {
    this.items = null;
  }
  
  void checkLoaded()
  {
    if (this.items == null) {
      synchronized (this)
      {
        List localList = this.fetcher.getItems();
        if (localList == null)
        {
          this.items = Collections.EMPTY_LIST;
          this.idToItem = Collections.EMPTY_MAP;
        }
        else
        {
          HashMap localHashMap = new HashMap(localList.size());
          int j = localList.size();
          for (int i = 0; i < j; i++)
          {
            EnumItem localEnumItem = (EnumItem)localList.get(i);
            localHashMap.put(localEnumItem.getId(), localEnumItem);
          }
          this.items = localList;
          this.idToItem = localHashMap;
        }
      }
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\CacheEnumInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */