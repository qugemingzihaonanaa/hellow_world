package edu.thu.model.stg.ds.spi;

import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.json.JsonWriter;
import edu.thu.model.stg.ds.EnumItem;
import edu.thu.model.stg.ds.IEnumInfo;
import edu.thu.util.ThreadLocalVars;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public abstract class AbstractEnumInfo
  implements IEnumInfo, Serializable
{
  private static final long serialVersionUID = -1176933786157693191L;
  String cacheListKey;
  
  public void setCacheListKey(String paramString)
  {
    this.cacheListKey = paramString;
  }
  
  protected List loadItems()
  {
    throw Exceptions.notAllowed();
  }
  
  public List getItems()
  {
    if (this.cacheListKey == null) {
      return loadItems();
    }
    Object localObject = (List)ThreadLocalVars.getVar(this.cacheListKey);
    if (localObject != null) {
      return (List)localObject;
    }
    localObject = loadItems();
    if (localObject == null) {
      localObject = new ArrayList(0);
    }
    ThreadLocalVars.setVar(this.cacheListKey, localObject);
    return (List)localObject;
  }
  
  public boolean existsItem(String paramString)
  {
    return getItem(paramString) != null;
  }
  
  public EnumItem getItem(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    List localList = getItems();
    if (localList == null) {
      return null;
    }
    int j = localList.size();
    for (int i = 0; i < j; i++)
    {
      EnumItem localEnumItem = (EnumItem)localList.get(i);
      if (paramString.equals(localEnumItem.getId())) {
        return localEnumItem;
      }
    }
    return null;
  }
  
  public EnumItem getItemByValue(Object paramObject)
  {
    if (paramObject == null) {
      return null;
    }
    String str1 = paramObject.toString();
    List localList = getItems();
    if (localList == null) {
      return null;
    }
    int j = localList.size();
    for (int i = 0; i < j; i++)
    {
      EnumItem localEnumItem = (EnumItem)localList.get(i);
      String str2 = localEnumItem.getValue() == null ? null : localEnumItem.getValue().toString();
      if (str1.equals(str2)) {
        return localEnumItem;
      }
    }
    return null;
  }
  
  public Object getItemValue(String paramString)
  {
    EnumItem localEnumItem = getItem(paramString);
    if (localEnumItem == null) {
      return null;
    }
    return localEnumItem.getValue();
  }
  
  public boolean isEmpty()
  {
    List localList = getItems();
    return (localList == null) || (localList.isEmpty());
  }
  
  public String toStdJsonString()
  {
    JsonWriter localJsonWriter = new JsonWriter();
    localJsonWriter.beginList();
    List localList = getItems();
    if (localList != null)
    {
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        EnumItem localEnumItem = (EnumItem)localIterator.next();
        localJsonWriter.beginMap();
        localJsonWriter.keyValue("value", localEnumItem.getId()).comma();
        localJsonWriter.keyValue("text", localEnumItem.getValue());
        if (localEnumItem.getCode() != null) {
          localJsonWriter.comma().keyValue("code", localEnumItem.getCode());
        }
        if (localEnumItem.getTip() != null) {
          localJsonWriter.comma().keyValue("tip", localEnumItem.getTip());
        }
        localJsonWriter.endMap();
        localJsonWriter.comma();
      }
      localJsonWriter.deleteComma();
    }
    localJsonWriter.endList();
    return localJsonWriter.getResult();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\AbstractEnumInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */