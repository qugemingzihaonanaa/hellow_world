package edu.thu.model.stg.ds.spi;

import edu.thu.app.sys.com.WxEnum;
import edu.thu.model.stg.ds.EnumItem;
import java.util.List;

public class WxEnumInfo
  extends AbstractEnumInfo
{
  private static final long serialVersionUID = -1358106267114469036L;
  WxEnum wxEnum;
  List<EnumItem> enumItems;
  
  public WxEnumInfo(WxEnum paramWxEnum)
  {
    this.wxEnum = paramWxEnum;
  }
  
  public boolean isUseCodeField()
  {
    return this.wxEnum.isUseCodeField();
  }
  
  protected List loadItems()
  {
    if (this.enumItems == null) {
      this.enumItems = this.wxEnum.getEnumItems();
    }
    return this.enumItems;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\WxEnumInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */