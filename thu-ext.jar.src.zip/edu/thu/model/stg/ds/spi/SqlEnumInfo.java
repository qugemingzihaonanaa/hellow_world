package edu.thu.model.stg.ds.spi;

import edu.thu.db.SQL;
import edu.thu.db.core.IJdbcTemplate;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.util.Coercions;
import edu.thu.model.stg.ds.EnumItem;
import edu.thu.orm.dao.DaoProvider;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SqlEnumInfo
  extends AbstractEnumInfo
{
  private static final long serialVersionUID = -7945408478822062206L;
  static final String[] PROP_NAMES = { "id", "value" };
  SQL sql;
  String dbEngine = "default";
  SQL itemSql;
  
  public SqlEnumInfo(SQL paramSQL)
  {
    this.sql = paramSQL;
  }
  
  public SqlEnumInfo(SQL paramSQL1, SQL paramSQL2, String paramString)
  {
    this.sql = paramSQL1;
    this.itemSql = paramSQL2;
    this.dbEngine = paramString;
  }
  
  public boolean isUseCodeField()
  {
    return this.itemSql.getText().indexOf(" code") > 0;
  }
  
  String getIgnoreCase(Map paramMap, String paramString)
  {
    Object localObject = paramMap.get(paramString);
    if (localObject == null) {
      localObject = paramMap.get(paramString.toUpperCase());
    }
    return Coercions.toString(localObject, null);
  }
  
  EnumItem transItem(Map paramMap)
  {
    if (paramMap == null) {
      return null;
    }
    EnumItem localEnumItem = new EnumItem();
    localEnumItem.setId(getIgnoreCase(paramMap, "id"));
    String str1 = getIgnoreCase(paramMap, "enumValue");
    if (str1 == null) {
      str1 = getIgnoreCase(paramMap, "value");
    }
    localEnumItem.setValue(str1);
    String str2 = getIgnoreCase(paramMap, "code");
    if (str2 == null) {
      str2 = localEnumItem.getId();
    }
    localEnumItem.setCode(str2);
    String str3 = getIgnoreCase(paramMap, "tip");
    localEnumItem.setTip(str3);
    return localEnumItem;
  }
  
  List transList(List paramList)
  {
    if (paramList == null) {
      return null;
    }
    int j = paramList.size();
    ArrayList localArrayList = new ArrayList(j);
    for (int i = 0; i < j; i++) {
      localArrayList.add(transItem((Map)paramList.get(i)));
    }
    return localArrayList;
  }
  
  protected List loadItems()
  {
    return transList(DaoProvider.jdbc().findAll(this.sql));
  }
  
  public EnumItem getItem(String paramString)
  {
    if (this.itemSql == null) {
      return super.getItem(paramString);
    }
    SQL localSQL = this.itemSql.copy();
    int j = localSQL.getParams().size();
    for (int i = 0; i < j; i++) {
      localSQL.getParams().set(i, paramString);
    }
    return transItem(DaoProvider.jdbc().findFirst(localSQL));
  }
  
  public EnumItem getItemByValue(Object paramObject)
  {
    throw Exceptions.notAllowed();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\SqlEnumInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */