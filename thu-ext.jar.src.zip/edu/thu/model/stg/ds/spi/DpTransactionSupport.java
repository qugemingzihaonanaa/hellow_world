package edu.thu.model.stg.ds.spi;

import edu.thu.db.TransactionMode;
import edu.thu.java.util.ClassUtils;
import edu.thu.model.stg.ds.IDataProvider;
import edu.thu.service.IParameterizable;
import edu.thu.service.txn.ITransactionMode;
import edu.thu.service.txn.ITransactionSupport;
import java.util.Map;

public class DpTransactionSupport
  implements ITransactionSupport, IParameterizable
{
  protected IDataProvider dp;
  
  public DpTransactionSupport(IDataProvider paramIDataProvider)
  {
    this.dp = paramIDataProvider;
  }
  
  protected Object createThis(IDataProvider paramIDataProvider)
  {
    return ClassUtils.classToObject(getClass(), paramIDataProvider);
  }
  
  protected TransactionMode getTxnDb()
  {
    return (TransactionMode)this.dp.getTransactionMode();
  }
  
  public boolean isParameterizable()
  {
    return this.dp.isParameterizable();
  }
  
  public Object parameterize(Map paramMap)
  {
    if (!isParameterizable()) {
      return this;
    }
    IDataProvider localIDataProvider = (IDataProvider)this.dp.parameterize(paramMap);
    return createThis(localIDataProvider);
  }
  
  public Object beginTransaction()
  {
    return createThis((IDataProvider)this.dp.beginTransaction());
  }
  
  public Object cooperate(ITransactionMode paramITransactionMode)
  {
    return createThis((IDataProvider)this.dp.cooperate(paramITransactionMode));
  }
  
  public void endTransaction(boolean paramBoolean)
  {
    this.dp.endTransaction(paramBoolean);
  }
  
  public ITransactionMode getTransactionMode()
  {
    return this.dp.getTransactionMode();
  }
  
  public boolean supportTransaction()
  {
    return this.dp.supportTransaction();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\DpTransactionSupport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */