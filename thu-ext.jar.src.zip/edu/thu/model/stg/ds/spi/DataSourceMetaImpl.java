package edu.thu.model.stg.ds.spi;

import edu.thu.app.pref.EntityPrefConfig;
import edu.thu.config.AppConfig;
import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.util.Coercions;
import edu.thu.lang.IVariant;
import edu.thu.lang.el.IExpressionReference;
import edu.thu.lang.exceptions.ErrorInfo;
import edu.thu.lang.exceptions.StdException;
import edu.thu.lang.util.ITplReference;
import edu.thu.lang.util.TplC;
import edu.thu.lang.xconfig.TplPieceSet;
import edu.thu.model.data.transform.ITransformer;
import edu.thu.model.stg.ds.BatchAddMeta;
import edu.thu.model.stg.ds.DataSourceMeta;
import edu.thu.model.stg.ds.EntityRelation;
import edu.thu.model.stg.ds.IDataSourceReference;
import edu.thu.model.stg.ds.OrderBy;
import edu.thu.model.stg.ds.QueryItem;
import edu.thu.model.stg.ds.QueryMeta;
import edu.thu.model.stg.ds.filter.IDataSourceInterceptor;
import edu.thu.model.stg.ds.spi.cp.FieldsInfo;
import edu.thu.model.tree.IXObject;
import edu.thu.model.tree.TreeNode;
import edu.thu.orm.dao.IEntityDao;
import edu.thu.service.IContextualizable;
import edu.thu.service.IServiceContext;
import edu.thu.service.SystemServiceContext;
import edu.thu.util.StampUtils;
import edu.thu.util.StringUtils;
import edu.thu.util.StringUtilsEx;
import edu.thu.util.validate.IValidatorSet;
import edu.thu.util.validate.ValidateException;
import edu.thu.web.layout.CardLayout;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class DataSourceMetaImpl
  extends DataSourceMeta
  implements IXObject, DsConstants
{
  private static final long serialVersionUID = -2036888679898942308L;
  TreeNode metaNode;
  boolean secure;
  boolean useTxnManager;
  boolean readOnly;
  boolean useCustomId;
  boolean cacheable;
  boolean stampCreate;
  boolean stampUpdate;
  boolean parameterizable;
  boolean contextualizable;
  boolean supportQueryBuilder;
  boolean supportBatchUpdate;
  boolean supportBatchAdd;
  boolean supportPartition;
  boolean supportModifyLog;
  String modeName;
  String pkField;
  String nameField;
  String keyField;
  String tipField;
  String markField;
  String activeFlagField;
  GroupMeta groupMeta;
  OrderBy orderby;
  List fields = new ArrayList();
  List<EntityRelation> entityRelations = new ArrayList();
  String popStyle;
  List shortListFields;
  Object initTpl;
  Object afterTpl;
  IValidatorSet validatorSet;
  Map<String, FieldMeta> fieldsMap;
  Map<String, IExpressionReference> defaultExprs;
  IDataSourceReference referer;
  IDataSourceReference referee;
  Map<String, Object> commands;
  Map<String, Object> references;
  Map<String, Object> extDs;
  Map<String, Object> modes;
  TreeMeta treeMeta;
  Map<String, IExpressionReference> autoExprs;
  String dsName;
  String showName;
  QueryMeta queryMeta;
  QueryItem quickQuery;
  Map<String, CardLayout> layouts;
  Map entityFormulas;
  List keys;
  List<String> refFields;
  BatchAddMeta batchAdd;
  TplPieceSet tpls;
  List<String> localFields;
  List<String> localLayouts;
  Map<String, EntityPrefConfig> prefs;
  Map<String, List<String>> fieldGroups;
  Map<String, TreeNode> extChildren;
  List<ITplReference> processors;
  ITplReference filterTpl;
  static boolean s_useStamp = AppConfig.var("ds.use_modify_stamp").booleanValue(true);
  
  public DataSourceMetaImpl(TreeNode paramTreeNode)
  {
    Debug.check(paramTreeNode);
    this.metaNode = paramTreeNode;
    initMeta();
  }
  
  public void setExtChildren(Map<String, TreeNode> paramMap)
  {
    this.extChildren = paramMap;
  }
  
  public String toString()
  {
    return DataSourceMetaImpl.class.getSimpleName() + "[" + getMetaName() + "|" + getStorePath() + "]";
  }
  
  public String getTipField()
  {
    return this.tipField;
  }
  
  public TreeNode getExtChild(String paramString)
  {
    if (this.extChildren == null) {
      return null;
    }
    return (TreeNode)this.extChildren.get(paramString);
  }
  
  public void detachMetaNode()
  {
    if (!Debug.isOn()) {
      this.metaNode.clearChildren();
    }
  }
  
  public void internText()
  {
    Iterator localIterator = this.fieldsMap.values().iterator();
    while (localIterator.hasNext())
    {
      FieldMeta localFieldMeta = (FieldMeta)localIterator.next();
      localFieldMeta.internText();
    }
    if (this.batchAdd != null) {
      this.batchAdd.internText();
    }
    if (this.modeName != null) {
      this.modeName = this.modeName.intern();
    }
    if (this.pkField != null) {
      this.pkField = this.pkField.intern();
    }
    if (this.nameField != null) {
      this.nameField = this.nameField.intern();
    }
    if (this.keyField != null) {
      this.keyField = this.keyField.intern();
    }
    if (this.markField != null) {
      this.markField = this.markField.intern();
    }
    if (this.activeFlagField != null) {
      this.activeFlagField = this.activeFlagField.intern();
    }
    StringUtilsEx.internList(this.refFields);
    StringUtilsEx.internList(this.localFields);
    StringUtilsEx.internList(this.localLayouts);
  }
  
  public void setValidatorSet(IValidatorSet paramIValidatorSet)
  {
    this.validatorSet = paramIValidatorSet;
  }
  
  public String getObjectName()
  {
    String str1 = this.metaNode.attribute("name").stripedStringValue();
    if (str1 == null)
    {
      String str2 = getMetaName();
      if (str2 != null)
      {
        int i = str2.lastIndexOf('/');
        if (i > 0)
        {
          str1 = str2.substring(i + 1);
          str1 = StringUtils.chompLast(str1, ".meta.xml");
        }
      }
    }
    return str1;
  }
  
  public ITplReference getFilterTpl()
  {
    return this.filterTpl;
  }
  
  public void setFilterTpl(ITplReference paramITplReference)
  {
    this.filterTpl = paramITplReference;
  }
  
  public String getMarkField()
  {
    return this.markField;
  }
  
  public void setMarkField(String paramString)
  {
    this.markField = paramString;
  }
  
  public List<String> getLocalLayouts()
  {
    return this.localLayouts;
  }
  
  public void setLocalLayouts(List<String> paramList)
  {
    this.localLayouts = paramList;
  }
  
  public List<String> getLocalFields()
  {
    return this.localFields;
  }
  
  public void setLocalFields(List<String> paramList)
  {
    this.localFields = paramList;
  }
  
  public boolean isSupportQueryBuilder()
  {
    return this.supportQueryBuilder;
  }
  
  public void setSupportQueryBuilder(boolean paramBoolean)
  {
    this.supportQueryBuilder = paramBoolean;
  }
  
  public List getRefFields()
  {
    return this.refFields;
  }
  
  public void setRefFields(List paramList)
  {
    this.refFields = paramList;
  }
  
  public String getActiveFlagField()
  {
    return this.activeFlagField;
  }
  
  public void setActiveFlagField(String paramString)
  {
    this.activeFlagField = paramString;
  }
  
  public Object getInitTpl()
  {
    return this.initTpl;
  }
  
  public void setInitTpl(Object paramObject)
  {
    this.initTpl = paramObject;
  }
  
  public Object getAfterTpl()
  {
    return this.afterTpl;
  }
  
  public void setAfterTpl(Object paramObject)
  {
    this.afterTpl = paramObject;
  }
  
  public OrderBy getOrderBy()
  {
    return this.orderby;
  }
  
  public void setOrderBy(OrderBy paramOrderBy)
  {
    this.orderby = paramOrderBy;
  }
  
  public String getPopStyle()
  {
    return this.popStyle;
  }
  
  public void setPopStyle(String paramString)
  {
    this.popStyle = paramString;
  }
  
  public Map getEntityFormulas()
  {
    return this.entityFormulas;
  }
  
  public void setEntityFormulas(Map paramMap)
  {
    this.entityFormulas = paramMap;
  }
  
  public TreeMeta getTreeMeta()
  {
    return this.treeMeta;
  }
  
  public TreeNode toNode()
  {
    if (this.metaNode == null) {
      throw Exceptions.notAllowed();
    }
    return this.metaNode;
  }
  
  public QueryMeta getQueryMeta()
  {
    return this.queryMeta;
  }
  
  public void setQueryMeta(QueryMeta paramQueryMeta)
  {
    this.queryMeta = paramQueryMeta;
  }
  
  public QueryItem getQuickQuery()
  {
    return this.quickQuery;
  }
  
  public void setQuickQuery(QueryItem paramQueryItem)
  {
    this.quickQuery = paramQueryItem;
  }
  
  public void setModes(Map paramMap)
  {
    this.modes = paramMap;
  }
  
  public GroupMeta getGroupMeta()
  {
    return this.groupMeta;
  }
  
  public void setGroupMeta(GroupMeta paramGroupMeta)
  {
    this.groupMeta = paramGroupMeta;
  }
  
  public void setCommands(Map paramMap)
  {
    this.commands = paramMap;
  }
  
  public void setExtDs(Map paramMap)
  {
    this.extDs = paramMap;
  }
  
  public void setReferee(IDataSourceReference paramIDataSourceReference)
  {
    this.referee = paramIDataSourceReference;
  }
  
  public void setReferences(Map paramMap)
  {
    this.references = paramMap;
  }
  
  public void setReferer(IDataSourceReference paramIDataSourceReference)
  {
    this.referer = paramIDataSourceReference;
  }
  
  public void setTreeMeta(TreeMeta paramTreeMeta)
  {
    this.treeMeta = paramTreeMeta;
  }
  
  public boolean isParameterizable()
  {
    return this.parameterizable;
  }
  
  public boolean isContextualizable()
  {
    return this.contextualizable;
  }
  
  public List getShortListFields()
  {
    return this.shortListFields;
  }
  
  public void setShortListFields(List paramList)
  {
    this.shortListFields = paramList;
  }
  
  public String getOrderField()
  {
    if (this.orderby == null) {
      return null;
    }
    return this.orderby.getFirstOrderField();
  }
  
  public boolean getDefaultOrder()
  {
    if (this.orderby == null) {
      return true;
    }
    return this.orderby.getFirstOrder();
  }
  
  public String getGroupField()
  {
    if (this.groupMeta == null) {
      return null;
    }
    return this.groupMeta.getGroupField();
  }
  
  public String getGroupEnum()
  {
    if (this.groupMeta == null) {
      return null;
    }
    return this.groupMeta.getGroupEnum();
  }
  
  public void setShowName(String paramString)
  {
    this.showName = paramString;
  }
  
  public String getShowName()
  {
    return this.showName;
  }
  
  void initMeta()
  {
    setAttributes(new HashMap(this.metaNode.getAttributes()));
    this.secure = this.metaNode.attribute("secure").booleanValue(false);
    this.readOnly = this.metaNode.childValue("readOnly").booleanValue(false);
    this.useTxnManager = this.metaNode.childValue("useTxnManager").booleanValue(true);
    boolean bool = Coercions.toBoolean(AppConfig.getVar("ds.meta.use_cache"), false);
    this.cacheable = this.metaNode.attribute("cacheable").booleanValue(bool);
    this.pkField = this.metaNode.childValue("pkField").stripedStringValue();
    this.nameField = this.metaNode.childValue("nameField").stripedStringValue();
    this.keyField = this.metaNode.childValue("keyField").stripedStringValue();
    String str = this.metaNode.childValue("codeField").stripedStringValue();
    setCodeField(str);
    this.tipField = this.metaNode.childValue("tipField").stripedStringValue();
    this.markField = this.metaNode.childValue("markField").stripedStringValue();
    this.stampCreate = this.metaNode.childValue("stampCreate").booleanValue(false);
    this.stampUpdate = this.metaNode.childValue("stampUpdate").booleanValue(false);
    this.supportQueryBuilder = this.metaNode.childValue("supportQueryBuilder").booleanValue(false);
    this.supportBatchAdd = this.metaNode.childValue("supportBatchAdd").booleanValue(false);
    this.supportBatchUpdate = this.metaNode.childValue("supportBatchUpdate").booleanValue(false);
    this.supportModifyLog = this.metaNode.childValue("supportModifyLog").booleanValue(false);
    this.supportPartition = this.metaNode.childValue("supportPartition").booleanValue(false);
    this.shortListFields = this.metaNode.childValue("shortListFields").listValue();
    setTypeField(this.metaNode.childValue("typeField").stripedStringValue());
    setActiveFlagField(this.metaNode.childValue("activeFlagField").stripedStringValue());
    this.parameterizable = this.metaNode.childValue("parameterizable").booleanValue(false);
    this.contextualizable = this.metaNode.childValue("contextualizable").booleanValue(true);
    this.popStyle = this.metaNode.childValue("popStyle").stripedStringValue();
  }
  
  public boolean isSupportModifyLog()
  {
    return this.supportModifyLog;
  }
  
  public String getDataSourceName()
  {
    return this.dsName;
  }
  
  public void setFieldGroups(Map<String, List<String>> paramMap)
  {
    this.fieldGroups = paramMap;
  }
  
  public Map<String, List<String>> getFieldGroups()
  {
    return this.fieldGroups;
  }
  
  public void setFieldsInfo(FieldsInfo paramFieldsInfo)
  {
    this.fieldsMap = paramFieldsInfo.fieldsMap;
    this.fields = paramFieldsInfo.fields;
    this.defaultExprs = paramFieldsInfo.defaultExprs;
    this.autoExprs = paramFieldsInfo.autoExprs;
    this.entityFormulas = paramFieldsInfo.entityFormulas;
    FieldMeta localFieldMeta = (FieldMeta)this.fieldsMap.get(this.pkField);
    this.useCustomId = (localFieldMeta == null ? false : localFieldMeta.isAddable());
  }
  
  public void setDefaultExpr(String paramString, IExpressionReference paramIExpressionReference)
  {
    if (this.defaultExprs == null) {
      this.defaultExprs = new HashMap();
    }
    this.defaultExprs.put(paramString, paramIExpressionReference);
  }
  
  public void setAutoExpr(String paramString, IExpressionReference paramIExpressionReference)
  {
    if (this.autoExprs == null) {
      this.autoExprs = new HashMap();
    }
    this.autoExprs.put(paramString, paramIExpressionReference);
  }
  
  public void setProcessors(List<ITplReference> paramList)
  {
    this.processors = paramList;
  }
  
  public List<String> getSelectedFieldNames(String paramString)
  {
    List localList = (List)this.fieldGroups.get(paramString);
    if (localList == null) {
      localList = Collections.emptyList();
    }
    return localList;
  }
  
  public List<FieldMeta> getSelectedFields(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = getSelectedFieldNames(paramString).iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      localArrayList.add((FieldMeta)this.fieldsMap.get(str));
    }
    return localArrayList;
  }
  
  public List<FieldMeta> getOrderableFields()
  {
    ArrayList localArrayList = new ArrayList();
    int j = this.fields.size();
    for (int i = 0; i < j; i++)
    {
      FieldMeta localFieldMeta = (FieldMeta)this.fields.get(i);
      if (localFieldMeta.isOrderable()) {
        localArrayList.add(localFieldMeta);
      }
    }
    return localArrayList;
  }
  
  public Map<String, FieldMeta> getSelectedFieldsMap(String paramString)
  {
    HashMap localHashMap = new HashMap();
    Iterator localIterator = getSelectedFieldNames(paramString).iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      localHashMap.put(str, (FieldMeta)this.fieldsMap.get(str));
    }
    return localHashMap;
  }
  
  public Map<String, FieldMeta> getFieldsMap()
  {
    return this.fieldsMap;
  }
  
  public boolean isSecure()
  {
    return this.secure;
  }
  
  public boolean isReadOnly()
  {
    return this.readOnly;
  }
  
  public boolean isUseTxnManager()
  {
    return this.useTxnManager;
  }
  
  public boolean isUseCustomId()
  {
    return this.useCustomId;
  }
  
  public boolean isCacheable()
  {
    return this.cacheable;
  }
  
  public boolean isStampCreate()
  {
    return this.stampCreate;
  }
  
  public boolean isStampUpdate()
  {
    return this.stampUpdate;
  }
  
  public Map getExtDs()
  {
    return this.extDs;
  }
  
  public String getModeName()
  {
    return this.modeName;
  }
  
  public String getKeyField()
  {
    return this.keyField;
  }
  
  public String getLayerCodeField()
  {
    if (this.treeMeta == null) {
      return null;
    }
    return this.treeMeta.getLayerCodeField();
  }
  
  public char getLayerCodeSeparator()
  {
    if (this.treeMeta == null) {
      return '.';
    }
    return this.treeMeta.getLayerCodeSeparator();
  }
  
  public String getLayerLevelField()
  {
    if (this.treeMeta == null) {
      return null;
    }
    return this.treeMeta.getLayerLevelField();
  }
  
  public String getNameField()
  {
    return this.nameField;
  }
  
  public String getParentIdField()
  {
    if (this.treeMeta == null) {
      return null;
    }
    return this.treeMeta.getParentIdField();
  }
  
  public String getPkField()
  {
    return this.pkField;
  }
  
  public IDataSourceReference getReferee()
  {
    return this.referee;
  }
  
  public IDataSourceReference getReference(String paramString)
  {
    if (this.references == null) {
      return null;
    }
    return (IDataSourceReference)this.references.get(paramString);
  }
  
  public IDataSourceReference getReferer()
  {
    return this.referer;
  }
  
  public Object transToBaseName(String paramString)
  {
    return getValidFieldMeta(paramString).transToBase();
  }
  
  public FieldMeta getValidFieldMeta(String paramString)
  {
    FieldMeta localFieldMeta = (FieldMeta)this.fieldsMap.get(paramString);
    if (localFieldMeta == null) {
      throw Exceptions.code("ds.CAN_err_unknown_field_name").param(paramString).param(this.dsName);
    }
    return localFieldMeta;
  }
  
  public TreeNode getField(String paramString)
  {
    return TreeNode.toNode(this.fieldsMap.get(paramString));
  }
  
  public boolean hasField(String paramString)
  {
    return this.fieldsMap.containsKey(paramString);
  }
  
  public void checkDefaultValues(Map paramMap)
  {
    if (this.defaultExprs.isEmpty()) {
      return;
    }
    HashMap localHashMap = null;
    Iterator localIterator = this.defaultExprs.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      Object localObject1 = localEntry.getKey();
      if (!paramMap.containsKey(localObject1))
      {
        IExpressionReference localIExpressionReference = (IExpressionReference)localEntry.getValue();
        Object localObject2 = TplC.evaluate(localIExpressionReference, paramMap);
        if (localHashMap == null) {
          localHashMap = new HashMap(1);
        }
        localHashMap.put(localObject1, localIExpressionReference);
      }
    }
    if (localHashMap != null) {
      paramMap.putAll(localHashMap);
    }
  }
  
  public void checkStamp(Map paramMap, boolean paramBoolean, Object paramObject)
  {
    if (!s_useStamp) {
      return;
    }
    Timestamp localTimestamp = StampUtils.getTimestamp();
    if ((isStampCreate()) && (!paramBoolean))
    {
      if (this.fieldsMap.containsKey("createrId")) {
        paramMap.put("createrId", paramObject);
      } else {
        paramMap.put("creater", paramObject);
      }
      paramMap.put("createTime", localTimestamp);
    }
    if (isStampUpdate())
    {
      if (this.fieldsMap.containsKey("updaterId")) {
        paramMap.put("updaterId", paramObject);
      } else {
        paramMap.put("updater", paramObject);
      }
      paramMap.put("updateTime", localTimestamp);
    }
  }
  
  void addAutoValues(Map paramMap)
  {
    Iterator localIterator = this.autoExprs.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      Object localObject1 = localEntry.getKey();
      if (paramMap.containsKey(localObject1)) {
        throw Exceptions.code("ds.CAN_err_auto_field_not_allowed").param(localObject1).param(paramMap);
      }
      IExpressionReference localIExpressionReference = (IExpressionReference)localEntry.getValue();
      if (TplC.canEvaluate(localIExpressionReference, paramMap))
      {
        Object localObject2 = TplC.evaluate(localIExpressionReference, paramMap);
        if (localObject2 == null) {
          Debug.traceErr("ds.CAN_err_auto_expr_evaluate_to_null::" + localIExpressionReference + "," + localObject1);
        }
        paramMap.put(localObject1, localObject2);
      }
    }
  }
  
  public void runProcessors(Map<String, Object> paramMap, IServiceContext paramIServiceContext)
  {
    if ((this.processors != null) && (!this.processors.isEmpty()))
    {
      Iterator localIterator = this.processors.iterator();
      while (localIterator.hasNext())
      {
        ITplReference localITplReference = (ITplReference)localIterator.next();
        TplC.runTpl(localITplReference, paramMap, paramIServiceContext);
      }
    }
  }
  
  public void runAutoExprs(Object paramObject, Map<String, Object> paramMap)
  {
    Iterator localIterator = this.autoExprs.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      String str = (String)localEntry.getKey();
      IExpressionReference localIExpressionReference = (IExpressionReference)localEntry.getValue();
      if (TplC.canEvaluate(localIExpressionReference, paramMap))
      {
        Object localObject = TplC.evaluate(localIExpressionReference, paramMap);
        if (localObject == null) {
          Debug.traceErr("ds.CAN_err_auto_expr_evaluate_to_null::" + localIExpressionReference + "," + str);
        }
        TplC.setProperty(paramObject, str, localObject);
      }
    }
  }
  
  public void runAutoExprs(Object paramObject, Map<String, Object> paramMap, IEntityDao paramIEntityDao)
  {
    Iterator localIterator = this.autoExprs.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      String str = (String)localEntry.getKey();
      IExpressionReference localIExpressionReference = (IExpressionReference)localEntry.getValue();
      if (TplC.canEvaluate(localIExpressionReference, paramMap))
      {
        Object localObject = TplC.evaluate(localIExpressionReference, paramMap);
        if (localObject == null) {
          Debug.traceErr("ds.CAN_err_auto_expr_evaluate_to_null::" + localIExpressionReference + "," + str);
        }
        paramIEntityDao.setPropertyValue(paramObject, str, localObject);
      }
    }
  }
  
  public void validateRow(String paramString, Map<String, Object> paramMap1, Map<String, Object> paramMap2)
  {
    ArrayList localArrayList = new ArrayList();
    int i = 0;
    Iterator localIterator = paramMap1.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      FieldMeta localFieldMeta = getValidFieldMeta(str);
      if (localFieldMeta.getValidators() != null)
      {
        Object localObject = paramMap1.get(str);
        paramMap2.put("value", localObject);
        List localList = localFieldMeta.checkValid(paramString, paramMap2);
        if (localList != null)
        {
          i = 1;
          localArrayList.addAll(localList);
        }
      }
    }
    if (i != 0) {
      throw new ValidateException("ds.CAN_err_validate_row").errorInfos(localArrayList).param(paramString).param(paramMap1);
    }
  }
  
  public void validateQuery(TreeNode paramTreeNode, Map<String, Object> paramMap)
  {
    if (paramTreeNode == null) {
      return;
    }
    ArrayList localArrayList = new ArrayList();
    boolean bool = _validateQuery(paramTreeNode, paramMap, localArrayList);
    if (bool) {
      throw new ValidateException("ds.CAN_err_validate_query").errorInfos(localArrayList).param(paramTreeNode);
    }
  }
  
  boolean _validateQuery(TreeNode paramTreeNode, Map<String, Object> paramMap, List<ErrorInfo> paramList)
  {
    boolean bool = false;
    String str = paramTreeNode.attribute("name").stripedStringValue();
    Object localObject2;
    if (str == null)
    {
      int j = paramTreeNode.getChildCount();
      for (int i = 0; i < j; i++)
      {
        localObject2 = paramTreeNode.getChild(i);
        if (_validateQuery((TreeNode)localObject2, paramMap, paramList)) {
          bool = true;
        }
      }
      return bool;
    }
    FieldMeta localFieldMeta = getFieldMeta(str);
    if (localFieldMeta != null)
    {
      Object localObject1 = paramTreeNode.getAttribute("value");
      if (localObject1 != null)
      {
        paramMap.put("value", localObject1);
        localObject2 = localFieldMeta.checkValid("query", paramMap);
        if (localObject2 != null)
        {
          bool = true;
          paramList.addAll((Collection)localObject2);
        }
      }
      localObject2 = paramTreeNode.getAttribute("highValue");
      if (localObject2 != null)
      {
        paramMap.put("highValue", localObject2);
        localObject3 = localFieldMeta.checkValid("query", paramMap);
        if (localObject3 != null)
        {
          bool = true;
          paramList.addAll((Collection)localObject3);
        }
      }
      Object localObject3 = paramTreeNode.getAttribute("lowValue");
      if (localObject3 != null)
      {
        paramMap.put("lowValue", localObject3);
        List localList = localFieldMeta.checkValid("query", paramMap);
        if (localList != null)
        {
          bool = true;
          paramList.addAll(localList);
        }
      }
    }
    return bool;
  }
  
  public void validateField(String paramString1, String paramString2, Object paramObject, Map<String, Object> paramMap)
  {
    FieldMeta localFieldMeta = getValidFieldMeta(paramString2);
    paramMap.put("value", paramObject);
    localFieldMeta.validate(paramString1, paramMap);
  }
  
  public Map<String, Object> transformIn(Map<String, Object> paramMap, boolean paramBoolean, Object paramObject)
  {
    return transformIn(paramMap, paramBoolean, paramObject, true);
  }
  
  public Map<String, Object> transformIn(Map<String, Object> paramMap, boolean paramBoolean1, Object paramObject, boolean paramBoolean2)
  {
    Debug.check(paramMap);
    LinkedHashMap localLinkedHashMap = new LinkedHashMap(paramMap.size());
    Iterator localIterator = paramMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      String str1 = (String)localEntry.getKey();
      FieldMeta localFieldMeta = (FieldMeta)this.fieldsMap.get(str1);
      if (localFieldMeta == null)
      {
        localLinkedHashMap.put(str1, localEntry.getValue());
      }
      else
      {
        if (!localFieldMeta.isAuto()) {
          if (paramBoolean1)
          {
            if ((!localFieldMeta.isUpdatable()) && (!localFieldMeta.isAddable())) {
              throw Exceptions.code("ds.CAN_err_field_not_updatable").param(str1).param(paramMap);
            }
          }
          else if (!localFieldMeta.isAddable()) {
            throw Exceptions.code("ds.CAN_err_field_not_addable").param(str1).param(paramMap);
          }
        }
        Object localObject = localEntry.getValue();
        ITransformer localITransformer = localFieldMeta.getInTransformer();
        if (localITransformer != null) {
          localObject = localITransformer.transform(localObject);
        }
        if (paramBoolean2)
        {
          String str2 = localFieldMeta.getBaseName();
          localLinkedHashMap.put(str2, localObject);
        }
        else
        {
          localLinkedHashMap.put(str1, localObject);
        }
      }
    }
    checkStamp(localLinkedHashMap, paramBoolean1, paramObject);
    return localLinkedHashMap;
  }
  
  public String getBaseName(String paramString)
  {
    FieldMeta localFieldMeta = (FieldMeta)this.fieldsMap.get(paramString);
    if (localFieldMeta == null) {
      return null;
    }
    return localFieldMeta.getBaseName();
  }
  
  public ITransformer getOutTransformer(String paramString)
  {
    FieldMeta localFieldMeta = (FieldMeta)this.fieldsMap.get(paramString);
    if (localFieldMeta == null) {
      return null;
    }
    ITransformer localITransformer = localFieldMeta.getOutTransformer();
    if ((localITransformer instanceof IContextualizable)) {
      localITransformer = (ITransformer)((IContextualizable)localITransformer).contextualize(SystemServiceContext.getInstance());
    }
    return localITransformer;
  }
  
  public DataSourceMapping getMapping(String paramString)
  {
    if (this.references == null) {
      return null;
    }
    return (DataSourceMapping)this.references.get(paramString);
  }
  
  public DataSourceLocation getLocation(String paramString)
  {
    if (this.references == null) {
      return null;
    }
    return (DataSourceLocation)this.references.get(paramString);
  }
  
  public TreeNode getModeMeta(String paramString)
  {
    if (paramString == null) {
      paramString = "default";
    }
    if (this.modes == null) {
      return null;
    }
    return (TreeNode)this.modes.get(paramString);
  }
  
  public IDataSourceInterceptor getFilter()
  {
    TreeNode localTreeNode = this.metaNode.existingChild("filters");
    if (localTreeNode == null) {
      return null;
    }
    return (IDataSourceInterceptor)localTreeNode.getAttribute("value");
  }
  
  public void setDataSourceName(String paramString)
  {
    this.metaNode.setAttribute("name", paramString);
    this.dsName = paramString;
  }
  
  public List<FieldMeta> getFields(List<String> paramList)
  {
    if (paramList == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(paramList.size());
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      String str = (String)paramList.get(i);
      FieldMeta localFieldMeta = getValidFieldMeta(str);
      localArrayList.add(localFieldMeta);
    }
    return localArrayList;
  }
  
  public void setEntityRelations(List paramList)
  {
    this.entityRelations = paramList;
  }
  
  public List getEntityRelations()
  {
    return this.entityRelations;
  }
  
  public EntityRelation getDefaultEntityRelation()
  {
    if ((this.entityRelations == null) || (this.entityRelations.isEmpty())) {
      return null;
    }
    int j = this.entityRelations.size();
    for (int i = 0; i < j; i++)
    {
      EntityRelation localEntityRelation = (EntityRelation)this.entityRelations.get(i);
      if (localEntityRelation.isDefault()) {
        return null;
      }
    }
    return (EntityRelation)this.entityRelations.get(0);
  }
  
  public List<EntityRelation> getSelectedEntityRelations(String paramString)
  {
    if ((this.entityRelations == null) || (this.entityRelations.isEmpty())) {
      return Collections.emptyList();
    }
    ArrayList localArrayList = new ArrayList();
    int j = this.entityRelations.size();
    for (int i = 0; i < j; i++)
    {
      EntityRelation localEntityRelation = (EntityRelation)this.entityRelations.get(i);
      if (localEntityRelation.matchSelector(paramString)) {
        localArrayList.add(localEntityRelation);
      }
    }
    return localArrayList;
  }
  
  public EntityRelation getSelectedEntityRelation(String paramString)
  {
    List localList = getSelectedEntityRelations(paramString);
    if (localList.isEmpty()) {
      return null;
    }
    if (localList.size() > 1) {
      throw new StdException("ds.err_multiple_relation_match_selector").param(paramString).param(this);
    }
    return (EntityRelation)localList.get(0);
  }
  
  public List<EntityRelation> getEntityRelationsNoSelector()
  {
    if ((this.entityRelations == null) || (this.entityRelations.isEmpty())) {
      return Collections.emptyList();
    }
    ArrayList localArrayList = new ArrayList();
    int j = this.entityRelations.size();
    for (int i = 0; i < j; i++)
    {
      EntityRelation localEntityRelation = (EntityRelation)this.entityRelations.get(i);
      if ((localEntityRelation.getSelectors() != null) && (localEntityRelation.getSelectors().isEmpty())) {}
      localArrayList.add(localEntityRelation);
    }
    return localArrayList;
  }
  
  public List<FieldMeta> getDbFields()
  {
    ArrayList localArrayList = new ArrayList();
    int j = this.fields.size();
    for (int i = 0; i < j; i++)
    {
      FieldMeta localFieldMeta = (FieldMeta)this.fields.get(i);
      if (localFieldMeta.getDbName() != null) {
        localArrayList.add(localFieldMeta);
      }
    }
    return localArrayList;
  }
  
  public List<String> getFieldNamesWithPrefix(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    int j = this.fields.size();
    for (int i = 0; i < j; i++)
    {
      FieldMeta localFieldMeta = (FieldMeta)this.fields.get(i);
      if (localFieldMeta.getName().startsWith(paramString)) {
        localArrayList.add(localFieldMeta.getName());
      }
    }
    return localArrayList;
  }
  
  public List<FieldMeta> getFieldsWithPrefix(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    int j = this.fields.size();
    for (int i = 0; i < j; i++)
    {
      FieldMeta localFieldMeta = (FieldMeta)this.fields.get(i);
      if (localFieldMeta.getName().startsWith(paramString)) {
        localArrayList.add(localFieldMeta);
      }
    }
    return localArrayList;
  }
  
  public List<FieldMeta> getSupportQueryBuilderFields()
  {
    ArrayList localArrayList = new ArrayList(this.fields.size());
    int j = this.fields.size();
    for (int i = 0; i < j; i++)
    {
      FieldMeta localFieldMeta = (FieldMeta)this.fields.get(i);
      if (localFieldMeta.isSupportQueryBuilder()) {
        localArrayList.add(localFieldMeta);
      }
    }
    return localArrayList;
  }
  
  public Map<String, CardLayout> getLayouts()
  {
    return this.layouts;
  }
  
  public void setLayouts(Map<String, CardLayout> paramMap)
  {
    this.layouts = paramMap;
  }
  
  public List<CardLayout> getSelectedLayouts(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    if ((this.layouts == null) || (this.layouts.isEmpty())) {
      return localArrayList;
    }
    Iterator localIterator = this.layouts.values().iterator();
    while (localIterator.hasNext())
    {
      CardLayout localCardLayout = (CardLayout)localIterator.next();
      if (localCardLayout.matchSelector(paramString)) {
        localArrayList.add(localCardLayout);
      }
    }
    return localArrayList;
  }
  
  public CardLayout getLayout(String paramString)
  {
    if (this.layouts == null) {
      return null;
    }
    return (CardLayout)this.layouts.get(paramString);
  }
  
  public CardLayout getLayoutWithDefault(String paramString)
  {
    CardLayout localCardLayout = getLayout(paramString);
    if (localCardLayout == null) {
      localCardLayout = getLayout("default");
    }
    return localCardLayout;
  }
  
  public List<String> getExportableFieldNames()
  {
    ArrayList localArrayList = new ArrayList(this.fields.size());
    int j = this.fields.size();
    for (int i = 0; i < j; i++)
    {
      FieldMeta localFieldMeta = (FieldMeta)this.fields.get(i);
      if (localFieldMeta.isExportable()) {
        localArrayList.add(localFieldMeta.getName());
      }
    }
    return localArrayList;
  }
  
  static String getExtObjFieldName(String paramString1, String paramString2)
  {
    if (paramString1.toLowerCase().endsWith("id")) {
      paramString1 = paramString1.substring(0, paramString1.length() - 2);
    } else {
      paramString1 = paramString1 + "Obj";
    }
    if ("userId".equals(paramString2)) {
      return paramString1 + ".hmName";
    }
    if ("deptId".equals(paramString2)) {
      return paramString1 + ".name";
    }
    return null;
  }
  
  public List<String> getFileFieldNames()
  {
    ArrayList localArrayList = new ArrayList();
    int j = this.fields.size();
    for (int i = 0; i < j; i++)
    {
      FieldMeta localFieldMeta = (FieldMeta)this.fields.get(i);
      String str = localFieldMeta.getType();
      if (("file".equals(str)) || ("fileList".equals(str))) {
        localArrayList.add(localFieldMeta.getName());
      }
    }
    return localArrayList;
  }
  
  public Map<String, String> getShowNameMap()
  {
    Map localMap = getFieldsMap();
    HashMap localHashMap = new HashMap(localMap.size());
    Iterator localIterator = localMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      String str1 = (String)localEntry.getKey();
      FieldMeta localFieldMeta = (FieldMeta)localEntry.getValue();
      String str2 = localFieldMeta.getShowName();
      localHashMap.put(str1, str2);
      if (localFieldMeta.getNameField() != null)
      {
        String str3 = str1 + "." + localFieldMeta.getNameField();
        if (!localHashMap.containsKey(str3)) {
          localHashMap.put(str3, str2);
        }
      }
      if (("userId".equals(localFieldMeta.getType())) || ("deptId".equals(localFieldMeta.getType()))) {
        localHashMap.put(getExtObjFieldName(localFieldMeta.getName(), localFieldMeta.getType()), str2);
      }
    }
    return localHashMap;
  }
  
  public List getKeys()
  {
    return this.keys;
  }
  
  public void setKeys(List paramList)
  {
    this.keys = paramList;
  }
  
  public KeyMeta getKeyById(String paramString)
  {
    if ((this.keys == null) || (paramString == null)) {
      return null;
    }
    int j = this.keys.size();
    for (int i = 0; i < j; i++)
    {
      KeyMeta localKeyMeta = (KeyMeta)this.keys.get(i);
      if (paramString.equals(localKeyMeta.getId())) {
        return localKeyMeta;
      }
    }
    return null;
  }
  
  public boolean isSupportBatchUpdate()
  {
    return this.supportBatchUpdate;
  }
  
  public void setSupportBatchUpdate(boolean paramBoolean)
  {
    this.supportBatchUpdate = paramBoolean;
  }
  
  public boolean isSupportBachAdd()
  {
    return this.supportBatchAdd;
  }
  
  public void setSupportBachAdd(boolean paramBoolean)
  {
    this.supportBatchAdd = paramBoolean;
  }
  
  public List<String> getBatchUpdateFieldNames()
  {
    if (this.fieldGroups != null)
    {
      List localList = (List)this.fieldGroups.get("batchUpdate");
      if (localList != null) {
        return localList;
      }
    }
    int j = this.fields.size();
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < j; i++)
    {
      FieldMeta localFieldMeta = (FieldMeta)this.fields.get(i);
      if (localFieldMeta.isBatchUpdate()) {
        localArrayList.add(localFieldMeta.getName());
      }
    }
    return localArrayList;
  }
  
  public List<String> getBatchUpdatableFieldNames()
  {
    if (this.fieldGroups != null)
    {
      List localList = (List)this.fieldGroups.get("batchUpdatable");
      if (localList != null) {
        return localList;
      }
    }
    int j = this.fields.size();
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < j; i++)
    {
      FieldMeta localFieldMeta = (FieldMeta)this.fields.get(i);
      if (localFieldMeta.isBatchUpdatable()) {
        localArrayList.add(localFieldMeta.getName());
      }
    }
    return localArrayList;
  }
  
  public List<String> getBatchAddableFieldNames()
  {
    if (this.batchAdd == null) {
      return null;
    }
    return this.batchAdd.getAllFields();
  }
  
  public BatchAddMeta getBatchAdd()
  {
    return this.batchAdd;
  }
  
  public void setBatchAdd(BatchAddMeta paramBatchAddMeta)
  {
    this.batchAdd = paramBatchAddMeta;
  }
  
  public boolean isSupportBatchAdd()
  {
    return this.supportBatchAdd;
  }
  
  public boolean isSupportPartition()
  {
    return this.supportPartition;
  }
  
  public void setSupportPartition(boolean paramBoolean)
  {
    this.supportPartition = paramBoolean;
  }
  
  public TplPieceSet getTpls()
  {
    return this.tpls;
  }
  
  public void setTpls(TplPieceSet paramTplPieceSet)
  {
    this.tpls = paramTplPieceSet;
  }
  
  public String getFieldsMetaAsJs(List paramList)
  {
    return getFieldsMetaAsJs(0, paramList, 0);
  }
  
  public String getFieldsMetaAsJs(int paramInt1, List paramList, int paramInt2)
  {
    if (paramList == null) {
      return "[]";
    }
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("[");
    for (int i = 0; i < paramInt1; i++) {
      localStringBuffer.append("{},");
    }
    int j = paramList.size();
    for (i = 0; i < j; i++)
    {
      FieldMeta localFieldMeta = (FieldMeta)this.fieldsMap.get(paramList.get(i));
      if (localFieldMeta == null) {
        throw Exceptions.code("ds.CAN_err_unknown_field").param(paramList.get(i)).param(this.fieldsMap.keySet());
      }
      localStringBuffer.append(localFieldMeta.toJs());
      if (i != j - 1) {
        localStringBuffer.append(",");
      }
    }
    for (i = 0; i < paramInt2; i++) {
      localStringBuffer.append(",{}");
    }
    localStringBuffer.append("]");
    return localStringBuffer.toString();
  }
  
  public void setPrefs(Map<String, EntityPrefConfig> paramMap)
  {
    this.prefs = paramMap;
  }
  
  public EntityPrefConfig getEntityPrefConfig(String paramString)
  {
    if (this.prefs == null) {
      return null;
    }
    return (EntityPrefConfig)this.prefs.get(paramString);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\DataSourceMetaImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */