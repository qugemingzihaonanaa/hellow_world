package edu.thu.model.stg.ds.spi;

import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IVariant;
import edu.thu.model.stg.ds.EnumLoader;
import edu.thu.model.stg.ds.IEnumInfo;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.SystemServiceContext;
import java.io.Serializable;
import java.util.List;

public class GroupMeta
  implements Serializable
{
  private static final long serialVersionUID = 4930095772777635873L;
  String B;
  String A;
  String C;
  
  public GroupMeta() {}
  
  public GroupMeta(TreeNode paramTreeNode)
  {
    this.B = paramTreeNode.attribute("name").stripedStringValue();
    this.A = paramTreeNode.makeChild("groupField").stripedStringValue();
    if (this.A == null) {
      throw Exceptions.code("ds.CAN_err_group_meta_no_group_field");
    }
    this.C = paramTreeNode.makeChild("groupEnum").stripedStringValue();
    if (this.C == null) {
      throw Exceptions.code("ds.CAN_err_group_meta_no_group_enum");
    }
  }
  
  public String getName()
  {
    return this.B;
  }
  
  public void setName(String paramString)
  {
    this.B = paramString;
  }
  
  public String getGroupEnum()
  {
    return this.C;
  }
  
  public void setGroupEnum(String paramString)
  {
    this.C = paramString;
  }
  
  public String getGroupField()
  {
    return this.A;
  }
  
  public void setGroupField(String paramString)
  {
    this.A = paramString;
  }
  
  public List getEnumData()
  {
    if (this.C == null) {
      return null;
    }
    return EnumLoader.loadEnum(this.C, SystemServiceContext.getInstance()).getItems();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\GroupMeta.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */