package edu.thu.model.stg.ds.spi;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.exceptions.StdException;
import edu.thu.model.bean.IBeanBuilder;
import edu.thu.model.data.table.IRowVisitor;
import edu.thu.model.data.table.ITableVisitor;
import edu.thu.model.data.table.TableToListVisitor;
import edu.thu.model.data.table.spi.AccumulateTableVisitor;
import edu.thu.model.data.table.spi.LayerTreeTableVisitor;
import edu.thu.model.data.table.spi.RowColumnVisitor;
import edu.thu.model.data.table.spi.RowToBeanVisitor;
import edu.thu.model.data.table.spi.RowToListVisitor;
import edu.thu.model.data.table.spi.RowToMapVisitor;
import edu.thu.model.data.table.spi.StringRowVisitor;
import edu.thu.model.data.table.spi.TransformRowVisitor;
import edu.thu.model.data.table.spi.TransformTableVisitor;
import edu.thu.model.data.table.spi.TreeNodeRowVisitor;
import edu.thu.model.data.transform.ITransformer;
import edu.thu.model.data.transform.spi.ListTransformer;
import edu.thu.model.tree.TreeNode;
import edu.thu.model.tree.stg.util.TreeBindings;
import edu.thu.search.CategoryName;
import edu.thu.search.IConditionQuery;
import edu.thu.search.IFieldQuery;
import edu.thu.search.IQuery;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DsImpls
  implements DsConstants
{
  public static Object transformResultType(Object paramObject, List paramList, DataSourceMetaImpl paramDataSourceMetaImpl)
  {
    paramObject = _transformResultType(paramObject, paramList, paramDataSourceMetaImpl);
    ListTransformer localListTransformer = null;
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      String str = (String)paramList.get(i);
      ITransformer localITransformer = paramDataSourceMetaImpl.getOutTransformer(str);
      if (localITransformer != null)
      {
        if (localListTransformer == null) {
          localListTransformer = new ListTransformer();
        }
        localListTransformer.setItemTransformer(i, localITransformer);
      }
    }
    if (localListTransformer != null)
    {
      if ((paramObject instanceof IRowVisitor)) {
        paramObject = new TransformRowVisitor((IRowVisitor)paramObject, localListTransformer);
      }
      if ((paramObject instanceof ITableVisitor)) {
        paramObject = new TransformTableVisitor((ITableVisitor)paramObject, localListTransformer);
      }
    }
    return paramObject;
  }
  
  public static Object _transformResultType(Object paramObject, List paramList, DataSourceMetaImpl paramDataSourceMetaImpl)
  {
    if (((paramObject instanceof IRowVisitor)) || ((paramObject instanceof ITableVisitor))) {
      return paramObject;
    }
    if ((paramObject instanceof IBeanBuilder)) {
      return new RowToBeanVisitor((IBeanBuilder)paramObject, paramList);
    }
    if (paramObject == null) {
      paramObject = "getterList";
    }
    if (paramObject.equals("getterList")) {
      return new RowToListVisitor(paramList);
    }
    if (paramObject.equals("getterListMatrix")) {
      return new TableToListVisitor(new RowToListVisitor(paramList));
    }
    if (paramObject.equals("string")) {
      return StringRowVisitor.SINGLETON;
    }
    if (paramObject.equals("object")) {
      return new RowColumnVisitor(0);
    }
    if (paramObject.equals("rowMap")) {
      return new RowToMapVisitor(paramList);
    }
    if (paramObject.equals("rowMapMatrix")) {
      return new TableToListVisitor(new RowToMapVisitor(paramList));
    }
    if (paramObject.equals("rowList")) {
      return new RowToListVisitor();
    }
    if (paramObject.equals("matrix")) {
      return new AccumulateTableVisitor();
    }
    if (paramObject.equals("list")) {
      return new TableToListVisitor(new RowColumnVisitor(0));
    }
    if (paramObject.equals("stringList")) {
      return new TableToListVisitor(new StringRowVisitor());
    }
    if (paramObject.equals("treeNode")) {
      return new TreeNodeRowVisitor(TreeBindings.attributeBindings(paramList));
    }
    if (paramObject.equals("treeNodeList")) {
      return new TableToListVisitor(new TreeNodeRowVisitor(TreeBindings.attributeBindings(paramList)));
    }
    if (paramObject.equals("tree")) {
      return new LayerTreeTableVisitor(paramList, paramDataSourceMetaImpl.getLayerCodeField(), paramDataSourceMetaImpl.getLayerCodeSeparator());
    }
    throw Exceptions.code("ds.CAN_err_ds_unknown_result_type").param(paramObject);
  }
  
  public static List transformFields(IQuery paramIQuery, DataSourceMetaImpl paramDataSourceMetaImpl)
  {
    if (!(paramIQuery instanceof IFieldQuery)) {
      return null;
    }
    List localList = ((IFieldQuery)paramIQuery).getFields();
    if (localList == null) {
      return null;
    }
    int j = localList.size();
    ArrayList localArrayList = new ArrayList(j);
    for (int i = 0; i < j; i++)
    {
      Object localObject = localList.get(i);
      String str = null;
      if ((localObject instanceof CategoryName))
      {
        CategoryName localCategoryName = (CategoryName)localObject;
        str = localCategoryName.getName();
        localObject = paramDataSourceMetaImpl.transToBaseName(str);
        localList.set(i, localObject);
      }
      else if ((localObject instanceof String))
      {
        str = localObject.toString();
        localObject = paramDataSourceMetaImpl.transToBaseName(str);
        localList.set(i, localObject);
      }
      else
      {
        throw Exceptions.code("ds.CAN_err_unknown_field_type").param(localObject);
      }
      localArrayList.add(str);
    }
    return localArrayList;
  }
  
  public static void transformCondition(IQuery paramIQuery, DataSourceMetaImpl paramDataSourceMetaImpl, boolean paramBoolean)
  {
    if (!(paramIQuery instanceof IConditionQuery)) {
      return;
    }
    TreeNode localTreeNode = ((IConditionQuery)paramIQuery).getCondition();
    A(localTreeNode, paramDataSourceMetaImpl, paramBoolean);
  }
  
  static void A(TreeNode paramTreeNode, DataSourceMetaImpl paramDataSourceMetaImpl, boolean paramBoolean)
  {
    if (paramTreeNode == null) {
      return;
    }
    String str = (String)paramTreeNode.getAttribute("name");
    Object localObject2;
    if ((str != null) && (!"dummy".equals(str)) && (!str.startsWith("dummy.q.")))
    {
      FieldMeta localFieldMeta = paramDataSourceMetaImpl.getFieldMeta(str);
      if (localFieldMeta == null) {
        throw Exceptions.code("ds.CAN_err_unknown_field").param(str).param(paramDataSourceMetaImpl.fieldsMap.keySet());
      }
      if (paramBoolean)
      {
        localObject1 = localFieldMeta.getBaseName();
        paramTreeNode.setAttribute("name", localObject1);
      }
      Object localObject1 = localFieldMeta.getInTransformer();
      if (localObject1 != null)
      {
        localObject2 = paramTreeNode.getAttribute("value");
        if (localObject2 != null)
        {
          localObject2 = ((ITransformer)localObject1).transform(localObject2);
          paramTreeNode.setAttribute("value", localObject2);
        }
        else
        {
          localObject2 = paramTreeNode.getAttribute("lowValue");
          if (localObject2 != null)
          {
            localObject2 = ((ITransformer)localObject1).transform(localObject2);
            paramTreeNode.setAttribute("lowValue", localObject2);
          }
          localObject2 = paramTreeNode.getAttribute("highValue");
          if (localObject2 != null)
          {
            localObject2 = ((ITransformer)localObject1).transform(localObject2);
            paramTreeNode.setAttribute("highValue", localObject2);
          }
        }
      }
    }
    int j = paramTreeNode.getChildCount();
    for (int i = 0; i < j; i++)
    {
      localObject2 = paramTreeNode.getChild(i);
      A((TreeNode)localObject2, paramDataSourceMetaImpl, paramBoolean);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\DsImpls.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */