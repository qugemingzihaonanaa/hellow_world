package edu.thu.model.stg.ds.spi;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.util.StringUtils;

public class DbMetaDataUtils
{
  public static String getLocalType(int paramInt)
  {
    switch (paramInt)
    {
    case 12: 
      return "string";
    case 4: 
      return "integer";
    case 8: 
      return "numeric";
    case 6: 
      return "numeric";
    case 2: 
      return "numeric";
    case 7: 
      return "numeric";
    case 91: 
      return "date";
    case 92: 
      return "date";
    case 93: 
      return "date";
    }
    throw Exceptions.code("ds.CAN_err_type_unknown").param(paramInt);
  }
  
  public static String fixBoolType(String paramString)
  {
    String str = StringUtils.chomp(paramString, " ").toLowerCase();
    if (str.equals("true")) {
      return "true";
    }
    if (str.equals("yes")) {
      return "true";
    }
    if (str.equals("false")) {
      return "false";
    }
    if (str.equals("no")) {
      return "false";
    }
    throw Exceptions.code("ds.CAN_err_string_not_be_fixed").param(paramString);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\DbMetaDataUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */