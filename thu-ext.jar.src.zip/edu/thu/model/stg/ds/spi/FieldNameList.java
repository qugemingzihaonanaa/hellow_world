package edu.thu.model.stg.ds.spi;

import edu.thu.lang.exceptions.StdException;
import java.io.Serializable;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.RandomAccess;

public class FieldNameList
  extends AbstractList<String>
  implements RandomAccess, Serializable
{
  private static final long serialVersionUID = -3476970722873745786L;
  final List<String> B;
  final List<String> A;
  boolean C;
  
  public FieldNameList(List<String> paramList1, List<String> paramList2)
  {
    this.B = paramList1;
    this.A = paramList2;
    this.C = true;
  }
  
  public FieldNameList copyForRetailAll(Collection<?> paramCollection)
  {
    ArrayList localArrayList1 = new ArrayList();
    ArrayList localArrayList2 = new ArrayList();
    int i = 0;
    int j = this.B.size();
    while (i < j)
    {
      String str = (String)this.B.get(i);
      if (paramCollection.contains(str))
      {
        localArrayList1.add(str);
        localArrayList2.add((String)this.A.get(i));
      }
      i++;
    }
    return new FieldNameList(localArrayList1, localArrayList2);
  }
  
  public int hashCode()
  {
    return this.B.hashCode();
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    return this.B.equals(paramObject);
  }
  
  public boolean isReadOnly()
  {
    return this.C;
  }
  
  public void setReadOnly(boolean paramBoolean)
  {
    this.C = paramBoolean;
  }
  
  public List<String> getShowNames()
  {
    return this.A;
  }
  
  void A()
  {
    if (this.C) {
      throw new StdException("ds.err_field_name_list_is_read_only").param(this);
    }
  }
  
  public String set(int paramInt, String paramString)
  {
    A();
    return (String)this.B.set(paramInt, paramString);
  }
  
  public boolean add(String paramString)
  {
    A();
    return this.B.add(paramString);
  }
  
  public void add(int paramInt, String paramString)
  {
    A();
    this.B.add(paramInt, paramString);
  }
  
  public String remove(int paramInt)
  {
    A();
    return (String)this.B.remove(paramInt);
  }
  
  public boolean remove(Object paramObject)
  {
    A();
    return this.B.remove(paramObject);
  }
  
  public void clear()
  {
    A();
    this.B.clear();
  }
  
  public boolean addAll(Collection<? extends String> paramCollection)
  {
    A();
    return this.B.addAll(paramCollection);
  }
  
  public boolean addAll(int paramInt, Collection<? extends String> paramCollection)
  {
    A();
    return this.B.addAll(paramInt, paramCollection);
  }
  
  public boolean removeAll(Collection<?> paramCollection)
  {
    A();
    return this.B.removeAll(paramCollection);
  }
  
  public boolean retainAll(Collection<?> paramCollection)
  {
    A();
    return this.B.retainAll(paramCollection);
  }
  
  public String get(int paramInt)
  {
    return (String)this.B.get(paramInt);
  }
  
  public int size()
  {
    return this.B.size();
  }
  
  public List<String> subList(int paramInt1, int paramInt2)
  {
    List localList1 = this.B.subList(paramInt1, paramInt2);
    List localList2 = this.A.subList(paramInt1, paramInt2);
    return new FieldNameList(localList1, localList2);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\FieldNameList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */