package edu.thu.model.stg.ds.spi;

import edu.thu.global.Debug;
import edu.thu.model.data.table.IRowSet;
import edu.thu.model.data.table.spi.RenamedRowSet;
import edu.thu.model.stg.ds.IDataProvider;
import edu.thu.model.stg.ds.IDataSourceUpdator;
import edu.thu.search.IQuery;
import edu.thu.service.IServiceContext;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public class DataSourceUpdatorImpl
  extends DataSourceBase
  implements IDataSourceUpdator
{
  protected Object updater;
  protected IServiceContext context;
  
  public DataSourceUpdatorImpl(Object paramObject, IDataProvider paramIDataProvider, DataSourceMetaImpl paramDataSourceMetaImpl, IServiceContext paramIServiceContext)
  {
    super(paramIDataProvider, paramDataSourceMetaImpl);
    Debug.check(paramObject);
    this.updater = paramObject;
    this.context = paramIServiceContext;
  }
  
  protected Object createThis(IDataProvider paramIDataProvider)
  {
    DataSourceUpdatorImpl localDataSourceUpdatorImpl = new DataSourceUpdatorImpl(this.updater, paramIDataProvider, this.dsMeta, this.context);
    return localDataSourceUpdatorImpl;
  }
  
  public IServiceContext getContext()
  {
    return this.context;
  }
  
  public Object add(Map paramMap)
  {
    this.dsMeta.checkDefaultValues(paramMap);
    paramMap = this.dsMeta.transformIn(paramMap, false, this.updater);
    return this.dp.add(paramMap, this.updater);
  }
  
  public void addMany(Collection paramCollection)
  {
    this.dp.addMany(paramCollection, this.updater);
  }
  
  public void clear()
  {
    this.dp.clear(this.updater);
  }
  
  public int remove(IQuery paramIQuery)
  {
    DsImpls.transformCondition(paramIQuery, this.dsMeta, true);
    return this.dp.remove(paramIQuery, this.updater);
  }
  
  public int update(Map paramMap, IQuery paramIQuery)
  {
    paramMap = this.dsMeta.transformIn(paramMap, true, this.updater);
    DsImpls.transformCondition(paramIQuery, this.dsMeta, true);
    return this.dp.update(paramMap, paramIQuery, this.updater);
  }
  
  public IRowSet selectForUpdate(IQuery paramIQuery)
  {
    DsImpls.transformCondition(paramIQuery, this.dsMeta, true);
    List localList = DsImpls.transformFields(paramIQuery, this.dsMeta);
    IRowSet localIRowSet = this.dp.selectForUpdate(paramIQuery);
    return new RenamedRowSet(localList, localIRowSet);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\DataSourceUpdatorImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */