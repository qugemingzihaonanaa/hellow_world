package edu.thu.model.stg.ds.spi;

import java.util.List;

public class NameIndex
{
  List B;
  int[] A;
  
  public NameIndex(List paramList, int[] paramArrayOfInt)
  {
    this.B = paramList;
    this.A = paramArrayOfInt;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\NameIndex.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */