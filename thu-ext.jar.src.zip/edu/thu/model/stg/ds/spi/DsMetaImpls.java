package edu.thu.model.stg.ds.spi;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.IVariant;
import edu.thu.lang.exceptions.StdException;
import edu.thu.model.tree.TreeNode;

public class DsMetaImpls
  implements DsConstants
{
  public static String getBasePkField(TreeNode paramTreeNode)
  {
    String str = paramTreeNode.makeChild("pkField").stripedStringValue();
    if (str == null) {
      return null;
    }
    TreeNode localTreeNode1 = paramTreeNode.makeChild("fields");
    TreeNode localTreeNode2 = localTreeNode1.childWithAttr("name", str);
    if (localTreeNode2 == null) {
      throw Exceptions.code("ds.CAN_err_unknown_pk_field").param(str).param(paramTreeNode);
    }
    return localTreeNode2.attribute("baseName").stripedStringValue(str);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\DsMetaImpls.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */