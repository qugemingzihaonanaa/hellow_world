package edu.thu.model.stg.ds.spi;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.model.tree.TreeNode;
import java.io.Serializable;
import java.util.List;

public class DataSourceMapping
  extends DataSourceLocation
  implements Serializable
{
  private static final long serialVersionUID = -452116580342096874L;
  String U;
  List T;
  
  public DataSourceMapping(TreeNode paramTreeNode)
  {
    super(paramTreeNode);
  }
  
  public String getKeyField()
  {
    return this.U;
  }
  
  public List getValueFields()
  {
    return this.T;
  }
  
  public void init(TreeNode paramTreeNode)
  {
    super.init(paramTreeNode);
    this.U = paramTreeNode.makeChild("keyField").stripedStringValue();
    if (this.U == null) {
      throw Exceptions.code("ds.CAN_err_reference_no_keyField").param(paramTreeNode);
    }
    this.T = paramTreeNode.makeChild("valueFields").listValue();
    if ((this.T != null) && (this.T.indexOf(null) >= 0)) {
      throw Exceptions.code("ds.CAN_err_mapping_contains_null_value_field").param(paramTreeNode);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\DataSourceMapping.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */