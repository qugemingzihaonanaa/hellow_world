package edu.thu.model.stg.ds.spi;

import edu.thu.global.IFactory;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.global.spi.ProxyFactory;
import edu.thu.lang.IVariant;
import edu.thu.model.stg.ds.IDataSource;
import edu.thu.model.tree.TreeNode;
import edu.thu.service.IUserServiceContext;
import edu.thu.service.SystemServiceContext;
import edu.thu.user.IUserContext;

class A
  extends ProxyFactory
{
  public A(IFactory paramIFactory)
  {
    super(paramIFactory);
  }
  
  public Object getInstance(String paramString, Object paramObject)
  {
    Object localObject = this.factory.getInstance(paramString, paramObject);
    if (!(localObject instanceof IDataSource)) {
      return localObject;
    }
    if ((paramObject instanceof SystemServiceContext)) {
      return localObject;
    }
    IDataSource localIDataSource = (IDataSource)localObject;
    TreeNode localTreeNode = localIDataSource.getMeta();
    boolean bool1 = localTreeNode.attribute("global").booleanValue(false);
    if (bool1) {
      return localIDataSource;
    }
    boolean bool2 = localTreeNode.attribute("secure").booleanValue(false);
    if ((paramObject instanceof IUserServiceContext)) {
      paramObject = ((IUserServiceContext)paramObject).getUserContext();
    }
    if (!(paramObject instanceof IUserContext))
    {
      if (bool2) {
        throw Exceptions.code("ds.CAN_err_no_user_context_provided").param(paramObject);
      }
      return localIDataSource;
    }
    IUserContext localIUserContext = (IUserContext)paramObject;
    return localIDataSource;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\stg\ds\spi\A.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */