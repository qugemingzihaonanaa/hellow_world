package edu.thu.model.data;

import edu.thu.db.IDbColumnData;
import edu.thu.global.Debug;
import edu.thu.java.util.Coercions;
import edu.thu.lang.el.IExpressionReference;
import edu.thu.lang.util.TplC;
import edu.thu.math.alg.Alog;
import edu.thu.model.Pair;
import edu.thu.report.util.WrapCollection;
import edu.thu.util.StringUtils;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class WxTable
  implements Serializable, Iterable<Object>
{
  private static final long serialVersionUID = 7446662100971412729L;
  List<String> I = new ArrayList();
  List<Object> D = new ArrayList();
  Map<Object, Object> F = new HashMap();
  Map<List<String>, Map<Object, List>> C = new HashMap();
  String G;
  String A;
  List<Object> E;
  List<Object> H;
  int B = 6;
  
  public Iterator iterator()
  {
    if (this.D == null) {
      return Collections.EMPTY_LIST.iterator();
    }
    return this.D.iterator();
  }
  
  public Object getFirst()
  {
    new TableMatcher().process(this);
    if (this.D == null) {
      return null;
    }
    return this.D.get(0);
  }
  
  public Map<Object, List> makeDataMapByFields(List<String> paramList)
  {
    Object localObject1 = (Map)this.C.get(paramList);
    if (localObject1 != null) {
      return (Map<Object, List>)localObject1;
    }
    localObject1 = new HashMap();
    Iterator localIterator = this.D.iterator();
    while (localIterator.hasNext())
    {
      Object localObject2 = localIterator.next();
      List localList = getColKeyValues(localObject2, paramList);
      Object localObject3 = (List)((Map)localObject1).get(localList);
      if (localObject3 == null)
      {
        localObject3 = new ArrayList();
        ((Map)localObject1).put(localList, localObject3);
      }
      ((List)localObject3).add(localObject2);
    }
    this.C.put(paramList, localObject1);
    return (Map<Object, List>)localObject1;
  }
  
  public List getDataListByFields(List<String> paramList, List<Object> paramList1)
  {
    Map localMap = makeDataMapByFields(paramList);
    return (List)localMap.get(paramList1);
  }
  
  public Object getFirstDataByFields(List<String> paramList, List<Object> paramList1)
  {
    List localList = getDataListByFields(paramList, paramList1);
    return localList == null ? null : localList.get(0);
  }
  
  public List<Object> getColKeyValues(Object paramObject, List<String> paramList)
  {
    ArrayList localArrayList = new ArrayList(paramList.size());
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      Object localObject = getKeyValue(getColValue(paramObject, str));
      localArrayList.add(localObject);
    }
    return localArrayList;
  }
  
  public int getRoundScale()
  {
    return this.B;
  }
  
  public void setRoundScale(int paramInt)
  {
    this.B = paramInt;
  }
  
  public List<Object> getRowValues()
  {
    return this.H;
  }
  
  public void setRowValues(List<Object> paramList)
  {
    this.H = paramList;
  }
  
  public List<Object> getColValues()
  {
    return this.E;
  }
  
  public void setColValues(List<Object> paramList)
  {
    this.E = paramList;
  }
  
  public String getRowField()
  {
    return this.G;
  }
  
  public void setRowField(String paramString)
  {
    this.G = paramString;
  }
  
  public String getColField()
  {
    return this.A;
  }
  
  public void setColField(String paramString)
  {
    this.A = paramString;
  }
  
  public void setColNames(List<String> paramList)
  {
    this.I = paramList;
  }
  
  public void setComparator(String paramString, Comparator paramComparator) {}
  
  public List<String> getColNames()
  {
    return this.I;
  }
  
  public Map<String, Object> makeRow(List<Object> paramList)
  {
    HashMap localHashMap = new HashMap();
    int j = Math.min(this.I.size(), paramList.size());
    for (int i = 0; i < j; i++)
    {
      String str = (String)this.I.get(i);
      localHashMap.put(str, paramList.get(i));
    }
    return localHashMap;
  }
  
  public static Pair<String, Object> parseRowPair(List paramList)
  {
    if ((paramList == null) || (paramList.isEmpty())) {
      return null;
    }
    String str = Coercions.toString(paramList.get(0), null);
    Object localObject = null;
    if (paramList.size() > 1) {
      localObject = paramList.get(1);
    }
    return new Pair(str, localObject);
  }
  
  public static List<Pair> parseRowPairs(List<List> paramList)
  {
    if (paramList == null) {
      return null;
    }
    int j = paramList.size();
    ArrayList localArrayList = new ArrayList(j);
    for (int i = 0; i < j; i++)
    {
      List localList = (List)paramList.get(i);
      Pair localPair = parseRowPair(localList);
      localArrayList.add(localPair);
    }
    return localArrayList;
  }
  
  public static Map<String, Object> parsePairsToRow(List<List> paramList)
  {
    if (paramList == null) {
      return null;
    }
    int j = paramList.size();
    HashMap localHashMap = new HashMap(j);
    for (int i = 0; i < j; i++)
    {
      List localList = (List)paramList.get(i);
      Pair localPair = parseRowPair(localList);
      if (localPair != null) {
        localHashMap.put((String)localPair.getFirst(), localPair.getSecond());
      }
    }
    return localHashMap;
  }
  
  List<String> A(List<Object> paramList)
  {
    if (paramList == null) {
      return null;
    }
    int j = paramList.size();
    ArrayList localArrayList = new ArrayList(j);
    for (int i = 0; i < j; i++) {
      localArrayList.add(Coercions.toString(paramList.get(i), null));
    }
    return localArrayList;
  }
  
  public void loadData(List<List> paramList, boolean paramBoolean)
  {
    if (paramList.isEmpty()) {
      return;
    }
    int i = 0;
    int j = paramList.size();
    List localList;
    if (paramBoolean)
    {
      localList = (List)paramList.get(0);
      this.I = A(localList);
    }
    for (i = 1; i < j; i++)
    {
      localList = (List)paramList.get(i);
      Map localMap = makeRow(localList);
      addRow(localMap);
    }
  }
  
  public void setData(List<Object> paramList)
  {
    if (paramList == null) {
      paramList = new ArrayList(0);
    }
    this.D = paramList;
  }
  
  public void addRow(Object paramObject)
  {
    this.D.add(paramObject);
  }
  
  public void addColName(String paramString)
  {
    this.I.add(paramString);
  }
  
  public List<Object> getData()
  {
    return this.D;
  }
  
  public int getRowCount()
  {
    return this.D.size();
  }
  
  public Object getRow(int paramInt)
  {
    if ((paramInt >= getRowCount()) || (paramInt < 0)) {
      return null;
    }
    return this.D.get(paramInt);
  }
  
  public Object getColValue(Object paramObject, String paramString)
  {
    if ((paramObject == null) || (paramString == null)) {
      return null;
    }
    return TplC.getProperty(paramObject, paramString);
  }
  
  public Object getCell(int paramInt, String paramString)
  {
    Object localObject = getRow(paramInt);
    return getColValue(localObject, paramString);
  }
  
  public String getCellStr(int paramInt, String paramString)
  {
    return StringUtils.strip(Coercions.toString(getCell(paramInt, paramString), null));
  }
  
  public int getCellInt(int paramInt1, String paramString, int paramInt2)
  {
    return Coercions.toInt(getCellStr(paramInt1, paramString), paramInt2);
  }
  
  public int size()
  {
    return this.D.size();
  }
  
  public double sum(String paramString)
  {
    return sum(paramString, this.B);
  }
  
  double A(String paramString)
  {
    double d = 0.0D;
    int j = this.D.size();
    for (int i = 0; i < j; i++)
    {
      Object localObject = this.D.get(i);
      d += Coercions.toDouble(getColValue(localObject, paramString), 0.0D);
    }
    return d;
  }
  
  public double sum(String paramString, int paramInt)
  {
    double d = A(paramString);
    if (paramInt >= 0) {
      d = Alog.round(Double.valueOf(d), paramInt).doubleValue();
    }
    return d;
  }
  
  public int countBool(String paramString, boolean paramBoolean)
  {
    int i = 0;
    int k = this.D.size();
    for (int j = 0; j < k; j++)
    {
      Object localObject = this.D.get(j);
      if (Coercions.toBoolean(getColValue(localObject, paramString), false) == paramBoolean) {
        i++;
      }
    }
    return i;
  }
  
  public static Object getKeyValue(Object paramObject)
  {
    if (paramObject == null) {
      return null;
    }
    if ((paramObject instanceof IDbColumnData)) {
      return Coercions.toString(((IDbColumnData)paramObject).toDbType(), null);
    }
    if ((paramObject instanceof Map))
    {
      Object localObject = ((Map)paramObject).get("id");
      if (localObject == null) {
        return ((Map)paramObject).get("sid");
      }
    }
    if ((paramObject instanceof Date)) {
      return paramObject;
    }
    return paramObject.toString();
  }
  
  protected boolean isEq(Object paramObject1, Object paramObject2)
  {
    if (paramObject1 == paramObject2) {
      return true;
    }
    if ((paramObject1 == null) || (paramObject2 == null)) {
      return false;
    }
    if (paramObject1.equals(paramObject2)) {
      return true;
    }
    if ((paramObject1 instanceof IDbColumnData)) {
      return ((IDbColumnData)paramObject1).toDbType().toString().equals(paramObject2.toString());
    }
    Object localObject;
    if ((paramObject1 instanceof Map))
    {
      localObject = ((Map)paramObject1).get("id");
      if (localObject == null) {
        return false;
      }
      return localObject.toString().equals(paramObject2.toString());
    }
    if (((paramObject1 instanceof Date)) || ((paramObject2 instanceof Date)))
    {
      localObject = Coercions.toDate(paramObject1, new Date());
      Date localDate = Coercions.toDate(paramObject2, new Date());
      return ((Date)localObject).equals(localDate);
    }
    return paramObject1.toString().equals(paramObject2.toString());
  }
  
  public double sum(String paramString1, String paramString2, Object paramObject)
  {
    double d = 0.0D;
    int j = this.D.size();
    for (int i = 0; i < j; i++)
    {
      Object localObject1 = this.D.get(i);
      Object localObject2 = getColValue(localObject1, paramString1);
      Object localObject3 = getColValue(localObject1, paramString2);
      if (isEq(localObject3, paramObject)) {
        d += Coercions.toDouble(localObject2, 0.0D);
      }
    }
    return d;
  }
  
  protected boolean isEmptyRow(Object paramObject)
  {
    return false;
  }
  
  protected boolean isZeroRow(Object paramObject)
  {
    return false;
  }
  
  public void removeZeroRow()
  {
    Iterator localIterator = this.D.iterator();
    while (localIterator.hasNext()) {
      if (isZeroRow(localIterator.next())) {
        localIterator.remove();
      }
    }
  }
  
  public void removeEmptyRow()
  {
    Iterator localIterator = this.D.iterator();
    while (localIterator.hasNext()) {
      if (isEmptyRow(localIterator.next())) {
        localIterator.remove();
      }
    }
  }
  
  Comparator<Object> B(String paramString)
  {
    return null;
  }
  
  public TreeSet<Object> getValues(String paramString)
  {
    int j = this.D.size();
    TreeSet localTreeSet = new TreeSet(B(paramString));
    for (int i = 0; i < j; i++)
    {
      Object localObject1 = this.D.get(i);
      Object localObject2 = getColValue(localObject1, paramString);
      localTreeSet.add(localObject2);
    }
    return localTreeSet;
  }
  
  public Object r(Object paramObject)
  {
    return getMapData(paramObject, null);
  }
  
  public boolean containsMapData(Object paramObject1, Object paramObject2)
  {
    Object localObject = makeMapKey(paramObject1, paramObject2);
    return this.F.containsKey(localObject);
  }
  
  public Object getMapData(Object paramObject1, Object paramObject2)
  {
    Object localObject = makeMapKey(paramObject1, paramObject2);
    return this.F.get(localObject);
  }
  
  public Map<Object, Object> getDataMap()
  {
    return this.F;
  }
  
  public void loadDataMapFromSql(String paramString1, Map paramMap, String paramString2, String paramString3) {}
  
  public Object makeMapKey(Object paramObject1, Object paramObject2)
  {
    if (this.G == null) {
      return getKeyValue(paramObject2);
    }
    if (this.A == null) {
      return getKeyValue(paramObject1);
    }
    ArrayList localArrayList = new ArrayList(2);
    localArrayList.add(getKeyValue(paramObject1));
    localArrayList.add(getKeyValue(paramObject2));
    return localArrayList;
  }
  
  public Object putMapData(Object paramObject1, Object paramObject2, Object paramObject3)
  {
    Object localObject = makeMapKey(paramObject1, paramObject2);
    return this.F.put(localObject, paramObject3);
  }
  
  public void initDataMap(String paramString1, String paramString2)
  {
    this.A = paramString2;
    this.G = paramString1;
    int j = this.D.size();
    for (int i = 0; i < j; i++)
    {
      Object localObject1 = this.D.get(i);
      Object localObject2 = getColValue(localObject1, paramString1);
      Object localObject3 = getColValue(localObject1, paramString2);
      Object localObject4 = makeMapKey(localObject2, localObject3);
      this.F.put(localObject4, localObject1);
    }
  }
  
  public void fillMapTable(WxTable paramWxTable)
  {
    Object localObject1 = paramWxTable.getRowValues();
    List localList1 = paramWxTable.getColValues();
    List localList2 = paramWxTable.getColNames();
    if (localList2 == null)
    {
      localList2 = A(localList1);
      paramWxTable.setColNames(localList2);
    }
    if ((localObject1 == null) && (this.G != null)) {
      localObject1 = new ArrayList(getValues(this.G));
    }
    if ((localObject1 == null) || (localList1 == null) || (((List)localObject1).isEmpty()) || (localList1.isEmpty())) {
      return;
    }
    ArrayList localArrayList = new ArrayList(((List)localObject1).size());
    int j = ((List)localObject1).size();
    for (int i = 0; i < j; i++)
    {
      Object localObject2 = ((List)localObject1).get(i);
      HashMap localHashMap = new HashMap(localList2.size());
      for (int k = 0; k < localList1.size(); k++)
      {
        Object localObject3 = localList1.get(k);
        Object localObject4 = getMapData(localObject2, localObject3);
        localHashMap.put(localList2.get(i), localObject4);
      }
      localArrayList.add(localHashMap);
    }
    paramWxTable.setData(this.D);
  }
  
  public void sortByFld(String paramString, boolean paramBoolean)
  {
    Alog.sortListByFld(this.D, paramString, paramBoolean);
  }
  
  public void setTP(Object paramObject1, String paramString, Object paramObject2)
  {
    if (paramObject1 == null) {
      return;
    }
    Object localObject = (Map)TplC.getProperty(paramObject1, "_t");
    if (localObject == null)
    {
      localObject = new HashMap();
      TplC.setProperty(paramObject1, "_t", localObject);
    }
    ((Map)localObject).put(paramString, paramObject2);
  }
  
  public void initTransientOrder(String paramString)
  {
    int i = 1;
    Object localObject1 = null;
    int k = this.D.size();
    for (int j = 0; j < k; j++)
    {
      Object localObject2 = this.D.get(j);
      Object localObject3 = getColValue(localObject2, paramString);
      if ((localObject3 == localObject1) || ((localObject3 != null) && (localObject3.equals(localObject1))))
      {
        setTP(localObject2, "order", Integer.valueOf(i));
      }
      else
      {
        localObject1 = localObject3;
        i = j + 1;
        setTP(localObject2, "order", Integer.valueOf(i));
      }
    }
  }
  
  public void pluckTo(WxTable paramWxTable, List<String> paramList)
  {
    Debug.check(paramWxTable.getColNames().size() == paramList.size());
    int j = this.D.size();
    for (int i = 0; i < j; i++)
    {
      Object localObject1 = this.D.get(i);
      HashMap localHashMap = new HashMap(paramList.size());
      for (int k = 0; k < paramList.size(); k++)
      {
        Object localObject2 = getColValue(localObject1, (String)paramList.get(k));
        localHashMap.put((String)paramWxTable.getColNames().get(k), localObject2);
      }
      paramWxTable.addRow(localHashMap);
    }
  }
  
  public TreeMap<Object, List> group(String paramString)
  {
    TreeMap localTreeMap = new TreeMap(B(paramString));
    if (this.D == null) {
      return localTreeMap;
    }
    int j = this.D.size();
    for (int i = 0; i < j; i++)
    {
      Object localObject1 = this.D.get(i);
      Object localObject2 = getColValue(localObject1, paramString);
      Object localObject3 = (List)localTreeMap.get(localObject2);
      if (localObject3 == null)
      {
        localObject3 = new ArrayList();
        localTreeMap.put(localObject2, localObject3);
      }
      ((List)localObject3).add(localObject1);
    }
    return localTreeMap;
  }
  
  public List<Map> group(String paramString, Map<String, IExpressionReference> paramMap)
  {
    TreeMap localTreeMap = group(paramString);
    ArrayList localArrayList = new ArrayList(localTreeMap.size());
    HashMap localHashMap1 = new HashMap();
    Iterator localIterator = localTreeMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      Object localObject = localEntry.getKey();
      List localList = (List)localEntry.getValue();
      HashMap localHashMap2 = new HashMap();
      localHashMap2.put("_groupValue", localObject);
      localHashMap1.put("_", new WrapCollection(localList, localHashMap1));
      A(localHashMap2, paramMap, localHashMap1);
      localArrayList.add(localHashMap2);
    }
    return localArrayList;
  }
  
  void A(Map<String, Object> paramMap1, Map<String, IExpressionReference> paramMap, Map<String, Object> paramMap2)
  {
    Iterator localIterator = paramMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      String str = (String)localEntry.getKey();
      IExpressionReference localIExpressionReference = (IExpressionReference)localEntry.getValue();
      Object localObject = null;
      if (localIExpressionReference != null) {
        localObject = TplC.evaluate(localIExpressionReference, paramMap2);
      }
      paramMap1.put(str, localObject);
    }
  }
  
  public Number percent(Object paramObject, String paramString)
  {
    if ((this.D.isEmpty()) || (((Map)paramObject).isEmpty())) {
      return null;
    }
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\WxTable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */