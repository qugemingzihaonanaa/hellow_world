package edu.thu.model.data.table;

import edu.thu.global.Debug;
import edu.thu.model.stg.view.IPageViewer;
import edu.thu.model.stg.view.Pager;
import java.util.Iterator;
import java.util.List;

public class TablePageProcessor
{
  protected int pageSize = 100;
  protected IPageViewer viewer;
  protected List headers;
  int A = -1;
  
  public TablePageProcessor(List paramList, IPageViewer paramIPageViewer)
  {
    Debug.check(paramIPageViewer);
    this.viewer = paramIPageViewer;
    this.headers = paramList;
  }
  
  public int getMaxCount()
  {
    return this.A;
  }
  
  public void setMaxCount(int paramInt)
  {
    this.A = paramInt;
  }
  
  public TablePageProcessor(List paramList, IPageViewer paramIPageViewer, int paramInt)
  {
    this(paramList, paramIPageViewer);
    Debug.check(paramInt > 0);
  }
  
  public TablePageProcessor(List paramList, Pager paramPager)
  {
    this(paramList, paramPager.getViewer(), paramPager.getPageSize());
  }
  
  public List getHeaders()
  {
    return this.headers;
  }
  
  public void setHeaders(List paramList)
  {
    this.headers = paramList;
  }
  
  public int getPageSize()
  {
    return this.pageSize;
  }
  
  public void setPageSize(int paramInt)
  {
    this.pageSize = paramInt;
  }
  
  public IPageViewer getViewer()
  {
    return this.viewer;
  }
  
  public void setViewer(IPageViewer paramIPageViewer)
  {
    this.viewer = paramIPageViewer;
  }
  
  public Object processByRow(ITableVisitor paramITableVisitor)
  {
    Pager localPager = new Pager(this.viewer, this.pageSize);
    paramITableVisitor.visitBegin(this.headers, (int)localPager.getTotalCount());
    Iterator localIterator = localPager.itemIterator();
    for (int i = 1; localIterator.hasNext(); i++)
    {
      Object localObject = localIterator.next();
      paramITableVisitor.visitRow(localObject, i);
      if ((this.A > 0) && (i >= this.A)) {
        break;
      }
    }
    return paramITableVisitor.visitEnd();
  }
  
  public Object processByPage(ITableVisitor paramITableVisitor)
  {
    Pager localPager = new Pager(this.viewer, this.pageSize);
    paramITableVisitor.visitBegin(this.headers, (int)localPager.getTotalCount());
    Iterator localIterator = localPager.pageIterator();
    int i = 1;
    while (localIterator.hasNext())
    {
      List localList = (List)localIterator.next();
      paramITableVisitor.visitRows(localList, i);
      i += (localList == null ? 0 : localList.size());
    }
    return paramITableVisitor.visitEnd();
  }
  
  public int forEachRow(IRowVisitor paramIRowVisitor)
  {
    Pager localPager = new Pager(this.viewer, this.pageSize);
    paramIRowVisitor.setHeaders(this.headers);
    Iterator localIterator = localPager.itemIterator();
    for (int i = 1; localIterator.hasNext(); i++)
    {
      Object localObject = localIterator.next();
      paramIRowVisitor.visitRow(localObject, i);
      if ((this.A > 0) && (i >= this.A)) {
        break;
      }
    }
    return i - 1;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\TablePageProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */