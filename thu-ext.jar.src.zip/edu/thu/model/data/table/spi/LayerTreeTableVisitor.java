package edu.thu.model.data.table.spi;

import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.exceptions.StdException;
import edu.thu.model.tree.LayerCode;
import edu.thu.model.tree.TreeNode;
import edu.thu.model.tree.stg.ITreeNodeBinding;
import edu.thu.model.tree.stg.util.TreeBindings;
import java.util.List;

public class LayerTreeTableVisitor
  extends AbstractTableVisitor
{
  protected String nodeName;
  protected List bindings;
  static final String DEFAULT_NODE_NAME = "tree";
  ITreeNodeBinding codeBinding;
  char separator;
  TreeNode result;
  TreeNode lastNode;
  LayerCode lastLc;
  
  public LayerTreeTableVisitor(List paramList, ITreeNodeBinding paramITreeNodeBinding, char paramChar)
  {
    Debug.check((paramList != null) && (paramList.size() > 0));
    Debug.check(paramITreeNodeBinding);
    this.bindings = paramList;
    this.codeBinding = paramITreeNodeBinding;
    this.separator = paramChar;
    this.nodeName = "tree";
  }
  
  public LayerTreeTableVisitor(List paramList, String paramString, char paramChar)
  {
    Debug.check((paramList != null) && (paramList.size() > 0));
    Debug.check(paramString);
    this.bindings = TreeBindings.attributeBindings(paramList);
    this.codeBinding = TreeBindings.attributeBinding(paramString);
    this.separator = paramChar;
    this.nodeName = "tree";
  }
  
  public void visitBegin(List paramList, int paramInt)
  {
    this.result = TreeNode.make(this.nodeName);
    this.lastNode = this.result;
  }
  
  public Object visitEnd()
  {
    return this.result;
  }
  
  protected TreeNode parseRow(Object paramObject, int paramInt)
  {
    if (paramObject == null) {
      return null;
    }
    TreeNode localTreeNode = TreeNode.make(this.nodeName);
    int j = this.bindings.size();
    for (int i = 0; i < j; i++)
    {
      ITreeNodeBinding localITreeNodeBinding = (ITreeNodeBinding)this.bindings.get(i);
      Object localObject;
      if ((paramObject instanceof Object[])) {
        localObject = ((Object[])paramObject)[i];
      } else {
        localObject = ((List)paramObject).get(i);
      }
      localITreeNodeBinding.setValue(localTreeNode, localObject);
    }
    return localTreeNode;
  }
  
  public boolean visitRow(Object paramObject, int paramInt)
  {
    TreeNode localTreeNode = parseRow(paramObject, paramInt);
    String str = (String)this.codeBinding.getValue(localTreeNode);
    LayerCode localLayerCode = new LayerCode(str, this.separator);
    this.codeBinding.setValue(localTreeNode, localLayerCode);
    if (this.lastLc == null)
    {
      Debug.check(this.result == this.lastNode);
      this.lastLc = localLayerCode;
      this.lastNode.appendChild(localTreeNode);
      this.lastNode = localTreeNode;
    }
    else
    {
      if (!localLayerCode.canFollow(this.lastLc)) {
        throw Exceptions.code("tree.CAN_err_layer_tree_invalid_layer").param(localLayerCode).param(this.lastLc);
      }
      int i = localLayerCode.getLevel();
      for (int j = this.lastLc.getLevel(); j >= i; j--) {
        this.lastNode = this.lastNode.getParent();
      }
      this.lastNode.appendChild(localTreeNode);
      this.lastLc = localLayerCode;
      this.lastNode = localTreeNode;
    }
    return true;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\LayerTreeTableVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */