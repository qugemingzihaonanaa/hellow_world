package edu.thu.model.data.table.spi;

import edu.thu.db.SqlQueryResult;

public class SqlResultRowSet
  extends RsRowSet
{
  SqlQueryResult sr;
  
  public SqlResultRowSet(SqlQueryResult paramSqlQueryResult)
  {
    super(paramSqlQueryResult.resultSet());
    this.sr = paramSqlQueryResult;
  }
  
  public void close()
  {
    this.sr.close();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\SqlResultRowSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */