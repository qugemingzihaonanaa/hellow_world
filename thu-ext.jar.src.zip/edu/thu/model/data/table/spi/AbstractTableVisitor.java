package edu.thu.model.data.table.spi;

import edu.thu.model.data.table.ITableVisitor;
import java.util.List;

public abstract class AbstractTableVisitor
  implements ITableVisitor
{
  public boolean supportFeature(int paramInt)
  {
    return false;
  }
  
  public void visitBegin(List paramList, int paramInt) {}
  
  public boolean visitRows(List paramList, int paramInt)
  {
    if (paramList == null) {
      return true;
    }
    int j = paramList.size();
    for (int i = 0; i < j; i++) {
      if (!visitRow(paramList.get(i), paramInt + i)) {
        return false;
      }
    }
    return true;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\AbstractTableVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */