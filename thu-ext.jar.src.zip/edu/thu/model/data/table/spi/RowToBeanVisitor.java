package edu.thu.model.data.table.spi;

import edu.thu.model.bean.IBeanBuilder;
import edu.thu.service.SystemServiceContext;
import java.util.List;
import java.util.Map;

public class RowToBeanVisitor
  extends RowToMapVisitor
{
  IBeanBuilder builder;
  
  public RowToBeanVisitor(IBeanBuilder paramIBeanBuilder)
  {
    this.builder = paramIBeanBuilder;
  }
  
  public RowToBeanVisitor(IBeanBuilder paramIBeanBuilder, List paramList)
  {
    super(paramList);
    this.builder = paramIBeanBuilder;
  }
  
  public Object visitRow(Object paramObject, int paramInt)
  {
    if ((paramObject instanceof Map)) {
      return this.builder.buildBean((Map)paramObject, SystemServiceContext.getInstance());
    }
    Map localMap = (Map)super.visitRow(paramObject, paramInt);
    return this.builder.buildBean(localMap, SystemServiceContext.getInstance());
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\RowToBeanVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */