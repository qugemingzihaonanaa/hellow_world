package edu.thu.model.data.table.spi;

import edu.thu.global.Debug;
import edu.thu.model.tree.ITreeBuilder;
import edu.thu.model.tree.util.TreeBuilder;
import edu.thu.model.tree.util.XmlTreeBuilder;
import java.util.List;
import java.util.Map;

public class BuildTreeVisitor
  extends AbstractTableVisitor
{
  ITreeBuilder tb;
  String rootName = "tree";
  String nodeName = "li";
  List headers;
  
  public BuildTreeVisitor(ITreeBuilder paramITreeBuilder)
  {
    Debug.check(paramITreeBuilder);
    this.tb = paramITreeBuilder;
  }
  
  public static BuildTreeVisitor forXml()
  {
    return new BuildTreeVisitor(new XmlTreeBuilder());
  }
  
  public static BuildTreeVisitor forNode()
  {
    return new BuildTreeVisitor(new TreeBuilder());
  }
  
  public void setRootName(String paramString)
  {
    Debug.check(paramString);
    this.rootName = paramString;
  }
  
  public void setNodeName(String paramString)
  {
    Debug.check(paramString);
    this.nodeName = paramString;
  }
  
  public boolean supportFeature(int paramInt)
  {
    return paramInt == 1;
  }
  
  public void visitBegin(List paramList, int paramInt)
  {
    this.headers = paramList;
    this.tb.node(this.rootName).down();
  }
  
  public Object visitEnd()
  {
    return this.tb.up().end();
  }
  
  public boolean visitRow(Object paramObject, int paramInt)
  {
    Map localMap = VisitorImpls.toMap(paramObject, this.headers);
    this.tb.node(this.nodeName, localMap, null);
    return false;
  }
  
  public Object process(List paramList1, List paramList2)
  {
    int j = paramList2.size();
    visitBegin(paramList1, j);
    for (int i = 0; i < j; i++) {
      visitRow(paramList2.get(i), i);
    }
    return visitEnd();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\BuildTreeVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */