package edu.thu.model.data.table.spi;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.lang.exceptions.StdException;
import edu.thu.model.data.table.IRowSet;
import java.util.List;

public class RenamedRowSet
  extends ProxyRowSet
{
  List headers;
  
  public RenamedRowSet(List paramList, IRowSet paramIRowSet)
  {
    super(paramIRowSet);
    this.headers = paramList;
  }
  
  public List getHeaders()
  {
    return this.headers;
  }
  
  int getIndex(String paramString)
  {
    int i = this.headers.indexOf(paramString);
    if (i < 0) {
      throw Exceptions.code("table.CAN_err_unknown_field").param(paramString).param(this.headers);
    }
    return i;
  }
  
  public Object getObject(String paramString)
  {
    return this.rs.getObject(getIndex(paramString) + 1);
  }
  
  public void setObject(String paramString, Object paramObject)
  {
    this.rs.setObject(getIndex(paramString) + 1, paramObject);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\RenamedRowSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */