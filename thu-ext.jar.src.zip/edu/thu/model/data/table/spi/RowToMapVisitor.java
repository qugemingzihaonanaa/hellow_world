package edu.thu.model.data.table.spi;

import edu.thu.global.Debug;
import java.util.List;

public class RowToMapVisitor
  extends AbstractRowVisitor
{
  List headers;
  
  public RowToMapVisitor() {}
  
  public RowToMapVisitor(List paramList)
  {
    this.headers = paramList;
  }
  
  public boolean supportFeature(int paramInt)
  {
    return (this.headers == null) && (paramInt == 1);
  }
  
  public void setHeaders(List paramList)
  {
    Debug.check((paramList != null) && (paramList.size() > 0));
    this.headers = paramList;
  }
  
  public Object visitRow(Object paramObject, int paramInt)
  {
    return VisitorImpls.toMap(paramObject, this.headers);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\RowToMapVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */