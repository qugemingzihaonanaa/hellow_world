package edu.thu.model.data.table.spi;

import edu.thu.global.Debug;
import edu.thu.model.data.table.ITableVisitor;
import edu.thu.model.data.transform.ITransformer;
import java.util.List;

public class TransformTableVisitor
  implements ITableVisitor
{
  ITableVisitor visitor;
  ITransformer transformer;
  
  public TransformTableVisitor(ITableVisitor paramITableVisitor, ITransformer paramITransformer)
  {
    Debug.check(paramITableVisitor);
    Debug.check(paramITransformer);
    this.visitor = paramITableVisitor;
    this.transformer = paramITransformer;
  }
  
  public boolean supportFeature(int paramInt)
  {
    return this.visitor.supportFeature(paramInt);
  }
  
  public void visitBegin(List paramList, int paramInt)
  {
    this.visitor.visitBegin(paramList, paramInt);
  }
  
  public Object visitEnd()
  {
    return this.visitor.visitEnd();
  }
  
  public boolean visitRow(Object paramObject, int paramInt)
  {
    paramObject = this.transformer.transform(paramObject);
    return this.visitor.visitRow(paramObject, paramInt);
  }
  
  public boolean visitRows(List paramList, int paramInt)
  {
    if (paramList != null)
    {
      int j = paramList.size();
      for (int i = 0; i < j; i++)
      {
        Object localObject = paramList.get(i);
        localObject = this.transformer.transform(localObject);
        paramList.set(i, localObject);
      }
    }
    return this.visitor.visitRows(paramList, paramInt);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\TransformTableVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */