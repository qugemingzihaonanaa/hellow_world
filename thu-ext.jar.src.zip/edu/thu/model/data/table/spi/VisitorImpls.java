package edu.thu.model.data.table.spi;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import java.util.List;
import java.util.Map;

public class VisitorImpls
{
  public static Map toMap(Object paramObject, List paramList)
  {
    if (paramObject == null) {
      return null;
    }
    if ((paramObject instanceof Map)) {
      return (Map)paramObject;
    }
    A localA = new A(paramList.size());
    Object localObject;
    int j;
    int i;
    if ((paramObject instanceof List))
    {
      localObject = (List)paramObject;
      j = paramList.size();
      for (i = 0; i < j; i++) {
        localA.put(paramList.get(i), ((List)localObject).get(i));
      }
    }
    else if ((paramObject instanceof Object[]))
    {
      localObject = (Object[])paramObject;
      j = paramList.size();
      for (i = 0; i < j; i++) {
        localA.put(paramList.get(i), localObject[i]);
      }
    }
    else
    {
      throw Exceptions.code("table.CAN_err_row_to_map_unknown_row_type").param(paramObject);
    }
    return localA;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\VisitorImpls.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */