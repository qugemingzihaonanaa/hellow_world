package edu.thu.model.data.table.spi;

import edu.thu.global.Debug;
import edu.thu.model.data.table.ITableVisitor;
import java.util.ArrayList;
import java.util.List;

public class BufferedTableVisitor
  implements ITableVisitor
{
  ITableVisitor visitor;
  List rows;
  int bufSize;
  
  public BufferedTableVisitor(ITableVisitor paramITableVisitor, int paramInt)
  {
    Debug.check(paramITableVisitor);
    Debug.check(paramInt > 0);
    this.visitor = paramITableVisitor;
    this.bufSize = paramInt;
    this.rows = new ArrayList(paramInt);
  }
  
  public boolean supportFeature(int paramInt)
  {
    return this.visitor.supportFeature(paramInt);
  }
  
  public void visitBegin(List paramList, int paramInt)
  {
    this.visitor.visitBegin(paramList, paramInt);
  }
  
  public Object visitEnd()
  {
    return this.visitor.visitEnd();
  }
  
  public boolean visitRow(Object paramObject, int paramInt)
  {
    this.rows.add(paramObject);
    if (this.rows.size() >= this.bufSize)
    {
      boolean bool = this.visitor.visitRows(this.rows, -1);
      this.rows.clear();
      return bool;
    }
    return false;
  }
  
  public boolean visitRows(List paramList, int paramInt)
  {
    paramList.addAll(paramList);
    if (paramList.size() >= this.bufSize)
    {
      boolean bool = this.visitor.visitRows(paramList, -1);
      paramList.clear();
      return bool;
    }
    return false;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\BufferedTableVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */