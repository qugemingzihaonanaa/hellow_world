package edu.thu.model.data.table.spi;

import edu.thu.global.Debug;
import edu.thu.model.data.table.IRowVisitor;
import edu.thu.model.data.transform.ITransformer;
import java.util.List;

public class TransformRowVisitor
  implements IRowVisitor
{
  IRowVisitor visitor;
  ITransformer transformer;
  
  public TransformRowVisitor(IRowVisitor paramIRowVisitor, ITransformer paramITransformer)
  {
    Debug.check(paramIRowVisitor);
    Debug.check(paramITransformer);
    this.visitor = paramIRowVisitor;
    this.transformer = paramITransformer;
  }
  
  public void setHeaders(List paramList)
  {
    this.visitor.setHeaders(paramList);
  }
  
  public List getHeaders()
  {
    return this.visitor.getHeaders();
  }
  
  public boolean supportFeature(int paramInt)
  {
    return this.visitor.supportFeature(paramInt);
  }
  
  public Object visitRow(Object paramObject, int paramInt)
  {
    paramObject = this.transformer.transform(paramObject);
    Object localObject = this.visitor.visitRow(paramObject, paramInt);
    return localObject;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\TransformRowVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */