package edu.thu.model.data.table.spi;

import edu.thu.global.Debug;
import edu.thu.model.data.table.IRowVisitor;
import edu.thu.model.data.table.ITableVisitor;
import java.util.List;

public class TableRowVisitorAdaptor
  implements ITableVisitor
{
  IRowVisitor visitor;
  Object result;
  
  public TableRowVisitorAdaptor(IRowVisitor paramIRowVisitor)
  {
    Debug.check(paramIRowVisitor);
    this.visitor = paramIRowVisitor;
  }
  
  public boolean supportFeature(int paramInt)
  {
    return this.visitor.supportFeature(paramInt);
  }
  
  public void visitBegin(List paramList, int paramInt)
  {
    if (this.visitor.supportFeature(1)) {
      this.visitor.setHeaders(paramList);
    }
  }
  
  public Object visitEnd()
  {
    return this.result;
  }
  
  public boolean visitRow(Object paramObject, int paramInt)
  {
    this.result = this.visitor.visitRow(paramObject, paramInt);
    return false;
  }
  
  public boolean visitRows(List paramList, int paramInt)
  {
    if (paramList == null) {
      return true;
    }
    return visitRow(paramList.get(0), paramInt);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\TableRowVisitorAdaptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */