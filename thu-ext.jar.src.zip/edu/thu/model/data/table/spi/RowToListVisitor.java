package edu.thu.model.data.table.spi;

import edu.thu.global.Debug;
import edu.thu.model.data.table.IRowVisitor;
import edu.thu.model.data.transform.ITransformer;
import edu.thu.set.list.GetterList;
import java.util.Arrays;
import java.util.List;

public class RowToListVisitor
  implements IRowVisitor, ITransformer
{
  List headers;
  boolean useHeaders = true;
  
  public RowToListVisitor() {}
  
  public RowToListVisitor(List paramList)
  {
    Debug.check((paramList != null) && (paramList.size() > 0));
    this.headers = paramList;
  }
  
  public boolean supportFeature(int paramInt)
  {
    return (this.headers == null) && (this.useHeaders) && (paramInt == 1);
  }
  
  public void setUseHeaders(boolean paramBoolean)
  {
    this.useHeaders = paramBoolean;
  }
  
  public void setHeaders(List paramList)
  {
    this.headers = paramList;
  }
  
  public List getHeaders()
  {
    return this.headers;
  }
  
  public Object visitRow(Object paramObject, int paramInt)
  {
    if (paramObject == null) {
      return null;
    }
    Object localObject;
    if ((paramObject instanceof Object[])) {
      localObject = Arrays.asList((Object[])paramObject);
    } else {
      localObject = (List)paramObject;
    }
    if (this.headers != null) {
      localObject = new GetterList(this.headers, (List)localObject);
    }
    return localObject;
  }
  
  public Object transform(Object paramObject)
  {
    return visitRow(paramObject, -1);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\RowToListVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */