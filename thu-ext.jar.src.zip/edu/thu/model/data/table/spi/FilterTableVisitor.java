package edu.thu.model.data.table.spi;

import edu.thu.global.Debug;
import edu.thu.global.IFilter;
import edu.thu.model.data.table.ITableVisitor;
import java.util.List;

public class FilterTableVisitor
  implements ITableVisitor
{
  ITableVisitor visitor;
  IFilter filter;
  
  public FilterTableVisitor(ITableVisitor paramITableVisitor, IFilter paramIFilter)
  {
    Debug.check(paramITableVisitor);
    Debug.check(paramIFilter);
    this.visitor = paramITableVisitor;
    this.filter = paramIFilter;
  }
  
  public boolean supportFeature(int paramInt)
  {
    return this.visitor.supportFeature(paramInt);
  }
  
  public Object visitEnd()
  {
    return this.visitor.visitEnd();
  }
  
  public void visitBegin(List paramList, int paramInt)
  {
    this.visitor.visitBegin(paramList, -1);
  }
  
  public boolean visitRow(Object paramObject, int paramInt)
  {
    if (this.filter.accept(paramObject)) {
      return this.visitor.visitRow(paramObject, paramInt);
    }
    return true;
  }
  
  public boolean visitRows(List paramList, int paramInt)
  {
    if (paramList == null) {
      return true;
    }
    int j = paramList.size();
    for (int i = 0; i < j; i++) {
      if (!visitRow(paramList.get(i), paramInt + i)) {
        return false;
      }
    }
    return true;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\FilterTableVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */