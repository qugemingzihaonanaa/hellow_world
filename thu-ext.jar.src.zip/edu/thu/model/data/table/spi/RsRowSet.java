package edu.thu.model.data.table.spi;

import edu.thu.db.DbException;
import edu.thu.db.util.RsUtils;
import edu.thu.global.Debug;
import edu.thu.model.data.table.IScrollableRowSet;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class RsRowSet
  implements IScrollableRowSet
{
  protected ResultSet rs;
  protected volatile boolean closed = false;
  
  public RsRowSet(ResultSet paramResultSet)
  {
    Debug.check(paramResultSet);
    this.rs = paramResultSet;
  }
  
  public void deleteRow()
  {
    try
    {
      this.rs.deleteRow();
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public Object getObject(int paramInt)
  {
    try
    {
      return this.rs.getObject(paramInt);
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public void setObject(int paramInt, Object paramObject)
  {
    try
    {
      if (paramObject == null) {
        this.rs.updateNull(paramInt);
      } else {
        this.rs.updateObject(paramInt, transValue(paramObject));
      }
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public Object getObject(String paramString)
  {
    try
    {
      return this.rs.getObject(paramString);
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public void insertRow()
  {
    try
    {
      this.rs.insertRow();
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public boolean next()
  {
    try
    {
      return this.rs.next();
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public void setObject(String paramString, Object paramObject)
  {
    try
    {
      this.rs.updateObject(paramString, transValue(paramObject));
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public void updateRow()
  {
    try
    {
      this.rs.updateRow();
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public boolean absolute(int paramInt)
  {
    try
    {
      return this.rs.absolute(paramInt);
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public void afterLast()
  {
    try
    {
      this.rs.afterLast();
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public void beforeFirst()
  {
    try
    {
      this.rs.beforeFirst();
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public boolean first()
  {
    try
    {
      return this.rs.first();
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public boolean isAfterLast()
  {
    try
    {
      return this.rs.isAfterLast();
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public boolean isBeforeFirst()
  {
    try
    {
      return this.rs.isBeforeFirst();
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public boolean isFirst()
  {
    try
    {
      return this.rs.isFirst();
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public boolean isLast()
  {
    try
    {
      return this.rs.isLast();
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public boolean isScrollable()
  {
    try
    {
      return this.rs.getType() != 1003;
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public boolean last()
  {
    try
    {
      return this.rs.last();
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public boolean previous()
  {
    try
    {
      return this.rs.previous();
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public boolean isReadOnly()
  {
    try
    {
      return this.rs.getConcurrency() == 1007;
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public void close()
  {
    try
    {
      this.closed = true;
      this.rs.close();
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public boolean isClosed()
  {
    return this.closed;
  }
  
  public int getRow()
  {
    try
    {
      return this.rs.getRow();
    }
    catch (SQLException localSQLException)
    {
      throw new DbException(localSQLException);
    }
  }
  
  public List getHeaders()
  {
    return Arrays.asList(RsUtils.getColumnNames(this.rs));
  }
  
  static Object transValue(Object paramObject)
  {
    if ((paramObject != null) && (paramObject.getClass() == Date.class)) {
      return new Timestamp(((Date)paramObject).getTime());
    }
    return paramObject;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\RsRowSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */