package edu.thu.model.data.table.spi;

import edu.thu.global.Debug;
import edu.thu.model.data.table.IRowVisitor;
import edu.thu.model.tree.TreeNode;
import edu.thu.model.tree.stg.ITreeNodeBinding;
import edu.thu.model.tree.stg.util.TreeBindings;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TreeNodeRowVisitor
  implements IRowVisitor
{
  protected String nodeName;
  protected List headers;
  protected List bindings;
  
  public TreeNodeRowVisitor(List paramList)
  {
    this(paramList, "li");
  }
  
  public TreeNodeRowVisitor(List paramList, String paramString)
  {
    Debug.check((paramList != null) && (paramList.size() > 0));
    Debug.check(paramString);
    this.bindings = paramList;
    this.nodeName = paramString;
    this.headers = getBindNames(paramList);
  }
  
  List getBindNames(List paramList)
  {
    ArrayList localArrayList = new ArrayList(paramList.size());
    int j = localArrayList.size();
    for (int i = 0; i < j; i++)
    {
      ITreeNodeBinding localITreeNodeBinding = (ITreeNodeBinding)paramList.get(i);
      localArrayList.add(i, localITreeNodeBinding.getName());
    }
    return localArrayList;
  }
  
  public TreeNodeRowVisitor()
  {
    this.nodeName = "li";
  }
  
  public List getHeaders()
  {
    return this.headers;
  }
  
  public void setHeaders(List paramList)
  {
    this.headers = paramList;
    this.bindings = TreeBindings.attributeBindings(paramList);
  }
  
  public boolean supportFeature(int paramInt)
  {
    return (this.bindings == null) && (paramInt == 1);
  }
  
  public Object visitRow(Object paramObject, int paramInt)
  {
    if (paramObject == null) {
      return null;
    }
    if ((paramObject instanceof Object[])) {
      paramObject = Arrays.asList((Object[])paramObject);
    }
    List localList = (List)paramObject;
    TreeNode localTreeNode = TreeNode.make(this.nodeName);
    int j = this.bindings.size();
    for (int i = 0; i < j; i++)
    {
      ITreeNodeBinding localITreeNodeBinding = (ITreeNodeBinding)this.bindings.get(i);
      Object localObject = localList.get(i);
      localITreeNodeBinding.setValue(localTreeNode, localObject);
    }
    return localTreeNode;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\TreeNodeRowVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */