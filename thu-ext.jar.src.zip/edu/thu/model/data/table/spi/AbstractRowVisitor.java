package edu.thu.model.data.table.spi;

import edu.thu.model.data.table.IRowVisitor;
import edu.thu.model.data.transform.ITransformer;
import java.util.List;

public abstract class AbstractRowVisitor
  implements IRowVisitor, ITransformer
{
  public void setHeaders(List paramList) {}
  
  public List getHeaders()
  {
    return null;
  }
  
  public boolean supportFeature(int paramInt)
  {
    return false;
  }
  
  public Object transform(Object paramObject)
  {
    return visitRow(paramObject, -1);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\AbstractRowVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */