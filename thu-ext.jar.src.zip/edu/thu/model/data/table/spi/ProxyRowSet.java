package edu.thu.model.data.table.spi;

import edu.thu.global.Debug;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.model.data.IScrollable;
import edu.thu.model.data.table.IRowSet;
import java.util.List;

public class ProxyRowSet
  implements IRowSet, IScrollable
{
  protected IRowSet rs;
  
  public ProxyRowSet(IRowSet paramIRowSet)
  {
    Debug.check(paramIRowSet);
    this.rs = paramIRowSet;
  }
  
  public void close()
  {
    this.rs.close();
  }
  
  public void deleteRow()
  {
    this.rs.deleteRow();
  }
  
  public List getHeaders()
  {
    return this.rs.getHeaders();
  }
  
  public Object getObject(String paramString)
  {
    return this.rs.getObject(paramString);
  }
  
  public Object getObject(int paramInt)
  {
    return this.rs.getObject(paramInt);
  }
  
  public void setObject(int paramInt, Object paramObject)
  {
    this.rs.setObject(paramInt, paramObject);
  }
  
  public void insertRow()
  {
    this.rs.insertRow();
  }
  
  public boolean isClosed()
  {
    return this.rs.isClosed();
  }
  
  public boolean isReadOnly()
  {
    return this.rs.isReadOnly();
  }
  
  public boolean next()
  {
    return this.rs.next();
  }
  
  public void setObject(String paramString, Object paramObject)
  {
    this.rs.setObject(paramString, paramObject);
  }
  
  public void updateRow()
  {
    this.rs.updateRow();
  }
  
  void checkScrollable()
  {
    if (!(this.rs instanceof IScrollable)) {
      throw Exceptions.code("rs.CAN_err_row_set_not_scrollable");
    }
  }
  
  public boolean absolute(int paramInt)
  {
    checkScrollable();
    return ((IScrollable)this.rs).absolute(paramInt);
  }
  
  public void afterLast()
  {
    checkScrollable();
    ((IScrollable)this.rs).afterLast();
  }
  
  public void beforeFirst()
  {
    checkScrollable();
    ((IScrollable)this.rs).beforeFirst();
  }
  
  public boolean first()
  {
    checkScrollable();
    return ((IScrollable)this.rs).first();
  }
  
  public int getRow()
  {
    checkScrollable();
    return ((IScrollable)this.rs).getRow();
  }
  
  public boolean isAfterLast()
  {
    checkScrollable();
    return ((IScrollable)this.rs).isAfterLast();
  }
  
  public boolean isBeforeFirst()
  {
    checkScrollable();
    return ((IScrollable)this.rs).isBeforeFirst();
  }
  
  public boolean isFirst()
  {
    checkScrollable();
    return ((IScrollable)this.rs).isFirst();
  }
  
  public boolean isLast()
  {
    checkScrollable();
    return ((IScrollable)this.rs).isLast();
  }
  
  public boolean isScrollable()
  {
    if (!(this.rs instanceof IScrollable)) {
      return false;
    }
    return ((IScrollable)this.rs).isScrollable();
  }
  
  public boolean last()
  {
    checkScrollable();
    return ((IScrollable)this.rs).last();
  }
  
  public boolean previous()
  {
    checkScrollable();
    return ((IScrollable)this.rs).previous();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\ProxyRowSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */