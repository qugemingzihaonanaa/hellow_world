package edu.thu.model.data.table.spi;

import java.util.List;

public class StringRowVisitor
  extends AbstractRowVisitor
{
  public static final StringRowVisitor SINGLETON = new StringRowVisitor();
  
  public Object visitRow(Object paramObject, int paramInt)
  {
    if (paramObject == null) {
      return null;
    }
    Object localObject;
    if ((paramObject instanceof Object[])) {
      localObject = ((Object[])paramObject)[0];
    } else {
      localObject = ((List)paramObject).get(0);
    }
    return localObject == null ? null : localObject.toString();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\StringRowVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */