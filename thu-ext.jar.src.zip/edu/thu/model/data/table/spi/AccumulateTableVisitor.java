package edu.thu.model.data.table.spi;

import edu.thu.model.data.table.ITableVisitor;
import java.util.ArrayList;
import java.util.List;

public class AccumulateTableVisitor
  implements ITableVisitor
{
  List result;
  
  public boolean supportFeature(int paramInt)
  {
    return false;
  }
  
  public void visitBegin(List paramList, int paramInt)
  {
    this.result = (paramInt > 0 ? new ArrayList(paramInt) : new ArrayList());
  }
  
  public Object visitEnd()
  {
    return this.result;
  }
  
  public boolean visitRow(Object paramObject, int paramInt)
  {
    this.result.add(paramObject);
    return true;
  }
  
  public boolean visitRows(List paramList, int paramInt)
  {
    if (paramList == null) {
      return true;
    }
    this.result.addAll(paramList);
    return true;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\AccumulateTableVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */