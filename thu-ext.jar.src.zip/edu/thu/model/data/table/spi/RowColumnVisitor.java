package edu.thu.model.data.table.spi;

import edu.thu.global.Debug;
import java.util.List;

public class RowColumnVisitor
  extends AbstractRowVisitor
{
  int columnIndex = 0;
  
  public RowColumnVisitor(int paramInt)
  {
    setColumnIndex(paramInt);
  }
  
  public void setColumnIndex(int paramInt)
  {
    Debug.check(paramInt >= 0);
    this.columnIndex = paramInt;
  }
  
  public Object visitRow(Object paramObject, int paramInt)
  {
    if (paramObject == null) {
      return null;
    }
    if ((paramObject instanceof Object[])) {
      return ((Object[])paramObject)[this.columnIndex];
    }
    return ((List)paramObject).get(this.columnIndex);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\RowColumnVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */