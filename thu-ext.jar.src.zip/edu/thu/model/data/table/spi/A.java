package edu.thu.model.data.table.spi;

import edu.thu.lang.IGetter;
import java.util.HashMap;

class A
  extends HashMap
  implements IGetter
{
  private static final long serialVersionUID = 8452490548498284677L;
  
  public A() {}
  
  public A(int paramInt)
  {
    super(paramInt);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\table\spi\A.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */