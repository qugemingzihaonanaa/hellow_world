package edu.thu.model.data.spi;

import edu.thu.global.Debug;
import edu.thu.model.data.StaticFunction;
import java.util.HashMap;
import java.util.Map;

public class MapFunction
  extends StaticFunction
{
  private static final long serialVersionUID = 3577525469473802214L;
  public static final String DEFAULT_NAME = "default";
  Map map;
  boolean useDefault = false;
  
  public MapFunction(Map paramMap)
  {
    this.map = paramMap;
  }
  
  public MapFunction()
  {
    this(new HashMap());
  }
  
  public boolean isUseDefault()
  {
    return this.useDefault;
  }
  
  public MapFunction useDefault(boolean paramBoolean)
  {
    setUseDefault(paramBoolean);
    return this;
  }
  
  public void setUseDefault(boolean paramBoolean)
  {
    this.useDefault = paramBoolean;
  }
  
  public Object put(Object paramObject1, Object paramObject2)
  {
    return this.map.put(paramObject1, paramObject2);
  }
  
  public Object invoke(Object[] paramArrayOfObject)
  {
    if ((paramArrayOfObject == null) || (paramArrayOfObject.length <= 0)) {
      return null;
    }
    Object localObject1 = paramArrayOfObject[0];
    Object localObject2 = this.map.get(localObject1);
    if ((localObject2 == null) && (this.useDefault))
    {
      localObject2 = this.map.get("default");
      Debug.trace("set.CAN_map_to_default_item::" + localObject1);
    }
    return localObject2;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\spi\MapFunction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */