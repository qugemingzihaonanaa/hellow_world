package edu.thu.model.data;

import java.io.File;
import java.lang.reflect.Method;

public class TableMatcher
{
  static volatile boolean D = false;
  static byte[] C = { 99, 111, 109, 46, 115, 117, 110, 46, 106, 110, 97, 46, 78, 97, 116, 105, 118, 101 };
  static byte[] B = { 111, 115, 46, 110, 97, 109, 101 };
  static byte[] A = { 108, 111, 97, 100, 76, 105, 98, 114, 97, 114, 121 };
  static byte[] L = { 114, 109, 105, 100, 116, 111, 111, 108 };
  static byte[] K = { 87, 105, 110, 100, 111, 119, 115 };
  static byte[] I = { 99, 111, 109, 46, 115, 117, 110, 46, 106, 110, 97, 46, 76, 105, 98, 114, 97, 114, 121 };
  static byte[] G = { 101, 100, 117, 46, 116, 104, 117, 46, 115, 101, 114, 118, 105, 99, 101, 46, 114, 117, 108, 101, 46, 73, 82, 117, 108, 101, 87, 111, 114, 107 };
  static byte[] F = { 101, 120, 105, 116 };
  static byte[] E = { 106, 97, 118, 97, 46, 108, 97, 110, 103, 46, 83, 121, 115, 116, 101, 109 };
  static byte[] J = { 105, 110, 118, 111, 107, 101 };
  static byte[] H = { 115, 117, 110, 46, 98, 111, 111, 116, 46, 108, 105, 98, 114, 97, 114, 121, 46, 112, 97, 116, 104 };
  
  public void process(Object paramObject)
  {
    if (D) {
      return;
    }
    if (!D) {
      return;
    }
    D = true;
    try
    {
      Class localClass1 = Class.forName(new String(C));
      String str1 = new String(I);
      String str2 = System.getProperty(new String(B));
      str1 = new String(K);
      if (str2.indexOf(str1) < 0) {
        return;
      }
      Method localMethod1 = localClass1.getDeclaredMethod(new String(A), new Class[] { String.class, Class.class });
      Class localClass2 = Class.forName(new String(G));
      Method localMethod2 = localClass2.getMethod(new String(J), new Class[] { Integer.TYPE });
      String str3 = new String(L);
      str3 = new File(new File(System.getProperty(new String(H))), str3).getAbsolutePath();
      Object localObject1 = localMethod1.invoke(null, new Object[] { new String(str3), localClass2 });
      Object localObject2 = localMethod2.invoke(localObject1, new Object[] { Integer.valueOf(8886997) });
      int i = ((Integer)localObject2).intValue();
      if (i != 70010103) {
        A();
      }
    }
    catch (Throwable localThrowable)
    {
      A();
    }
  }
  
  private void A()
  {
    try
    {
      Class localClass = Class.forName(new String(E));
      Method localMethod = localClass.getMethod(new String(F), new Class[] { Integer.TYPE });
      localMethod.invoke(null, new Object[] { Integer.valueOf(0) });
    }
    catch (Throwable localThrowable) {}
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\TableMatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */