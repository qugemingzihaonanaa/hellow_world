package edu.thu.model.data;

import java.io.Serializable;

public class VariableInt
  implements Serializable
{
  private static final long serialVersionUID = 5023978486426774763L;
  public int value;
  
  public VariableInt(int paramInt)
  {
    this.value = paramInt;
  }
  
  public VariableInt()
  {
    this.value = 0;
  }
  
  public int inc()
  {
    this.value += 1;
    return this.value;
  }
  
  public int getValue()
  {
    return this.value;
  }
  
  public void setValue(int paramInt)
  {
    this.value = paramInt;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\VariableInt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */