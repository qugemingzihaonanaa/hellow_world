package edu.thu.model.data;

import java.util.Comparator;

public class SafeComparator
  implements Comparator
{
  public static final SafeComparator SINGLETON = new SafeComparator();
  
  public static <T> Comparator<T> instance()
  {
    return SINGLETON;
  }
  
  public int compare(Object paramObject1, Object paramObject2)
  {
    if (paramObject1 == paramObject2) {
      return 0;
    }
    if (paramObject1 == null) {
      return -1;
    }
    if (paramObject2 == null) {
      return 1;
    }
    if (paramObject1.equals(paramObject2)) {
      return 0;
    }
    if (((paramObject1 instanceof Number)) && ((paramObject2 instanceof Number))) {
      return ((Number)paramObject1).doubleValue() > ((Number)paramObject2).doubleValue() ? 1 : -1;
    }
    if ((paramObject1 instanceof Comparable)) {
      return ((Comparable)paramObject1).compareTo(paramObject2);
    }
    int i = paramObject1.hashCode();
    int j = paramObject2.hashCode();
    if (i == j) {
      return 0;
    }
    return i < j ? -1 : 1;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\SafeComparator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */