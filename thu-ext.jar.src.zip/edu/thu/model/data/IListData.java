package edu.thu.model.data;

import java.util.List;

public abstract interface IListData<T>
{
  public abstract List<T> getListData();
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\IListData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */