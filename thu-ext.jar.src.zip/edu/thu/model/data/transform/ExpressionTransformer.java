package edu.thu.model.data.transform;

import edu.thu.lang.el.IExpressionReference;
import edu.thu.lang.util.TplC;
import edu.thu.service.IContextualizable;
import edu.thu.service.IServiceContext;
import java.util.HashMap;
import java.util.Map;

public class ExpressionTransformer
  implements ITransformer, IContextualizable
{
  static String VALUE_NAME = "value";
  Map vars;
  IExpressionReference expr;
  
  public ExpressionTransformer(Map paramMap, IExpressionReference paramIExpressionReference)
  {
    this.vars = (paramMap == null ? new HashMap() : new HashMap(paramMap));
    this.expr = paramIExpressionReference;
  }
  
  public ExpressionTransformer(IExpressionReference paramIExpressionReference)
  {
    this(null, paramIExpressionReference);
  }
  
  public Object transform(Object paramObject)
  {
    this.vars.put(VALUE_NAME, paramObject);
    return TplC.evaluate(this.expr, this.vars);
  }
  
  public Object contextualize(IServiceContext paramIServiceContext)
  {
    return new ExpressionTransformer(this.vars, this.expr);
  }
  
  public IServiceContext getContext()
  {
    return null;
  }
  
  public boolean isContextualizable()
  {
    return this.vars == null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\model\data\transform\ExpressionTransformer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */