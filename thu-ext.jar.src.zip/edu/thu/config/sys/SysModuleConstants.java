package edu.thu.config.sys;

public abstract interface SysModuleConstants
{
  public static final String SUB_SYSTEM_ID_NAME = "subsystemId";
  public static final String MODULE_NAME = "module";
  public static final String MODULE_FUNC_NAME = "moduleFunc";
  public static final String MODULE_ID_NAME = "moduleId";
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\config\sys\SysModuleConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */