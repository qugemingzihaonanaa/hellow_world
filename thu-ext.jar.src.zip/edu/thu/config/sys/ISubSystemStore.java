package edu.thu.config.sys;

import edu.thu.model.stg.ds.IDataStore;

public abstract interface ISubSystemStore
  extends IDataStore
{
  public abstract IModuleStore getModuleStore(String paramString);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\config\sys\ISubSystemStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */