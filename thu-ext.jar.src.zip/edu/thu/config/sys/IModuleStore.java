package edu.thu.config.sys;

import edu.thu.model.stg.ds.IDataStore;

public abstract interface IModuleStore
  extends IDataStore
{
  public abstract String getSubSystemId();
  
  public abstract IModuleFuncStore getModuleFuncStore(String paramString);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\config\sys\IModuleStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */