package edu.thu.config;

import edu.thu.db.DbEngineFactory;
import edu.thu.db.spi.SqlServerDbEngine;

public final class DefaultSqlServerDbEngine
  extends SqlServerDbEngine
{
  public DefaultSqlServerDbEngine()
  {
    String str1 = "localhost";
    String str2 = "1433";
    String str3 = "test";
    this.connStr = ("jdbc:microsoft:sqlserver://" + str1 + ":" + str2 + ";DatabaseName=" + str3 + ";selectMethod=cursor");
    this.user = "sa";
    this.password = "heiheihei";
    createConnection();
  }
  
  public static void register()
  {
    DbEngineFactory.registerPool("default", DefaultSqlServerDbEngine.class, 5, 10, 30000);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\config\DefaultSqlServerDbEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */