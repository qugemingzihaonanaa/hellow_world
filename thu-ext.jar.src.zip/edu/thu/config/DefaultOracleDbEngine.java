package edu.thu.config;

import edu.thu.db.DbEngineFactory;
import edu.thu.db.spi.OracleDbEngine;

public final class DefaultOracleDbEngine
  extends OracleDbEngine
{
  public DefaultOracleDbEngine()
  {
    String str1 = "oracle_default_config";
    String str2 = "192.168.0.172";
    String str3 = "1521";
    String str4 = "oasis";
    this.user = "system";
    this.password = "test";
    this.user = "oasis";
    this.password = "oasis";
    this.connStr = "jdbc:oracle:thin:@localhost:1521:oradb";
    createConnection();
    this.sqlCheck = "select * from id_map";
  }
  
  public String generateId(String paramString1, String paramString2, int paramInt)
  {
    String str = "select hibernate_sequence.nextval from dual";
    return null;
  }
  
  public static void register()
  {
    DbEngineFactory.registerPool("default", DefaultOracleDbEngine.class, 100, 100, 30000);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\config\DefaultOracleDbEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */