package edu.thu.db;

import edu.thu.core.AppEnv;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.util.Coercions;
import edu.thu.lang.reflect.BeanInstance;
import edu.thu.service.BeanLoader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;

public class ExDataSource
  implements DataSource
{
  DataSource D;
  ThreadLocal<DataSource> B = new ThreadLocal();
  int A = 10000;
  int C = 300000;
  
  public static ExDataSource getInstance()
  {
    return (ExDataSource)BeanLoader.getBean(ExDataSource.class);
  }
  
  public void setCheckInterval(int paramInt)
  {
    this.A = paramInt;
  }
  
  public void setCheckTimeout(int paramInt)
  {
    this.C = paramInt;
  }
  
  public void checkConnection()
  {
    if (this.A <= 0) {
      return;
    }
    long l = AppEnv.currentTimeMillis() + this.C;
    do
    {
      Connection localConnection = null;
      try
      {
        localConnection = A().getConnection();
        System.out.println("\r\n================ DataSource checkConnection succeed ====================\r\n\r\n");
        return;
      }
      catch (Exception localException1)
      {
        localException1.printStackTrace();
        try
        {
          Thread.sleep(this.A);
        }
        catch (Exception localException2) {}
      }
      finally
      {
        try
        {
          localConnection.close();
        }
        catch (Exception localException5) {}
      }
    } while (l > AppEnv.currentTimeMillis());
  }
  
  @PostConstruct
  public void afterPropertiesSet()
    throws Exception
  {
    checkConnection();
  }
  
  DataSource A()
  {
    DataSource localDataSource = getThreadDataSource();
    if (localDataSource == null)
    {
      localDataSource = this.D;
      setThreadDataSource(localDataSource);
    }
    if (localDataSource == null) {
      throw Exceptions.code("db.CAN_err_null_dataSource");
    }
    return localDataSource;
  }
  
  public void setThreadDataSource(DataSource paramDataSource)
  {
    this.B.set(paramDataSource);
  }
  
  public DataSource putThreadDataSource(DataSource paramDataSource)
  {
    DataSource localDataSource = (DataSource)this.B.get();
    this.B.set(paramDataSource);
    return localDataSource;
  }
  
  public DataSource getThreadDataSource()
  {
    return (DataSource)this.B.get();
  }
  
  public void setDataSource(DataSource paramDataSource)
  {
    this.D = paramDataSource;
  }
  
  public Connection getConnection()
    throws SQLException
  {
    return A().getConnection();
  }
  
  public Connection getConnection(String paramString1, String paramString2)
    throws SQLException
  {
    return A().getConnection(paramString1, paramString2);
  }
  
  public PrintWriter getLogWriter()
    throws SQLException
  {
    return A().getLogWriter();
  }
  
  public int getLoginTimeout()
    throws SQLException
  {
    return A().getLoginTimeout();
  }
  
  public void setLogWriter(PrintWriter paramPrintWriter)
    throws SQLException
  {
    A().setLogWriter(paramPrintWriter);
  }
  
  public void setLoginTimeout(int paramInt)
    throws SQLException
  {
    A().setLoginTimeout(paramInt);
  }
  
  public boolean isWrapperFor(Class<?> paramClass)
    throws SQLException
  {
    BeanInstance localBeanInstance = new BeanInstance(A());
    return Coercions.toBoolean(localBeanInstance.invokeMethod("isWrapperFor", new Object[] { paramClass }), false);
  }
  
  public <T> T unwrap(Class<T> paramClass)
    throws SQLException
  {
    BeanInstance localBeanInstance = new BeanInstance(A());
    return (T)localBeanInstance.invokeMethod("unwrap", new Object[] { paramClass });
  }
  
  public Logger getParentLogger()
    throws SQLFeatureNotSupportedException
  {
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\db\ExDataSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */