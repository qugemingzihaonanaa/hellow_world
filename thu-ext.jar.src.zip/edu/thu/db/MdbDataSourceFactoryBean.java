package edu.thu.db;

import edu.thu.apm.AppResourceLoader;
import edu.thu.ext.hsql.DbManagerHelper;
import edu.thu.service.bean.interfaces.IFactoryBean;
import java.io.File;
import javax.sql.DataSource;

public class MdbDataSourceFactoryBean
  implements IFactoryBean<DataSource>
{
  String virtualFile;
  String userName;
  String userPass;
  String driverClass;
  
  public void setVirtualFile(String paramString)
  {
    this.virtualFile = paramString;
  }
  
  public String getVirtualFile()
  {
    return this.virtualFile;
  }
  
  public void setUserName(String paramString)
  {
    this.userName = paramString;
  }
  
  public String getUserName()
  {
    return this.userName;
  }
  
  public void setUserPass(String paramString)
  {
    this.userPass = paramString;
  }
  
  public String getUserPass()
  {
    return this.userPass;
  }
  
  public void setDriverClass(String paramString)
  {
    this.driverClass = paramString;
  }
  
  public DataSource getObject()
    throws Exception
  {
    String str = AppResourceLoader.getInstance().getSysFile(this.virtualFile).getAbsolutePath();
    return DbManagerHelper.createMdbDs(str, this.userName, this.userPass, this.driverClass);
  }
  
  public Class<DataSource> getObjectType()
  {
    return DataSource.class;
  }
  
  public boolean isSingleton()
  {
    return true;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\db\MdbDataSourceFactoryBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */