package edu.thu.db.batch;

import edu.thu.db.SQL;
import edu.thu.db.lob.ILobCreator;
import edu.thu.db.mapper.ColumnMapRowMapper;
import edu.thu.db.util.JdbcHelper;
import edu.thu.lang.exceptions.StdException;
import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JdbcBatcher
{
  static final Logger I = LoggerFactory.getLogger(JdbcBatcher.class);
  LinkedList<_A> A = new LinkedList();
  int F = 100;
  int H = 1000;
  boolean E = true;
  Connection C;
  boolean D;
  boolean B;
  ILobCreator G;
  
  public void setLobCreator(ILobCreator paramILobCreator) {}
  
  public void setUseTxn(boolean paramBoolean)
  {
    this.B = paramBoolean;
  }
  
  public void disableBatch()
  {
    this.D = false;
  }
  
  public void setBatchSize(int paramInt)
  {
    this.F = paramInt;
  }
  
  public void setFlushSize(int paramInt)
  {
    this.H = paramInt;
  }
  
  public void setAutoFlush(boolean paramBoolean)
  {
    this.E = paramBoolean;
  }
  
  public void addFirst(SQL paramSQL, IBatchCallback paramIBatchCallback)
  {
    _A local_A = new _A(paramSQL, paramIBatchCallback);
    if (this.D)
    {
      this.A.addFirst(local_A);
      A();
    }
    else
    {
      A(local_A, this.C);
    }
  }
  
  public void addLast(SQL paramSQL, IBatchCallback paramIBatchCallback)
  {
    _A local_A = new _A(paramSQL, paramIBatchCallback);
    if (this.D)
    {
      this.A.addLast(local_A);
      A();
    }
    else
    {
      A(local_A, this.C);
    }
  }
  
  void A()
  {
    if ((this.E) && (this.A.size() >= this.H)) {
      flush();
    }
  }
  
  public void beginBatch(Connection paramConnection)
  {
    this.C = paramConnection;
    try
    {
      this.D = paramConnection.getMetaData().supportsBatchUpdates();
    }
    catch (Exception localException)
    {
      this.D = false;
      I.info("jdbc.CAN_not_support_batch", localException);
    }
  }
  
  public void endBatch()
  {
    this.C = null;
  }
  
  public void flush()
  {
    if (this.A.isEmpty()) {
      return;
    }
    try
    {
      A(this.A, this.C);
    }
    catch (SQLException localSQLException)
    {
      throw StdException.wrap(localSQLException);
    }
  }
  
  /* Error */
  void A(LinkedList<_A> paramLinkedList, Connection paramConnection)
    throws SQLException
  {
    // Byte code:
    //   0: new 144	java/util/ArrayList
    //   3: dup
    //   4: aload_0
    //   5: getfield 43	edu/thu/db/batch/JdbcBatcher:F	I
    //   8: invokespecial 146	java/util/ArrayList:<init>	(I)V
    //   11: astore_3
    //   12: aload_1
    //   13: invokevirtual 148	java/util/LinkedList:removeFirst	()Ljava/lang/Object;
    //   16: checkcast 66	edu/thu/db/batch/JdbcBatcher$_A
    //   19: astore 4
    //   21: aload_3
    //   22: aload 4
    //   24: invokeinterface 152 2 0
    //   29: pop
    //   30: aconst_null
    //   31: astore 5
    //   33: aconst_null
    //   34: astore 6
    //   36: aconst_null
    //   37: astore 7
    //   39: aload_2
    //   40: invokeinterface 158 1 0
    //   45: istore 8
    //   47: aload_0
    //   48: getfield 55	edu/thu/db/batch/JdbcBatcher:B	Z
    //   51: ifeq +15 -> 66
    //   54: iload 8
    //   56: ifeq +10 -> 66
    //   59: aload_2
    //   60: iconst_0
    //   61: invokeinterface 161 2 0
    //   66: aload 4
    //   68: invokevirtual 164	edu/thu/db/batch/JdbcBatcher$_A:A	()I
    //   71: ifle +142 -> 213
    //   74: aload 6
    //   76: ifnonnull +19 -> 95
    //   79: aload_2
    //   80: aload 4
    //   82: getfield 167	edu/thu/db/batch/JdbcBatcher$_A:A	Ledu/thu/db/SQL;
    //   85: invokevirtual 169	edu/thu/db/SQL:getSql	()Ljava/lang/String;
    //   88: invokeinterface 175 2 0
    //   93: astore 6
    //   95: aload_0
    //   96: aload 6
    //   98: aload 4
    //   100: getfield 167	edu/thu/db/batch/JdbcBatcher$_A:A	Ledu/thu/db/SQL;
    //   103: invokevirtual 179	edu/thu/db/SQL:getParamsArray	()[Ljava/lang/Object;
    //   106: aload 7
    //   108: invokevirtual 183	edu/thu/db/batch/JdbcBatcher:A	(Ljava/sql/PreparedStatement;[Ljava/lang/Object;Ledu/thu/db/lob/ILobCreator;)V
    //   111: aload 6
    //   113: invokeinterface 187 1 0
    //   118: goto +65 -> 183
    //   121: aload_1
    //   122: invokevirtual 192	java/util/LinkedList:peekFirst	()Ljava/lang/Object;
    //   125: checkcast 66	edu/thu/db/batch/JdbcBatcher$_A
    //   128: astore 9
    //   130: aload 9
    //   132: invokevirtual 195	edu/thu/db/batch/JdbcBatcher$_A:B	()Ljava/lang/String;
    //   135: aload 4
    //   137: invokevirtual 195	edu/thu/db/batch/JdbcBatcher$_A:B	()Ljava/lang/String;
    //   140: invokevirtual 198	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   143: ifeq +60 -> 203
    //   146: aload_0
    //   147: aload 6
    //   149: aload 9
    //   151: getfield 167	edu/thu/db/batch/JdbcBatcher$_A:A	Ledu/thu/db/SQL;
    //   154: invokevirtual 179	edu/thu/db/SQL:getParamsArray	()[Ljava/lang/Object;
    //   157: aload 7
    //   159: invokevirtual 183	edu/thu/db/batch/JdbcBatcher:A	(Ljava/sql/PreparedStatement;[Ljava/lang/Object;Ledu/thu/db/lob/ILobCreator;)V
    //   162: aload 6
    //   164: invokeinterface 187 1 0
    //   169: aload_1
    //   170: invokevirtual 148	java/util/LinkedList:removeFirst	()Ljava/lang/Object;
    //   173: pop
    //   174: aload_3
    //   175: aload 9
    //   177: invokeinterface 152 2 0
    //   182: pop
    //   183: aload_1
    //   184: invokevirtual 126	java/util/LinkedList:isEmpty	()Z
    //   187: ifne +16 -> 203
    //   190: aload_3
    //   191: invokeinterface 203 1 0
    //   196: aload_0
    //   197: getfield 43	edu/thu/db/batch/JdbcBatcher:F	I
    //   200: if_icmplt -79 -> 121
    //   203: aload_0
    //   204: aload 6
    //   206: aload_3
    //   207: invokevirtual 204	edu/thu/db/batch/JdbcBatcher:A	(Ljava/sql/Statement;Ljava/util/List;)V
    //   210: goto +101 -> 311
    //   213: aload 5
    //   215: ifnonnull +11 -> 226
    //   218: aload_2
    //   219: invokeinterface 208 1 0
    //   224: astore 5
    //   226: aload 5
    //   228: aload 4
    //   230: invokevirtual 195	edu/thu/db/batch/JdbcBatcher$_A:B	()Ljava/lang/String;
    //   233: invokeinterface 212 2 0
    //   238: goto +46 -> 284
    //   241: aload_1
    //   242: invokevirtual 192	java/util/LinkedList:peekFirst	()Ljava/lang/Object;
    //   245: checkcast 66	edu/thu/db/batch/JdbcBatcher$_A
    //   248: astore 9
    //   250: aload 9
    //   252: invokevirtual 164	edu/thu/db/batch/JdbcBatcher$_A:A	()I
    //   255: ifne +49 -> 304
    //   258: aload 5
    //   260: aload 9
    //   262: invokevirtual 195	edu/thu/db/batch/JdbcBatcher$_A:B	()Ljava/lang/String;
    //   265: invokeinterface 212 2 0
    //   270: aload_1
    //   271: invokevirtual 148	java/util/LinkedList:removeFirst	()Ljava/lang/Object;
    //   274: pop
    //   275: aload_3
    //   276: aload 9
    //   278: invokeinterface 152 2 0
    //   283: pop
    //   284: aload_1
    //   285: invokevirtual 126	java/util/LinkedList:isEmpty	()Z
    //   288: ifne +16 -> 304
    //   291: aload_3
    //   292: invokeinterface 203 1 0
    //   297: aload_0
    //   298: getfield 43	edu/thu/db/batch/JdbcBatcher:F	I
    //   301: if_icmplt -60 -> 241
    //   304: aload_0
    //   305: aload 5
    //   307: aload_3
    //   308: invokevirtual 204	edu/thu/db/batch/JdbcBatcher:A	(Ljava/sql/Statement;Ljava/util/List;)V
    //   311: aload_3
    //   312: invokeinterface 217 1 0
    //   317: ifne +18 -> 335
    //   320: aload_3
    //   321: iconst_0
    //   322: invokeinterface 218 2 0
    //   327: checkcast 66	edu/thu/db/batch/JdbcBatcher$_A
    //   330: astore 4
    //   332: goto -266 -> 66
    //   335: aload_1
    //   336: invokevirtual 126	java/util/LinkedList:isEmpty	()Z
    //   339: ifne +92 -> 431
    //   342: aload_1
    //   343: invokevirtual 148	java/util/LinkedList:removeFirst	()Ljava/lang/Object;
    //   346: checkcast 66	edu/thu/db/batch/JdbcBatcher$_A
    //   349: astore 9
    //   351: aload 9
    //   353: invokevirtual 164	edu/thu/db/batch/JdbcBatcher$_A:A	()I
    //   356: ifeq +27 -> 383
    //   359: aload 9
    //   361: invokevirtual 195	edu/thu/db/batch/JdbcBatcher$_A:B	()Ljava/lang/String;
    //   364: aload 4
    //   366: invokevirtual 195	edu/thu/db/batch/JdbcBatcher$_A:B	()Ljava/lang/String;
    //   369: invokevirtual 198	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   372: ifne +11 -> 383
    //   375: aload 6
    //   377: invokestatic 222	edu/thu/db/util/JdbcHelper:safeClose	(Ljava/sql/Statement;)V
    //   380: aconst_null
    //   381: astore 6
    //   383: aload 9
    //   385: astore 4
    //   387: aload_3
    //   388: aload 9
    //   390: invokeinterface 152 2 0
    //   395: pop
    //   396: goto -330 -> 66
    //   399: astore 10
    //   401: aload 6
    //   403: invokestatic 222	edu/thu/db/util/JdbcHelper:safeClose	(Ljava/sql/Statement;)V
    //   406: aload 5
    //   408: invokestatic 222	edu/thu/db/util/JdbcHelper:safeClose	(Ljava/sql/Statement;)V
    //   411: iload 8
    //   413: ifeq +15 -> 428
    //   416: aload_2
    //   417: iconst_1
    //   418: invokeinterface 161 2 0
    //   423: goto +5 -> 428
    //   426: astore 11
    //   428: aload 10
    //   430: athrow
    //   431: aload 6
    //   433: invokestatic 222	edu/thu/db/util/JdbcHelper:safeClose	(Ljava/sql/Statement;)V
    //   436: aload 5
    //   438: invokestatic 222	edu/thu/db/util/JdbcHelper:safeClose	(Ljava/sql/Statement;)V
    //   441: iload 8
    //   443: ifeq +15 -> 458
    //   446: aload_2
    //   447: iconst_1
    //   448: invokeinterface 161 2 0
    //   453: goto +5 -> 458
    //   456: astore 11
    //   458: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	459	0	this	JdbcBatcher
    //   0	459	1	paramLinkedList	LinkedList<_A>
    //   0	459	2	paramConnection	Connection
    //   11	377	3	localArrayList	java.util.ArrayList
    //   19	367	4	localObject1	Object
    //   31	406	5	localStatement	Statement
    //   34	398	6	localPreparedStatement	PreparedStatement
    //   37	121	7	localILobCreator	ILobCreator
    //   45	397	8	bool	boolean
    //   128	261	9	local_A	_A
    //   399	30	10	localObject2	Object
    //   426	1	11	localException1	Exception
    //   456	1	11	localException2	Exception
    // Exception table:
    //   from	to	target	type
    //   47	399	399	finally
    //   416	423	426	java/lang/Exception
    //   446	453	456	java/lang/Exception
  }
  
  void A(Statement paramStatement, List<_A> paramList)
    throws SQLException
  {
    try
    {
      int[] arrayOfInt1 = paramStatement.executeBatch();
      j = arrayOfInt1.length;
      for (int i = 0; i < j; i++)
      {
        _A local_A1 = (_A)paramList.get(i);
        local_A1.A(arrayOfInt1[i]);
      }
      paramList.clear();
    }
    catch (BatchUpdateException localBatchUpdateException)
    {
      int[] arrayOfInt2 = localBatchUpdateException.getUpdateCounts();
      if ((arrayOfInt2 == null) || (arrayOfInt2.length == 0)) {
        arrayOfInt2 = new int[-3];
      }
      int k = arrayOfInt2.length;
      for (int j = 0; j < k; j++)
      {
        _A local_A2 = (_A)paramList.remove(0);
        if (arrayOfInt2[j] == -3) {
          local_A2.A(localBatchUpdateException.getNextException() == null ? localBatchUpdateException : localBatchUpdateException.getNextException());
        } else {
          local_A2.A(arrayOfInt2[j]);
        }
      }
    }
  }
  
  void A(PreparedStatement paramPreparedStatement, Object[] paramArrayOfObject, ILobCreator paramILobCreator)
    throws SQLException
  {}
  
  /* Error */
  void A(_A param_A, Connection paramConnection)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aload_2
    //   3: aload_1
    //   4: getfield 167	edu/thu/db/batch/JdbcBatcher$_A:A	Ledu/thu/db/SQL;
    //   7: invokevirtual 169	edu/thu/db/SQL:getSql	()Ljava/lang/String;
    //   10: invokeinterface 175 2 0
    //   15: astore_3
    //   16: aload_3
    //   17: invokeinterface 278 1 0
    //   22: istore 4
    //   24: aload_1
    //   25: iload 4
    //   27: invokevirtual 248	edu/thu/db/batch/JdbcBatcher$_A:A	(I)V
    //   30: goto +27 -> 57
    //   33: astore 4
    //   35: aload_1
    //   36: aload 4
    //   38: invokevirtual 266	edu/thu/db/batch/JdbcBatcher$_A:A	(Ljava/lang/Exception;)V
    //   41: aload_3
    //   42: invokestatic 222	edu/thu/db/util/JdbcHelper:safeClose	(Ljava/sql/Statement;)V
    //   45: goto +16 -> 61
    //   48: astore 5
    //   50: aload_3
    //   51: invokestatic 222	edu/thu/db/util/JdbcHelper:safeClose	(Ljava/sql/Statement;)V
    //   54: aload 5
    //   56: athrow
    //   57: aload_3
    //   58: invokestatic 222	edu/thu/db/util/JdbcHelper:safeClose	(Ljava/sql/Statement;)V
    //   61: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	62	0	this	JdbcBatcher
    //   0	62	1	param_A	_A
    //   0	62	2	paramConnection	Connection
    //   1	57	3	localPreparedStatement	PreparedStatement
    //   22	4	4	i	int
    //   33	4	4	localException	Exception
    //   48	7	5	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   2	30	33	java/lang/Exception
    //   2	41	48	finally
  }
  
  public Map<String, Object> findFirst(SQL paramSQL)
  {
    PreparedStatement localPreparedStatement = null;
    ResultSet localResultSet = null;
    try
    {
      localPreparedStatement = this.C.prepareStatement(paramSQL.getText());
      localPreparedStatement.setMaxRows(1);
      A(localPreparedStatement, paramSQL.getParamsArray(), null);
      localResultSet = localPreparedStatement.executeQuery();
      Map localMap = ColumnMapRowMapper.INSTANCE.mapRow(localResultSet, 0);
      return localMap;
    }
    catch (Exception localException)
    {
      throw StdException.wrap(localException);
    }
    finally
    {
      JdbcHelper.safeClose(localResultSet);
      JdbcHelper.safeClose(localPreparedStatement);
    }
  }
  
  static class _A
  {
    SQL A;
    IBatchCallback B;
    
    public _A(SQL paramSQL, IBatchCallback paramIBatchCallback)
    {
      this.A = paramSQL;
      this.B = paramIBatchCallback;
    }
    
    int A()
    {
      if (this.A.getParams() == null) {
        return 0;
      }
      return this.A.getParams().size();
    }
    
    public String B()
    {
      return this.A.getText();
    }
    
    public void A(int paramInt)
    {
      if (this.B != null) {
        this.B.onSuccess(this.A, paramInt);
      }
    }
    
    public void A(Exception paramException)
    {
      if (this.B != null) {
        this.B.onFail(this.A, paramException);
      } else {
        JdbcBatcher.I.info("db.CAN_err_execute_fail", paramException);
      }
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\db\batch\JdbcBatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */