package edu.thu.db.batch;

import edu.thu.db.SQL;

public abstract interface IBatchCallback
{
  public abstract void onSuccess(SQL paramSQL, int paramInt);
  
  public abstract void onFail(SQL paramSQL, Exception paramException);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\db\batch\IBatchCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */