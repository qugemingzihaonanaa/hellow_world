package edu.thu.db;

import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.logging.Logger;
import javax.sql.DataSource;

public class BaseDataSource
  implements DataSource
{
  volatile boolean A = false;
  String D;
  String C;
  String E;
  String B;
  
  public String getDriverClassName()
  {
    return this.D;
  }
  
  public void setDriverClassName(String paramString)
  {
    this.D = paramString;
  }
  
  public void setUrl(String paramString)
  {
    this.C = paramString;
  }
  
  public void setUsername(String paramString)
  {
    this.E = paramString;
  }
  
  public void setPassword(String paramString)
  {
    this.B = paramString;
  }
  
  public Connection getConnection()
    throws SQLException
  {
    return getConnection(this.E, this.B);
  }
  
  public Connection getConnection(String paramString1, String paramString2)
    throws SQLException
  {
    if (!this.A)
    {
      try
      {
        Class.forName(this.D);
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
      this.A = true;
    }
    return DriverManager.getConnection(this.C, paramString1, paramString2);
  }
  
  public int getLoginTimeout()
    throws SQLException
  {
    return -1;
  }
  
  public PrintWriter getLogWriter()
    throws SQLException
  {
    return new PrintWriter(new OutputStreamWriter(System.out));
  }
  
  public void setLoginTimeout(int paramInt)
    throws SQLException
  {}
  
  public void setLogWriter(PrintWriter paramPrintWriter)
    throws SQLException
  {}
  
  public boolean isWrapperFor(Class<?> paramClass)
    throws SQLException
  {
    return false;
  }
  
  public <T> T unwrap(Class<T> paramClass)
    throws SQLException
  {
    return null;
  }
  
  public Logger getParentLogger()
    throws SQLFeatureNotSupportedException
  {
    return null;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\db\BaseDataSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */