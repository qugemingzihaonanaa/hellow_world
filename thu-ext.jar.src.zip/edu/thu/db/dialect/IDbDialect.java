package edu.thu.db.dialect;

import edu.thu.ext.pdm.core.DataType;
import edu.thu.orm.dialect.IDialect;
import java.util.List;

public abstract interface IDbDialect
  extends IDialect
{
  public abstract DataType convertStdDataType(DataType paramDataType);
  
  public abstract List<String> getDisallowedDataTypes();
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\db\dialect\IDbDialect.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */