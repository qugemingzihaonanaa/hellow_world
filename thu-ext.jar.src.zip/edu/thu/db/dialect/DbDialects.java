package edu.thu.db.dialect;

import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

public class DbDialects
{
  static Map<String, IDbDialect> A = new HashMap();
  
  public static void register(String paramString, IDbDialect paramIDbDialect)
  {
    A.put(paramString, paramIDbDialect);
  }
  
  public static IDbDialect getDialect(Connection paramConnection)
  {
    return null;
  }
  
  public static IDbDialect get(String paramString)
  {
    IDbDialect localIDbDialect = (IDbDialect)A.get(paramString);
    if (localIDbDialect == null) {
      throw Exceptions.code("pdm.CAN_err_unknown_db_dialect").param(paramString);
    }
    return localIDbDialect;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\db\dialect\DbDialects.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */