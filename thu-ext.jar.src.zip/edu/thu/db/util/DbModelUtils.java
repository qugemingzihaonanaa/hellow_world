package edu.thu.db.util;

import edu.thu.db.core.IJdbcTemplate;
import java.sql.Connection;

public class DbModelUtils
{
  public static boolean assureTableExists(Connection paramConnection, String paramString, IJdbcTemplate paramIJdbcTemplate)
  {
    return true;
  }
  
  public static boolean assureTableExists(Connection paramConnection, String paramString1, IJdbcTemplate paramIJdbcTemplate, String paramString2)
  {
    return true;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\db\util\DbModelUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */