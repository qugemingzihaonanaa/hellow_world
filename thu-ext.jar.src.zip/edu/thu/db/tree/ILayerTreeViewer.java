package edu.thu.db.tree;

import edu.thu.model.stg.view.IPageViewer;
import edu.thu.model.tree.LayerCode;
import edu.thu.model.tree.TreeNode;
import edu.thu.search.IQuery;
import java.util.List;

public abstract interface ILayerTreeViewer
{
  public abstract String getIdByLayerCode(LayerCode paramLayerCode);
  
  public abstract LayerCode getLayerCodeById(String paramString);
  
  public abstract boolean exists(LayerCode paramLayerCode);
  
  public abstract boolean existsById(String paramString);
  
  public abstract TreeNode getWholeTree();
  
  public abstract TreeNode getWholeTree(int paramInt);
  
  public abstract TreeNode getSubTree(LayerCode paramLayerCode);
  
  public abstract TreeNode getSubTreeById(String paramString);
  
  public abstract TreeNode getSubTree(LayerCode paramLayerCode, int paramInt);
  
  public abstract TreeNode getNode(LayerCode paramLayerCode);
  
  public abstract TreeNode getNodeById(String paramString);
  
  public abstract List getNodes(List paramList);
  
  public abstract boolean containsSub(LayerCode paramLayerCode);
  
  public abstract boolean containsSubById(String paramString);
  
  public abstract IPageViewer viewDirectSub(LayerCode paramLayerCode);
  
  public abstract IPageViewer viewDirectSubById(String paramString);
  
  public abstract List getRoots();
  
  public abstract ILayerTreeViewer filter(IQuery paramIQuery);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\db\tree\ILayerTreeViewer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */