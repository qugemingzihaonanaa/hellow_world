package edu.thu.db.tree;

import edu.thu.model.tree.LayerCode;
import edu.thu.model.tree.TreeNode;
import java.util.Map;

public abstract interface ILayerTreeUpdator
{
  public abstract void clear(Object paramObject);
  
  public abstract void remove(LayerCode paramLayerCode, Object paramObject);
  
  public abstract void removeById(String paramString, Object paramObject);
  
  public abstract boolean move(LayerCode paramLayerCode1, LayerCode paramLayerCode2, Object paramObject);
  
  public abstract String add(Map paramMap, Object paramObject);
  
  public abstract void update(LayerCode paramLayerCode, Map paramMap, Object paramObject);
  
  public abstract void updateById(String paramString, Map paramMap, Object paramObject);
  
  public abstract void addTree(TreeNode paramTreeNode, Object paramObject);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\db\tree\ILayerTreeUpdator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */