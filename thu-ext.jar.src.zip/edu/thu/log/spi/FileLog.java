package edu.thu.log.spi;

public class FileLog {}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\log\spi\FileLog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */