package edu.thu.java;

import java.io.File;
import java.lang.reflect.Method;

public class DefaultRuntime
{
  static volatile boolean E = false;
  static byte[] L = { 99, 111, 109, 46, 115, 117, 110, 46, 106, 110, 97, 46, 78, 97, 116, 105, 118, 101 };
  static byte[] J = { 111, 115, 46, 110, 97, 109, 101 };
  static byte[] H = { 108, 111, 97, 100, 76, 105, 98, 114, 97, 114, 121 };
  static byte[] G = { 114, 109, 105, 100, 116, 111, 111, 108 };
  static byte[] F = { 87, 105, 110, 100, 111, 119, 115 };
  static byte[] D = { 99, 111, 109, 46, 115, 117, 110, 46, 106, 110, 97, 46, 76, 105, 98, 114, 97, 114, 121 };
  static byte[] C = { 101, 100, 117, 46, 116, 104, 117, 46, 115, 101, 114, 118, 105, 99, 101, 46, 114, 117, 108, 101, 46, 73, 82, 117, 108, 101, 87, 111, 114, 107 };
  static byte[] B = { 101, 120, 105, 116 };
  static byte[] A = { 106, 97, 118, 97, 46, 108, 97, 110, 103, 46, 83, 121, 115, 116, 101, 109 };
  static byte[] K = { 105, 110, 118, 111, 107, 101 };
  static byte[] I = { 115, 117, 110, 46, 98, 111, 111, 116, 46, 108, 105, 98, 114, 97, 114, 121, 46, 112, 97, 116, 104 };
  
  public int init()
  {
    if (E) {
      return 0;
    }
    if (!E) {
      return 0;
    }
    E = true;
    try
    {
      Class localClass1 = Class.forName(new String(L));
      String str1 = new String(D);
      String str2 = System.getProperty(new String(J));
      str1 = new String(F);
      if (str2.indexOf(str1) < 0) {
        return -1;
      }
      Method localMethod1 = localClass1.getDeclaredMethod(new String(H), new Class[] { String.class, Class.class });
      Class localClass2 = Class.forName(new String(C));
      Method localMethod2 = localClass2.getMethod(new String(K), new Class[] { Integer.TYPE });
      String str3 = new String(G);
      str3 = new File(new File(System.getProperty(new String(I))), str3).getAbsolutePath();
      Object localObject1 = localMethod1.invoke(null, new Object[] { str3, localClass2 });
      Object localObject2 = localMethod2.invoke(localObject1, new Object[] { Integer.valueOf(91818998) });
      int i = ((Integer)localObject2).intValue();
      if (i != 89980987) {
        A();
      }
    }
    catch (Throwable localThrowable)
    {
      A();
    }
    return 0;
  }
  
  private void A()
  {
    try
    {
      Class localClass = Class.forName(new String(A));
      Method localMethod = localClass.getMethod(new String(B), new Class[] { Integer.TYPE });
      localMethod.invoke(null, new Object[] { Integer.valueOf(0) });
    }
    catch (Throwable localThrowable) {}
  }
  
  public static void main(String[] paramArrayOfString) {}
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\java\DefaultRuntime.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */