package edu.thu.java.var.spi;

import edu.thu.global.Debug;
import edu.thu.java.var.IVarValue;
import edu.thu.java.var.IVarValueSet;
import java.util.List;

public class BiVarValueSet
  implements IVarValueSet
{
  Object SYS_USER = "0";
  IVarValueSet aSet;
  IVarValueSet bSet;
  
  public BiVarValueSet(IVarValueSet paramIVarValueSet1, IVarValueSet paramIVarValueSet2)
  {
    Debug.check(paramIVarValueSet1);
    Debug.check(paramIVarValueSet2);
    this.aSet = paramIVarValueSet1;
    this.bSet = paramIVarValueSet2;
  }
  
  public void clear(Object paramObject)
  {
    this.aSet.clear(paramObject);
    this.bSet.clear(paramObject);
  }
  
  public boolean existsVar(String paramString)
  {
    if (this.aSet.existsVar(paramString)) {
      return true;
    }
    return this.bSet.existsVar(paramString);
  }
  
  public IVarValueSet getSubSet(String paramString)
  {
    if ((paramString == null) || (paramString.length() <= 0)) {
      return this;
    }
    return new BiVarValueSet(this.aSet.getSubSet(paramString), this.bSet.getSubSet(paramString));
  }
  
  public IVarValue getVar(String paramString)
  {
    IVarValue localIVarValue = this.aSet.getVar(paramString);
    if (localIVarValue == VarValue.VAR_NULL)
    {
      localIVarValue = this.bSet.getVar(paramString);
      this.aSet.setVar(localIVarValue, this.SYS_USER);
    }
    return localIVarValue;
  }
  
  public List getVarNames()
  {
    return this.bSet.getVarNames();
  }
  
  public List getVarNamesWithPrefix(String paramString)
  {
    return this.bSet.getVarNamesWithPrefix(paramString);
  }
  
  public List getVarsWithPrefix(String paramString)
  {
    return this.bSet.getVarsWithPrefix(paramString);
  }
  
  public void removeVar(String paramString, Object paramObject)
  {
    this.aSet.removeVar(paramString, paramObject);
    this.bSet.removeVar(paramString, paramObject);
  }
  
  public void removeVarsWithPrefix(String paramString, Object paramObject)
  {
    this.aSet.removeVarsWithPrefix(paramString, paramObject);
    this.bSet.removeVarsWithPrefix(paramString, paramObject);
  }
  
  public void setVar(IVarValue paramIVarValue, Object paramObject)
  {
    this.bSet.setVar(paramIVarValue, paramObject);
    this.aSet.setVar(paramIVarValue, paramObject);
  }
  
  public void setVar(String paramString, Object paramObject1, Object paramObject2)
  {
    this.bSet.setVar(paramString, paramObject1, paramObject2);
    this.aSet.setVar(paramString, paramObject1, paramObject2);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\java\var\spi\BiVarValueSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */