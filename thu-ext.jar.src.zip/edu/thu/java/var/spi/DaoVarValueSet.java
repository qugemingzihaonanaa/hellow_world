package edu.thu.java.var.spi;

import edu.thu.db.SQL;
import edu.thu.db.SqlBuilder;
import edu.thu.java.var.IVarValue;
import edu.thu.java.var.IVarValueSet;
import edu.thu.lang.IVariant;
import edu.thu.model.tree.LayerCode;
import edu.thu.orm.dao.IEntityDao;
import edu.thu.search.Condition;
import edu.thu.search.Query;
import edu.thu.search.Query.ConditionSpec;
import edu.thu.search.Query.OrderBySpec;
import java.util.List;
import java.util.Map;

public class DaoVarValueSet
  implements IVarValueSet
{
  public static final String PROP_VAR_NAME = "varName";
  IEntityDao dao;
  Map conds;
  
  public DaoVarValueSet(IEntityDao paramIEntityDao, Map paramMap)
  {
    this.dao = paramIEntityDao;
    this.conds = paramMap;
  }
  
  public boolean existsVar(String paramString)
  {
    if ((paramString == null) || (paramString.length() <= 0)) {
      return false;
    }
    return this.dao.exists(SQL.begin().eq("varName", paramString).end());
  }
  
  public IVarValueSet getSubSet(String paramString)
  {
    if ((paramString == null) || (paramString.length() <= 0)) {
      return this;
    }
    return new PrefixVarValueSet(LayerCode.valueOf(paramString, '/'), this);
  }
  
  public IVarValue getVar(String paramString)
  {
    Query localQuery = Condition.begin().eq("varName", paramString).eq(this.conds).end();
    IVariant localIVariant = (IVariant)this.dao.findFirst(this.dao.buildConditionSql(localQuery.getCondition()));
    if (localIVariant == null) {
      return VarValue.VAR_NULL;
    }
    return (IVarValue)localIVariant;
  }
  
  public List getVarNames()
  {
    Query localQuery = Condition.begin().eq(this.conds).orderby().field("varName", true).end();
    return this.dao.findScalar("varName", this.dao.buildConditionSql(localQuery.getCondition()));
  }
  
  public List getVarNamesWithPrefix(String paramString)
  {
    if ((paramString == null) || (paramString.length() <= 0)) {
      return getVarNames();
    }
    Query localQuery = Condition.begin().cascade_include("varName", LayerCode.valueOf(paramString, '/')).eq(this.conds).orderby().field("varName", true).end();
    return this.dao.findScalar("varName", this.dao.buildConditionSql(localQuery.getCondition()));
  }
  
  public List getVarsWithPrefix(String paramString)
  {
    if ((paramString == null) || (paramString.length() <= 0))
    {
      localQuery = Condition.begin().eq(this.conds).orderby().field("varName", true).end();
      return this.dao.getAll(this.dao.buildConditionSql(localQuery.getCondition()));
    }
    Query localQuery = Condition.begin().cascade_include("varName", LayerCode.valueOf(paramString, '/')).eq(this.conds).orderby().field("varName", true).end();
    return this.dao.getAll(this.dao.buildConditionSql(localQuery.getCondition()));
  }
  
  public void removeVar(String paramString, Object paramObject)
  {
    Query localQuery = Condition.begin().eq(this.conds).eq("varName", paramString).end();
    this.dao.deleteEntityByCond(this.dao.buildConditionSql(localQuery.getCondition()));
  }
  
  public void removeVarsWithPrefix(String paramString, Object paramObject)
  {
    if ((paramString == null) || (paramString.length() <= 0))
    {
      clear(paramObject);
      return;
    }
    LayerCode localLayerCode = new LayerCode(paramString, '/');
    Query localQuery = Condition.begin().eq(this.conds).cascade_include("varName", localLayerCode).end();
    this.dao.deleteEntityByCond(this.dao.buildConditionSql(localQuery.getCondition()));
  }
  
  public void clear(Object paramObject)
  {
    this.dao.deleteEntityByCond(this.dao.buildEqCondition(this.conds));
  }
  
  public void setVar(String paramString, Object paramObject1, Object paramObject2)
  {
    setVar(new VarValue(paramString, paramObject1), paramObject2);
  }
  
  public void setVar(IVarValue paramIVarValue, Object paramObject)
  {
    String str = paramIVarValue.getName();
    VarValue localVarValue1 = (VarValue)getVar(str);
    if (localVarValue1 == VarValue.VAR_NULL)
    {
      VarValue localVarValue2 = (VarValue)this.dao.newEntity(null, null);
      localVarValue2.setValue(paramIVarValue.objectValue());
      localVarValue2.setName(str);
      if (this.conds != null) {
        this.dao.setProperties(localVarValue2, this.conds);
      }
      this.dao.saveEntity(localVarValue2);
    }
    else
    {
      localVarValue1.setValue(paramIVarValue.objectValue());
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\java\var\spi\DaoVarValueSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */