package edu.thu.java.var.spi;

import edu.thu.global.Debug;
import edu.thu.java.var.IVarType;
import edu.thu.java.var.IVarValue;
import edu.thu.java.var.IVarValueSet;
import edu.thu.lang.Variant;
import edu.thu.model.tree.TreeNode;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class LazyLoadVarValue
  implements IVarValue
{
  String name;
  IVarValue value;
  IVarValueSet varSet;
  
  IVarValue _getVarValue()
  {
    if (this.value != null) {
      return this.value;
    }
    return this.varSet.getVar(this.name);
  }
  
  public LazyLoadVarValue(String paramString, IVarValueSet paramIVarValueSet)
  {
    Debug.check(paramString);
    Debug.check(paramIVarValueSet);
    this.name = paramString;
    this.varSet = paramIVarValueSet;
  }
  
  public List<String> stringListValue()
  {
    return listValue();
  }
  
  public Object[] arrayValue()
  {
    return _getVarValue().arrayValue();
  }
  
  public Object[] arrayValue(Object[] paramArrayOfObject)
  {
    return _getVarValue().arrayValue(paramArrayOfObject);
  }
  
  public boolean booleanValue()
  {
    return _getVarValue().booleanValue();
  }
  
  public boolean booleanValue(boolean paramBoolean)
  {
    return _getVarValue().booleanValue(paramBoolean);
  }
  
  public byte[] bytesValue()
  {
    return _getVarValue().bytesValue();
  }
  
  public byte[] bytesValue(byte[] paramArrayOfByte)
  {
    return _getVarValue().bytesValue(paramArrayOfByte);
  }
  
  public byte byteValue()
  {
    return _getVarValue().byteValue();
  }
  
  public byte byteValue(byte paramByte)
  {
    return _getVarValue().byteValue(paramByte);
  }
  
  public char charValue()
  {
    return _getVarValue().charValue();
  }
  
  public char charValue(char paramChar)
  {
    return _getVarValue().charValue(paramChar);
  }
  
  public Collection collectionValue()
  {
    return _getVarValue().collectionValue();
  }
  
  public Collection collectionValue(Collection paramCollection)
  {
    return _getVarValue().collectionValue(paramCollection);
  }
  
  public Date dateValue()
  {
    return _getVarValue().dateValue();
  }
  
  public Date dateValue(Date paramDate)
  {
    return _getVarValue().dateValue(paramDate);
  }
  
  public double doubleValue()
  {
    return _getVarValue().doubleValue();
  }
  
  public double doubleValue(double paramDouble)
  {
    return _getVarValue().doubleValue(paramDouble);
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public IVarType getType()
  {
    return _getVarValue().getType();
  }
  
  public int intValue()
  {
    return _getVarValue().intValue();
  }
  
  public int intValue(int paramInt)
  {
    return _getVarValue().intValue(paramInt);
  }
  
  public boolean isNull()
  {
    return _getVarValue().isNull();
  }
  
  public List listValue()
  {
    return _getVarValue().listValue();
  }
  
  public List listValue(List paramList)
  {
    return _getVarValue().listValue(paramList);
  }
  
  public long longValue()
  {
    return _getVarValue().longValue();
  }
  
  public long longValue(long paramLong)
  {
    return _getVarValue().longValue(paramLong);
  }
  
  public Map mapValue()
  {
    return _getVarValue().mapValue();
  }
  
  public Map mapValue(Map paramMap)
  {
    return _getVarValue().mapValue(paramMap);
  }
  
  public Number numberValue()
  {
    return _getVarValue().numberValue();
  }
  
  public Number numberValue(Number paramNumber)
  {
    return _getVarValue().numberValue(paramNumber);
  }
  
  public Object objectValue()
  {
    return _getVarValue().objectValue();
  }
  
  public Object objectValue(Object paramObject)
  {
    return _getVarValue().objectValue(paramObject);
  }
  
  public double rangeValue(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    return _getVarValue().rangeValue(paramDouble1, paramDouble2, paramDouble3);
  }
  
  public int rangeValue(int paramInt1, int paramInt2, int paramInt3)
  {
    return 0;
  }
  
  public void setValue(Object paramObject) {}
  
  public String stringValue()
  {
    return _getVarValue().stringValue();
  }
  
  public String stringValue(String paramString)
  {
    return _getVarValue().stringValue(paramString);
  }
  
  public String stripedStringValue()
  {
    return _getVarValue().stripedStringValue();
  }
  
  public String stripedStringValue(String paramString)
  {
    return _getVarValue().stripedStringValue(paramString);
  }
  
  public String toString()
  {
    return _getVarValue().toString();
  }
  
  public void validate()
  {
    _getVarValue().validate();
  }
  
  public TreeNode nodeValue()
  {
    return _getVarValue().nodeValue();
  }
  
  public Timestamp stampValue()
  {
    return _getVarValue().stampValue();
  }
  
  public String formatDate(String paramString)
  {
    return _getVarValue().formatDate(paramString);
  }
  
  public String formatNumber(String paramString)
  {
    return _getVarValue().formatNumber(paramString);
  }
  
  public <T> Set<T> collectionSetValue()
  {
    Collection localCollection = collectionValue();
    if (localCollection == null) {
      return null;
    }
    if ((localCollection instanceof Set)) {
      return (Set)localCollection;
    }
    return new LinkedHashSet(localCollection);
  }
  
  public <T> Set<T> collectionSetValue(Set<T> paramSet)
  {
    Object localObject = collectionSetValue();
    if (localObject == null) {
      localObject = paramSet;
    }
    return (Set<T>)localObject;
  }
  
  public boolean booleanValue(boolean paramBoolean1, boolean paramBoolean2)
  {
    return Variant.toBoolean(this.value, paramBoolean1, paramBoolean2);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\java\var\spi\LazyLoadVarValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */