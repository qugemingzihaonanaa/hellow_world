package edu.thu.java.var.spi;

public abstract interface DsVarConstants
{
  public static final String FLD_VAR_NAME = "var_name";
  public static final String FLD_VAR_NAME_LEVEL = "var_name_level";
  public static final String FLD_VAR_TYPE = "var_type";
  public static final String FLD_VALUE_TYPE = "value_type";
  public static final String FLD_STR_VALUE = "str_value";
  public static final String FLD_NUM_VALUE = "num_value";
  public static final String FLD_DATE_VALUE = "date_value";
  public static final String FLD_BLOB_VALUE = "blob_value";
  public static final int TYPE_STR_VALUE = 1;
  public static final int TYPE_NUM_VALUE = 2;
  public static final int TYPE_DATE_VALUE = 3;
  public static final int TYPE_BLOB_VALUE = 4;
  public static final int POS_FLD_VAR_NAME = 0;
  public static final int POS_FLD_VAR_TYPE = 1;
  public static final int POS_FLD_VALUE_TYPE = 2;
  public static final int POS_FLD_STR_VALUE = 3;
  public static final int POS_FLD_NUM_VALUE = 4;
  public static final int POS_FLD_DATE_VALUE = 5;
  public static final int POS_FLD_BLOB_VALUE = 6;
  public static final String[] VAR_FIELDS = { "var_name", "var_type", "value_type", "str_value", "num_value", "date_value", "blob_value" };
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\java\var\spi\DsVarConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */