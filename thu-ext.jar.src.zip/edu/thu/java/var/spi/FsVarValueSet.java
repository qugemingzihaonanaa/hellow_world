package edu.thu.java.var.spi;

import edu.thu.global.Debug;
import edu.thu.io.IoUtils;
import edu.thu.java.var.IVarValue;
import edu.thu.java.var.IVarValueSet;
import edu.thu.model.tree.TreeNode;
import edu.thu.util.FileUtils;
import edu.thu.xml.dom.DomToTree;
import java.beans.XMLDecoder;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class FsVarValueSet
  implements IVarValueSet
{
  static String JAVA_NAME = "java";
  static String CLASS_NAME = "class";
  File path;
  
  public FsVarValueSet(File paramFile)
  {
    Debug.check(paramFile);
    this.path = paramFile;
  }
  
  public void clear(Object paramObject)
  {
    Debug.trace("remove path :" + this.path);
    FileUtils.removeSub(this.path);
  }
  
  public boolean existsVar(String paramString)
  {
    if ((paramString == null) || (paramString.length() <= 0)) {
      return false;
    }
    File localFile = new File(this.path, paramString);
    return localFile.isFile();
  }
  
  public IVarValueSet getSubSet(String paramString)
  {
    if ((paramString == null) || (paramString.length() <= 0)) {
      return this;
    }
    File localFile = new File(this.path, paramString);
    return new FsVarValueSet(localFile);
  }
  
  public IVarValue getVar(String paramString)
  {
    if ((paramString == null) || (paramString.length() <= 0)) {
      return VarValue.VAR_NULL;
    }
    File localFile = new File(this.path, paramString);
    if (!localFile.isFile()) {
      return VarValue.VAR_NULL;
    }
    Object localObject1 = null;
    try
    {
      TreeNode localTreeNode = DomToTree.getInstance().transform(localFile);
      if (localTreeNode == null)
      {
        localVarValue = VarValue.VAR_NULL;
        return localVarValue;
      }
      if ((localTreeNode.getName().equals(JAVA_NAME)) && (XMLDecoder.class.getName().equals(localTreeNode.getAttribute(CLASS_NAME))))
      {
        localObject1 = new BufferedInputStream(new FileInputStream(localFile));
        XMLDecoder localXMLDecoder = new XMLDecoder((InputStream)localObject1);
        Object localObject2 = localXMLDecoder.readObject();
        localVarValue = new VarValue(paramString, localObject2);
        return localVarValue;
      }
      localVarValue = new VarValue(paramString, localTreeNode);
      return localVarValue;
    }
    catch (Exception localException)
    {
      VarValue localVarValue = VarValue.VAR_NULL;
      return localVarValue;
    }
    finally
    {
      IoUtils.safeClose((InputStream)localObject1);
    }
  }
  
  public List getVarNames()
  {
    return getVarNamesWithPrefix(null);
  }
  
  public List getVarNamesWithPrefix(String paramString)
  {
    File localFile = this.path;
    if ((paramString != null) && (paramString.length() > 0)) {
      localFile = new File(this.path, paramString);
    }
    ArrayList localArrayList = new ArrayList();
    _navigate(localFile, localArrayList);
    return localArrayList;
  }
  
  void _navigate(File paramFile, List paramList)
  {
    File[] arrayOfFile = paramFile.listFiles();
    if (arrayOfFile != null)
    {
      int j = arrayOfFile.length;
      for (int i = 0; i < j; i++)
      {
        File localFile = arrayOfFile[i];
        if (localFile.isDirectory())
        {
          _navigate(localFile, paramList);
        }
        else if (localFile.isFile())
        {
          String str = localFile.getAbsolutePath().substring(this.path.getAbsolutePath().length() + 1);
          str = str.replace('\\', '/');
          paramList.add(str);
        }
      }
    }
  }
  
  public List getVarsWithPrefix(String paramString)
  {
    List localList = getVarNamesWithPrefix(paramString);
    if ((localList == null) || (localList.size() <= 0)) {
      return localList;
    }
    int j = localList.size();
    for (int i = 0; i < j; i++)
    {
      String str = (String)localList.get(i);
      LazyLoadVarValue localLazyLoadVarValue = new LazyLoadVarValue(str, this);
      localList.set(i, localLazyLoadVarValue);
    }
    return localList;
  }
  
  public void removeVar(String paramString, Object paramObject)
  {
    if ((paramString == null) || (paramString.length() <= 0)) {
      return;
    }
    File localFile = new File(this.path, paramString);
    localFile.delete();
  }
  
  public void removeVarsWithPrefix(String paramString, Object paramObject)
  {
    File localFile = this.path;
    if ((paramString != null) || (paramString.length() > 0)) {
      localFile = new File(this.path, paramString);
    }
    FileUtils.removeSub(localFile);
  }
  
  public void setVar(String paramString, Object paramObject1, Object paramObject2)
  {
    setVar(new VarValue(paramString, paramObject1), paramObject2);
  }
  
  /* Error */
  public void setVar(IVarValue paramIVarValue, Object paramObject)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull +4 -> 5
    //   4: return
    //   5: aload_1
    //   6: invokeinterface 239 1 0
    //   11: astore_3
    //   12: new 74	java/io/File
    //   15: dup
    //   16: aload_0
    //   17: getfield 35	edu/thu/java/var/spi/FsVarValueSet:path	Ljava/io/File;
    //   20: aload_3
    //   21: invokespecial 76	java/io/File:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   24: astore 4
    //   26: aload 4
    //   28: invokevirtual 242	java/io/File:getParentFile	()Ljava/io/File;
    //   31: astore 5
    //   33: aload 5
    //   35: ifnull +9 -> 44
    //   38: aload 5
    //   40: invokevirtual 246	java/io/File:mkdirs	()Z
    //   43: pop
    //   44: aload_1
    //   45: invokeinterface 249 1 0
    //   50: astore 6
    //   52: aload 6
    //   54: ifnonnull +12 -> 66
    //   57: aload 4
    //   59: invokevirtual 230	java/io/File:delete	()Z
    //   62: pop
    //   63: goto +118 -> 181
    //   66: aconst_null
    //   67: astore 7
    //   69: aload 6
    //   71: instanceof 116
    //   74: ifeq +29 -> 103
    //   77: aload 6
    //   79: checkcast 252	edu/thu/model/tree/IXObject
    //   82: invokeinterface 254 1 0
    //   87: astore 7
    //   89: aload 4
    //   91: aload 7
    //   93: invokevirtual 258	edu/thu/model/tree/TreeNode:toXml	()Ljava/lang/String;
    //   96: iconst_0
    //   97: invokestatic 261	edu/thu/util/FileUtils:save	(Ljava/io/File;Ljava/lang/String;Z)V
    //   100: goto +81 -> 181
    //   103: aconst_null
    //   104: astore 8
    //   106: new 265	java/io/FileOutputStream
    //   109: dup
    //   110: aload 4
    //   112: invokespecial 267	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   115: astore 8
    //   117: new 268	java/beans/XMLEncoder
    //   120: dup
    //   121: new 270	java/io/BufferedOutputStream
    //   124: dup
    //   125: aload 8
    //   127: invokespecial 272	java/io/BufferedOutputStream:<init>	(Ljava/io/OutputStream;)V
    //   130: invokespecial 275	java/beans/XMLEncoder:<init>	(Ljava/io/OutputStream;)V
    //   133: astore 9
    //   135: aload 9
    //   137: aload 6
    //   139: invokevirtual 276	java/beans/XMLEncoder:writeObject	(Ljava/lang/Object;)V
    //   142: aload 9
    //   144: invokevirtual 279	java/beans/XMLEncoder:close	()V
    //   147: goto +28 -> 175
    //   150: astore 9
    //   152: aload 4
    //   154: invokevirtual 230	java/io/File:delete	()Z
    //   157: pop
    //   158: aload 9
    //   160: invokestatic 282	edu/thu/global/exceptions/Exceptions:source	(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;
    //   163: athrow
    //   164: astore 10
    //   166: aload 8
    //   168: invokestatic 288	edu/thu/io/IoUtils:safeClose	(Ljava/io/OutputStream;)Z
    //   171: pop
    //   172: aload 10
    //   174: athrow
    //   175: aload 8
    //   177: invokestatic 288	edu/thu/io/IoUtils:safeClose	(Ljava/io/OutputStream;)Z
    //   180: pop
    //   181: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	182	0	this	FsVarValueSet
    //   0	182	1	paramIVarValue	IVarValue
    //   0	182	2	paramObject	Object
    //   11	10	3	str	String
    //   24	129	4	localFile1	File
    //   31	8	5	localFile2	File
    //   50	88	6	localObject1	Object
    //   67	25	7	localTreeNode	TreeNode
    //   104	72	8	localFileOutputStream	java.io.FileOutputStream
    //   133	10	9	localXMLEncoder	java.beans.XMLEncoder
    //   150	9	9	localException	Exception
    //   164	9	10	localObject2	Object
    // Exception table:
    //   from	to	target	type
    //   106	147	150	java/lang/Exception
    //   106	164	164	finally
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\java\var\spi\FsVarValueSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */