package edu.thu.java.var.spi;

import edu.thu.global.Debug;
import edu.thu.java.var.IVarValue;
import edu.thu.java.var.IVarValueSet;
import java.util.List;

public class IgnoreErrorVarValueSet
  implements IVarValueSet
{
  IVarValueSet set;
  
  public IgnoreErrorVarValueSet(IVarValueSet paramIVarValueSet)
  {
    this.set = paramIVarValueSet;
  }
  
  public void clear(Object paramObject)
  {
    try
    {
      this.set.clear(paramObject);
    }
    catch (Exception localException)
    {
      Debug.trace(localException);
    }
  }
  
  public boolean existsVar(String paramString)
  {
    try
    {
      return this.set.existsVar(paramString);
    }
    catch (Exception localException)
    {
      Debug.trace(localException);
    }
    return false;
  }
  
  public IVarValueSet getSubSet(String paramString)
  {
    return new IgnoreErrorVarValueSet(this.set.getSubSet(paramString));
  }
  
  public IVarValue getVar(String paramString)
  {
    try
    {
      return this.set.getVar(paramString);
    }
    catch (Exception localException)
    {
      Debug.trace(localException);
    }
    return VarValue.VAR_NULL;
  }
  
  public List getVarNames()
  {
    try
    {
      return this.set.getVarNames();
    }
    catch (Exception localException)
    {
      Debug.trace(localException);
    }
    return null;
  }
  
  public List getVarNamesWithPrefix(String paramString)
  {
    try
    {
      return this.set.getVarNamesWithPrefix(paramString);
    }
    catch (Exception localException)
    {
      Debug.trace(localException);
    }
    return null;
  }
  
  public List getVarsWithPrefix(String paramString)
  {
    try
    {
      return this.set.getVarsWithPrefix(paramString);
    }
    catch (Exception localException)
    {
      Debug.trace(localException);
    }
    return null;
  }
  
  public void removeVar(String paramString, Object paramObject)
  {
    try
    {
      this.set.removeVar(paramString, paramObject);
    }
    catch (Exception localException)
    {
      Debug.trace(localException);
    }
  }
  
  public void removeVarsWithPrefix(String paramString, Object paramObject)
  {
    try
    {
      this.set.removeVarsWithPrefix(paramString, paramObject);
    }
    catch (Exception localException)
    {
      Debug.trace(localException);
    }
  }
  
  public void setVar(IVarValue paramIVarValue, Object paramObject)
  {
    try
    {
      this.set.setVar(paramIVarValue, paramObject);
    }
    catch (Exception localException)
    {
      Debug.trace(localException);
    }
  }
  
  public void setVar(String paramString, Object paramObject1, Object paramObject2)
  {
    try
    {
      this.set.setVar(paramString, paramObject1, paramObject2);
    }
    catch (Exception localException)
    {
      Debug.trace(localException);
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\java\var\spi\IgnoreErrorVarValueSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */