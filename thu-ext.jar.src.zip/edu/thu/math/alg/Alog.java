package edu.thu.math.alg;

import edu.thu.db.IDbColumnData;
import edu.thu.ext.hibernate.AbstractEntity;
import edu.thu.global.Debug;
import edu.thu.global.exceptions.CommonException;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.java.ObjectResolver;
import edu.thu.java.util.Coercions;
import edu.thu.lang.IVariant;
import edu.thu.lang.Variant;
import edu.thu.lang.reflect.BeanInstance;
import edu.thu.lang.util.TplC;
import edu.thu.model.data.SafeComparator;
import edu.thu.service.EntityManager;
import edu.thu.util.time.EasyCalendar;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Alog
{
  static Alog B = new Alog();
  private static int A = 4;
  public static String ROUND_RULE_SIX_UP = "1";
  public static String ROUND_RULE_FIVE_UP = "2";
  public static String ROUND_RULE_DOWN = "3";
  public static int COMPARE_MODE_GT = 1;
  public static int COMPARE_MODE_GE = 2;
  
  public static Alog getInstance()
  {
    return B;
  }
  
  public static void registerForExpr()
  {
    ObjectResolver.register("$Alog", getInstance());
  }
  
  public static List<Integer> getOrderList(List paramList)
  {
    if (paramList == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(paramList.size());
    localArrayList.add(Integer.valueOf(1));
    for (int i = 1; i < paramList.size(); i++)
    {
      int j = i + 1;
      if (paramList.get(i) == paramList.get(i - 1)) {
        j = ((Integer)localArrayList.get(i - 1)).intValue();
      }
      localArrayList.add(Integer.valueOf(j));
    }
    return localArrayList;
  }
  
  public static List toNumberList(List paramList)
  {
    if (paramList == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(paramList.size());
    for (int i = 0; i < paramList.size(); i++) {
      localArrayList.add(Variant.valueOf(paramList.get(i)).numberValue(Integer.valueOf(0)));
    }
    return localArrayList;
  }
  
  public static List<Double> toDoubleList(List paramList)
  {
    if (paramList == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(paramList.size());
    for (int i = 0; i < paramList.size(); i++)
    {
      Double localDouble = Double.valueOf(Coercions.toDouble(paramList.get(i), 0.0D));
      localArrayList.add(localDouble);
    }
    return localArrayList;
  }
  
  public static Number normalize(Number paramNumber, int paramInt)
  {
    if (paramNumber == null) {
      return null;
    }
    double d = paramNumber.doubleValue() * Math.pow(10.0D, paramInt);
    return Double.valueOf(d);
  }
  
  public static Number sum(Collection paramCollection)
  {
    if ((paramCollection == null) || (paramCollection.size() == 0)) {
      return null;
    }
    BigDecimal localBigDecimal = new BigDecimal(0);
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      Number localNumber = Coercions.toNumber(localObject, null);
      if (localNumber != null) {
        localBigDecimal = localBigDecimal.add(new BigDecimal(localNumber.toString()));
      }
    }
    if (numberCount(paramCollection) == 0) {
      return null;
    }
    return Double.valueOf(localBigDecimal.doubleValue());
  }
  
  public static int numberCount(Collection paramCollection)
  {
    int i = 0;
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      Number localNumber = Coercions.toNumber(localObject, null);
      if (localNumber != null) {
        i++;
      }
    }
    return i;
  }
  
  public static Number avg(Collection paramCollection)
  {
    if ((paramCollection == null) || (paramCollection.size() == 0)) {
      return null;
    }
    Number localNumber = sum(paramCollection);
    if (localNumber == null) {
      return null;
    }
    int i = numberCount(paramCollection);
    if (i == 0) {
      return null;
    }
    return Double.valueOf(localNumber.doubleValue() / i);
  }
  
  public static Number avg2(Number paramNumber1, Number paramNumber2)
  {
    if ((paramNumber1 != null) && (!Double.isNaN(paramNumber1.doubleValue())) && (paramNumber2 != null) && (!Double.isNaN(paramNumber2.doubleValue())))
    {
      ArrayList localArrayList = new ArrayList();
      localArrayList.add(paramNumber1);
      localArrayList.add(paramNumber2);
      return avg(localArrayList);
    }
    if ((paramNumber1 != null) && (!Double.isNaN(paramNumber1.doubleValue())) && ((paramNumber2 == null) || (Double.isNaN(paramNumber2.doubleValue())))) {
      return paramNumber1;
    }
    if (((paramNumber1 == null) || (Double.isNaN(paramNumber1.doubleValue()))) && (paramNumber2 != null) && (!Double.isNaN(paramNumber2.doubleValue()))) {
      return paramNumber2;
    }
    return null;
  }
  
  public static Object maxObj(Collection paramCollection)
  {
    if ((paramCollection == null) || (paramCollection.size() == 0)) {
      return null;
    }
    Object localObject1 = null;
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject2 = localIterator.next();
      if (localObject2 != null)
      {
        Comparable localComparable = (Comparable)localObject2;
        if ((localObject1 == null) || (localComparable.compareTo(localObject1) > 0)) {
          localObject1 = localComparable;
        }
      }
    }
    return localObject1;
  }
  
  public static Object minObj(Collection paramCollection)
  {
    if ((paramCollection == null) || (paramCollection.size() == 0)) {
      return null;
    }
    Object localObject1 = null;
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject2 = localIterator.next();
      if (localObject2 != null)
      {
        Comparable localComparable = (Comparable)localObject2;
        if ((localObject1 == null) || (localComparable.compareTo(localObject1) < 0)) {
          localObject1 = localComparable;
        }
      }
    }
    return localObject1;
  }
  
  public static Number max(Collection paramCollection)
  {
    if ((paramCollection == null) || (paramCollection.size() == 0)) {
      return null;
    }
    Object localObject1 = null;
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject2 = localIterator.next();
      Number localNumber = Coercions.toNumber(localObject2, null);
      if ((localNumber != null) && ((localObject1 == null) || (localNumber.doubleValue() > ((Number)localObject1).doubleValue()))) {
        localObject1 = localNumber;
      }
    }
    return (Number)localObject1;
  }
  
  public static Number min(Collection paramCollection)
  {
    if ((paramCollection == null) || (paramCollection.size() == 0)) {
      return null;
    }
    Object localObject1 = null;
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject2 = localIterator.next();
      Number localNumber = Coercions.toNumber(localObject2, null);
      if ((localNumber != null) && ((localObject1 == null) || (localNumber.doubleValue() < ((Number)localObject1).doubleValue()))) {
        localObject1 = localNumber;
      }
    }
    return (Number)localObject1;
  }
  
  public static Number diff(Collection paramCollection)
  {
    if ((paramCollection == null) || (paramCollection.size() == 0)) {
      return null;
    }
    Number localNumber1 = max(paramCollection);
    Number localNumber2 = min(paramCollection);
    if ((localNumber1 == null) || (localNumber2 == null)) {
      return null;
    }
    return Double.valueOf(localNumber1.doubleValue() - localNumber2.doubleValue());
  }
  
  public static List aDiv(List paramList)
  {
    if ((paramList == null) || (paramList.size() == 0)) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(paramList.size());
    int j = paramList.size();
    double d = avg(paramList).doubleValue();
    for (int i = 0; i < j; i++)
    {
      Number localNumber = (Number)paramList.get(i);
      if (localNumber != null) {
        localArrayList.add(new Double(localNumber.doubleValue() - d));
      } else {
        localArrayList.add(null);
      }
    }
    return localArrayList;
  }
  
  public static List rDiv(List paramList)
  {
    if ((paramList == null) || (paramList.size() == 0)) {
      return null;
    }
    ArrayList localArrayList = new ArrayList();
    double d = avg(paramList).doubleValue();
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      Number localNumber = (Number)paramList.get(i);
      if ((d != 0.0D) && (localNumber != null)) {
        localArrayList.add(new Double((localNumber.doubleValue() - d) / d));
      } else {
        localArrayList.add(null);
      }
    }
    return localArrayList;
  }
  
  public static Number mDiv(List paramList)
  {
    if ((paramList == null) || (paramList.size() == 0)) {
      return null;
    }
    double d = Double.MIN_VALUE;
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      Number localNumber = (Number)rDiv(paramList).get(i);
      if ((localNumber != null) && (Math.abs(localNumber.doubleValue()) > Math.abs(d))) {
        d = localNumber.doubleValue();
      }
    }
    return Double.valueOf(d);
  }
  
  public static Number stdev(List paramList)
  {
    if ((paramList == null) || (paramList.size() == 0)) {
      return null;
    }
    double d1 = 0.0D;
    double d2 = 0.0D;
    Number localNumber1 = avg(paramList);
    if (localNumber1 == null) {
      return null;
    }
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      Number localNumber2 = (Number)paramList.get(i);
      if (localNumber2 != null)
      {
        d2 = subtract(localNumber2, localNumber1).doubleValue();
        d2 = multiply(d2, d2).doubleValue();
        d1 = add(d1, d2).doubleValue();
      }
    }
    if (j > 1)
    {
      d1 /= (j - 1);
      d1 = Math.sqrt(d1);
    }
    return Double.valueOf(d1);
  }
  
  public static Number var(List paramList)
  {
    if ((paramList == null) || (paramList.size() == 0)) {
      return null;
    }
    double d1 = 0.0D;
    Number localNumber1 = stdev(paramList);
    if (localNumber1 == null) {
      return null;
    }
    double d2 = localNumber1.doubleValue();
    Number localNumber2 = avg(paramList);
    if (localNumber2 == null) {
      return null;
    }
    double d3 = localNumber2.doubleValue();
    if (d3 != 0.0D) {
      d1 = d2 / d3;
    }
    return Double.valueOf(d1);
  }
  
  public static Number roundDouble(double paramDouble, int paramInt)
  {
    if (Double.isNaN(paramDouble)) {
      return null;
    }
    if (Double.isInfinite(paramDouble)) {
      throw Exceptions.code("lims.CAN_err_number_to_round_is_infinite").param(paramDouble);
    }
    BigDecimal localBigDecimal = new BigDecimal(Double.toString(paramDouble));
    return localBigDecimal.setScale(paramInt, 4);
  }
  
  public static Number roundNumber(Number paramNumber, int paramInt)
  {
    if (paramNumber == null) {
      return null;
    }
    return roundDouble(paramNumber.doubleValue(), paramInt);
  }
  
  public static Number round(Object paramObject, int paramInt)
  {
    if (paramObject == null) {
      return null;
    }
    Double localDouble = Double.valueOf(Double.parseDouble(String.valueOf(paramObject)));
    if (Double.isNaN(localDouble.doubleValue())) {
      return null;
    }
    return roundDouble(localDouble.doubleValue(), paramInt);
  }
  
  public static Number roundoff(Number paramNumber, int paramInt)
  {
    if (paramNumber == null) {
      return null;
    }
    return roundoff(paramNumber.doubleValue(), paramInt);
  }
  
  public static Number roundoff(Object paramObject, int paramInt)
  {
    if (paramObject == null) {
      return null;
    }
    return roundoff(Double.parseDouble(String.valueOf(paramObject)), paramInt);
  }
  
  public static Number roundoff(double paramDouble, int paramInt)
  {
    if (Double.isNaN(paramDouble)) {
      return null;
    }
    if (Double.isInfinite(paramDouble)) {
      throw Exceptions.code("lims.CAN_err_number_to_round_is_infinite").param(paramDouble);
    }
    BigDecimal localBigDecimal = new BigDecimal(Double.toString(paramDouble));
    return localBigDecimal.setScale(paramInt, 6);
  }
  
  public static Number roundDown(Number paramNumber, int paramInt)
  {
    if (paramNumber == null) {
      return null;
    }
    return roundDown(paramNumber.doubleValue(), paramInt);
  }
  
  public static Number roundDown(Object paramObject, int paramInt)
  {
    if (paramObject == null) {
      return null;
    }
    return roundDown(Double.parseDouble(String.valueOf(paramObject)), paramInt);
  }
  
  public static Number roundDown(double paramDouble, int paramInt)
  {
    if (Double.isNaN(paramDouble)) {
      return null;
    }
    if (Double.isInfinite(paramDouble)) {
      throw Exceptions.code("lims.CAN_err_number_to_round_is_infinite").param(paramDouble);
    }
    BigDecimal localBigDecimal = new BigDecimal(Double.toString(paramDouble));
    return localBigDecimal.setScale(paramInt, 1);
  }
  
  public static Number rd(double paramDouble1, double paramDouble2, int paramInt1, int paramInt2, int paramInt3)
  {
    if ((Double.isNaN(paramDouble1)) || (Double.isNaN(paramDouble2))) {
      return null;
    }
    if (COMPARE_MODE_GT == paramInt1)
    {
      if (paramDouble1 > paramDouble2) {
        return roundoff(paramDouble1, paramInt2);
      }
      return roundoff(paramDouble1, paramInt3);
    }
    if (paramDouble1 >= paramDouble2) {
      return roundoff(paramDouble1, paramInt2);
    }
    return roundoff(paramDouble1, paramInt3);
  }
  
  public static List roundoffEach(Collection paramCollection, int paramInt)
  {
    if ((paramCollection == null) || (paramCollection.size() == 0)) {
      return null;
    }
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      localArrayList.add(roundoff(localObject, paramInt));
    }
    return localArrayList;
  }
  
  public static Object roundData(Integer paramInteger, String paramString, Object paramObject)
  {
    if (paramObject == null) {
      return null;
    }
    if ((paramInteger != null) && (paramString != null)) {
      if (ROUND_RULE_FIVE_UP.equals(paramString)) {
        paramObject = round(paramObject, paramInteger.intValue());
      } else if (ROUND_RULE_SIX_UP.equals(paramString)) {
        paramObject = roundoff(paramObject, paramInteger.intValue());
      } else if (ROUND_RULE_DOWN.equals(paramString)) {
        paramObject = roundDown(paramObject, paramInteger.intValue());
      }
    }
    return paramObject;
  }
  
  public static List pluck(Collection paramCollection, String paramString)
  {
    if (paramCollection == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(paramCollection.size());
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      if (localObject == null) {
        localArrayList.add(null);
      } else {
        localArrayList.add(TplC.getProperty(localObject, paramString));
      }
    }
    return localArrayList;
  }
  
  public static List pluckWithDefault(Collection paramCollection, String paramString, Object paramObject)
  {
    if (paramCollection == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(paramCollection.size());
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject1 = localIterator.next();
      if (localObject1 == null)
      {
        localArrayList.add(paramObject);
      }
      else
      {
        Object localObject2 = TplC.getProperty(localObject1, paramString);
        localArrayList.add(localObject2 == null ? paramObject : localObject2);
      }
    }
    return localArrayList;
  }
  
  public static List<Map> pluckMap(Collection paramCollection, List<String> paramList)
  {
    if (paramCollection == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(paramCollection.size());
    Iterator localIterator1 = paramCollection.iterator();
    while (localIterator1.hasNext())
    {
      Object localObject = localIterator1.next();
      if (localObject == null)
      {
        localArrayList.add(null);
      }
      else
      {
        HashMap localHashMap = new HashMap();
        if (paramList != null)
        {
          Iterator localIterator2 = paramList.iterator();
          while (localIterator2.hasNext())
          {
            String str = (String)localIterator2.next();
            localHashMap.put(str, TplC.getProperty(localObject, str));
          }
        }
        localArrayList.add(localHashMap);
      }
    }
    return localArrayList;
  }
  
  public static List<List> pluckList(Collection paramCollection, List<String> paramList)
  {
    if (paramCollection == null) {
      return null;
    }
    ArrayList localArrayList1 = new ArrayList(paramCollection.size());
    Iterator localIterator1 = paramCollection.iterator();
    while (localIterator1.hasNext())
    {
      Object localObject = localIterator1.next();
      if (localObject == null)
      {
        localArrayList1.add(null);
      }
      else
      {
        ArrayList localArrayList2 = new ArrayList();
        if (paramList != null)
        {
          Iterator localIterator2 = paramList.iterator();
          while (localIterator2.hasNext())
          {
            String str = (String)localIterator2.next();
            localArrayList2.add(TplC.getProperty(localObject, str));
          }
        }
        localArrayList1.add(localArrayList2);
      }
    }
    return localArrayList1;
  }
  
  public static Collection remove(Collection paramCollection1, String paramString, Collection paramCollection2)
  {
    if (paramCollection1 == null) {
      return null;
    }
    Iterator localIterator = paramCollection1.iterator();
    while (localIterator.hasNext())
    {
      Object localObject1 = localIterator.next();
      if (localObject1 != null)
      {
        Object localObject2 = TplC.getProperty(localObject1, paramString);
        if (paramCollection2.contains(localObject2)) {
          localIterator.remove();
        }
      }
    }
    return paramCollection1;
  }
  
  public static Collection retain(Collection paramCollection1, String paramString, Collection paramCollection2)
  {
    if (paramCollection1 == null) {
      return null;
    }
    if (paramCollection2 == null) {
      return paramCollection1;
    }
    Iterator localIterator = paramCollection1.iterator();
    while (localIterator.hasNext())
    {
      Object localObject1 = localIterator.next();
      if (localObject1 == null)
      {
        localIterator.remove();
      }
      else
      {
        Object localObject2 = TplC.getProperty(localObject1, paramString);
        if (!paramCollection2.contains(localObject2)) {
          localIterator.remove();
        }
      }
    }
    return paramCollection1;
  }
  
  public static List cast(Collection paramCollection, Class paramClass)
  {
    if (paramCollection == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject1 = localIterator.next();
      if (paramClass.isInstance(localObject1))
      {
        localArrayList.add(localObject1);
      }
      else
      {
        Object localObject2;
        if (((localObject1 instanceof AbstractEntity)) && (paramClass == String.class))
        {
          localObject2 = ((AbstractEntity)localObject1).getIdAsString();
          localArrayList.add(localObject2);
        }
        else if (AbstractEntity.class.isAssignableFrom(paramClass))
        {
          localObject2 = EntityManager.get(paramClass, localObject1);
          localArrayList.add(localObject2);
        }
        else
        {
          localArrayList.add(Coercions.cast(paramClass, localObject1));
        }
      }
    }
    return localArrayList;
  }
  
  public static void removeByFld(Collection paramCollection, String paramString, Object paramObject)
  {
    if (paramCollection == null) {
      return;
    }
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject1 = localIterator.next();
      if (localObject1 != null)
      {
        Object localObject2 = TplC.getProperty(localObject1, paramString);
        if (localObject2 == paramObject) {
          localIterator.remove();
        } else if ((paramObject != null) && (paramObject.equals(localObject2))) {
          localIterator.remove();
        }
      }
    }
  }
  
  public static List removeByFldFromNew(Collection paramCollection, String paramString, Object paramObject)
  {
    if (paramCollection == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(paramCollection);
    Iterator localIterator = localArrayList.iterator();
    while (localIterator.hasNext())
    {
      Object localObject1 = localIterator.next();
      if (localObject1 != null)
      {
        Object localObject2 = TplC.getProperty(localObject1, paramString);
        if (localObject2 == paramObject) {
          localIterator.remove();
        } else if ((paramObject != null) && (paramObject.equals(localObject2))) {
          localIterator.remove();
        }
      }
    }
    return localArrayList;
  }
  
  public static Object find(Collection paramCollection, String paramString, Object paramObject)
  {
    if (paramCollection == null) {
      return null;
    }
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject1 = localIterator.next();
      if (localObject1 != null)
      {
        Object localObject2 = TplC.getProperty(localObject1, paramString);
        if (eqEx(localObject2, paramObject)) {
          return localObject1;
        }
      }
    }
    return null;
  }
  
  public static boolean eqEx(Object paramObject1, Object paramObject2)
  {
    if (paramObject1 == paramObject2) {
      return true;
    }
    if (paramObject1 == null) {
      return paramObject2 == null;
    }
    if (paramObject1.equals(paramObject2)) {
      return true;
    }
    if ((paramObject1 instanceof IDbColumnData))
    {
      String str = Coercions.toString((IDbColumnData)paramObject1, "");
      if (str.equals(Coercions.toString(paramObject2, ""))) {
        return true;
      }
    }
    else
    {
      if (((paramObject1 instanceof Number)) && (paramObject1.toString().equals(paramObject2))) {
        return true;
      }
      if (((paramObject2 instanceof Number)) && (paramObject2.toString().equals(paramObject1))) {
        return true;
      }
    }
    return false;
  }
  
  public static List findMany(Collection paramCollection, String paramString, Object paramObject)
  {
    if (paramCollection == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject1 = localIterator.next();
      if (localObject1 != null)
      {
        Object localObject2 = TplC.getProperty(localObject1, paramString);
        if (eqEx(localObject2, paramObject)) {
          localArrayList.add(localObject1);
        }
      }
    }
    return localArrayList;
  }
  
  public static Object findByMultiFields(Collection paramCollection, List paramList1, List paramList2)
  {
    if ((paramCollection == null) || (paramList1 == null) || (paramList2 == null)) {
      return null;
    }
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject1 = localIterator.next();
      if (localObject1 != null)
      {
        int i = 1;
        int j = paramList1.size();
        for (int k = 0; k < j; k++)
        {
          String str = (String)paramList1.get(k);
          Object localObject2 = paramList2.get(k);
          Object localObject3 = TplC.getProperty(localObject1, str);
          if (localObject3 == null)
          {
            i = 0;
            break;
          }
          if ((localObject3 != localObject2) && (!localObject3.equals(localObject2)))
          {
            i = 0;
            break;
          }
        }
        if (i != 0) {
          return localObject1;
        }
      }
    }
    return null;
  }
  
  public static List compact(Collection paramCollection)
  {
    if (paramCollection == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      if ((localObject != null) && ((!(localObject instanceof String)) || (localObject.toString().length() != 0))) {
        localArrayList.add(localObject);
      }
    }
    return localArrayList;
  }
  
  public static Integer outR(List paramList, double paramDouble1, double paramDouble2)
  {
    return outB(paramList, multiply(Double.valueOf(paramDouble1), subtract(1.0D, paramDouble2)).doubleValue(), multiply(Double.valueOf(paramDouble1), add(1.0D, paramDouble2)).doubleValue());
  }
  
  public static Integer outR(List paramList, int paramInt, double paramDouble1, double paramDouble2)
  {
    return outR(roundoffEach(paramList, paramInt), paramDouble1, paramDouble2);
  }
  
  public static Integer outP(List paramList, Number paramNumber1, Number paramNumber2)
  {
    if ((paramList == null) || (paramList.size() == 0) || (paramNumber1 == null) || (paramNumber2 == null)) {
      return null;
    }
    return outB(paramList, subtract(paramNumber1, paramNumber2).doubleValue(), add(paramNumber1, paramNumber2).doubleValue());
  }
  
  public static Integer outP(List paramList, int paramInt, Number paramNumber1, Number paramNumber2)
  {
    if ((paramList == null) || (paramList.size() == 0) || (paramNumber1 == null) || (paramNumber2 == null)) {
      return null;
    }
    return outB(roundoffEach(paramList, paramInt), subtract(paramNumber1, paramNumber2).doubleValue(), add(paramNumber1, paramNumber2).doubleValue());
  }
  
  public static Integer outB(List paramList, double paramDouble1, double paramDouble2)
  {
    if ((paramList == null) || (paramList.size() == 0)) {
      return null;
    }
    int i = 0;
    for (int j = 0; j < paramList.size(); j++)
    {
      double d = Variant.valueOf(paramList.get(j)).doubleValue(0.0D);
      if (!inBound(d, paramDouble1, paramDouble2)) {
        i++;
      }
    }
    return Integer.valueOf(i);
  }
  
  public static Integer outB(List paramList, Number paramNumber1, Number paramNumber2)
  {
    if ((paramList == null) || (paramList.size() == 0)) {
      return null;
    }
    int i = 0;
    for (int j = 0; j < paramList.size(); j++)
    {
      double d = Variant.valueOf(paramList.get(j)).doubleValue(0.0D);
      if (!inBound(d, paramNumber1, paramNumber2)) {
        i++;
      }
    }
    return Integer.valueOf(i);
  }
  
  public static Integer inB(List paramList, double paramDouble1, double paramDouble2)
  {
    if ((paramList == null) || (paramList.size() == 0)) {
      return null;
    }
    int i = 0;
    for (int j = 0; j < paramList.size(); j++)
    {
      double d = Variant.valueOf(paramList.get(j)).doubleValue(0.0D);
      if (inBound(d, paramDouble1, paramDouble2)) {
        i++;
      }
    }
    return Integer.valueOf(i);
  }
  
  public static Integer outB(List paramList, int paramInt, Number paramNumber1, Number paramNumber2)
  {
    return outB(roundoffEach(paramList, paramInt), paramNumber1, paramNumber2);
  }
  
  public static boolean between(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    return inBound(paramDouble1, subtract(paramDouble2, paramDouble3).doubleValue(), add(paramDouble2, paramDouble3).doubleValue());
  }
  
  public static boolean between(double paramDouble1, int paramInt, double paramDouble2, double paramDouble3)
  {
    return between(roundoff(paramDouble1, paramInt).doubleValue(), paramDouble2, paramDouble3);
  }
  
  public static boolean inRange(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    return inBound(paramDouble1, multiply(Double.valueOf(paramDouble2), subtract(1.0D, paramDouble3)).doubleValue(), multiply(Double.valueOf(paramDouble2), add(1.0D, paramDouble3)).doubleValue());
  }
  
  public static boolean inRange(double paramDouble1, int paramInt, double paramDouble2, double paramDouble3)
  {
    return inBound(roundoff(paramDouble1, paramInt).doubleValue(), multiply(Double.valueOf(paramDouble2), subtract(1.0D, paramDouble3)).doubleValue(), multiply(Double.valueOf(paramDouble2), add(1.0D, paramDouble3)).doubleValue());
  }
  
  public static boolean inBound(Number paramNumber, double paramDouble1, double paramDouble2)
  {
    if (paramNumber == null) {
      return false;
    }
    return inBound(paramNumber.doubleValue(), paramDouble1, paramDouble2);
  }
  
  public static boolean inBound(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    return (paramDouble1 >= paramDouble2) && (paramDouble1 <= paramDouble3);
  }
  
  public static boolean inBound(double paramDouble, Number paramNumber1, Number paramNumber2)
  {
    if ((paramNumber1 == null) && (paramNumber2 == null)) {
      return true;
    }
    if ((paramNumber1 != null) && (paramNumber2 == null)) {
      return paramDouble > paramNumber1.doubleValue();
    }
    if ((paramNumber1 == null) && (paramNumber2 != null)) {
      return paramDouble < paramNumber2.doubleValue();
    }
    return inBound(paramDouble, paramNumber1.doubleValue(), paramNumber2.doubleValue());
  }
  
  public static List removeDuplicate(Collection paramCollection)
  {
    if (paramCollection == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(paramCollection.size());
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      if (!localArrayList.contains(localObject)) {
        localArrayList.add(localObject);
      }
    }
    return localArrayList;
  }
  
  public static List sort(Collection paramCollection)
  {
    if (paramCollection == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(paramCollection);
    Collections.sort(localArrayList, SafeComparator.SINGLETON);
    return localArrayList;
  }
  
  public static List nearMean(List paramList, boolean paramBoolean, int paramInt)
  {
    if (paramList == null) {
      return null;
    }
    double d = Variant.valueOf(avg(paramList)).doubleValue(0.0D);
    ArrayList localArrayList = new ArrayList(paramList);
    Collections.sort(localArrayList, new Comparator()
    {
      public int compare(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        int i = 0;
        double d1 = Math.abs(Variant.valueOf(paramAnonymousObject1).doubleValue(0.0D) - this.A);
        double d2 = Math.abs(Variant.valueOf(paramAnonymousObject2).doubleValue(0.0D) - this.A);
        if (d1 == d2) {
          i = 0;
        } else if (d1 > d2) {
          i = this.B ? 1 : -1;
        } else {
          i = this.B ? -1 : 1;
        }
        return i;
      }
    });
    if (paramInt > localArrayList.size()) {
      paramInt = localArrayList.size();
    }
    return localArrayList.subList(0, paramInt);
  }
  
  public static List nearMean(Collection paramCollection, String paramString, final boolean paramBoolean, int paramInt)
  {
    if (paramCollection == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(paramCollection);
    final double d = Variant.valueOf(avg(pluck(paramCollection, paramString))).doubleValue(0.0D);
    Collections.sort(localArrayList, new Comparator()
    {
      public int compare(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        int i = 0;
        Double localDouble1 = Double.valueOf(Variant.valueOf(TplC.getProperty(paramAnonymousObject1, Alog.this)).doubleValue());
        Double localDouble2 = Double.valueOf(Variant.valueOf(TplC.getProperty(paramAnonymousObject2, Alog.this)).doubleValue());
        if (localDouble1 == null) {
          localDouble1 = Double.valueOf(paramBoolean ? Double.MAX_VALUE : Double.MIN_VALUE);
        }
        if (localDouble2 == null) {
          localDouble2 = Double.valueOf(paramBoolean ? Double.MAX_VALUE : Double.MIN_VALUE);
        }
        double d1 = Math.abs(localDouble1.doubleValue() - d);
        double d2 = Math.abs(localDouble2.doubleValue() - d);
        if (d1 == d2) {
          i = 0;
        } else {
          i = Double.valueOf(d1).compareTo(Double.valueOf(d2));
        }
        return paramBoolean ? i : -i;
      }
    });
    if (paramInt > localArrayList.size()) {
      paramInt = localArrayList.size();
    }
    return localArrayList.subList(0, paramInt);
  }
  
  public static void sortListByFld(List paramList, String paramString, final boolean paramBoolean)
  {
    if (paramList == null) {
      return;
    }
    Collections.sort(paramList, new Comparator()
    {
      public int compare(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        if (paramAnonymousObject1 == paramAnonymousObject2) {
          return 0;
        }
        if (paramAnonymousObject1 == null) {
          return -1;
        }
        if (paramAnonymousObject2 == null) {
          return 1;
        }
        int i = 0;
        Object localObject1 = TplC.getProperty(paramAnonymousObject1, Alog.this);
        Object localObject2 = TplC.getProperty(paramAnonymousObject2, Alog.this);
        if (localObject1 == localObject2) {
          i = 0;
        } else if (localObject1 == null) {
          i = -1;
        } else if (localObject2 == null) {
          i = 1;
        } else {
          i = ((Comparable)localObject1).compareTo(localObject2);
        }
        return paramBoolean ? i : -i;
      }
    });
  }
  
  public static List sortByFld(Collection paramCollection, String paramString, boolean paramBoolean)
  {
    if (paramCollection == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(paramCollection);
    sortListByFld(localArrayList, paramString, paramBoolean);
    return localArrayList;
  }
  
  public static void setProperty(Collection paramCollection, String paramString, Object paramObject)
  {
    if (paramCollection == null) {
      return;
    }
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      if (localObject != null) {
        TplC.setProperty(localObject, paramString, paramObject);
      }
    }
  }
  
  public static boolean isEq(Object paramObject1, Object paramObject2)
  {
    return paramObject1 == null ? false : paramObject2 == null ? true : paramObject1.equals(paramObject2);
  }
  
  public static boolean isAllEq(Collection paramCollection, String paramString, Object paramObject)
  {
    if (paramCollection == null) {
      return true;
    }
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = TplC.getProperty(localIterator.next(), paramString);
      if (localObject == null)
      {
        if (paramObject != null) {
          return false;
        }
      }
      else if (!localObject.equals(paramObject)) {
        return false;
      }
    }
    return true;
  }
  
  public static int countByFld(Collection paramCollection, String paramString, Object paramObject)
  {
    if (paramCollection == null) {
      return 0;
    }
    int i = 0;
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject1 = localIterator.next();
      Object localObject2 = TplC.getProperty(localObject1, paramString);
      if (isEq(localObject2, paramObject)) {
        i++;
      }
    }
    return i;
  }
  
  public static Integer countTrueNum(Collection paramCollection)
  {
    if (paramCollection == null) {
      return null;
    }
    int i = 0;
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      if (Variant.valueOf(localObject).booleanValue(false)) {
        i++;
      }
    }
    return Integer.valueOf(i);
  }
  
  public static int getStringByteCount(String paramString)
  {
    if (paramString == null) {
      return 0;
    }
    return paramString.getBytes().length;
  }
  
  public static Number add(Number paramNumber1, Number paramNumber2)
  {
    if ((paramNumber1 == null) || (paramNumber2 == null)) {
      return null;
    }
    return add(paramNumber1.doubleValue(), paramNumber2.doubleValue());
  }
  
  public static Number add(double paramDouble1, double paramDouble2)
  {
    if ((Double.isNaN(paramDouble1)) || (Double.isNaN(paramDouble2))) {
      return null;
    }
    return new BigDecimal(String.valueOf(paramDouble1)).add(new BigDecimal(String.valueOf(paramDouble2)));
  }
  
  public static Number subtract(Number paramNumber1, Number paramNumber2)
  {
    if ((paramNumber1 == null) || (paramNumber2 == null)) {
      return null;
    }
    return subtract(paramNumber1.doubleValue(), paramNumber2.doubleValue());
  }
  
  public static Number subtract(double paramDouble1, double paramDouble2)
  {
    if ((Double.isNaN(paramDouble1)) || (Double.isNaN(paramDouble2))) {
      return null;
    }
    return new BigDecimal(String.valueOf(paramDouble1)).subtract(new BigDecimal(String.valueOf(paramDouble2)));
  }
  
  public static Number multiply(Number paramNumber1, Number paramNumber2)
  {
    if ((paramNumber1 == null) || (paramNumber2 == null)) {
      return null;
    }
    return multiply(paramNumber1.doubleValue(), paramNumber2.doubleValue());
  }
  
  public static Number multiply(double paramDouble1, double paramDouble2)
  {
    if ((Double.isNaN(paramDouble1)) || (Double.isNaN(paramDouble2))) {
      return null;
    }
    return new BigDecimal(String.valueOf(paramDouble1)).multiply(new BigDecimal(String.valueOf(paramDouble2)));
  }
  
  public static Number divide(Number paramNumber1, Number paramNumber2)
  {
    if ((paramNumber1 == null) || (paramNumber2 == null)) {
      return null;
    }
    return divide(paramNumber1.doubleValue(), paramNumber2.doubleValue());
  }
  
  public static Number divide(double paramDouble1, double paramDouble2)
  {
    if ((Double.isNaN(paramDouble1)) || (Double.isNaN(paramDouble2))) {
      return null;
    }
    return new BigDecimal(String.valueOf(paramDouble1)).divide(new BigDecimal(String.valueOf(paramDouble2)));
  }
  
  public static List checkLimit(List paramList, double paramDouble)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      if (Variant.valueOf(localObject).doubleValue(0.0D) < paramDouble) {
        localArrayList.add(Integer.valueOf(0));
      } else {
        localArrayList.add(localObject);
      }
    }
    return localArrayList;
  }
  
  public static boolean isOverStepPV(double paramDouble1, double paramDouble2, Number paramNumber)
  {
    return !isEligible(paramDouble1, null, paramDouble2, paramNumber, null);
  }
  
  public static boolean isOverStepPV(double paramDouble1, Integer paramInteger, double paramDouble2, Number paramNumber)
  {
    return !isEligible(paramDouble1, paramInteger, paramDouble2, paramNumber, null);
  }
  
  public static boolean isOverStepPR(double paramDouble1, double paramDouble2, Number paramNumber)
  {
    return !isEligible(paramDouble1, null, paramDouble2, null, paramNumber);
  }
  
  public static boolean isOverStepPR(double paramDouble1, Integer paramInteger, double paramDouble2, Number paramNumber)
  {
    return !isEligible(paramDouble1, paramInteger, paramDouble2, null, paramNumber);
  }
  
  public static boolean isEligible(double paramDouble1, Integer paramInteger, double paramDouble2, Number paramNumber1, Number paramNumber2)
  {
    if (paramNumber1 != null)
    {
      if (paramInteger == null) {
        return between(paramDouble1, paramDouble2, paramNumber1.doubleValue());
      }
      return between(paramDouble1, paramInteger.intValue(), paramDouble2, paramNumber1.doubleValue());
    }
    if (paramNumber2 != null)
    {
      if (paramInteger == null) {
        return inRange(paramDouble1, paramDouble2, paramNumber2.doubleValue());
      }
      return inRange(paramDouble1, paramInteger.intValue(), paramDouble2, paramNumber2.doubleValue());
    }
    return true;
  }
  
  public static List multiplyEach(Collection paramCollection, Number paramNumber)
  {
    if ((paramCollection == null) || (paramCollection.size() == 0) || (paramNumber == null)) {
      return null;
    }
    return multiplyEach(paramCollection, paramNumber.doubleValue());
  }
  
  public static List multiplyEach(Collection paramCollection, double paramDouble)
  {
    if ((paramCollection == null) || (paramCollection.size() == 0) || (Double.isNaN(paramDouble))) {
      return null;
    }
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      Number localNumber = Coercions.toNumber(localObject, null);
      if (localNumber == null) {
        localArrayList.add(null);
      } else {
        localArrayList.add(multiply(localNumber.doubleValue(), paramDouble));
      }
    }
    return localArrayList;
  }
  
  public static List cloneList(Collection paramCollection)
  {
    if (paramCollection == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(paramCollection.size());
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      if (localObject == null) {
        localArrayList.add(null);
      } else {
        localArrayList.add(new BeanInstance(localObject).cloneInstance(false));
      }
    }
    return localArrayList;
  }
  
  public static void main(String[] paramArrayOfString)
  {
    Number localNumber1 = round("3.399999999999999998", 3);
    Debug.trace(localNumber1.doubleValue());
    Number localNumber2 = round("12227999980.0011122e15", 3);
    Debug.trace(Double.valueOf(localNumber2.doubleValue()));
  }
  
  public static List addCollection(Collection<Collection> paramCollection)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      Collection localCollection = (Collection)localIterator.next();
      if (localCollection != null) {
        localArrayList.addAll(localCollection);
      }
    }
    return localArrayList;
  }
  
  public static List makeRanges(Collection paramCollection)
  {
    if ((paramCollection == null) || (paramCollection.size() == 0)) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(paramCollection.size() - 1);
    Iterator localIterator = paramCollection.iterator();
    double d1 = 0.0D;
    if (localIterator.hasNext()) {}
    double d2;
    for (d1 = Variant.valueOf(localIterator.next()).doubleValue(0.0D); localIterator.hasNext(); d1 = d2)
    {
      d2 = Variant.valueOf(localIterator.next()).doubleValue(0.0D);
      localArrayList.add(Double.valueOf(Math.abs(d2 - d1)));
    }
    return localArrayList;
  }
  
  public static String fmtNumberString(BigDecimal paramBigDecimal)
  {
    if (paramBigDecimal == null) {
      return null;
    }
    if ((paramBigDecimal.scale() < 0) && (Math.abs(paramBigDecimal.longValue()) < 1000000L)) {
      return Long.toString(paramBigDecimal.longValue());
    }
    return paramBigDecimal.toString();
  }
  
  public static void putOneToManyMap(List<Map> paramList, String paramString, Object paramObject)
  {
    if ((paramString == null) || (paramList == null)) {
      return;
    }
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      Map localMap = (Map)paramList.get(i);
      localMap.put(paramString, paramObject);
    }
  }
  
  public static void putMany(List<Map> paramList, String paramString, List<Object> paramList1)
  {
    if ((paramString == null) || (paramList == null) || (paramList1 == null)) {
      return;
    }
    if (paramList.size() != paramList1.size()) {
      return;
    }
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      Map localMap = (Map)paramList.get(i);
      localMap.put(paramString, paramList1.get(i));
    }
  }
  
  public static List<Map> replaceMapKey(List<Map> paramList, Object paramObject1, Object paramObject2)
  {
    if ((paramList == null) || (paramObject1 == null) || (paramObject2 == null)) {
      return paramList;
    }
    int j = paramList.size();
    for (int i = 0; i < j; i++)
    {
      Map localMap = (Map)paramList.get(i);
      if (localMap != null)
      {
        Object localObject = localMap.get(paramObject1);
        if (localObject != null)
        {
          localMap.put(paramObject2, localObject);
          localMap.remove(paramObject1);
        }
      }
    }
    return paramList;
  }
  
  public static EasyCalendar moveYear(Timestamp paramTimestamp, int paramInt)
  {
    if (paramTimestamp == null) {
      return null;
    }
    EasyCalendar localEasyCalendar = new EasyCalendar();
    localEasyCalendar.setTimeInMillis(paramTimestamp.getTime());
    localEasyCalendar.moveYear(paramInt);
    return localEasyCalendar;
  }
  
  public static EasyCalendar moveMonth(Timestamp paramTimestamp, int paramInt)
  {
    if (paramTimestamp == null) {
      return null;
    }
    EasyCalendar localEasyCalendar = new EasyCalendar();
    localEasyCalendar.setTimeInMillis(paramTimestamp.getTime());
    localEasyCalendar.moveMonth(paramInt);
    return localEasyCalendar;
  }
  
  public static Map transMultiMapToOne(List<Map> paramList)
  {
    if (paramList == null) {
      return null;
    }
    LinkedHashMap localLinkedHashMap = new LinkedHashMap();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      Map localMap = (Map)localIterator.next();
      if ((localMap != null) && (!localMap.isEmpty())) {
        localLinkedHashMap.putAll(localMap);
      }
    }
    return localLinkedHashMap;
  }
  
  public static void removeNullTail(List paramList)
  {
    if (paramList != null)
    {
      int j = paramList.size() - 1;
      for (int i = j - 1; i >= 0; i--)
      {
        if (paramList.get(i) != null) {
          break;
        }
        paramList.remove(i);
      }
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\math\alg\Alog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */