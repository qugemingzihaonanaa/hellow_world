package edu.thu.apm.impl;

import edu.thu.apm.AppResourceLoader;
import edu.thu.core.IResource;
import edu.thu.util.UrlUtils;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;

public class LazyLoadResource
  implements IResource
{
  private static final long serialVersionUID = 8244533894627470461L;
  String stdPath;
  String path;
  IResource _resource;
  
  public LazyLoadResource(String paramString1, String paramString2)
  {
    this.path = paramString2;
    this.stdPath = paramString1;
  }
  
  synchronized IResource loadResource()
  {
    if (this._resource == null) {
      this._resource = AppResourceLoader.getInstance().getCustomizableResource(this.path);
    }
    return this._resource;
  }
  
  public boolean exists()
  {
    return loadResource().exists();
  }
  
  public InputStream getInputStream()
  {
    return loadResource().getInputStream();
  }
  
  public OutputStream getOutputStream()
  {
    return loadResource().getOutputStream();
  }
  
  public String getStdPath()
  {
    return this.stdPath;
  }
  
  public String getPath()
  {
    return this.path;
  }
  
  public String getFileName()
  {
    return UrlUtils.getFullName(this.path.replace('\\', '/'));
  }
  
  public long lastModified()
  {
    return loadResource().lastModified();
  }
  
  public long length()
  {
    return loadResource().length();
  }
  
  public boolean delete()
  {
    return loadResource().delete();
  }
  
  public File getLocalFile()
  {
    return loadResource().getLocalFile();
  }
  
  public void saveToFile(File paramFile)
  {
    loadResource().saveToFile(paramFile);
  }
  
  public void setLastModified(long paramLong)
  {
    loadResource().setLastModified(paramLong);
  }
  
  public URL toURL()
  {
    return loadResource().toURL();
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\apm\impl\LazyLoadResource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */