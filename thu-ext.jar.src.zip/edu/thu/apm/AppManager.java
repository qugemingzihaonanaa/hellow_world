package edu.thu.apm;

import edu.thu.config.AppConfig;
import edu.thu.ext.spring.BeanLazyInitializer;
import edu.thu.service.BeanLoader;
import edu.thu.service.ThreadServiceContext;
import edu.thu.service.bean.IBeanLoader;
import edu.thu.tools.lib.TplActionSet;
import edu.thu.user.IUserContext;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public abstract class AppManager
  implements ApmConstants
{
  IBeanLoader A;
  IBeanLoader D;
  IBeanLoader E;
  TplActionSet B;
  TplActionSet C;
  
  public static AppManager getInstance()
  {
    return (AppManager)BeanLoader.getBean(AppManager.class);
  }
  
  public void setModuleIds(List<String> paramList)
  {
    AppResourceLoader.getInstance().setModuleIds(paramList);
  }
  
  public TplActionSet getAopActionSet()
  {
    return this.B;
  }
  
  public TplActionSet getSecureActionSet()
  {
    return this.C;
  }
  
  public void setAopActionSet(TplActionSet paramTplActionSet)
  {
    this.B = paramTplActionSet;
  }
  
  public IBeanLoader getBaseBeanLoader()
  {
    return this.A;
  }
  
  public IBeanLoader getAppBeanLoader()
  {
    return this.D;
  }
  
  public AppResourceLoader getResourceLoader()
  {
    return AppResourceLoader.getInstance();
  }
  
  public String getAppId()
  {
    return getResourceLoader().getAppId();
  }
  
  public String getDefaultAppId()
  {
    return getResourceLoader().getDefaultAppId();
  }
  
  public IBeanLoader getWebBeanLoader()
  {
    return this.E;
  }
  
  public void initUserContext(IUserContext paramIUserContext)
  {
    HashMap localHashMap = new HashMap(3);
    localHashMap.put("userContext", paramIUserContext);
    getResourceLoader().invokeModuleAction("initUserContext", localHashMap);
  }
  
  public void clearCache()
  {
    getResourceLoader().clearCache();
    if (this.B != null) {
      this.B.clearCache();
    }
    if (this.C != null) {
      this.C.clearCache();
    }
  }
  
  void B() {}
  
  public void start()
  {
    AppResourceLoader localAppResourceLoader = getResourceLoader();
    if (AppConfig.isConfigMode())
    {
      E();
    }
    else
    {
      localAppResourceLoader.start();
      A();
      D();
      G();
      F();
      BeanLazyInitializer localBeanLazyInitializer = (BeanLazyInitializer)BeanLoader.getBean(BeanLazyInitializer.class);
      localBeanLazyInitializer.runAndClear();
      localAppResourceLoader.init();
      C();
      localBeanLazyInitializer = (BeanLazyInitializer)BeanLoader.getBean(BeanLazyInitializer.class);
      localBeanLazyInitializer.runAndClear();
    }
  }
  
  void A()
  {
    this.B = new TplActionSet();
    AppResourceLoader localAppResourceLoader = getResourceLoader();
    List localList = localAppResourceLoader.getAppAopFilePath();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      this.B.addLazyLib("aop", str);
    }
  }
  
  void D()
  {
    this.C = new TplActionSet();
    AppResourceLoader localAppResourceLoader = getResourceLoader();
    List localList = localAppResourceLoader.getAppSecureFilePath();
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      this.C.addLazyLib("sec", str);
    }
  }
  
  public Object execSecureAction(String paramString, Map<String, Object> paramMap)
  {
    if (this.C == null) {
      return null;
    }
    return this.C.execTpl("sec:" + paramString, paramMap, ThreadServiceContext.getCurrentContext());
  }
  
  protected List<String> getConfigBeansFilePath()
  {
    return getResourceLoader().getConfigBeansFilePath();
  }
  
  protected List<String> getBaseBeansFilePath()
  {
    return getResourceLoader().getBaseBeansFilePath();
  }
  
  protected List<String> getAppBeansFilePath()
  {
    return getResourceLoader().getAppBeansFilePath();
  }
  
  protected List<String> getWebBeansFilePath()
  {
    return getResourceLoader().getWebBeansFilePath();
  }
  
  void E()
  {
    String[] arrayOfString = (String[])getConfigBeansFilePath().toArray(new String[0]);
    IBeanLoader localIBeanLoader = createBeanLoader("config", arrayOfString, BeanLoader.getInstance());
    BeanLoader.registerInstance(localIBeanLoader);
    localIBeanLoader.refresh();
    this.A = localIBeanLoader;
    this.D = localIBeanLoader;
    this.E = localIBeanLoader;
  }
  
  void G()
  {
    String[] arrayOfString = (String[])getBaseBeansFilePath().toArray(new String[0]);
    IBeanLoader localIBeanLoader = createBeanLoader("base", arrayOfString, BeanLoader.getInstance());
    BeanLoader.registerInstance(localIBeanLoader);
    this.A = localIBeanLoader;
    localIBeanLoader.refresh();
  }
  
  void F()
  {
    String[] arrayOfString = (String[])getAppBeansFilePath().toArray(new String[0]);
    IBeanLoader localIBeanLoader = createBeanLoader("app", arrayOfString, BeanLoader.getInstance());
    BeanLoader.registerInstance(localIBeanLoader);
    this.D = localIBeanLoader;
    localIBeanLoader.refresh();
  }
  
  void C()
  {
    String[] arrayOfString = (String[])getWebBeansFilePath().toArray(new String[0]);
    IBeanLoader localIBeanLoader = createBeanLoader("web", arrayOfString, BeanLoader.getInstance());
    this.E = localIBeanLoader;
    localIBeanLoader.refresh();
  }
  
  public void refreshWebBeanLoader()
  {
    this.E.refresh();
  }
  
  public void refreshAppBeanLoader(boolean paramBoolean)
  {
    this.D.refresh();
    if (paramBoolean) {
      this.E.refresh();
    }
  }
  
  public void refreshBaseBeanLoader()
  {
    this.A.refresh();
    this.D.refresh();
    this.E.refresh();
  }
  
  public void stop()
  {
    getResourceLoader().stop();
    if (this.E != null) {
      this.E.stop();
    }
    if (this.D != null) {
      this.D.stop();
    }
    if (this.A != null) {
      this.A.stop();
    }
  }
  
  protected abstract IBeanLoader createBeanLoader(String paramString, String[] paramArrayOfString, IBeanLoader paramIBeanLoader);
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\apm\AppManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */