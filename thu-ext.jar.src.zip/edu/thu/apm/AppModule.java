package edu.thu.apm;

import edu.thu.service.SystemServiceContext;
import edu.thu.tools.lib.TplActionSet;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class AppModule
  implements Serializable
{
  private static final long serialVersionUID = -7727380783336743135L;
  String B;
  TplActionSet C;
  Properties A;
  
  public void clearCache()
  {
    if (this.C != null) {
      this.C.clearCache();
    }
  }
  
  public Properties getProperties()
  {
    return this.A;
  }
  
  public String getModuleId()
  {
    return this.B;
  }
  
  public void setModuleId(String paramString)
  {
    this.B = paramString;
  }
  
  public TplActionSet getActions()
  {
    return this.C;
  }
  
  public void setActions(TplActionSet paramTplActionSet)
  {
    this.C = paramTplActionSet;
  }
  
  public void invokeAction(String paramString)
  {
    if (this.C != null)
    {
      HashMap localHashMap = new HashMap();
      this.C.execTpl("app:" + paramString, localHashMap, SystemServiceContext.getInstance());
    }
  }
  
  public boolean isLoadable()
  {
    if (this.C != null)
    {
      HashMap localHashMap = new HashMap();
      this.C.execTpl("app:CheckLoadable", localHashMap, SystemServiceContext.getInstance());
    }
    return false;
  }
  
  public void invokeAction(String paramString, Map<String, Object> paramMap)
  {
    if (this.C != null) {
      this.C.execTpl("app:" + paramString, paramMap, SystemServiceContext.getInstance());
    }
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\apm\AppModule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */