package edu.thu.apm;

public abstract interface ApmConstants
{
  public static final String PATH_CUSTOM = "/_custom";
  public static final String PATH_MODULES = "/_modules";
  public static final String PREFIX_PATH_CONFIG = "/_config/";
  public static final String PREFIX_PATH_CUSTOM = "/_custom/";
  public static final String PATH_CP = "/_cp";
  public static final String POSTFIX_CP_FILE = "c";
  public static final String LOADER_ID_BASE = "base";
  public static final String LOADER_ID_APP = "app";
  public static final String LOADER_ID_WEB = "web";
  public static final String LOADER_ID_BOOTSTRAP = "bootstrap";
  public static final String LOADER_ID_CONFIG = "config";
  public static final String NS_AOP = "aop";
  public static final String NS_SEC = "sec";
  public static final String VAR_THIS = "this";
  public static final String VAR_INVOCATION = "invocation";
  public static final String VAR_USER_CONTEXT = "userContext";
  public static final String APP_ID_NAME = "app_id";
  public static final String DEFAULT_APP_ID_NAME = "default_app_id";
  public static final String CUSTOM_APP_ID_NAME = "custom_app_id";
  public static final String MODULE_NAME = "module";
  public static final String KEY_GLOBAL_APP_ID = "global.app_id";
  public static final String KEY_GLOBAL_DEFAULT_APP_ID = "global.default_app_id";
  public static final String KEY_GLOBAL_CUSTOM_APP_ID = "global.custom_app_id";
  public static final String KEY_START_BEANS_FILE = "start.beans_file";
  public static final String DEFAULT_START_BEANS_FILE = "classpath:start.beans.xml";
  public static final String WEB_BEANS_FILE = "/_config/web.beans.xml";
  public static final String WEB_ADAPTER_BEANS_FILE = "/_config/web_adapter.beans.xml";
  public static final String APP_BEANS_FILE = "/_config/app.beans.xml";
  public static final String BASE_BEANS_FILE = "/_config/base.beans.xml";
  public static final String SPRING_CONFIG_FILE = "classpath:spring_config.xml";
  public static final String CONFIG_BEANS_FILE = "/_config/config.beans.xml";
  public static final String CONFIG_ADAPTER_BEANS_FILE = "/_config/config_adapter.beans.xml";
  public static final String APP_ADAPTER_BEANS_FILE = "/_config/app_adapter.beans.xml";
  public static final String BASE_ADAPTER_BEANS_FILE = "/_config/base_adapter.beans.xml";
  public static final String APP_AOP_FILE = "/_config/app.aop.xml";
  public static final String APP_SECURE_FILE = "/_config/app.sec.xml";
  public static final String SPRING_BEANS_FILE = "classpath:spring_beans.xml";
  public static final String APP_MANAGE_FILE = "/_config/app.manage.xml";
  public static final String CONFIG_PROPERTIES_FILE = "/_config/config.properties";
  public static final String METHOD_START = "start";
  public static final String METHOD_INIT = "init";
  public static final String METHOD_STOP = "stop";
  public static final String METHOD_INIT_USER_CONTEXT = "initUserContext";
  public static final String APP_NS_NAME = "app";
  public static final String CHECK_LOADABLE_NAME = "CheckLoadable";
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\apm\ApmConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */