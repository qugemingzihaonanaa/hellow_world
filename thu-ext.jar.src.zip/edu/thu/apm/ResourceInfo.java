package edu.thu.apm;

import java.io.Serializable;

public class ResourceInfo
  implements Serializable
{
  private static final long serialVersionUID = -6685509435251714958L;
  String A;
  String C;
  String D;
  String B;
  
  public String getStdPath()
  {
    return this.B;
  }
  
  public void setStdPath(String paramString)
  {
    this.B = paramString;
  }
  
  public String getPostfix()
  {
    return this.D;
  }
  
  public void setPostfix(String paramString)
  {
    this.D = paramString;
  }
  
  public String getName()
  {
    return this.C;
  }
  
  public void setName(String paramString)
  {
    this.C = paramString;
  }
  
  public String getVirtualPath()
  {
    return this.A;
  }
  
  public void setVirtualPath(String paramString)
  {
    this.A = paramString;
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\apm\ResourceInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */