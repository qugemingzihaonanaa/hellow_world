package edu.thu.apm;

import edu.thu.config.AppConfig;
import edu.thu.core.IResource;
import edu.thu.core.IResourceLoaderEx;
import edu.thu.core.impl.ClassPathResource;
import edu.thu.core.impl.FileResource;
import edu.thu.global.exceptions.Exceptions;
import edu.thu.io.util.IoUtils;
import edu.thu.java.DefaultRuntime;
import edu.thu.lang.IVariant;
import edu.thu.lang.exceptions.StdException;
import edu.thu.tools.lib.TplActionSet;
import edu.thu.util.UrlUtils;
import edu.thu.vfs.FileProcessor;
import edu.thu.vfs.FileSystem;
import edu.thu.vfs.IFile;
import edu.thu.vfs.spi.local.LocalFile;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppResourceLoader
  implements IResourceLoaderEx
{
  static final Logger logger = LoggerFactory.getLogger(AppResourceLoader.class);
  static final int code = new DefaultRuntime().init();
  static AppResourceLoader _instance = new AppResourceLoader();
  List<String> moduleIds;
  Map<String, AppModule> modules = new LinkedHashMap();
  AppModule defaultModule;
  String globalAppId = AppConfig.var("global.app_id").stripedStringValue();
  String defaultAppId = AppConfig.var("global.default_app_id").stripedStringValue();
  String customAppId = AppConfig.var("global.custom_app_id").stripedStringValue();
  
  public static AppResourceLoader getInstance()
  {
    return _instance;
  }
  
  public static void registerInstance(AppResourceLoader paramAppResourceLoader)
  {
    _instance = paramAppResourceLoader;
  }
  
  public void clearCache()
  {
    if (this.defaultModule != null) {
      this.defaultModule.clearCache();
    }
    Iterator localIterator = this.modules.values().iterator();
    while (localIterator.hasNext())
    {
      AppModule localAppModule = (AppModule)localIterator.next();
      localAppModule.clearCache();
    }
  }
  
  protected AppModule getModule(String paramString)
  {
    return (AppModule)this.modules.get(paramString);
  }
  
  protected void addModule(AppModule paramAppModule)
  {
    this.modules.put(paramAppModule.getModuleId(), paramAppModule);
  }
  
  public String getAppId()
  {
    return this.globalAppId;
  }
  
  public String getDefaultAppId()
  {
    return this.defaultAppId;
  }
  
  public String getCustomAppId()
  {
    return this.customAppId;
  }
  
  public boolean isUseModuleActionCache()
  {
    return AppConfig.isUseCache("module_action.");
  }
  
  public void setModuleIds(List<String> paramList)
  {
    this.moduleIds = paramList;
  }
  
  public boolean existsResource(String paramString)
  {
    return getResource(paramString).exists();
  }
  
  public boolean isCustomizedResource(String paramString)
  {
    return paramString.startsWith("/_custom/");
  }
  
  File getRootFile()
  {
    return getSysFile("/");
  }
  
  public File getTempDir(String paramString)
  {
    String str = AppConfig.var("app.temp_dir").stripedStringValue();
    if (str != null) {
      return new File(str, paramString);
    }
    return new File(getSysFile("/_temp"), paramString);
  }
  
  public IFile getVFile(String paramString)
  {
    File localFile = getSysFile(paramString);
    return new LocalFile(localFile);
  }
  
  protected File doGetSysFile(String paramString)
  {
    paramString = UrlUtils.normalize(paramString);
    return new File(AppConfig.getRootPath(), paramString);
  }
  
  public File getSysFile(String paramString)
  {
    return getResource(paramString).getLocalFile();
  }
  
  public void discoverModules()
  {
    loadDefaultModule();
    if (this.moduleIds == null) {
      this.moduleIds = AppConfig.var("global.load_module_ids").listValue();
    }
    Object localObject2;
    Object localObject1;
    if (this.moduleIds != null)
    {
      logger.info("apm.use_global_module_ids:{}", this.moduleIds);
      localObject2 = this.moduleIds.iterator();
      while (((Iterator)localObject2).hasNext())
      {
        localObject1 = (String)((Iterator)localObject2).next();
        _loadModule((String)localObject1);
      }
    }
    else
    {
      localObject1 = AppConfig.var("global.ignore_module_ids").listValue();
      localObject2 = getDefaultModuleIds();
      Iterator localIterator = ((List)localObject2).iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        if ((localObject1 != null) && (((List)localObject1).contains(str))) {
          logger.info("apm.ignore_module::{}", str);
        } else {
          _loadModule(str);
        }
      }
    }
  }
  
  protected List<String> getDefaultModuleIds()
  {
    ArrayList localArrayList = new ArrayList();
    File localFile1 = getRootFile();
    File[] arrayOfFile1 = localFile1.listFiles();
    if (arrayOfFile1 != null)
    {
      File[] arrayOfFile2;
      int j = (arrayOfFile2 = arrayOfFile1).length;
      for (int i = 0; i < j; i++)
      {
        File localFile2 = arrayOfFile2[i];
        if ((localFile2.isDirectory()) && (!localFile2.getName().startsWith("_")) && (!localFile2.getName().startsWith(".")))
        {
          File localFile3 = new File(localFile2, "/_config/");
          if (localFile3.exists()) {
            localArrayList.add(localFile2.getName());
          }
        }
      }
    }
    return localArrayList;
  }
  
  public String getModulePath(String paramString1, String paramString2)
  {
    return "/" + paramString1 + paramString2;
  }
  
  IResource getModuleResource(String paramString1, String paramString2)
  {
    return getResource(getModulePath(paramString1, paramString2));
  }
  
  IResource getCustomizableModuleResource(String paramString1, String paramString2)
  {
    return getCustomizableResource(getModulePath(paramString1, paramString2));
  }
  
  boolean existsModuleResourcex(String paramString1, String paramString2)
  {
    return getModuleResource(paramString1, paramString2).exists();
  }
  
  protected void loadDefaultModule()
  {
    IResource localIResource = getResource("/_config/app.manage.xml");
    AppModule localAppModule = new AppModule();
    localAppModule.setModuleId("");
    if (localIResource.exists())
    {
      TplActionSet localTplActionSet = new TplActionSet();
      localTplActionSet.setNamespace("app");
      localTplActionSet.setUrl("/_config/app.manage.xml");
      localTplActionSet.setUseCache(isUseModuleActionCache());
      localTplActionSet.init();
      localAppModule.setActions(localTplActionSet);
    }
    this.defaultModule = localAppModule;
  }
  
  protected void _loadModule(String paramString)
  {
    logger.info("apm.load_module::{}", paramString);
    IResource localIResource = getModuleResource(paramString, "/_config/app.manage.xml");
    AppModule localAppModule = new AppModule();
    localAppModule.setModuleId(paramString);
    if (localIResource.exists())
    {
      TplActionSet localTplActionSet = new TplActionSet();
      localTplActionSet.setNamespace("app");
      localTplActionSet.setUrl(getModulePath(paramString, "/_config/app.manage.xml"));
      localTplActionSet.setUseCache(isUseModuleActionCache());
      localTplActionSet.init();
      localAppModule.setActions(localTplActionSet);
    }
    this.modules.put(localAppModule.getModuleId(), localAppModule);
  }
  
  public List<String> getAppAopFilePath()
  {
    return getStdOrModuleFilePathList("/_config/app.aop.xml");
  }
  
  public List<String> getAppSecureFilePath()
  {
    return getStdOrModuleFilePathList("/_config/app.sec.xml");
  }
  
  public List<String> getConfigBeansFilePath()
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add("classpath:spring_config.xml");
    localArrayList.addAll(getStdOrModuleFilePathList("/_config/config.beans.xml"));
    String str = findStdCustomizablePath("/_config/config_adapter.beans.xml");
    if (existsResource(str)) {
      localArrayList.add(str);
    }
    return localArrayList;
  }
  
  public List<String> getBaseBeansFilePath()
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add("classpath:spring_beans.xml");
    localArrayList.addAll(getStdOrModuleFilePathList("/_config/base.beans.xml"));
    String str = findStdCustomizablePath("/_config/base_adapter.beans.xml");
    if (existsResource(str)) {
      localArrayList.add(str);
    }
    return localArrayList;
  }
  
  public List<String> getAppBeansFilePath()
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.addAll(getStdOrModuleFilePathList("/_config/app.beans.xml"));
    String str = findStdCustomizablePath("/_config/app_adapter.beans.xml");
    if (existsResource(str)) {
      localArrayList.add(str);
    }
    return localArrayList;
  }
  
  public String getStdOrModuleFilePath(String paramString)
  {
    if (existsResource(paramString)) {
      return paramString;
    }
    Iterator localIterator = this.modules.values().iterator();
    while (localIterator.hasNext())
    {
      AppModule localAppModule = (AppModule)localIterator.next();
      IResource localIResource = getModuleResource(localAppModule.getModuleId(), paramString);
      if (localIResource.exists())
      {
        String str = localIResource.getStdPath();
        return str;
      }
    }
    return paramString;
  }
  
  public List<String> getStdOrModuleFilePathList(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    if (existsResource(paramString)) {
      localArrayList.add(paramString);
    }
    Iterator localIterator = this.modules.values().iterator();
    while (localIterator.hasNext())
    {
      AppModule localAppModule = (AppModule)localIterator.next();
      IResource localIResource = getModuleResource(localAppModule.getModuleId(), paramString);
      if (localIResource.exists())
      {
        String str = localIResource.getStdPath();
        localArrayList.add(str);
      }
    }
    return localArrayList;
  }
  
  public List<IResource> getCustomizableStdOrModuleResources(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    String str = A(paramString);
    if ((str != null) && (existsResource(str))) {
      localArrayList.add(getResource(paramString, str));
    }
    Iterator localIterator = this.modules.values().iterator();
    while (localIterator.hasNext())
    {
      AppModule localAppModule = (AppModule)localIterator.next();
      IResource localIResource = getCustomizableModuleResource(localAppModule.getModuleId(), paramString);
      if (localIResource.exists()) {
        localArrayList.add(localIResource);
      }
    }
    return localArrayList;
  }
  
  public List<String> getWebBeansFilePath()
  {
    List localList = getStdOrModuleFilePathList("/_config/web.beans.xml");
    String str = findStdCustomizablePath("/_config/web_adapter.beans.xml");
    if (existsResource(str)) {
      localList.add(str);
    }
    return localList;
  }
  
  void invokeModuleAction(String paramString)
  {
    if (this.defaultModule != null) {
      this.defaultModule.invokeAction(paramString);
    }
    Iterator localIterator = this.modules.values().iterator();
    while (localIterator.hasNext())
    {
      AppModule localAppModule = (AppModule)localIterator.next();
      localAppModule.invokeAction(paramString);
    }
  }
  
  public void invokeModuleAction(String paramString, Map<String, Object> paramMap)
  {
    if (this.defaultModule != null) {
      this.defaultModule.invokeAction(paramString, paramMap);
    }
    Iterator localIterator = this.modules.values().iterator();
    while (localIterator.hasNext())
    {
      AppModule localAppModule = (AppModule)localIterator.next();
      localAppModule.invokeAction(paramString, paramMap);
    }
  }
  
  public String getModuleVar(String paramString1, String paramString2)
  {
    return (String)AppConfig.getVar("module." + paramString1 + "." + paramString2);
  }
  
  public String findModuleCustomizablePath(String paramString)
  {
    if (paramString.startsWith("classpath:")) {
      return paramString;
    }
    String str = _findModuleCustomizablePath(paramString);
    if ((logger.isInfoEnabled()) && (str != null) && (str != paramString)) {
      logger.info("apm.CAN_path_mapping::" + paramString + "-->" + str);
    }
    if (str == null) {
      str = paramString;
    }
    return str;
  }
  
  public String findStdCustomizablePath(String paramString)
  {
    String str = A(paramString);
    if ((logger.isInfoEnabled()) && (str != null)) {
      logger.info("apm.CAN_path_mapping::" + paramString + "-->" + str);
    }
    if (str == null) {
      str = paramString;
    }
    return str;
  }
  
  protected boolean matchPostfix(String paramString1, String paramString2)
  {
    if (paramString2 == null) {
      return true;
    }
    return paramString1.endsWith(paramString2);
  }
  
  protected void collectResources(String paramString1, String paramString2, String paramString3, Map<String, IResource> paramMap)
  {
    collectResources(getSysFile(paramString2), paramString1, paramString2, paramString3, paramMap);
  }
  
  protected void collectResources(File paramFile, final String paramString1, final String paramString2, final String paramString3, final Map<String, IResource> paramMap)
  {
    final LocalFile localLocalFile = new LocalFile(paramFile);
    FileSystem.forEachSub(localLocalFile, null, new FileProcessor()
    {
      public boolean processFile(IFile paramAnonymousIFile)
      {
        if (paramAnonymousIFile.getName().endsWith(paramString3 + ".remove"))
        {
          paramMap.remove(paramString1 + getRelativePath(localLocalFile, paramAnonymousIFile));
          return false;
        }
        if (!AppResourceLoader.this.matchPostfix(paramAnonymousIFile.getName(), paramString3)) {
          return false;
        }
        String str = getRelativePath(localLocalFile, paramAnonymousIFile);
        File localFile = ((LocalFile)paramAnonymousIFile).getLocalFile();
        paramMap.put(paramString1 + str, new FileResource(paramString1 + str, paramString2 + str, localFile));
        return false;
      }
    });
  }
  
  public Map<String, IResource> getAllStdCustomizableResources(String paramString1, String paramString2)
  {
    if (paramString1.endsWith("/")) {
      paramString1 = paramString1.substring(0, paramString1.length() - 1);
    }
    TreeMap localTreeMap = new TreeMap();
    String str1 = getAppId();
    String str2 = getDefaultAppId();
    String str3 = getCustomAppId();
    collectResources(paramString1, paramString1, paramString2, localTreeMap);
    collectResources(paramString1, "/_custom/default" + paramString1, paramString2, localTreeMap);
    if (str2 != null) {
      collectResources(paramString1, "/_custom/" + str2 + paramString1, paramString2, localTreeMap);
    }
    if (str1 != null) {
      collectResources(paramString1, "/_custom/" + str1 + paramString1, paramString2, localTreeMap);
    }
    if (str3 != null) {
      collectResources(paramString1, "/_custom/" + str3 + paramString1, paramString2, localTreeMap);
    }
    return localTreeMap;
  }
  
  public List<IResource> getResourceChildren(String paramString1, String paramString2)
  {
    File localFile1 = getSysFile(paramString1);
    File[] arrayOfFile1 = localFile1.listFiles();
    if (arrayOfFile1 == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(arrayOfFile1.length);
    File[] arrayOfFile2;
    int j = (arrayOfFile2 = arrayOfFile1).length;
    for (int i = 0; i < j; i++)
    {
      File localFile2 = arrayOfFile2[i];
      if (matchPostfix(localFile2.getName(), paramString2))
      {
        String str = paramString1 + "/" + localFile2.getName();
        localArrayList.add(getResource(str));
      }
    }
    return localArrayList;
  }
  
  public List<IResource> getCustomizableResourceChildren(String paramString1, String paramString2)
  {
    File localFile1 = getSysFile(paramString1);
    File[] arrayOfFile1 = localFile1.listFiles();
    if (arrayOfFile1 == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList(arrayOfFile1.length);
    File[] arrayOfFile2;
    int j = (arrayOfFile2 = arrayOfFile1).length;
    for (int i = 0; i < j; i++)
    {
      File localFile2 = arrayOfFile2[i];
      if (matchPostfix(localFile2.getName(), paramString2))
      {
        String str = paramString1 + "/" + localFile2.getName();
        localArrayList.add(getCustomizableResource(str));
      }
    }
    return localArrayList;
  }
  
  List<ResourceInfo> getResourceInfos(Collection<IResource> paramCollection, String paramString)
  {
    ArrayList localArrayList = new ArrayList(paramCollection.size());
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
    {
      IResource localIResource = (IResource)localIterator.next();
      String str1 = localIResource.getPath();
      String str2 = UrlUtils.getFullName(str1);
      if (paramString != null) {
        str2 = str2.substring(0, str2.length() - paramString.length());
      }
      ResourceInfo localResourceInfo = new ResourceInfo();
      localResourceInfo.setName(str2);
      localResourceInfo.setPostfix(paramString);
      localResourceInfo.setVirtualPath(str1);
      localResourceInfo.setStdPath(localIResource.getStdPath());
      localArrayList.add(localResourceInfo);
    }
    return localArrayList;
  }
  
  public List<ResourceInfo> getResourceChildrenInfos(String paramString1, String paramString2)
  {
    return getResourceInfos(getResourceChildren(paramString1, paramString2), paramString2);
  }
  
  public Map<String, IResource> getAllCustomizableResources(String paramString1, String paramString2)
  {
    if (paramString1.endsWith("/")) {
      paramString1 = paramString1.substring(0, paramString1.length() - 1);
    }
    Map localMap = getAllStdCustomizableResources(paramString1, paramString2);
    Iterator localIterator = this.modules.values().iterator();
    while (localIterator.hasNext())
    {
      AppModule localAppModule = (AppModule)localIterator.next();
      String str1 = getModuleVar(localAppModule.getModuleId(), "app_id");
      String str2 = getModuleVar(localAppModule.getModuleId(), "default_app_id");
      String str3 = getModuleVar(localAppModule.getModuleId(), "custom_app_id");
      if (str1 == null) {
        str1 = this.globalAppId;
      }
      if (str2 == null) {
        str2 = this.defaultAppId;
      }
      if (str3 == null) {
        str3 = this.customAppId;
      }
      collectResources(paramString1, getModulePath(localAppModule.getModuleId(), paramString1), paramString2, localMap);
      if (str2 != null) {
        collectResources(paramString1, "/_custom/" + str2 + "/" + localAppModule.getModuleId() + paramString1, paramString2, localMap);
      }
      if (str1 != null) {
        collectResources(paramString1, "/_custom/" + str1 + "/" + localAppModule.getModuleId() + paramString1, paramString2, localMap);
      }
      if (str3 != null) {
        collectResources(paramString1, "/_custom/" + str3 + "/" + localAppModule.getModuleId() + paramString1, paramString2, localMap);
      }
    }
    return localMap;
  }
  
  public List<ResourceInfo> getAllCustomizableResInfos(String paramString1, String paramString2)
  {
    Map localMap = getAllCustomizableResources(paramString1, paramString2);
    return getResourceInfos(localMap.values(), paramString2);
  }
  
  public List<String> getStdPossiblePaths(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    List localList = getStdPossibleResources(paramString);
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      IResource localIResource = (IResource)localIterator.next();
      localArrayList.add(localIResource.getPath());
    }
    return localArrayList;
  }
  
  public List<String> getPossiblePaths(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    List localList = getPossibleResources(paramString);
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      IResource localIResource = (IResource)localIterator.next();
      localArrayList.add(localIResource.getPath());
    }
    return localArrayList;
  }
  
  public List<IResource> getStdPossibleResources(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    String str1 = getAppId();
    String str2 = getDefaultAppId();
    String str3 = getCustomAppId();
    if (str3 != null) {
      localArrayList.add(getResource(paramString, "/_custom/" + str3 + paramString));
    }
    if (str1 != null) {
      localArrayList.add(getResource(paramString, "/_custom/" + str1 + paramString));
    }
    if (str2 != null) {
      localArrayList.add(getResource(paramString, "/_custom/" + str2 + paramString));
    }
    localArrayList.add(getResource(paramString, "/_custom/default" + paramString));
    localArrayList.add(getResource(paramString, paramString));
    return localArrayList;
  }
  
  public List<IResource> getPossibleResources(String paramString)
  {
    List localList = getStdPossibleResources(paramString);
    Iterator localIterator = this.modules.values().iterator();
    while (localIterator.hasNext())
    {
      AppModule localAppModule = (AppModule)localIterator.next();
      String str1 = getModuleVar(localAppModule.getModuleId(), "app_id");
      String str2 = getModuleVar(localAppModule.getModuleId(), "default_app_id");
      String str3 = getModuleVar(localAppModule.getModuleId(), "custom_app_id");
      if (str1 == null) {
        str1 = this.globalAppId;
      }
      if (str2 == null) {
        str2 = this.defaultAppId;
      }
      if (str3 == null) {
        str3 = this.customAppId;
      }
      if (str3 != null) {
        localList.add(getResource(paramString, "/_custom/" + str3 + "/" + localAppModule.getModuleId() + paramString));
      }
      if (str1 != null) {
        localList.add(getResource(paramString, "/_custom/" + str1 + "/" + localAppModule.getModuleId() + paramString));
      }
      if (str2 != null) {
        localList.add(getResource(paramString, "/_custom/" + str2 + "/" + localAppModule.getModuleId() + paramString));
      }
      localList.add(getResource(paramString, getModulePath(localAppModule.getModuleId(), paramString)));
    }
    return localList;
  }
  
  public Map<String, String> getCustomizablePathsByModule(String paramString)
  {
    TreeMap localTreeMap = new TreeMap();
    Iterator localIterator = this.modules.values().iterator();
    while (localIterator.hasNext())
    {
      AppModule localAppModule = (AppModule)localIterator.next();
      String str1 = getModuleVar(localAppModule.getModuleId(), "app_id");
      String str2 = getModuleVar(localAppModule.getModuleId(), "default_app_id");
      String str3 = getModuleVar(localAppModule.getModuleId(), "custom_app_id");
      if (str1 == null) {
        str1 = this.globalAppId;
      }
      if (str2 == null) {
        str2 = this.defaultAppId;
      }
      if (str3 == null) {
        str3 = this.customAppId;
      }
      if (str3 != null)
      {
        str4 = "/_custom/" + str3 + "/" + localAppModule.getModuleId() + paramString;
        if (existsResource(str4))
        {
          localTreeMap.put(localAppModule.getModuleId(), str4);
          continue;
        }
      }
      if (str1 != null)
      {
        str4 = "/_custom/" + str1 + "/" + localAppModule.getModuleId() + paramString;
        if (existsResource(str4))
        {
          localTreeMap.put(localAppModule.getModuleId(), str4);
          continue;
        }
      }
      if (str2 != null)
      {
        str4 = "/_custom/" + str2 + "/" + localAppModule.getModuleId() + paramString;
        if (existsResource(str4))
        {
          localTreeMap.put(localAppModule.getModuleId(), str4);
          continue;
        }
      }
      String str4 = getModulePath(localAppModule.getModuleId(), paramString);
      if (existsResource(str4)) {
        localTreeMap.put(localAppModule.getModuleId(), str4);
      }
    }
    return localTreeMap;
  }
  
  private String A(String paramString)
  {
    if (paramString.startsWith("/_custom/")) {
      return paramString;
    }
    String str1 = getAppId();
    String str2 = getDefaultAppId();
    String str3 = getCustomAppId();
    String str4 = paramString;
    if ((str3 != null) && (str3.length() > 0))
    {
      str4 = "/_custom/" + str3 + paramString;
      if (existsResource(str4)) {
        return str4;
      }
    }
    if ((str1 != null) && (str1.length() > 0))
    {
      str4 = "/_custom/" + str1 + paramString;
      if (existsResource(str4)) {
        return str4;
      }
    }
    if ((str2 != null) && (str2.length() > 0))
    {
      str4 = "/_custom/" + str2 + paramString;
      if (existsResource(str4)) {
        return str4;
      }
    }
    str4 = "/_custom/default" + paramString;
    if (existsResource(str4)) {
      return str4;
    }
    if (existsResource(paramString)) {
      return paramString;
    }
    return null;
  }
  
  String _findModuleCustomizablePath(String paramString)
  {
    String str1 = A(paramString);
    if (str1 != null) {
      return str1;
    }
    if (!paramString.startsWith("/_config/")) {
      return null;
    }
    Iterator localIterator = this.modules.values().iterator();
    while (localIterator.hasNext())
    {
      AppModule localAppModule = (AppModule)localIterator.next();
      String str2 = getModuleVar(localAppModule.getModuleId(), "app_id");
      String str3 = getModuleVar(localAppModule.getModuleId(), "default_app_id");
      String str4 = getModuleVar(localAppModule.getModuleId(), "custom_app_id");
      if (str2 == null) {
        str2 = this.globalAppId;
      }
      if (str3 == null) {
        str3 = this.defaultAppId;
      }
      if (str4 == null) {
        str4 = this.customAppId;
      }
      if (str4 != null)
      {
        str1 = "/_custom/" + str4 + "/" + localAppModule.getModuleId() + paramString;
        if (existsResource(str1)) {
          return str1;
        }
      }
      if (str2 != null)
      {
        str1 = "/_custom/" + str2 + "/" + localAppModule.getModuleId() + paramString;
        if (existsResource(str1)) {
          return str1;
        }
      }
      if (str3 != null)
      {
        str1 = "/_custom/" + str3 + "/" + localAppModule.getModuleId() + paramString;
        if (existsResource(str1)) {
          return str1;
        }
      }
      str1 = getModulePath(localAppModule.getModuleId(), paramString);
      if (existsResource(str1)) {
        return str1;
      }
    }
    return null;
  }
  
  public IResource getCustomizableResource(String paramString)
  {
    String str = findModuleCustomizablePath(paramString);
    return getResource(paramString, str);
  }
  
  public IResource getCpResource(String paramString)
  {
    return getResource("/_cp" + paramString + "c");
  }
  
  public Object loadCpObject(String paramString)
  {
    IResource localIResource = getCpResource(paramString);
    if (!localIResource.exists()) {
      return null;
    }
    InputStream localInputStream = null;
    try
    {
      localInputStream = localIResource.getInputStream();
      Object localObject2 = IoUtils.deserialize(localInputStream);
      return localObject2;
    }
    catch (Exception localException)
    {
      throw Exceptions.source(localException);
    }
    finally
    {
      IoUtils.safeClose(localInputStream);
    }
  }
  
  protected void checkValidPath(String paramString)
  {
    if ((paramString.indexOf("../") >= 0) || (paramString.indexOf("..\\") >= 0) || (paramString.indexOf('?') >= 0)) {
      throw new StdException("core.err_invalid_resource_path").param(paramString);
    }
  }
  
  public IResource getResource(String paramString1, String paramString2)
  {
    if (paramString2.startsWith("classpath:")) {
      return new ClassPathResource(paramString2, paramString2.substring("classpath:".length()));
    }
    checkValidPath(paramString2);
    if (paramString2.startsWith("ext:"))
    {
      localObject = UrlUtils.normalize(paramString2.substring("ext:".length()));
      File localFile1 = new File(AppConfig.getRootPath(), "../ext");
      File localFile2 = new File(localFile1, (String)localObject);
      return new FileResource(paramString1, paramString2, localFile2);
    }
    Object localObject = doGetSysFile(paramString2);
    return new FileResource(paramString1, paramString2, (File)localObject);
  }
  
  public IResource getResource(String paramString)
  {
    return getResource(paramString, paramString);
  }
  
  public void start()
  {
    discoverModules();
    invokeModuleAction("start");
  }
  
  public void init()
  {
    invokeModuleAction("init");
  }
  
  public void stop()
  {
    invokeModuleAction("stop");
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\apm\AppResourceLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */