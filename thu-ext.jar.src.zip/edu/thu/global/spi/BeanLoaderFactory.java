package edu.thu.global.spi;

import edu.thu.service.IServiceContext;
import edu.thu.service.bean.IBeanLoader;

public class BeanLoaderFactory
  extends SimpleFactory
{
  private static final long serialVersionUID = 6698749265210937536L;
  IBeanLoader loader;
  
  public void setBeanLoader(IBeanLoader paramIBeanLoader)
  {
    this.loader = paramIBeanLoader;
  }
  
  public Object getInstance(String paramString, Object paramObject)
  {
    Object localObject = super.getInstance(paramString, paramObject);
    if (localObject != null) {
      return localObject;
    }
    if (this.loader == null) {
      return null;
    }
    if ((paramObject instanceof IServiceContext)) {
      return this.loader.getBean(paramString);
    }
    return this.loader.getBean(paramString);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\global\spi\BeanLoaderFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */