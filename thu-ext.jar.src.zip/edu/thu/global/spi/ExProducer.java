package edu.thu.global.spi;

import edu.thu.global.IProducer;
import java.util.Map;

public class ExProducer
  implements IProducer
{
  Map exProducers;
  IProducer defaultProducer;
  
  public void setExProducers(Map paramMap)
  {
    this.exProducers = paramMap;
  }
  
  public void setDefaultProducer(IProducer paramIProducer)
  {
    this.defaultProducer = paramIProducer;
  }
  
  IProducer getProducer(String paramString)
  {
    if (this.exProducers == null) {
      return this.defaultProducer;
    }
    int i = paramString.indexOf('.');
    if (i < 0) {
      return this.defaultProducer;
    }
    String str = paramString.substring(0, i);
    IProducer localIProducer = (IProducer)this.exProducers.get(str);
    if (localIProducer == null) {
      localIProducer = this.defaultProducer;
    }
    return localIProducer;
  }
  
  public Object getInstance(String paramString, Object paramObject)
  {
    return getProducer(paramString).getInstance(paramString, paramObject);
  }
}


/* Location:              D:\ymx\workspace\th_demo\th_platform\defaultroot\WEB-INF\lib\thu-ext.jar!\edu\thu\global\spi\ExProducer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */